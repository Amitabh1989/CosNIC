======================================
Ethernet Controller Automation Package
======================================

This Python package includes test scripts (which work as standalone as well as
STAT test scripts) and libraries that test scripts depend on.

Note that libraries can be used as independent modules to interact with local
amd remote systems through the interpreter shell and/or standalone Python
scripts.

Will use acronym "ECA" for Ethernet Controller Automation.

How To Install
--------------

Linux
=====
First of all, you need to download and install pip (you can skip this if
your system has one already)::

    $ wget https://bootstrap.pypa.io/get-pip.py
    $ python get-pip.py

.. warning::

   Installing python packages requires root privileges

The next step is to install the ECA package.

If you install from the QA git repository::

    $ pip install git+ssh://svcccxswgit@git-ccxsw.irv.broadcom.com/qa-testscripts-controller

.. note::

   To download from the QA git repository, you must have access to the
   repository as well as git client. Please contact IT for the git repository
   access.

If you install from the development (and unstable) repository::

    $ pip install http://auto-devel-gitlab.swdvt.lab.irv.broadcom.com/controller/controller/repository/archive.zip

Windows
=======
I strongly recommend to install ActivePython from
http://www.activestate.com/activepython. This will take care of installing
pip and some Windows specific Python packages as well.

Once ActivePython is installed, you can install the ECA package using pip by
following the Linux steps.

setuptools
==========
If you cannot use "pip" for some reasons, you still can install the package
using setuptools. Most Python has setuptools already, so you do not need to
install separate packages to use setuptools.

1. Download the ECA package
2. Extract the package
3. cd to the directory where package was extracted at step #2
4. Run command::

   > python setup.py install

.. note::

   If you are using any other types of Python i.e.) IronPython you can run
   setup.py using the interpreter which you want to install the package on.

.. note::

   If you install the package to STAT using IronPython, you should comment out
   "scapy" from the "install_requires" in controller/setup.py. For example::

       install_requires = [
           'rpyc>=3.2.3',
           'scapy>=2.3.1',
       ]

   to::

       install_requires = [
           'rpyc>=3.2.3',
           # 'scapy>=2.3.1',
       ]

   so the "scapy" package does not get installed on STAT.

Verify the Installation
-----------------------
You can verify whether the ECA package was successfully installed by importing
the package and check its version.

>>> import controller
>>> controller.get_version()
'0.2.1'

API Documentation
-----------------
API documentation is available at :ref:`lib.index`