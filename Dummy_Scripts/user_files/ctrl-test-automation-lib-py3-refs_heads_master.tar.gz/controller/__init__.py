__version__ = '2.2.9a63'
__min_compatible_version__ = '2.2.9a63'
__max_compatible_version__ = __version__


def get_version(*args, **kwargs):
    # Create a funciton to return a translated version number as PEP 386
    # For now, return the current version
    return __version__
