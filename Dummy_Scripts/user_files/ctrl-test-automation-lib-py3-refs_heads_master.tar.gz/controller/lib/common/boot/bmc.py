"""
:mod:`bmc` .
=========================================

.. module:: controller.lib.common.boot.bmc
.. moduleauthor:: Uma sankar Donepudi <umasankar.donepudi@broadcom.com>

This is a python module for BMC management commands. Listed below are the
functionalities provided by this module:

1. exec_cmd function
2. ping_analysis

This Module can handle HP iLO, Dell iDRAC, Facebook BMC, Lenovo IMM and Huawei iBMC basic functions.
This module can be used to directly to talk with BMC or you can use the method currently used(STAT-Client-BMC/Host).
It depends on your netowrk configuration. If the STAT Machine and test machines are in single network
we can use direct method. If the STAT machine can't access the private network better use a client as a mediator.

Configuration to run NCSI Test Cases:

BMC Test cases needed special treatment since it gives some challenges for regular STAT rpyc framework. 
We tried to handle all OEM BMC CLI interface in a generic way as much as possible. 

Challenges:
1. Private Network. Most of the NCSI test cases needs private network since it is not simple Back to
    back configuration. It needs BMC, SUT, and Client in a private network. Private network recommended
    since ping flood is a common test. So we configure a private network and assign BMC, Host and Client
    with private IPv4 and IPv6 Addresses. Please follow the config file for NCSI to provide the required inputs.
2. Non STAT capable Host: for Facebook kernels, it is not possible to install Controller package in Host
    and control with STAT. To overcome this, we use Client as SUT. Yes you heard it. We use a Client which
    is having Controller installed and running, and provide these details in Config file as SUT. Our Host
    and BMC details we will provide as individual values in config. So our STAT machine talks to Client which
    creates SSH Sessions(Paramiko) to BMC and Host through private network. All you have to make sure is Private
    IP configured in Client, Host and BMC are accessible to each other.

"""
import re
import logging
import paramiko

log = logging.getLogger(__name__)


class bmc(object):
    def __init__(self, bmc_ip, bmc_username, bmc_password):
        self.bmc_ip = bmc_ip
        self.bmc_username = bmc_username
        self.bmc_password = bmc_password

    def exec_cmd(self, cmd, int_cmd=None):
        ssh_connection = paramiko.SSHClient()
        ssh_connection.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        logging.info('Connecting to the SSH Client')
        # look_for_keys should be False for HPE latest servers. If any issues issues
        # seen for other OEMs we need handle this specific to OEMs
        ssh_connection.connect(self.bmc_ip, username=self.bmc_username,
                               password=self.bmc_password, look_for_keys=False)
        logging.info('Executing the command %s' % cmd)
        stdin, stdout, stderr = ssh_connection.exec_command(cmd)
        if int_cmd:
            int_input = int_cmd + '\n'
            stdin.write(int_input)
        output = stdout.read()
        logging.info('command result is %s' % output)
        ssh_connection.close()
        return output

    @staticmethod
    def ping_analysis(output):
        match = re.search(r'([\d]*\.[\d]*)/([\d]*\.[\d]*)/([\d]*\.[\d]*)/([\d]*\.[\d]*)',
                          str(output))
        ping_min = match.group(1)
        ping_avg = match.group(2)
        ping_max = match.group(3)
        log.info('RTT minimum val is %s, average value is %s and maximum value is %s'
                 % (ping_min, ping_avg, ping_max))
        
        tx_pkt = re.search(r'(\d*) packets transmitted', str(output))
        tx_packets = tx_pkt.group(1)
        rx_pkt = re.search(r'(\d*) received', str(output))
        rx_packets = rx_pkt.group(1)
        pkt_loss = re.search(r'(\d*)% packet loss', str(output))
        loss_percentage = pkt_loss.group(1)
        log.info('Packets Sent: %s, Packets Received: %s and Packet Loss Percentage: %s'
                 % (tx_packets, rx_packets, loss_percentage))
        return int(loss_percentage)


# HPE iLO access
class hpilo(bmc):
    def bmc_ping(self, dst_ip):
        cmd = 'oemHPE_ping ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ping timed out' in str(output):
            return False
        elif 'The ping was successful' in str(output):
            return True
        else:
            log.info('Unexpected output observed')
            return False

    def onetimeboot(self, boot_type='usb'):
        """
         The ONETIMEBOOT command is used to access the One-Time Boot
          onetimeboot               -- Displays the current state on the server.
          onetimeboot usb           -- Set to USB.
          onetimeboot ip            -- Set to Intelligent Provisioning.
          onetimeboot smartstartLX  -- Set to IP Smart Start Linux PE.
          onetimeboot netdev1       -- Set to Network Device 1.
          onetimeboot none          -- Disable One-Time Boot.
        Returns:
        """
        log.info(f"Setting the One time boot into {boot_type}")
        cmd = f"onetimeboot {boot_type}"
        output = self.exec_cmd(cmd)
        if "COMMAND COMPLETED" in str(output):
            log.info(f'Successfully set One time boot into {boot_type}')
            return True
        else:
            log.info(f'failed to set One time boot into {boot_type}')
            return False

    def power_control(self, action='reset'):
        """
          power          -- Displays the current server power state
          power on       -- Turns the server on
          power off      -- Turns the server off
          power off hard -- Force the server off using press and hold
          power reset    -- Reset the server
        Args:
            action: Performs the power action based on the input

        Returns: Returns True or False based on the action output
        Todo: Update this method based on the other outputs for different power actions
        """
        cmd = f"power {action}"
        output = self.exec_cmd(cmd)
        if "COMMAND COMPLETED" in str(output):
            if action == 'reset' and "Server resetting" in str(output):
                log.info('Power reset is completed Successfully')
                return True
            else:
                log.info(f'Power {action} is completed Successfully')
                return True
        else:
            return False


# Dell BCM
class idrac(bmc):
    def bmc_ping(self, dst_ip):
        cmd = 'racadm ping ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ERROR' in str(output):
            return False
        elif 'ttl' in str(output):
            return True
        else:
            log.info('Unexpected output observed')
            return False

    def bmc_ping6(self, dst_ip):
        cmd = 'racadm ping6 ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ERROR' in str(output):
            return False
        elif 'ttl' in str(output):
            return True
        else:
            log.info('Unexpected output observed')
            return False


# Lenovo IMM access
class imm(bmc):
    def bmc_ping(self, dst_ip):
        cmd = 'racadm ping ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ERROR' in str(output):
            return False
        elif 'ttl' in str(output):
            return True
        else:
            log.info('Unexpected output observed')
            return False


# TiagoPass BMC SSH access
class facebook(bmc):
    def bmc_ping(self, dst_ip):
        cmd = 'ping -c 50 ' + dst_ip
        output = self.exec_cmd(cmd)
        return self.ping_analysis(output)

    def bmc_ping6(self, dst_ip):
        cmd = 'ping6 -c 50 ' + dst_ip
        output = self.exec_cmd(cmd)
        return self.ping_analysis(output)


# Huawei iBMC Access
class ibmc(bmc):
    def bmc_ping(self, dst_ip):
        cmd = 'ping -4 -c 2 ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ttl' in str(output):
            return True
        else:
            log.info('Ping Failed')
            return False
            
    def bmc_ping6(self, dst_ip):
        cmd = 'ping -6 -c 2 ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ttl' in str(output):
            return True
        else:
            log.info('Ping Failed')
            return False
            
    def bmc_export_config(self, path):
        cmd = 'ipmcget -t config -d export -v ' + path
        output = self.exec_cmd(cmd)
        if 'Export configuration successfully' in str(output):
            return True
        elif 'ERROR' in str(output):
            return False
        else:
            log.info('Unexpected output observed')
            return False
    
    def bmc_import_config(self, path):
        cmd = 'ipmcset -t config -d import -v ' + path
        output = self.exec_cmd(cmd)
        if 'Import configuration successfully' in str(output):
            return True
        elif 'ERROR' in str(output):
            return False
        else:
            log.info('Unexpected output observed')
            return False
            
    def bmc_reset(self):
        cmd = 'ipmcset -d clearcmos'
        output = self.exec_cmd(cmd, int_cmd='yes')
        if 'Clear CMOS successfully' in str(output):
            return True
        elif 'ERROR' in str(output):
            return False
        else:
            log.info('Unexpected output observed')
            return False


# Generic Linux OS access
class generic(bmc):
    def ping(self, dst_ip):
        cmd = 'ping -c 50 ' + dst_ip
        output = self.exec_cmd(cmd)
        return self.ping_analysis(output)

    def ping6(self, dst_ip):
        cmd = 'ping6 -c 50 ' + dst_ip
        output = self.exec_cmd(cmd)
        return self.ping_analysis(output)

    def iperf_srv_start(self):
        cmd = 'iperf -s &'
        return self.exec_cmd(cmd)

    def iperf_srv_stop(self):
        cmd = 'pkill iperf'
        self.exec_cmd(cmd)
