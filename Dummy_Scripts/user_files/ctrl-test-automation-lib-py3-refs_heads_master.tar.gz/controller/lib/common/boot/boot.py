"""
:mod:`boot` .
=========================================

.. module:: controller.lib.common.OneCLI
.. moduleauthor:: Uma sankar Donepudi <umasankar.donepudi@broadcom.com>

This is a python module for OneCLI commands. Listed below are the
functionalities provided by this module:

1. get_vm_mac function
2. create_vfs function
3. create_max_vfs function
4. dmesg_check
5. qemu_check
"""

import time
import re
import logging

from controller.lib.common.shell import exe
log = logging.getLogger(__name__)

class boot(object):
    def __init__(self, **kwargs):
        self._vf_per_pf = kwargs.get('vf_per_pf')
        self._vm_per_pf = kwargs.get('vm_per_pf')
        self._pf_count =  kwargs.get('pf_count')

    def gen_vm_mac(self, mac_addr):
        test_vm_cnt = int(self._pf_count) * int(self._vm_per_pf)
        logging.info('The given mac for VMs is : %s and macs to generate are %s' % \
            (mac_addr, test_vm_cnt))
        # This will create an array with the prerequired number of spaces
        maclist = [0 for x in range (test_vm_cnt)]

        for i in range(test_vm_cnt):
            mac_tmp = "{:012X}".format(int(mac_addr, 16) + i)
            maclist[i] = ':'.join(mac_tmp[i:i+2] for i in range(0,12,2))

        logging.info('The count of MAC addresses is %s'  % len(maclist))
        return maclist

    def create_vfs(self, sut):
        exe = sut.import_module('controller.lib.common.shell.exe')
        test_vm_cnt = int(self._pf_count) * int(self._vm_per_pf)
        self.vf_pci_bdfs = []
        self.vf_count = str(test_vm_cnt)
        dut_iface_name = [iface.name for iface in sut.iface_list]

        logging.info('Initializing the VFs to zero if not initialized to zero already')

        for ifname in dut_iface_name:
            vfsfile = '/sys/class/net/' + ifname + '/device/sriov_numvfs'
            command = 'cat ' + vfsfile
            command_op = exe.block_run(command, shell=True).strip()
            if command_op != '0':
                log.info('VFs are showing non zero value. Initializing the value to 0')
                command = 'echo 0 ' + ' > ' + vfsfile
                exe.block_run(command, shell=True)
                time.sleep(2)

        for ifname in dut_iface_name:
            vfsfile = '/sys/class/net/' + ifname + '/device/sriov_numvfs'
            command = 'echo ' + self._vm_per_pf + ' > ' + vfsfile
            time.sleep(2)
            exe.block_run(command, shell=True)
            time.sleep(2)
            command = 'cat ' + vfsfile
            command_op = exe.block_run(command, shell=True).strip()

            if command_op != self._vm_per_pf:           #both of them are strings so type error didn't appear
                log.info('VFs not set')
                self.test_result = False
                return self.test_result

            logging.info('VFs set successfully on %s' % ifname)

        command = 'lspci | grep "Virtual Function"'
        command_op = exe.block_run(command, shell= True)
        lines = command_op.strip().split('\n')

        for each_line in lines:
            self.vf_pci_bdfs.append(each_line.split()[0])

        return self.vf_pci_bdfs

    def create_max_vfs(self, sut):
        exe = sut.import_module('controller.lib.common.shell.exe')
        test_vm_cnt = int(self._pf_count) * int(self._vm_per_pf)
        self.vf_pci_bdfs = []
        self.vf_count = str(test_vm_cnt)
        dut_iface_name = [iface.name for iface in sut.iface_list]

        logging.info('Initializing the VFs to zero if not initialized to zero already')

        for ifname in dut_iface_name:
            vfsfile = '/sys/class/net/' + ifname + '/device/sriov_numvfs'
            command = 'cat ' + vfsfile
            command_op = exe.block_run(command, shell=True).strip()
            if command_op != '0':
                log.info('VFs are showing non zero value. Initializing the value to 0')
                command = 'echo 0 ' + ' > ' + vfsfile
                exe.block_run(command, shell=True)
                time.sleep(2)

        for ifname in dut_iface_name:
            vfsfile = '/sys/class/net/' + ifname + '/device/sriov_numvfs'
            command = 'echo ' + self._vf_per_pf + ' > ' + vfsfile
            time.sleep(2)
            exe.block_run(command, shell=True)
            time.sleep(2)
            command = 'cat ' + vfsfile
            command_op = exe.block_run(command, shell=True).strip()
            # both of them are strings so type error didn't appear
            if command_op != self._vf_per_pf:
                log.info('VFs not set')
                self.test_result = False
                return self.test_result

            logging.info('VFs set successfully on %s' % ifname)

        command = 'lspci | grep "Virtual Function"'
        command_op = exe.block_run(command, shell= True)
        lines = command_op.strip().split('\n')

        for each_line in lines:
            self.vf_pci_bdfs.append(each_line.split()[0])

        maxvf_per_pf = int(self._vf_per_pf)

        if len(self.vf_pci_bdfs) == (maxvf_per_pf * 2):
            logging.info('Length of the Total VFs are matching with Created VFs.')
        else:
            logging.warning('Length mismatch of VFs. Needed %s and created %s VFs' % \
                (maxvf_per_pf, len(self.vf_pci_bdfs)))
            return False

        port1_vfs = self.vf_pci_bdfs[:maxvf_per_pf]
        port2_vfs = self.vf_pci_bdfs[maxvf_per_pf:]
        testvf_list1 = port1_vfs[:int(self._vm_per_pf)]
        testvf_list2 = port2_vfs[:int(self._vm_per_pf)]

        for i in testvf_list1:
            logging.info(i)

        for j in testvf_list2:
            logging.info(j)

        testvf_list = testvf_list1 + testvf_list2
        return testvf_list

    def dmesg_check(self, sut):
        exe = sut.import_module('controller.lib.common.shell.exe')
        logging.info('Checking DMESG for Timeout Errors')
        dmesgcmd = 'dmesg | grep "bnxt_en"'
        logging.info(dmesgcmd)
        cmd_op = exe.block_run(dmesgcmd, shell=True)
        lines = cmd_op.strip().split('\n')

        for line in lines:
            templine = line.split()
            if templine[5] == 'timeout':
                logging.warning('TX Timeout error occurred on %s' % templine[3])
                return False

        logging.info('No TX Timeout errors observed yet')
        return True

    def qemu_check(self, sut):
        exe = sut.import_module('controller.lib.common.shell.exe')
        logging.info('Checking for the instances of QEMU')
        command = 'ps -ef |grep "qemu"'
        qemu_op = exe.block_run(command, shell=True)
        lines = qemu_op.strip().split('\n')
        if any("qemu-system-x86_64" in qemu for qemu in lines):
            return True
        return False

    def promisc_test(self, sut, promisc):
        exe = sut.import_module('controller.lib.common.shell.exe')
        logging.info('Starting Promiscous mode toggiling on both ports')
        dut_iface_name = [iface.name for iface in sut.iface_list]
        if promisc == 'ON':
            for port in dut_iface_name:
                cmd = 'ip link set ' + port + ' promisc on'
                exe.block_run(cmd, shell=True)
                status_cmd = 'netstat -I=' + port
                output = exe.block_run(status_cmd, shell=True)
                lines = output.strip().split('\n')
                for line in lines:
                    templine = line.split()
                    if((templine[0] == port) and (templine[10] == BMPRU)):
                        logging.info('PROMISC mode is enabled on port %s' % port)
                    elif((templine[0] == port) and (templine[10] != BMPRU)):
                        logging.info('PROMISC mode is not enabled on port %s' % port)
                        return False
            return True
        elif promisc == 'TOGGLE':
            promisc_states = ['on', 'off']
            for state in promisc_states:
                for port in dut_iface_name:
                    pro_cmd= 'ip link set ' + port + ' promisc ' + state
                    exe.block_run(pro_cmd, shell=True)
                    status_cmd = 'netstat -I=' + port
                    output = exe.block_run(status_cmd, shell=True)
                    lines = output.strip().split('\n')
                    for line in lines:
                        templine = line.split()
                        if (templine[0] == port) and (templine[10] == 'BMPRU') and (state == 'on'):
                            logging.info('PROMISC mode is enabled on port %s' % port)
                            return True
                        elif templine[0] == port and templine[10] == BMPU and state == 'off':
                            logging.info('PROMISC mode is disabled on port %s' % port)
            return False
        else:
            pass


