"""
:mod:`racadm` .
=========================================

.. module:: controller.lib.common.boot.bmc
.. moduleauthor:: Uma sankar Donepudi <umasankar.donepudi@broadcom.com>

"""

import re
import time
import logging
import paramiko
from datetime import datetime

from controller.lib.core import exception

log = logging.getLogger(__name__)


class racadm(object):
    def __init__(self, bmc_ip, bmc_username, bmc_password):
        self.bmc_ip = bmc_ip
        self.bmc_username = bmc_username
        self.bmc_password = bmc_password

    def exec_cmd(self, cmd, int_cmd=None):
        ssh_connection = paramiko.SSHClient()
        ssh_connection.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        log.info('Connecting to the iDRAC SSH Client')
        ssh_connection.connect(self.bmc_ip, username=self.bmc_username, password=self.bmc_password)
        log.info('Executing the command %s' % cmd)
        stdin, stdout, stderr = ssh_connection.exec_command(cmd)
        if int_cmd:
            int_input = int_cmd + '\n'
            stdin.write(int_input)
        output = stdout.read()
        log.debug('command result is %s' % output.decode("utf-8"))
        ssh_connection.close()
        return output.decode("utf-8")

    @staticmethod
    def ping_analysis(output):
        match = re.search(r'([\d]*\.[\d]*)/([\d]*\.[\d]*)/([\d]*\.[\d]*)/([\d]*\.[\d]*)', str(output))
        ping_min = match.group(1)
        ping_avg = match.group(2)
        ping_max = match.group(3)
        log.info('RTT minimum val is %s, average value is %s and maximum value is %s'
                 % (ping_min, ping_avg, ping_max))

        tx_pkt = re.search(r'(\d*) packets transmitted', str(output))
        tx_packets = tx_pkt.group(1)
        rx_pkt = re.search(r'(\d*) received', str(output))
        rx_packets = rx_pkt.group(1)
        pkt_loss = re.search(r'(\d*)% packet loss', str(output))
        loss_percentage = pkt_loss.group(1)
        log.info('Packets Sent: %s, Packets Received: %s and Packet Loss Percentage: %s'
                 % (tx_packets, rx_packets, loss_percentage))
        return int(loss_percentage)

    @staticmethod
    def racadm_get_analysis(output):
        log.info(str(output))
        pattern = re.compile(r'^\[Key=(.*)#(\w+)\]')
        matches = pattern.finditer(output[0])

        while "" in output:  # Taking out empty values in the output array
            output.remove("")

        get_dict = {}
        get_arr = []

        if matches:
            del output[0]
            for line in output:
                arr = line.split('=')
                get_dict[arr[0]] = arr[1]
            return get_dict
        else:
            for line in output:
                arr = line.split(" ")
                get_arr.append(arr[0])
            return get_arr

    @staticmethod
    def racadm_set_analysis(output):
        while "" in output:
            output.remove("")
        matches = re.search(r'\[Key=(.*)#(\w+)\]', str(output))
        rac_device_id = ''

        if matches:
            rac_device_id = matches.group(1)
        else:
            return False
        return rac_device_id

    @staticmethod
    def track_analysis(output):
        while "" in output:
            output.remove("")
        track_dict = {}
        for line in output:
            if '=' in line:
                arr = line.split('=')
                arr = list(map(str.strip, arr))  # This will strip each element in array
                track_dict[arr[0]] = arr[1]
        for key, value in list(track_dict.items()):
            track_dict[key] = value.replace('[', '').replace(']', '')
        return track_dict['Status']


class idrac(racadm):  # Dell
    def racadm_ping(self, dst_ip):
        cmd = 'racadm ping ' + dst_ip
        output = self.exec_cmd(cmd)
        if 'ERROR' in str(output):
            return False
        elif 'ttl' in str(output):
            return True
        else:
            log.info('Unexpected output observed')
            return False

    def racadm_get(self, fqdd):
        get_cmd = 'racadm get'
        cmd = " ".join([get_cmd, fqdd])
        output = self.exec_cmd(cmd)
        output = output.split('\n')

        if 'ERROR' in str(output):
            return False
        else:
            fin_result = self.racadm_get_analysis(output)
            return fin_result

    def racadm_set(self, fqdd, value):
        get_cmd = 'racadm set'
        cmd = " ".join([get_cmd, fqdd, value])
        output = self.exec_cmd(cmd)
        output = output.split('\n')

        if 'ERROR' in str(output):
            return False
        elif 'Successfully' in str(output):
            log.info('RACADM SET Command executed successfully.')
            rac_id = self.racadm_set_analysis(output)
            return rac_id
        elif 'Object value modified successfully' in str(output):
            log.info('RACADM SET Command executed successfully.')
            rac_id = self.racadm_set_analysis(output)
            return rac_id
        else:
            log.info('Unexpected Output detected. Please check the logs')
            log.info(str(output))
            return False

    def generate_xml_file(self, share='nfs', user=None, password=None, path=None):
        filename = 'config_' + datetime.now().strftime('%H_%M_%S_%d_%m_%Y.xml')
        if share == 'nfs':
            command = f'racadm get -f {filename} -t xml -l {path}'
        elif share == 'cifs' or share == 'smb':
            # racadm get -f config_15_07_54_25_03_2024.xml -t xml  -u lsi  -p lsilogic@123 -l //10.123.159.84/SMBShare
            command = f'racadm get -f {filename} -t xml  -u {user}  -p {password} -l {path}'
        else:
            raise exception.ConfigException('ERROR: Unsupported share type "%s". '
                                            'Supported values are [nfs|cifs|smb]' % share)
        log.info(f"Issuing RACADM GET command..")
        output = self.exec_cmd(command)
        if 'ERROR' in output:
            raise exception.ExeException('Failed to generate XML file')

        matches = re.search('"racadm jobqueue view -i (\S+)"', str(output))
        job_id = matches.group(1)
        job_finished = self.track_job(job_id)
        if job_finished:
            log.info('Downloading is completed')
        else:
            raise exception.ExeException(f'ERROR: Job failed for jobid={job_id} during generate XML file!')

        return filename

    def import_xml_file(self, path, xml_file, share='nfs', user=None, password=None):
        if share == 'nfs':
            command = f'racadm set -f {xml_file} -t xml -l {path} -b Forced'
        if share == 'cifs' or share == 'smb':
            # racadm set -f <filename> -t xml -u <username> -p <password> -l <CIFS share>
            command = f'racadm set -f {xml_file} -t xml -u {user} -p {password} -l {path} -b Forced'
        else:
            raise exception.ConfigException('ERROR: Unsupported share type "%s". '
                                            'Supported values are [nfs|cifs|smb]' % share)
        log.info(f"Issuing RACADM SET command..")
        output = self.exec_cmd(command)
        log.info(f'RACADM SET CMD output: {output}')
        matches = re.search('"racadm jobqueue view -i (\S+)"', str(output))
        job_id = matches.group(1)

        time.sleep(5)
        log.info('Initiating Power Cycle...')
        if not self.power_cycle():
            raise exception.ConfigException('System power cycle was unsuccessful during import XML file operation!')
        job_finished = self.track_job(job_id)
        if job_finished:
            log.info('RACADM Set XML is completed')
        else:
            log.error(f'ERROR: Job failed for jobid={job_id} during import XML file!')

    def sys_lockdown_get(self):
        cmd = 'racadm get iDRAC.Lockdown.SystemLockdown'
        log.info('racadm command is %s' % cmd)
        output = self.exec_cmd(cmd)
        output = output.split('\n')
        for line in output:
            if 'SystemLockdown' in line:
                return line.split('=')[1]
        return False

    def sys_lockdown_set(self, value):
        cmd = 'racadm set iDRAC.Lockdown.SystemLockdown ' + value
        log.info('racadm command is %s' % cmd)
        output = self.exec_cmd(cmd)
        output = output.split('\n')
        if 'ERROR' in str(output):
            log.info('Failed to Change System Lockdown')
            return False
        elif 'successfully' in str(output):
            log.info('System lockdown mode successfully changed')
            return True

    def create_job(self, rac_id):
        job_cmd = 'racadm jobqueue create ' + rac_id
        output = self.exec_cmd(job_cmd)
        if 'Successfully' in str(output):
            log.info('RACADM JOB CREATE command executed successfully')
        output = output.split('\n')
        for line in output:
            if 'Commit' in line:
                jid = line.split('=')[1]
                jid = jid.strip()
                log.info('The Job ID for the created JOB is %s' % jid)
                return jid
        return False

    def delete_job(self, job_id):
        if 'JID' in 'job_id':
            del_cmd = 'racadm jobqueue delete -i ' + job_id
        else:
            del_cmd = 'racadm jobqueue delete --all'

        output = self.exec_cmd(del_cmd)
        if 'RAC1032' in str(output):
            logging.info('Job(s) got deleted successfully')
        else:
            logging.error('Failed to delete Jobs. Please clear them manually')
            return False
        return True

    def get_fqdd(self, mac):
        # Finds Fully Qualified Device Descriptor through MAC address and returns the same
        # FQDD is unique ID assigned to each Interface
        upper_mac = mac.upper()
        nic_info = self.exec_cmd('racadm hwinventory nic')
        nic_info = nic_info.split('\n')
        fqdd = adp_name = None
        for line in nic_info:
            log.info(line)
            if upper_mac in line:
                match = re.search('(\S+):(.*)\s+\-\s+(\S+)', line)
                fqdd = match.group(1)
                adp_name = match.group(2)
                log.info('Match found for MAC with FQDD {} and Adapter name as {}'.format(fqdd, adp_name))
                return fqdd

        if fqdd is None:
            vndr_page = self.exec_cmd('racadm get NIC.VndrConfigPage')
            vndr_page = vndr_page.split('\n')
            nic_count = 0
            for line in vndr_page:
                if 'NIC.VndrConfigPage' in line:
                    nic_count += 1
            log.info('Total nics available are : %s' % str(nic_count))
            for nic_index in range(1, nic_count + 1):
                output = self.exec_cmd(f'racadm get NIC.VndrConfigPage.{nic_index}')
                if upper_mac in str(output):
                    matches = re.search('\[Key=(.*)#(\w+)\]', str(output))
                    fqdd = matches.group(1)
                    return fqdd
        return False

    def get_nic_pages(self, fqdd):
        nic_page_list = ['VndrConfigPage', 'NICConfig', 'DeviceLevelConfig', 'NICPartitioningConfig']
        nic_page_dict = {}
        for page in nic_page_list:
            output = self.exec_cmd(f'racadm get NIC.{page}')
            output = output.split('\n')
            for line in output:
                if fqdd in line:
                    matches = re.search('NIC.(\w+).(\d+)\s+', str(line))
                    nic_page = matches.group(1)
                    nic_index = matches.group(2)
                    nic_page_dict[page] = f'{page}.{str(nic_index)}'
        return nic_page_dict

    def get_inf_index(self, mac):
        upper_mac = mac.upper()
        log.info('Getting Interface Index')
        vndr_page = self.exec_cmd('racadm get NIC.VndrConfigPage')
        vndr_page = vndr_page.split('\n')
        nic_count = 0
        for line in vndr_page:
            if 'NIC.VndrConfigPage' in line:
                nic_count += 1
        log.info('Total nics available are : %s' % str(nic_count))
        for nic_index in range(1, nic_count + 1):
            output = self.exec_cmd(f'racadm get NIC.VndrConfigPage.{nic_index}')
            if upper_mac in str(output):
                matches = re.search('\[Key=(.*)#(\w+)\]', str(output))
                fqdd = matches.group(1)
                return str(nic_index)

    def get_fw_version(self, fqdd):
        fw_dict = {}
        cmd = 'racadm get NIC.FrmwImgMenu'
        port_id_num = port_full_id = ''
        output = self.exec_cmd(cmd)
        output = output.split('\n')
        for line in output:
            if fqdd in line:
                log.info('fqdd found in line %s' % line)
                match = re.search('(NIC\.FrmwImgMenu\.(\d))', line)
                port_full_id = match.group(1)
                port_id_num = match.group(2)

        if port_id_num:
            new_cmd = 'racadm get ' + port_full_id
            fw_data = self.exec_cmd(new_cmd)
            fw_data = fw_data.split('\n')
            while ("" in fw_data):
                fw_data.remove("")
            for line in fw_data:
                if 'Key' in line:
                    pass
                else:
                    line = line.replace('#', '')
                    arr = line.split('=')
                    fw_dict[arr[0]] = arr[1]
        else:
            return False

        return fw_dict

    def racadm_update(self, method, path, filename, smb_user=None, smb_password=None):
        if method == 'nfs':
            update_cmd = 'racadm update -f ' + filename + ' -l ' + path
            cmd_status = self.exec_cmd(update_cmd)
            if 'RAC987' in str(cmd_status):
                log.info('Firmware update initiated... Checking the status')
                return True
            elif 'RAC0904' in str(cmd_status):
                log.info('Firmware update failed since The remote file location is not accessible or reachable')
                return False
            else:
                log.info('Firmware update command failed with the below error {}'.format(cmd_status))
                return False
        elif method == 'cifs':
            update_cmd = 'racadm update -f ' + filename + ' -u ' + smb_user + ' -p ' + smb_password + ' -l ' + path
            cmd_status = self.exec_cmd(update_cmd)
            if 'RAC987' in str(cmd_status):
                log.info('Firmware update initiated... Checking the status')
                return True
            elif 'RAC0904' in str(cmd_status):
                log.info('Firmware update failed since The remote file location is not accessible or reachable')
                return False
            else:
                log.info('Firmware update command failed with the below error {}'.format(cmd_status))
                return False
        else:
            log.info('Wrong or unsupported share type mentioned')
            return False

    def get_newjob_id(self):
        get_cmd = 'racadm jobqueue view'
        job_data = self.exec_cmd(get_cmd)
        job_data = job_data.split('\n')
        while "" in job_data:
            job_data.remove("")

        status_list = ['Scheduled', 'New', 'Downloading', 'Running', 'Completed'] if "ePSA Diagnostics" \
                                        in str(job_data) else ['Scheduled', 'New', 'Downloading', 'Running']

        temp_index = ''
        jid_index = ''
        for index, line in enumerate(job_data):
            if 'Status' in line:
                if any(state in line for state in status_list):
                    temp_index = index
                    break
        if temp_index:
            jid_index = temp_index - 2
            temp = job_data[jid_index].replace('[', '').replace(']', '')
            jid = temp.split('=')[1]
            jid = jid.strip()
            logging.info('Found the JID as %s' % jid)
            return jid
        else:
            log.info('No new jobs found')
            return False

    def power_cycle(self):
        cycle_cmd = 'racadm serveraction powercycle'
        status = self.exec_cmd(cycle_cmd)
        if 'Server power operation initiated successfully' in str(status):
            log.info('Server Power Cycle command initiated successfully')
            return True
        else:
            log.error(f'Server Power Cycle command failed. \n'
                      f'Debug: Status=[{status}]')
            return False

    def track_job(self, jid):
        track_cmd = 'racadm jobqueue view -i ' + jid
        log.info('Monitoring the JOB ID with the command - %s' % track_cmd)
        while (1):
            output = self.exec_cmd(track_cmd)
            if 'Job Name' in str(output):
                output = output.split('\n')
                status = self.track_analysis(output)
                if status == 'Completed':
                    log.info('The Job ID %s status is %s' % (jid, status))
                    return True
                elif status == 'Failed':
                    log.info('FAIL: The Job ID %s status is %s. Exiting...' % (jid, status))
                    return False
                else:
                    log.info('The Job ID %s status is %s. Waiting for JOB completion' % (jid, status))
                    time.sleep(10)
                    pass
            else:
                log.info('Unexpected output observed: %s' % str(output))
                return False

    def get_nic_page(self, cmd_opts, fqdd):
        cmd = f'racadm get {cmd_opts}'
        output = self.exec_cmd(cmd)
        output = output.split('\n')
        for line in output:
            if fqdd in line:
                log.info('fqdd found in line %s' % line)
                match = re.search(rf'({cmd_opts}\.(\d+))', line)
                port_full_id = match.group(1)
                new_cmd = 'racadm get ' + port_full_id
                data = self.exec_cmd(new_cmd)
                data = [line for line in data.split('\n') if line.strip()]
                fw_dict = {}
                for line in data:
                    if 'Key=' in line:
                        continue
                    att, val = line.split('=')
                    fw_dict[att.replace('#', '')] = val.strip()
                return fw_dict

    def get_nic_vndr_configpage(self, fqdd):
        cmd_opts = 'NIC.VndrConfigPage'
        return self.get_nic_page(cmd_opts, fqdd)

    def get_nic_config(self, fqdd):
        cmd_opts = 'NIC.NICConfig'
        return self.get_nic_page(cmd_opts, fqdd)

    def get_nic_device_level_config(self, fqdd):
        cmd_opts = 'NIC.DeviceLevelConfig'
        return self.get_nic_page(cmd_opts, fqdd)

    def get_nic_partitioning_config(self, fqdd):
        cmd_opts = 'NIC.NICPartitioningConfig'
        return self.get_nic_page(cmd_opts, fqdd)

    def get_hwinventory(self, fqdd):
        nic_info = self.exec_cmd(f'racadm hwinventory {fqdd}')
        nic_info = nic_info.split('\n')
        fw_dict = {}
        for line in nic_info:
            if not line or 'Key=' in line or ':' not in line:
                continue
            att, val = line.split(':', 1)
            fw_dict[att.replace('#', '')] = val.strip() if val else ''
        return fw_dict

    def diagnostic_test(self, test_dict):
        '''
        -m : <Mode> : Type of diagnostic mode / 0: Express /  1: Extended /  2: Both
        -r : <reboot type>    : Type can be one of the following / pwrcycle / Graceful / Forced
        '''
        test_status = True
        diag_test_cmd = f"racadm diagnostics run -m {str(test_dict['mode'])} -r {test_dict['reboot_type']} " \
                        f"-s {test_dict['start_time']} -e {test_dict['exp_time']}"
        output = self.exec_cmd(diag_test_cmd)
        output = output.split('\n')
        if "The Remote Diagnostic run operation is initiated" not in str(output):
            log.error("Unable to initiate the Diagnostic test")
            return False
        job_id = self.get_newjob_id()
        if job_id:
            if not self.track_job(job_id):
                log.error('RACADM Diagnostics test not completed')
                test_status = False
        else:
            test_status = False
        return test_status

    def diagnostic_report(self, report_dict):
        report_status = True
        diag_report_cmd = f"racadm diagnostics export -f {report_dict['file_name']}"
        if report_dict['share_type'] in ['nfs', 'cifs']:
            diag_report_cmd = f"racadm diagnostics export -f {report_dict['file_name']} -l {report_dict['path']} " \
                              f"-u {report_dict['username']} -p {report_dict['password']}"
        output = self.exec_cmd(diag_report_cmd)
        output = output.split('\n')
        if "The Remote Diagnostic export operation initiated" not in str(output):
            log.error('Unable to export the test results')
            return False
        job_id = self.get_newjob_id()
        if job_id:
            if not self.track_job(job_id):
                log.error('RACADM Diagnostics report generation failed')
                report_status = False
        else:
            report_status = False
        return report_status
