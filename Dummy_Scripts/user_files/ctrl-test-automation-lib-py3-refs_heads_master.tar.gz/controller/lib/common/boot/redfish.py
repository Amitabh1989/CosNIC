"""
:mod:`redfish` .
=========================================

.. module:: controller.lib.common.boot.redfish
.. moduleauthor:: Uma sankar Donepudi <umasankar.donepudi@broadcom.com>

This python module is for redfish module "redfish"

Installation:
This module can be installed through the command "pip install redfish".

usage:
>>> import redfish
>>> REDFISH_OBJ = redfish.redfish_client(base_url=login_host, username=login_account, \
                      password=login_password, default_prefix='/redfish/v1/')

After creating the REDFISH_OBJ, perform the login operation to authenticate with the service.
The auth parameter allows you to specify the login method.

>>> REDFISH_OBJ.login(auth="session")

The Redfish library performs GET, POST, PUT, PATCH and DELETE operations

>>> response = REDFISH_OBJ.get("/redfish/v1/Systems/1")
>>> body = {"ResetType": "GracefulShutdown"}
>>> response = REDFISH_OBJ.post("/redfish/v1/Systems/1/Actions/ComputerSystem.Reset", body=body)

Please refer the below link for further development of this module
https://github.com/DMTF/python-redfish-library/tree/main

"""

import json
import logging
import redfish
import pathlib

from controller.lib.core import exception

log = logging.getLogger(__name__)


class Redfish(object):
    def __init__(self, bmc_ip, bmc_username, bmc_password):
        self.bmc_ip = bmc_ip
        self.bmc_username = bmc_username
        self.bmc_password = bmc_password
        self.login_host = f"https://{self.bmc_ip}/"
        self.login_account = self.bmc_username
        self.login_password = self.bmc_password
        self.default_prefix = '/redfish/v1'
        self.default_chassis = 'Chassis/1'

    def create_query(self, query_type="NetworkAdapters", nic_id=None, port_id=None,
                     dev_function_id=None, skip=None, top=None, expand=None):
        """
        Creates a query based on the inputs
        Args:
            query_type: Query type based on the output required
            nic_id: nic id which can obtained by get_nic_odata_id
            port_id: port id
            dev_function_id: device function id
            skip: screening option skip
            top: screening option top
            expand: expand filter option

        Returns: returns query
        """
        redfish_query = self.default_prefix
        if query_type == "Chassis":
            redfish_query = f"{redfish_query}/{self.default_chassis}/"
        elif query_type == "NetworkAdapters":
            redfish_query = f"{redfish_query}/{self.default_chassis}/NetworkAdapters/"
            redfish_query = redfish_query + f"{str(nic_id)}/" if nic_id else redfish_query
        elif query_type == "Ports" and nic_id:
            redfish_query = f"{redfish_query}/{self.default_chassis}/NetworkAdapters/{nic_id}/Ports/"
            redfish_query = redfish_query + f"{str(port_id)}/" if port_id else redfish_query
        elif query_type == "NetworkDeviceFunctions" and nic_id:
            redfish_query = \
                f"{redfish_query}/{self.default_chassis}/NetworkAdapters/{nic_id}/NetworkDeviceFunctions/"
            redfish_query = redfish_query + f"{str(dev_function_id)}/" if dev_function_id else redfish_query
        elif query_type == "PCIeDevices":
            redfish_query = f"{redfish_query}/{self.default_chassis}/PCIeDevices/"
            if nic_id:
                redfish_query = redfish_query + f"{str(nic_id)}" + "/PCIeFunctions/"
        else:
            log.warning("Incorrect Inputs provided for the query. Pleas read the docstring for correct inputs")

        redfish_query.replace("//", "/")

        if skip or top or expand:
            screen_page_list = []
            if skip is not None:
                screen_page_list.append(f"$skip={str(skip)}")
            if top is not None:
                screen_page_list.append(f"$top={str(top)}")
            if expand is not None:
                screen_page_list.append(f"$expand={str(expand)}")
            screen_page_str = "&".join(screen_page_list)

            if redfish_query[-1] == "/":
                redfish_query = redfish_query.rstrip("/")
            redfish_query = redfish_query + "?" + screen_page_str

        return redfish_query

    def start_redfish_session(self, auth_type='session'):
        """
        starts redfish session
        Args:
            auth_type: session type

        Returns: returns session object

        """
        try:
            log.info(f"Initializing Redfish session to {self.login_host}")
            REDFISH_OBJ = redfish.redfish_client(base_url=self.login_host, username=self.login_account,
                                                 password=self.login_password, default_prefix=self.default_prefix)
            REDFISH_OBJ.login(auth=auth_type)
            log.info(f"Redfish session to {self.login_host} is initialized successfully")
        except:
            raise exception.TestCaseFailure("Failed to initiate redfish session")

        return REDFISH_OBJ

    def get_response(self, redfish_obj, query):
        """
        Gets response of the given query in json format
        Args:
            redfish_obj: redfish session object
            query: query to be sent

        Returns: redfish query response in json format

        """
        try:
            log.info(f"Querying the redfish session with query: {query}")

            response = redfish_obj.get(query)
            if response.status != 200:
                raise exception.TestCaseFailure(f"Get query failed with response code {response.status}")
            enh_response = str(response.read).replace("\n", "")
            try:
                output_json = json.loads(response.read)
            except:
                output_json = json.loads(enh_response)
            if 'error' in output_json.keys():
                raise exception.TestCaseFailure("Errors observed in the redfish query output")
        except:
            raise exception.TestCaseFailure("Unable to query from redfish session")
        return output_json

    def send_patch(self, redfish_obj, new_path, new_body, expect_failure=False,
                   settings=True, headers=None, return_response=False):
        """
        sends patch
        Args:
            redfish_obj: redfish session object
            new_path: new path
            new_body: new body string
            expect_failure: Validates the output as if the failure is expected
            settings: adds postfix of settings if required based on the params passed
            headers: headers required
            return_response: Returns output without validating the same

        Returns: returns response

        """
        new_path = str(pathlib.PurePosixPath(new_path, 'settings')) if settings else new_path
        log.info(f"Sending the new patch {new_body} to the path {new_path}")
        response = redfish_obj.patch(path=new_path, body=new_body, headers=headers)
        if return_response:
            return response
        if response.status != 200:
            if expect_failure:
                log.warning(f"Failed to set new patch {new_body} to the path {new_path} as expected: {response}")
                return True
            else:
                raise exception.TestCaseFailure(f"Patch request failed with respose code {response.status}")
        enh_response = str(response.read).replace("\n", "")
        try:
            output_json = json.loads(response.read)
        except:
            output_json = json.loads(enh_response)
        log.info(f"output json {output_json}")
        if 'Success' not in output_json['error']['@Message.ExtendedInfo'][0]['MessageId']:
            raise exception.TestCaseFailure(f"Patch request is not successful. Failure message is: "
                                            f"{output_json['error']['@Message.ExtendedInfo'][0]['MessageId']}")
        else:
            log.info(f"successfully set new Patch {new_body} to the path {new_path}")

        return True

    def send_post(self, redfish_obj, new_path, expect_failure=False):
        """
        Sends post option
        Args:
            redfish_obj: redfish session object
            new_path: new path
            expect_failure: Validates the output as if failure is expected

        Returns: returns Boolean based on the response

        """
        log.info(f"Sending the new post with the path {new_path}")
        response = redfish_obj.post(path=new_path)
        if response.status != 200:
            if expect_failure:
                log.warning(f"Failed to set new post with the path {new_path} as expected: {response}")
                return True
            else:
                raise exception.TestCaseFailure(f"post request failed with respose code {response.status}")
        enh_response = str(response.read).replace("\n", "")
        try:
            output_json = json.loads(response.read)
        except:
            output_json = json.loads(enh_response)
        log.info(f"output json {output_json}")
        if 'Success' not in output_json['error']['@Message.ExtendedInfo'][0]['MessageId']:
            raise exception.TestCaseFailure(f"Post request is not successful. Failure message is: "
                                            f"{output_json['error']['@Message.ExtendedInfo'][0]['MessageId']}")
        else:
            log.info(f"successfully set new Post with the path {new_path}")

        return True

    def get_nic_odata_id(self, redfish_obj, mac_addr):
        """
        Collects get nic odata id
        Args:
            redfish_obj: redfish session object
            mac_addr: mac address of the nic which odata id is needed

        Returns: returns odata id in string format
        """
        log.info(f"Gathering the NIC ID for the mac address {mac_addr}")
        network_adp_query = self.create_query(query_type="NetworkAdapters")
        response = self.get_response(redfish_obj, network_adp_query)

        nic_id_queries = [list(member.values())[0] for member in response['Members']]
        for nic_id_query in nic_id_queries:
            nic_responce = self.get_response(redfish_obj, nic_id_query)
            ports_query = self.create_query(query_type="Ports", nic_id=nic_responce['Id'])
            nic_id_output = self.get_response(redfish_obj, ports_query)
            port_id_queries = [list(member.values())[0] for member in nic_id_output['Members']]
            for port_id_query in port_id_queries:
                port_id_response = self.get_response(redfish_obj, port_id_query)
                if mac_addr in port_id_response["Ethernet"]["AssociatedMACAddresses"]:
                    log.info(f"NIC ID mapped for the mac {mac_addr} is {nic_responce['Id']}")
                    return nic_responce['Id']
