"""
:mod:`decode_coredump` -- Decode the coredump.
==============================================

.. module:: controller.lib.common.brcm.corefile_decoder.py
.. module author:: Surendra <surendra-reddy.narala@broadcom.com>
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2022 Broadcom Inc"

import logging
import os
import re
import tempfile
from distutils.spawn import find_executable
from pathlib import Path

import controller.lib.common.shell.exe as exe
from controller.lib.core import exception

log = logging.getLogger(__name__)


class CorefileDecoder(object):
    def __init__(self, coredump_path, app_path=None):

        if Path(coredump_path).is_file() is False:
            raise exception.ConfigException('%s does not exists' % coredump_path)

        if app_path and (Path(app_path).is_file() is False):
            raise exception.ConfigException('%s does not exists' % app_path)

        self.app_path = app_path or find_executable('corefile_decoder')
        if not self.app_path:
            raise exception.ConfigException('corefile_decoder is not found')

        self.coredump_path = coredump_path

    @property
    def corefile_decoder_app(self):
        return self.app_path

    def exec_command(self, cmd, shell=False, silent=False, **kwargs):
        options = []
        for k, v in kwargs.items():
            options.append(f'{k}' if v is None else f'{k} {v}')
        options = ' '.join(options)
        cmd = f'{self.corefile_decoder_app} {self.coredump_path} {cmd} {options}'
        output = exe.block_run(cmd, shell=shell, silent=silent)
        return output

    def ctxm_summary(self):
        log.info('Getting ctxm summary of coredump file: %s' % self.coredump_path)
        cmd = 'ctxm summary'
        output = self.exec_command(cmd, shell=True, silent=True)
        log.info(output)
        _ctxm_summary = {}
        block_name = None
        for line in output.split('\n'):
            line = line.strip()
            if line.startswith('*'):
                log.info(line)
                block_name = re.search(r'\*+(\w+)\*+', line).group(1)
                _ctxm_summary.setdefault(block_name, {})
            elif block_name and line:
                if _ctxm_summary[block_name] == {} and ':' not in line:
                    items = re.findall(r'(\w+)', line)
                    _ctxm_summary[block_name] = {k: [] for k in items}
                elif ':' in line:
                    values = re.findall(r'(\w+)', line)
                    for key, value in zip(list(_ctxm_summary[block_name].keys()), values):
                        _ctxm_summary[block_name][key].append(value)
        log.debug('ctxm summary: %s' % _ctxm_summary)
        return _ctxm_summary

    def block_names(self):
        ctxm_summary = self.ctxm_summary()
        return list(ctxm_summary.keys())

    def item_names(self, block_name):
        ctxm_summary = self.ctxm_summary()
        return list(ctxm_summary[block_name].keys())

    def item_values(self, block_name, item_name):
        ctxm_summary = self.ctxm_summary()
        return ctxm_summary[block_name][item_name]

    def validate(self):
        cmd = 'validate'
        output = self.exec_command(cmd, shell=True)
        return 'PASSED' in output

    def extract_nvram(self):
        cmd = 'extract nvram'
        output = self.exec_command(cmd, shell=True, silent=True)
        return output

    def extract_nvram_file(self):
        fd, crashdump_file_path = tempfile.mkstemp(suffix='.txt')
        os.close(fd)
        cmd = f'extract nvram > {crashdump_file_path}'
        self.exec_command(cmd, shell=True, silent=False)
        return crashdump_file_path

    def grc_all(self):
        fd, grc_file = tempfile.mkstemp(suffix='.txt')
        os.close(fd)
        cmd = f'grc all > {grc_file}'
        self.exec_command(cmd, shell=True, silent=True)
        return grc_file
