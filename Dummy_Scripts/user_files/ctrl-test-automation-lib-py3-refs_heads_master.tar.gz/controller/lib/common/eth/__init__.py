"""
:mod:`eth` -- Ethernet interface API
====================================

.. module:: controller.lib.common.eth.ip
.. moduleauthor:: Eugene Cho <echo@broadcom.com>


This module provides a base class for "eth" module for various OS types

"""


import platform
import importlib

ETH_MOD = f'controller.lib.{platform.system().lower()}.eth'


def get_interface(iface, **kwargs):
    """A factory method to return the instantiated object depending on OS

    Args:
        iface (str): interface name
        **kwargs (kwargs): keyword arguments for the OS specific get_interface()
            function
    """

    module = importlib.import_module(ETH_MOD)

    return module.get_interface(iface, **kwargs)


def get_interface_by_mac_addr(mac_addr, **kwargs):
    """A factory method to return the instantiated object depending on OS

    Args:
        mac_addr (str): MAC address in format xx:xx:xx:xx:xx:xx
        **kwargs (kwargs): keyword arguments for the OS specific get_interface()
            function
    """
    module = importlib.import_module(ETH_MOD)

    return module.get_interface_by_mac_addr(mac_addr, **kwargs)


def get_interfaces_by_driver(driver, **kwargs):
    """Return a list of instantiated Interface objects that use the given
    driver

    Args:
        driver (str): driver name
    """
    module = importlib.import_module(ETH_MOD)

    return module.get_interfaces_by_driver(driver, **kwargs)


def get_interfaces(**kwargs):
    """Return a list of all network interfaces"""
    module = importlib.import_module(ETH_MOD)

    return module.get_interfaces(**kwargs)


def get_interfaces_by_ip_addr(ip_addr):
    """Return a list of instantiated interface objects that have the given
    IP address

    Args:
        ip_addr (str): IP address x.x.x.x
    """
    module = importlib.import_module(ETH_MOD)

    if len(ip_addr.split('/')) > 1:
        ip_addr = ip_addr.split('/')[0]

    return module.get_interfaces_by_ip_addr(ip_addr)
