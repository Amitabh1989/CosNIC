"""
:mod:`interface` -- Back-end interface to interact with NIC
===========================================================

.. module:: controller.lib.common.eth.interface
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import abc
from typing import Dict, List, Tuple, TYPE_CHECKING

from controller.lib.core import log_handler

if TYPE_CHECKING:
    from controller.lib.common.eth.stats import BaseNIC

log = log_handler.get_logger(__name__)


class BaseInterface(abc.ABC):
    """
    Can control a single Ethernet interface using this object. Abstract
    backend and perform different interactions with a system depending on
    the method.

    This class uses user-space tools to interact with NIC

    Args:
        iface (str): ethX or interface name

    Returns:
        Interface: Interface object that has methods to interact with
            the Ethernet interface

    """

    def __init__(self, iface):
        self.iface = iface

    @property
    def name(self):
        return self.iface

    @abc.abstractmethod
    def up(self):
        """Bring up the interface"""
        pass

    @abc.abstractmethod
    def down(self):
        """Bring down the interface"""
        pass

    @property
    @abc.abstractmethod
    def ip_addr(self):
        """Return IPv4 address of the interface.

        If there are multiple assigned IP addresses, return the one that
        basic level user-space tools return (i.e. IP address that ifconfig
        returns for Linux)

        Returns:
            str: IP address of the interface
            None: If No IP address is assigned

        """
        raise NotImplementedError('Not Implemented')

    @ip_addr.setter
    @abc.abstractmethod
    def ip_addr(self, new_ip_addr):
        """Set IP address of the interface.

        It should behaves as the basic level user-space tools. Following is
        behaviors for Windows and Linux:

           * If no IP address was assigned, the new IP address will be assigned
           * If IP address was already assigned, the new IP address will
             replace it
           * If 'new_ip_addr' is 0.0.0.0, will remove the IP address

        Args:
            new_ip_addr (str): New IP address of the interface with subnet.
                format should be x.x.x.x/x

        """
        raise NotImplementedError('Not Implemented')

    @property
    @abc.abstractmethod
    def ip6_addr(self):
        """Return IPv6 addresses of the interface.

        Returns:
            list: List of IPv6 addresses

        """
        raise NotImplementedError('Not implemented')

    @ip6_addr.setter
    @abc.abstractmethod
    def ip6_addr(self, new_ip6_addr):
        """Add (not replace) the new_ip6_addr

        Args:
            new_ip6_addr (str): IPv6 address with prefix that will be added to
                the interface

        """
        raise NotImplementedError('Not Implemented')

    @abc.abstractmethod
    def set_ip6_addr(self, new_ip6_addr, method, **kwargs):
        """Assign a new IPv6 address to the interface. This method should be
        called if user-space tools require more than a new IPv6 address, such
        as method (add, del, set, etc) prefix or default gateway.

        Args:
            new_ip_addr (str): New IP address of the interface
                with prefix preceded by '/' (e.g. <ipv6 addr>/<prefix>)
            method (str): choices=[add|del] "add" will append a new IP
                address, "del" will remove the given IP address
            **kwargs (kwargs): Keyword arguments to pass to the user-space tool
                wrapper.

        """
        raise NotImplementedError('Not Implemented')

    @property
    @abc.abstractmethod
    def netmask(self):
        """Return netmask of the interface.

        Returns:
            str: netmask of the interface. x.x.x.x format

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def prefix(self):
        """Return prefix of the interface

        Return:
            int: prefix of the interface

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def ip6_prefix(self):
        """Return IPv6 prefix of the interface as a dictionary, due to multiple
        IPv6 addresses can be assigned normally.

        key is a IP address and value is the prefix, since it's expected to see
        multiple addresses

        Return:
            dict: key=IP address, value=prefix

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def mac_addr(self):
        """Return MAC address of the interface

        Returns:
            str: MAC address of the interface in xx:xx:xx:xx:xx:xx format and
                in lowercase.
        """
        raise NotImplementedError('Not implemented')

    @mac_addr.setter
    @abc.abstractmethod
    def mac_addr(self, new_mac_addr):
        """Set MAC address of the interface

        Args:
            new_mac_addr (str): New MAC address of the interface
                in xx:xx:xx:xx:xx:x format and in lowercase

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def state(self):
        """Return link status. 'up', 'down' and 'unknown'

        In the case that expected value is not found in the output, should
        raise exception.IPException('Cannot find link state information')

        Returns:
            str: link status
        """
        raise NotImplementedError('Not implemented')

    @property
    def link_status(self):
        """
        Return link status. 'yes' (== 'active'), else 'no' ('no carrier': not connected, remote down, etc.)

        Returns:
            str: link status
        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def mtu(self):
        """Return MTU of the interface

        In the case that expected value is not found in the output, should
        raise exception.IPException('Cannot find MTU information')

        Return:
            int: MTU of the interface

        """
        raise NotImplementedError('Not implemented')

    @mtu.setter
    @abc.abstractmethod
    def mtu(self, new_mtu):
        """Set MTU size of the interface

        Args:
            new_mtu (int): New MTU of the interface
        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def speed(self):
        """Return link speed of the interface in Mb.

        Return:
            int: link speed in Mb. Return -1 when the speed is unknown
                i.e.) link is down

        """
        raise NotImplementedError('Not implemented')

    @speed.setter
    @abc.abstractmethod
    def speed(self, new_speed):
        """Set speed of the interface

        Args:
            new_speed (int): New speed in Mb of the interface

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def duplex(self):
        """Return duplex mode of the interface

        Return:
            str: duplex mode. choices=[half|full|unknown]
        """
        raise NotImplementedError('Not implemented')

    @duplex.setter
    @abc.abstractmethod
    def duplex(self, new_duplex):
        """Set duplex mode of the interface

        Args:
            new_duplex (str): full/half

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def stats(self) -> 'BaseNIC':
        """Return statistics of the interface.

        Returns:
            obj: controller.lib.common.eth.stats.BaseNIC
        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def interrupt(self):
        """Return interrupt that are triggered by NIC

        Return:
            dict: key=<(int) cpu_num or (str)total>,
                value=<(int) interrupt number>
        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def drvinfo(self):
        """Return driver information of the interface.

        Returns:
            dict: driver information. Format is below.
            {
                'name': <driver_name>,
                'version': <driver_version,
                'firmware": <optional. Firmware version>
            }

        """
        raise NotImplementedError('Not implemented')

    def dump(self, attr_list=None):
        """Dump the NIC property in dict.

        Returns:
            dict: key=param, value=value
        """

        attr_list = attr_list or [
            'ip_addr', 'ip6_addr', 'netmask', 'mac_addr', 'state',
            'mtu', 'speed', 'duplex', 'drvinfo'
        ]

        ret_dict = {}

        for attr in attr_list:
            ret_dict[attr] = getattr(self, attr)

        return ret_dict

    @property
    @abc.abstractmethod
    def features(self):
        """Return a dictionary of NIC features.

        key is a feature name, such as "tx-vlan-offload" or "LSOv2IPv4"
        value is the value for the feature.

        Note that feature names and values should NOT normalized, since they
        are all different and even for the same feature, they expect different
        values.

        For Windows, all values must be "display" ones, not the values that
        are written to registers

        Returns:
            dict: features

        """
        raise NotImplementedError('Not implemented')

    @abc.abstractmethod
    def set_feature(self, **kwargs):
        """Set offload feature settings.

        Args:
            **kwargs: keyword arguments. It's up to OS specific module how to
                implement this.
        """
        raise NotImplementedError('Not implemented')

    @property
    def coalesce(self):
        """Return ethtool -c output in dictionary

        key is a name of parameter and value is integer, except adaptive rx/tx
        which has 'on' and 'off' as possible values
        """
        raise NotImplementedError('Not implemented')

    def set_coalesce(self, param, value):
        """Set value of the coalesce parameter

        Acceptable parameter / values are as what coalesce() returns

        Args:
            param (str): parametner name i.e.) rx-frames
            value (str, int): str for adaptive rx/tx and integer for all other
                parameters
        """
        raise NotImplementedError('Not implemented')

    @property
    def smp_affinity(self):
        """Return CPU affinity list

        Return:
            dict: key=interrupt id, value=affinity in list of CPU index. i.e.)
                [0,6] means the affinity is set to CPU 0 and CPU 6
        """
        raise NotImplementedError('Not implemented')

    @smp_affinity.setter
    def smp_affinity(self, affinity_dict):
        """Set affinitiy list

        Args:
            affinity_dict: key=interrupt id, value=affinity in list of CPU
                index. i.e.) [0,6] will set affinity to CPU 0 and CPU 6
        """
        raise NotImplementedError('Not implemented')

    @property
    def netstats(self):
        """Return all netstat -s stats

        Return:
            dict: key=parameter, value=value
        """
        raise NotImplementedError('Not implemented')

    @property
    def netstat(self):
        """Return /proc/net/netstat (linux nstat -s) equivalent (roughly): netstat -s tcp and ip values

        Return:
            dict: key=parameter, value=value
            json output is flattened for tcp (two levels: eg. tcp-<counter>, tcp-sack-<counter>)
            and ip (one level: eg. ip-<counter>)
        """
        raise NotImplementedError('Not implemented')

    @property
    def snmp(self):
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def flow_control(self):
        """Return pause options

        Return:
            str: choices=[auto_neg, disabled, rx, tx, rx_tx]
        """
        raise NotImplementedError('Not implemented')

    @flow_control.setter
    @abc.abstractmethod
    def flow_control(self, new_mode):
        """Set pause options

        Args:
            mode: auto_neg, disabled, rx, tx, rx_tx

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def route(self):
        """Return route information of the current iface.

        Each routing entry is a dictionary that has following format

        {
            'iface': <iface>,
            'destination': <destination>,
            'netmask': <netmask>,
            'metric': <metric>,
            'gateway': <gateway>
        }

        Return:
            list: List of routing entries for iface
            None: If no routing entries exists for the iface

        """
        raise NotImplementedError('Not implemented')

    @abc.abstractmethod
    def set_route(self, method, dst, gateway=None):
        """Set route

        Args:
            method (str): [add|del]
            dst (str): destination
            gateway (str, None): gateway

        """
        raise NotImplementedError('Not implemented')

    @property
    def ip6_route(self):
        """Return IPv6 route information for the current iface.

        Follow the same format as route()
        """
        raise NotImplementedError('Not implemented')

    def set_ip6_route(self, method, dst, gateway=None):
        """Set IPv6 route

        Args:
            method (str): [add|del]
            dst (str): destination
            gateway (str, None): gateway

        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def queue(self):
        """Return channel settings (Linux) or max number of RSS queues (Windows)

        Return:
            dict: key=['rx', 'tx'] value=queue number

        """
        raise NotImplementedError('Not implemented')

    @queue.setter
    @abc.abstractmethod
    def queue(self, queue_dict):
        """Configure the number of queues

        if rx and tx queue numbers are different and OS does not support such
        configuration, should raise exception.

        Args:
            queue_dict (dict): {'rx': <rx_queue_num>, 'tx': <tx_queue_num>}

        """
        raise NotImplementedError('Not implemented')

    @property
    def channel(self):
        """Return channel settings
        """
        raise NotImplementedError('Not implemented')

    @channel.setter
    def channel(self, channel_settings):
        """Configure the channel using the given parameter.

        Args:
            channel_settings (dict): new channel settings. The format of the
                expected channel_settings is same as the return value of
                get_channels()
        """
        raise NotImplementedError('Not implemented')

    @property
    def ring(self):
        """ Return ring settings
        """
        raise NotImplementedError('Not implemented')

    @ring.setter
    def ring(self, ring_settings=None):
        """ Configure the ring parameters using the dictionary argument
        """
        raise NotImplementedError('Not implemented')

    @property
    def medium(self):
        """Return the transmission medium type [FIBRE/TP]

        """
        raise NotImplementedError('Not implemented')

    @abc.abstractmethod
    def ping(self, dst_ip, count=10, **kwargs):
        """Ping the remote host

        Args:
            dst_ip (str): Destination IP address
            count (int): A number of ping
            **kwargs (kwargs): key=param, value=value. This can be used to pass
                extra options to ping
        """
        raise NotImplementedError('Not implemented')

    @abc.abstractmethod
    def ping6(self, dst_ip, count=10, **kwargs):
        """Ping over IPv6 to remote host

        Args:
            dst_ip (str): Destination IP address
            count (int): A number of ping
            **kwargs (kwargs): key=param, value=value. This can be used to pass
                extra options to ping
        """
        raise NotImplementedError('Not implemented')

    @abc.abstractmethod
    def add_vlan(self, vlan_id):
        """Add a VLAN interface

        Args:
            vlan_id (int): VLAN ID
        """
        raise NotImplementedError('Not implemented')

    @abc.abstractmethod
    def remove_vlan(self, vlan_id):
        """Remove a VLAN interface

        Args:
            vlan_id (int): VLAN ID
        """
        raise NotImplementedError('Not implemented')

    @property
    @abc.abstractmethod
    def pcidevice(self):
        """ Return PCI device name"""
        raise NotImplementedError('Not implemented')

    @property
    def roce_first_port(self) -> str:
        """Return the first roce port number of the interface (expect 1)"""
        raise NotImplementedError('Not implemented')

    def set_roce_version(self, roce_v2=True):
        """Set the default roce mode to v1 or v2"""
        raise NotImplementedError('Not implemented')

    @property
    def roce(self) -> str:
        """ Return the associated roce interface name"""
        raise NotImplementedError('Not implemented')

    @property
    def roce_state(self) -> str:
        """ Return the state of the RoCE interface """
        raise NotImplementedError('Not implemented')

    @property
    def roce_phys_state(self) -> str:
        """ Return the physical state of the RoCE interface """
        raise NotImplementedError('Not implemented')

    @property
    def roce_rate(self) -> Tuple[float, int]:
        """ Return the rate of the RoCE interface: speed (Gbps) and width (speed multiplier) """
        raise NotImplementedError('Not implemented')

    @property
    def roce_speed(self) -> float:
        """ Return the speed of the RoCE interface in Gbps """
        raise NotImplementedError('Not implemented')

    def roce_gid(self, ip_addr) -> List[str]:
        """ Return a list of GUID indices for the RoCE interface """
        raise NotImplementedError('Not implemented')

    def roce_v1_gid(self, ip_addr=None) -> str:
        """ Return a list of RoCE V1 gids for the RoCE interface """
        raise NotImplementedError('Not implemented')

    def roce_v2_gid(self, ip_addr=None) -> str:
        """ Return a list of RoCE V2 gids for the RoCE interface """
        raise NotImplementedError('Not implemented')

    @property
    def roce_stats(self) -> Dict[str, str]:
        """ Return the stats of the RoCE interface """
        raise NotImplementedError('Not implemented')

    @property
    def qPairs(self) -> Dict[str, str]:  # pylint: disable=C0103
        raise NotImplementedError('Not implemented')
