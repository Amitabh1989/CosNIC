"""
:mod:`multicast` -- Linux multicast library
===========================================

.. module:: controller.lib.common.eth.multicast
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library provides some basic client and server functions to send and
receive multicast for specific groups.

"""


import socket
import struct
import threading
import socketserver

from controller.lib.core import log_handler
from controller.lib.common import eth


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class Client(object):
    """Multicast client

    Args:
        mcast_address (tuple): (<multicast IP address>, <multicast port>)
        iface (str): Interface name where the multicast packet will be sent to
    """
    def __init__(self, mcast_address, iface=None):
        self.mcast_address = mcast_address

        self._sock = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)

        # Limit the multicast TTL to 2
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)

        if iface:
            iface = eth.get_interface(iface)
            self.sock.setsockopt(
                socket.IPPROTO_IP, socket.IP_MULTICAST_IF,
                socket.inet_aton(iface.ip_addr))

    @property
    def sock(self):
        return self._sock

    def sendto(self, data):
        self.sock.sendto(data, self.mcast_address)

    def recv(self):
        return self.sock.recv()

    def stop(self):
        self._sock.close()


class EchoServer(socketserver.BaseRequestHandler):
    """Echo server. Send back all received messages to client"""
    def handle(self):
        data, client_sock = self.request
        log.debug('Received data: %s' % data)
        client_sock.sendto(data, self.client_address)


class Server(socketserver.ThreadingUDPServer):
    """Non-blocking multicast server

    Args:
        mcast_address (tuple): (<multicast IP address>, <multicast port>)
        iface (str): Interface name where the server will listen to. If None,
            listen to any interfaces, but this is required for Windows
        handler (obj): Server handler object

    """
    def __init__(self, mcast_address, iface=None, handler=EchoServer):
        self._thread = None

        mcast_addr, mcast_port = mcast_address
        socketserver.UDPServer.__init__(self, ('', mcast_port), handler)

        if iface is None:
            mreq = struct.pack(
                "4sI", socket.inet_aton(mcast_addr), socket.INADDR_ANY)
            self.socket.setsockopt(
                socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        else:
            iface = eth.get_interface(iface)

            mreq = socket.inet_aton(
                mcast_addr) + socket.inet_aton(iface.ip_addr)
            self.socket.setsockopt(
                socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    def start(self):
        self._thread = threading.Thread(target=self.serve_forever)
        self._thread.daemon = True
        self._thread.start()
