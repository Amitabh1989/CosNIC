"""
:mod:`stats` -- Ethernet interface statistics library
=====================================================

.. module:: controller.lib.common.eth.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a library that converts ethtool statistics output information into
an object type.

The problem of ethtool statistics is there are no standard names - namely
each vendor can choose their own name as well as a way to display queue
information.

For example, even Broadcom tg3 and bnxt_en drivers use different names.
(e.g. rx_ucast_octet vs. rx_ucast_bytes)

To support various NIC types, it's necessary to abstract parsing process
but return standardized structure.

There are several base classes and NIC specific sub classes - but these
should be abstract for developers most times. The way to access the
statistics information is through a factory function - get_stats()

Get Ethernet Statistics
-----------------------
get_stats() takes one argument - "iface", namely ethX name.

>>> from controller.lib.common.eth import stats
>>> p1p1_stats = stats.get_stats('p1p1')

get_stats will choose a correct class and return the instantiated object, so
developers do not need to worry about NIC types.

The returned object has several attributes, including NIC type specific one.
But by standard, 'rx' and 'tx' attributes are always there.

>>> p1p1_stats.rx
<errors: 170 | bytes: 124270 | mcast_bytes: 0 | packets: 381 | ucast_bytes: 105222 | bcast_packets: 35 | bcast_bytes: 19048 | ucast_packets: 346 | drops: 0 | mcast_packets: 0>

The object name already shows some useful information, but you can access more
details by accessing below attributes. The default values are::

* bytes
* packets
* drops
* errors

And Cumulus has some additional attributes as the sample output above. (i.e.
mcast_bytes)

For example, if you need to access the received unicast packet numbers, then

>>> p1p1_stats.rx.ucast_packets
[953465903, 5128, 937260606, 1874560573]

Wait, but it's a list, not a number. That's because multi-queue supported NICs
usually report a statistics per queue. Namely, p1p1 has 4 queues and each
queue's received unicast packet numbers are as above.

If you only need to care about sum of unicast packets, then just sum them up
using sum built-in function.

>>> sum(p1p1_stats.rx.ucast_packets)
3765292210

Similarly, you can access tx side.

>>> p1p1_stats.tx.bcast_packets
[0, 0, 382396, 0]

Get Statistics Differences
--------------------------
All statistics objects have get_diff() function, which allows to calculate
differences of statistics.

Let's say you collect the Ethernet statistics, and sleep 10 secs.

>>> import time
>>> old_stats = stats.get_stats('p1p1')
>>> time.sleep(10)

And now you collect updated statistics.

>>> new_stats = stats.get_stats('p1p1')

There are two ways to calculate the statistics differences.

>>> stats_diff = new_stats.get_diff(old_stats, new_stats)

Above will return another statistics object which has statistics differences
between old_stats and new_stats object. Note that arguments can be any
statistics objects. Below is to show rx side statistics differences.

>>> stats_diff.rx
<ucast_packets: 4869779 | mcast_packets: 0 | bcast_packets: 0 | drops: 0 | errors: 2>

The other way to calculate is simply subtract one from the other

>>> stats_diff = new_stats - old_stats

This will return statistics differences between old_stats and new_stats -
namely between the called object vs. passed object (namely new_stats vs.
old_stats)

"""


import importlib
import platform

from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


class CounterBase(object):
    """Base class for any counters"""

    def __init__(self, *args):
        [setattr(self, arg, None) for arg in args]

    def __getitem__(self, item):
        return getattr(self, item)

    @classmethod
    def factory(cls, **kwargs):
        return cls(**kwargs)

    @property
    def counter_list(self):
        return list(self.__dict__.keys())

    def get_diff(self, old_cast_counter, new_cast_counter):
        diff_counter = self.factory()

        for counter in new_cast_counter.counter_list:
            new_value = getattr(new_cast_counter, counter)
            old_value = getattr(old_cast_counter, counter)

            if new_value is None or old_value is None:
                setattr(diff_counter, counter, None)
                continue

            value = []
            for new_value, old_value in zip(new_value, old_value):
                diff_value = new_value - old_value if None not in (new_value, old_value) else None
                value.append(diff_value)
            setattr(diff_counter, counter, value)

        return diff_counter

    def set_queue_value(self, counter_type, queue, value):
        """Assign the value to the given queue number

        Dynamically expand the list depending on the given queue. If OS or NIC
        does not support queue-based statistics, simply set queue=0.

        Args:
            counter_type (str): counter name i.e.) packets
            queue (int): queue number
            value (int): counter value
        """
        init_value = getattr(self, counter_type) or []

        if len(init_value) == queue:
            init_value.append(value)
            setattr(self, counter_type, init_value)
            return True

        try:
            if init_value[queue] is None:
                init_value[queue] = value
            else:
                init_value[queue] += value

        except IndexError:
            # No such queue exists. Create one.
            [init_value.append(None) for _ in range(queue - len(init_value))]
            init_value[-1] = value

        finally:
            setattr(self, counter_type, init_value)

        return True

    def __repr__(self):
        counter_list = []

        for counter in self.counter_list:
            value = getattr(self, counter)
            if isinstance(value, list):
                value = sum([count for count in value if count is not None])

            counter_list.append('%s: %s' % (counter, value))

        return '<' + ' | '.join(counter_list) + '>'


class BaseNIC(object):
    driver_name = None
    default_counters = ['packets', 'bytes', 'drops', 'errors', 'xmit', 'cmpl']
    counter_list = []

    def __init__(self, *args):
        """ If args are passed in they are used as the counter names to add in addition
            to the fixed list of default_counters.
            If no args pased in, then assume the child class added to the counter_list class var
            (which will be _added to_ for every new instance of this class; ie. multiple nics)
            If the counters across different NICs are the same this is ok, since duplicates are removed in CounterBase
            but if not, this can cause issues as the first instance has different counters than the last/newest if
            a NIC with more counters is added _after_ a nic with fewer. Diffs will then break.
            Derived classes should migrate to pass in the counters rather than set self.counter_list as done in freebsd
        """
        counters = list(args) if args else BaseNIC.counter_list
        self.counters = self.default_counters.copy() + counters
        self.rx = CounterBase(*self.counters)
        self.tx = CounterBase(*self.counters)

    @classmethod
    def factory(cls, **kwargs):
        return cls(**kwargs)

    def __sub__(self, stats):
        return self.get_diff(stats, self)

    def __getitem__(self, item):
        return getattr(self, item)

    def get_diff(self, old_stats: 'BaseNIC', new_stats: 'BaseNIC' = None) -> 'BaseNIC':
        """Return stats differences in the format of CastCounter

        If need to return other statistic counter differences, this should be
        override.

        Args:
            old_stats (StatsBase): Statistics object that has old counter values
            new_stats (StatsBase): Statistics object that has new counter values
        """
        new_stats = new_stats or self

        diff_stats = self.factory()
        diff_stats.rx = diff_stats.rx.get_diff(old_stats.rx, new_stats.rx)
        diff_stats.tx = diff_stats.tx.get_diff(old_stats.tx, new_stats.tx)

        return diff_stats

    def set_stats_counter(self, attr, queue, counter_type, value):
        """Set statistics counter number

        Args:
            attr (str): attribute name where values will be set. i.e.) rx, tx
            queue (str, int): queue number
            counter_type (str): counter type. i.e.) packets, bytes
            value (str, int): counter value
        """

        queue = queue if queue is None else int(queue)
        value = int(value)

        counter_obj: CounterBase = getattr(self, attr)
        counter_obj.set_queue_value(counter_type, queue, value)

    @staticmethod
    def get_stats(iface):
        raise NotImplementedError(
            'Should not call StatsBase directly - Call NIC class '
            '(i.e. Cumulus) instead')


def get_stats(iface, **kwargs):
    """Return statistics information of the given iface

    Args:
        iface (str): ethX name
    """

    stats_module = importlib.import_module(
        'controller.lib.{}.eth.stats'.format(platform.system().lower())
    )

    return stats_module.get_stats(iface, **kwargs)
