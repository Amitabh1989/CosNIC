# -*- coding: utf-8 -*-
"""
:mod:`teaming` -- Back-end interface to teaming
===========================================================

.. module:: controller.lib.common.eth.teaming
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>

"""


import abc

from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


log = log_handler.get_logger(__name__)


class BaseTeam(object, metaclass=abc.ABCMeta):
    """
    Teaming operations on NIC adapter. 
    Abstract backend and perform teaming operations with a system depending on
    the method.

    This class uses user-space tools to do 
    teaming/bonding operations on the NIC

    Args:
        team_name (str): Name of the team / bond to be created.

    Returns:
        Interface : Interface object that has methods to interact with
                    the teaming.

    """

    __metaclass__ = abc.ABCMeta
    
    def __init__(self, team_name):
        self.team_name = team_name
        #self.iface = eth.get_interface(self.team_name) 
    
    @abc.abstractmethod
    def create_teaming(self, member_names, team_mode,**kwargs):
        """Create Teaming / Bonding"""
        raise NotImplemented

    @abc.abstractmethod
    def remove_teaming(self):
        """Remove Teaming / Bonding"""
        raise NotImplemented

    @abc.abstractmethod
    def add_team_members(self, member_names, **kwargs):
        """Add Team members"""
        raise NotImplemented
    
    @abc.abstractmethod
    def remove_team_members(self, member_names):
        """Remove Team members"""
        raise NotImplemented
    
    @abc.abstractmethod
    def create_vlan(self, vlan_id=None):
        """Create vlan on teamed port"""
        raise NotImplemented
    
    @abc.abstractmethod
    def remove_vlan(self, vlan_id=None):
        """Remove vlan on Teamed port"""
        raise NotImplemented
    
    @abc.abstractmethod
    def set_team_params(self, **kwargs):
        """Sets parameters on the specified NIC team.
        
        Function, sets the TeamingMode or LoadBalancingAlgorithm parameters 
        on the specified NIC team.
        
        Args:
            team_mode (str): Specifies the mode of the NIC teaming. 
            
            load_balancing (str): Specifies the load-balancing algorithm 
                the new team uses to distribute network traffic between 
                the interfaces.
                
        Returns:
            bool: True if successful else False 
        """
        raise NotImplemented
    
    @abc.abstractproperty
    def get_team_info(self, **kwargs):
        """Function to get teaming / bonding information.
        
        Returns:
            Str if arg else dict
                teaming information. 
        """
        raise NotImplemented
    
    @abc.abstractproperty
    def get_team_member_info(self, **kwargs):
        """Function to get teaming / bonding information.
        
        Returns:
            Str if arg else dict
                team member information. 
        """
        raise NotImplemented