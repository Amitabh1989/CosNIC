"""
:mod:`tshark` -- tshark wrapper
===============================

.. module:: controller.lib.common.eth.tshark
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Tried to use pyshark, but it's buggy (i.e. does not clean up terminated
tshark processes correctly), does not support non-blocking, and does not work
well over RPyC. So decided to create one.

Use temporary file to store the packet data to avoid any buffer overflow.

scapy sniff works mostly well, but IPv6 has some problems.

Some other third party tools are also available (and pyshark was one of them)
but decided to wrap around tshark since it's most reliable and well maintained
packet capture.

Due to the performance issue, the maximum number of packets to be captured
will be limited to 10000. If it's necessary to capture more packets, you should
filter packets using bpf.

There are two formats to capture packets - CSV and PDML.

CSV is much faster and fully customizable, but it stores information as a
single layer dictionary; namely no structured data.

PDML provides very detail information about packets; but obviously, with a
cost of performance.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import os
import platform
import time

from distutils.spawn import find_executable
from controller.lib.core import exception
from controller.lib.core import log_handler

from .parser import csv_parser


log = log_handler.get_logger(__name__)


class TsharkHandler(object):
    """"tshark" process Handler

    Will try to auto-detect the "tshark", but if it fails, you need to manually
    set the path using set_tshark_path()

    """

    def __init__(self):
        self._tshark_path = None
        self._parser = None

    @property
    def tshark_proc(self):
        """Return controller.lib.common.shell.exe Process handler for tshark"""
        return self._parser.tshark_proc

    @property
    def tshark_path(self):
        """Return tshark path. Will raise exception if cannot find one"""
        return self._tshark_path or self.get_tshark_path()

    def get_tshark_path(self):
        filename = 'tshark.exe' if platform.system() == 'Windows' else 'tshark'
        if find_executable(filename):
            return find_executable(filename)

        if platform.system() == 'Windows':
            for path in [
                'C:/Program Files/Wireshark/tshark.exe',
                'C:/Program Files (x86)/Wireshark/tshark.exe',
            ]:
                if os.access(path, os.X_OK):
                    return path

        raise exception.ConfigException(
            'Cannot find tshark. Please set a path to tshark.exe using '
            'set_tshark_path()')

    def set_tshark_path(self, path):
        """Set the tshark path manually"""
        self._tshark_path = path

    def set_parser(self, parser_type, **kwargs):
        if parser_type == 'csv':
            self._parser = csv_parser.Parser(self.tshark_path, **kwargs)
        else:
            raise exception.ValueException('Invalid parser type')

    def sniff(
            self, iface, count=None, timeout=None, bpf=None, parser_type='csv',
            **kwargs):
        """Start sniffing packets as blocking

        Args:
            iface (str): Interface name
            count (int): A number of packets to be captured
            timeout (int): A timeout in secs
            bpf (str): bpf to be passed to tshark
            parser_type (str): Obsolete for now, since "pxml" parser is
                currently disabled
        """
        self.start(iface, count, timeout, bpf, parser_type, **kwargs)

        while self.poll() is None:
            # No additional timeout here, since tshark should handle it
            try:
                time.sleep(1)
            except KeyboardInterrupt:
                self.tshark_proc.kill()
                break
        return True

    def start(
            self, iface, count=None, timeout=None, bpf=None, parser_type='csv',
            tshark_opt_list=None, **kwargs):
        """Start sniffing packets, but as non-blocking

        Args:
            iface (str): Interface name
            count (int): A number of packets to be captured
            timeout (int): A timeout in secs
            bpf (str): bpf to be passed to tshark
            parser_type (str): Obsolete for now, since "pxml" parser is
                currently disabled

        """
        self.set_parser(parser_type, **kwargs)

        if tshark_opt_list is not None:  # not checking type. should be list
            tshark_opt_list = list(tshark_opt_list)

        self._parser.start(iface, count, timeout, bpf, tshark_opt_list)

    def stop(self):
        """Stop the tshark process"""
        if not self._parser:
            log.warning('No parser is set. start() called?')
            return None
        self._parser.stop()

    def poll(self):
        """Poll the tshark process"""
        if not self._parser:
            log.warning('No parser is set. start() called?')
            return None
        return self._parser.poll()

    def get_packet(self):
        """Return captured packets"""
        if not self._parser:
            log.warning('No parser is set. start() called?')
            return None
        return self._parser.get_packet()

