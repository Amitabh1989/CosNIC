from controller.lib.common.shell import exe
from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


class BasePacketList(object):
    def __init__(self):
        self._packet_list = []

    @property
    def packets(self):
        return self._packet_list

    def __len__(self):
        return len(self.packets)

    def __repr__(self):
        return '< tshark | %s packets captured >' % len(self.packets)

    def __iter__(self):
        return iter(self.packets)

    def __getitem__(self, index):
        return self._packet_list[index]

    def parse(self, output):
        # Parse and store packet information
        raise NotImplementedError

    def summary(self):
        raise NotImplementedError


class BaseParser(object):
    MAX_PACKETS = 10000

    def __init__(self, tshark_path):
        self._tshark_proc = None
        self._tshark_path = tshark_path

    @property
    def tshark_proc(self):
        return self._tshark_proc

    def start(
            self, iface, parser_type, count=None, timeout=None, bpf=None,
            tshark_opt_list=None):
        opt_list = ['-i%s' % iface, '-T%s' % parser_type]

        if count is None or count > self.MAX_PACKETS:
            log.warning(
                'Limit the maximum number of packets to %s' % self.MAX_PACKETS)
            count = self.MAX_PACKETS

        opt_list.append('-c%s' % count)

        if timeout:
            opt_list.append('-aduration:%s' % timeout)

        if bpf:
            opt_list.append('-f%s' % bpf)

        opt_list += tshark_opt_list or []

        self._tshark_proc = exe.run(
            [self._tshark_path] + opt_list, stderr=exe.subprocess.PIPE,
            universal_newlines=True
        )

    def stop(self):
        self.tshark_proc.kill()

    def poll(self):
        return self.tshark_proc.poll()

    def get_packet(self):
        # Should return the PacketList object
        raise NotImplementedError
