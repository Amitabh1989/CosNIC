"""
:mod:`csv_parser` -- tshark parser (CSV)
========================================

.. module:: controller.lib.common.eth.tshark.parser.csv_parser
.. moduleauthor:: Eugene Cho <echo@broadcom.com>


The default parser for the tshark library. Comparing to PDML, this is much
faster and reliable, and very customizable as returning requested fields.

By default, this parser returns following fields:

* source MAC address
* destination MAC address
* source IPv4 address
* destination IPv4 address
* source IPv6 address
* destination IPv6 address
* Protocols
* packet length

Basic Usage
-----------
The way to capture the packet is quite simple. First, import the library and
instantiate the object from it

>>> from controller.lib.common.eth import tshark
>>> th = tshark.TsharkHandler()

Now you can start capture the packet using the "th" object. There are two ways
to capture the packets - blocking and non-blocking.

For blocking, you can use "sniff" method.

>>> th.sniff(iface='p1p1', count=10, timeout=10, bpf='tcp')
True

Above line basically means "I will sniff "p1p1" interface, up to 10 packets OR
10 seconds, using BPF filter 'tcp'". You can find the syntrax for bpf at
http://biot.com/capstats/bpf.html

Once it hits timeout or reaches the maximum pakcet number to capture, it will
return True. Now you can get captured packets.

>>> packets = th.get_packet()
>>> packets
< tshark | 10 packets captured >

It seems it successfully captured 10 packets. Let's see what they are.

>>> packets.summary()
['10.13.251.138 -> 10.13.246.101 | eth:ip:tcp:ssh | Length: 114',
 '10.13.246.101 -> 10.13.251.138 | eth:ip:tcp:ssh | Length: 114',
 '10.13.251.138 -> 10.13.246.101 | eth:ip:tcp | Length: 66',
 '10.13.246.101 -> 10.13.241.147 | eth:ip:tcp | Length: 66',
 '10.13.246.101 -> 10.13.241.147 | eth:ip:tcp | Length: 74',
 '10.13.241.147 -> 10.13.246.101 | eth:ip:tcp | Length: 66',
 '10.13.241.147 -> 10.13.246.101 | eth:ip:tcp | Length: 70',
 '10.13.246.101 -> 10.13.241.147 | eth:ip:tcp | Length: 66',
 '10.13.246.101 -> 10.13.241.147 | eth:ip:tcp:data | Length: 74',
 '10.13.241.147 -> 10.13.246.101 | eth:ip:tcp | Length: 66']

And the way to access the information is simple, since each packet is a
dictionary.

>>> packets[0]
{'eth.dst': '44:a8:42:32:53:f0',
 'eth.src': '00:50:56:83:6c:6f',
 'frame.len': '114',
 'frame.protocols': 'eth:ip:tcp:ssh',
 'ip.dst': '10.13.246.101',
 'ip.src': '10.13.251.138',
 'ipv6.dst': '',
 'ipv6.src': ''}

That's pretty much it.

Advance Usage
-------------
Obviously sometimes you need more information than what the default fields
return. One good example is when you want to compare TCP checksum. Let me go
over this example.

First, import and instantiate.

>>> from controller.lib.common.eth import tshark
>>> th = tshark.TsharkHandler()

And then start the sniff, but with special "field_list" arguments. Available
fields that you can pass here are defined at
https://www.wireshark.org/docs/dfref/

>>> field_list = ['ip.src', 'ip.dst', 'tcp.checksum', 'tcp.checksum_calculated']
>>> tshark_opt_list = ['-otcp.check_checksum:TRUE']
>>> th.sniff(iface='p1p1', count=10, bpf='tcp', tshark_opt_list=tshark_opt_list, field_list=field_list)
True

.. warning::
   It's not recommended to use "sniff" method over RPyC, especially you need to
   send Ctrl+C which will not be passed to the server but only terminates the
   local one. To sniff over RPyC, use "start" instead which is non-blocking and
   you can terminate the process as you are done.

Now get the packets.

>>> packets = th.get_packet()
>>> packets.summary()
['10.13.251.138 -> 10.13.246.101',
 '10.13.246.101 -> 10.13.251.138',
 '10.13.251.138 -> 10.13.246.101',
 '10.13.246.87 -> 10.13.246.101',
 '10.13.246.101 -> 10.13.246.87',
 '10.13.246.101 -> 10.13.246.87',
 '10.13.246.87 -> 10.13.246.101',
 '10.13.246.101 -> 10.13.251.138',
 '10.13.251.138 -> 10.13.246.101',
 '10.13.246.101 -> 10.13.246.87']

Because we didn't capture all information, summary shows only what available
ones, which is IPv4 source and destination this case.

And if you look at the packet ...

>>> packets[0]
{'ip.dst': '10.13.241.95',
 'ip.src': '10.13.241.81',
 'tcp.checksum': '0x0000eaf9',
 'tcp.checksum_calculated': '0x0000eaf9'}

Alright, now you have information what you wanted to have. Actual checksum
as well as the calculated one.

.. warning::
   "tcp.checksum_calculated" is only available in the latest Wireshark and
   the extra option "-otcp.check_checksum:TRUE" must be enabled. Otherwise
   "tcp.checksum_calculated" will be empty string.

So you can get any fields that you are interested using this library.

"""

import csv

from . import BaseParser, BasePacketList
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)

class PacketList(BasePacketList):
    def __init__(self, field_list):
        super(PacketList, self).__init__()
        self._field_list = field_list

    def parse(self, output):
        """Parse and add processed packets to self._packet_list

        Unlike PXML which require to wait for entire tree before parsing,
        this can be called anytime since "exe" will return output as a line
        base. Which means parsing and processing packets can happen while
        tshark is still running

        Performance wise, this would be better comapring to PXML but will lose
        some structure-model, such as layers due to having a single layer
        data structure

        Due to using the field name as a key, will store data as a dictionary

        """
        csv_reader = csv.reader(output.splitlines())

        for data_line in csv_reader:
            self._packet_list.append(dict(list(zip(self._field_list, data_line))))

    def summary(self):
        ret_list = []

        for packet in self._packet_list:
            packet_info = []

            if packet['ip.src'] and packet['ip.dst']:
                packet_info.append('%s -> %s' % (packet['ip.src'], packet['ip.dst']))
            elif packet['ipv6.src'] and packet['ipv6.dst']:
                packet_info.append('%s -> %s' % (packet['ipv6.src'], packet['ipv6.dst']))
            else:
                packet_info.append('%s -> %s' % (packet['eth.src'], packet['eth.dst']))

            if 'frame.protocols' in packet:
                packet_info.append(packet['frame.protocols'])

            if 'frame.len' in packet:
                packet_info.append('Length: %s' % packet['frame.len'])

            ret_list.append(' | '.join(packet_info))

        return ret_list


class Parser(BaseParser):
    """Parser for Wireshark + CSV output

    By default, capture following fields

    MAC src, MAC dst, IP src, IP dst, IPv6 src, IPv6 dst, protocols,
    packet length

    Args:
        field_list (list): List of fields to be captured from packets. Refer
            "-e" option of tshark.
    """
    def __init__(self, tshark_path, field_list=None):
        super(Parser, self).__init__(tshark_path)
        self._field_list = field_list or ['eth.src', 'eth.dst', 'ip.src', 'ip.dst', \
            'ipv6.src', 'ipv6.dst', 'frame.protocols', 'frame.len']
        self._packet_list = PacketList(self._field_list)

    def start(self, iface, count=None, timeout=None, bpf=None, tshark_opt_list=None, **kwargs):
        field_list = ['-e%s' % field for field in self._field_list]
        csv_opt_list = ['-Eseparator=,', '-Equote=d']
        tshark_opt_list = tshark_opt_list or []

        super(Parser, self).start(iface, 'fields', count, timeout, bpf, \
            tshark_opt_list=field_list + csv_opt_list + tshark_opt_list)

    def get_packet(self):
        self._packet_list.parse(self.tshark_proc.get_output())
        return self._packet_list

def unittest():
    from controller.lib.common.eth import tshark
    log.root.level = 10
    th = tshark.TsharkHandler()
    th.start(iface='p5p1', timeout=10, parser_type='csv')
    packet_list = th.get_packet()
    log.info('Packet number: %s' % len(packet_list))
    return th

if __name__ == '__main__':
    unittest()
