"""
:mod:`tunnel` -- Abstract class module for tunneling
====================================================

.. module:: controller.lib.common.eth.tunnel
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""


from controller.lib.common import eth


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


class BaseTunnel(object):
    def __init__(self, iface):
        self._iface = iface
        self._ctrl = eth.get_interface(iface=iface)

        vnic_name = self.ctrl.get_vnic()
        self._vctrl = eth.get_interface(iface=vnic_name) if vnic_name else None

    @property
    def iface(self):
        return self._iface

    @property
    def ctrl(self):
        return self._ctrl

    @property
    def vctrl(self):
        return self._vctrl

    @classmethod
    def factory(cls, iface, **kwargs):
        return cls(iface, **kwargs)

    def add(self, **kwargs):
        raise NotImplementedError

    def remove(self, **kwargs):
        raise NotImplementedError

