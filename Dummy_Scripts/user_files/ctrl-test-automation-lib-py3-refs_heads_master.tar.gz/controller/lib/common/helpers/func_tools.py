import copy
import inspect
import logging
import time
from itertools import repeat
from typing import Callable, Any, Iterator, Union

log = logging.getLogger(__name__)


def get_api_callables(obj) -> list:
    """Get names of object functions and methods that do not start with '_'."""
    routines = inspect.getmembers(obj, lambda m: inspect.isroutine(m))
    return [m[0] for m in routines if m[0].startswith('_') is False]


def poll(func: Callable, *args, expected: Any = True, max_wait: float = 300.0,
         check_interval: float = 10.0, ignore_exceptions: bool = False, **kwargs) -> bool:
    """Execute c given function until it returns the provided expected value within given max_time - return True,
    else return False.
    This is a straight forward blocking implementation. Please use something else if you need async polling,
    event-based execution, or any other form of concurrency.

    *args and **kwargs will be passed to the function.

    .. note::

        This implementation is about time to spend to poll a function rather than the exact number of attempts.
        Please choose the max_wait and check_interval wisely. If you need at least 4 execution attempts and
        the func call usually takes less than 1-second try max_wait=20 and check_interval=4, then in most cases
        there will be 5 attempts.
        Due to some reasons, e.g., bug or high load or high network/CPU usage, the func() call may take different
        amount of time.

    .. note::

        The poll() does not limits a func() execution time nor interrupt the func call.
        If func execution will take more them max_wait the function will be executed at least once.

    :param func: Callable object which return value will be evaluated to determine success.
    :param expected: the value of any type which we expect from the function to consider "success" and stop polling.
                     With an instance of a user defined class, please ensure that __eq__ and __ne__ are implemented.
    :param max_wait: time to poll the function before return False
    :param check_interval: desired time in seconds between each func call. Func call won`t be interrupted if takes
                           more than the check interval.
    :param ignore_exceptions: ignore exceptions on attempt to execute function.
    """
    check_timing_values(max_wait, check_interval)

    max_time = time.time() + max_wait

    loop_start = time.time()
    while loop_start < max_time:
        try:
            if func(*args, **kwargs) == expected:
                return True
        except Exception as err:
            if ignore_exceptions:
                log.debug(f'Ignore {repr(err)} during polling function {func.__name__}.')
            else:
                raise err

        possible_wait = check_interval - (time.time() - loop_start)
        if possible_wait > 0:
            time.sleep(possible_wait)

        loop_start = time.time()

    return False


def poll_not(func: Callable, *args, condition: Any = None, max_wait: float = 300.0,
             check_interval: float = 10.0, **kwargs) -> Any:
    """Execute c given function until it returns result different than "condition".

    This function is similar as poll() but waits till something else then condition is returned.
    In current implementation it does not handle exception but it is further improvement.

    We can`t return None/False here in this case because the value may not be correctly interpreted by a caller.

    :param func: Callable object which return value will be evaluated to determine success.
    :param condition: the value of any type which we DO NOT expect from the function.
                      ANy other values considered as "success" and stop polling.
                     With an instance of a user defined class, please ensure that __eq__ and __ne__ are implemented.
    :param max_wait: time to poll the function before raise Timeout exception
    :param check_interval: desired time in seconds between each func call. Func call won`t be interrupted if takes
                           more than the check interval.
    :return: first function output which different than result.
    """
    check_timing_values(max_wait, check_interval)
    max_time = time.time() + max_wait

    loop_start = time.time()
    while loop_start < max_time:
        out = func(*args, **kwargs)
        if out != condition:
            return out

        possible_wait = check_interval - (time.time() - loop_start)
        if possible_wait > 0:
            time.sleep(possible_wait)

        loop_start = time.time()

    raise TimeoutError(f'Polling function {func.__name__}() for result different than {condition} has failed.')


def check_timing_values(max_wait, check_interval):
    if max_wait < check_interval:
        raise ValueError(f'Max wait for polling {max_wait} should be more more than '
                         f'the check interval {check_interval}.')
    if check_interval < 0.2:
        raise ValueError(f'The check interval {check_interval} is less than minimum allowed 0.2 second.')


def define_num_of_workers(args, kwargs) -> int:
    """Define number of threads or class instances to handle the arguments."""
    if isinstance(args, list) and isinstance(kwargs, list):
        if len(args) != len(kwargs):
            raise ValueError('Positional and keywords arguments lists should have equal length.')
        else:
            return len(args)

    if args is None and kwargs is None:
        return 1

    if isinstance(kwargs, list):
        kwargs_len = len(kwargs)
    else:
        kwargs_len = 1

    if isinstance(args, list):
        args_len = len(args)
    else:
        args_len = 1

    return max(kwargs_len, args_len)


def get_len(itr, max_len: int = 256) -> int:
    """Get length of an iterable object, raise exception if it is greater than max_len.

    Iterable may be `endless`, so that this function used to get and validate against max size.

    **If "itr" is an iterator, it can`t be used again.**
    This function is useful when we can create an iterable
    object multiple times and would like to know the length in advance.

    :param itr: Iterable object that should be measured.
    :param max_len: max allowed length for an endless iterators.
    """
    try:
        size = len(itr)
    except TypeError:
        size = 0
        for _ in itr:
            size += 1
            if size > max_len:
                break

    if size > max_len:
        raise ValueError(f'The provided iterator has length more than max allowed {max_len}.')

    return size


def try_to_call_func_with_check(func: Callable, *args, check: bool = True, **kwargs):
    try:
        result = func(*args, check=check, **kwargs)
    except TypeError as err:
        if "argument 'check'" in repr(err):
            result = func(*args, **kwargs)
        else:
            raise err

    return result


def prepare_arguments(args=None, kwargs=None, n: int = 0) -> Iterator:
    """Prepare positional and keyword arguments.

    Return zip object with two iterables which returns (list, dict) on iteration.
    Each (list, dict) represents a function call arguments.

    >>> ips = ['127.0.0.1', '8.8.8.8']
    >>> packets = [dict(packets=10), dict(packets=4)]
    >>> prepare_arguments(ips, packets)
    [(['127.0.0.1'], {packets=10}) , (['8.8.8.8'], {packets=4})]

    >>> ips = ['127.0.0.1', '8.8.8.8']
    >>> packets = dict(packets=10]
    >>> prepare_arguments(ips, packets)
    [(['127.0.0.1'], {packets=10}) , (['8.8.8.8'], {packets=10})]

    >>> ips = '127.0.0.1'
    >>> packets = [dict(packets=10), dict(packets=4)]
    >>> prepare_arguments(ips, packets)
    [(['127.0.0.1'], {packets=10}) , (['127.0.0.1'], {packets=10})]

    >>> ips = [['127.0.0.1', 1], ['8.8.8.8', 2]]
    >>> packets = [dict(packets=10, dnf=1), dict(packets=4, dnf=0)]
    >>> prepare_arguments(ips, packets)
    [(['127.0.0.1', 1], {packets=10, dnf=1}) , (['127.0.0.1', 2], {packets=10, dnf=0})]

    :param args: represents positional argument of a function call.
                  In case of list, each element of the list represents a single function call.
                  For an other data type, the element will be repeated in all iterations.
    :param kwargs: dict or list represents keyword arguments of a function call.
                   if kwargs is a dict - it will be repeated in all elements - same argument for all calls.
                   In case of list, each element of the list represents a single function call.
    :param n: number of elements to prepare.
    """
    if isinstance(args, list) and isinstance(kwargs, list):
        if len(args) != len(kwargs):
            raise ValueError('Positional and keywords arguments lists should have equal length.')

    if kwargs is not None and isinstance(kwargs, (list, dict)) is False:
        raise ValueError('Keywords arguments are expected in list or dict format.')

    prepared_args = []

    if args is None and kwargs is None:
        raise TypeError('At least one of Positional or keywords arguments should not be None.')

    if args is None or args == []:
        if n:
            prepared_args = [[] for _ in range(n)]
        else:
            prepared_args = repeat([])
    elif isinstance(args, list) is False:
        prepared_args = repeat([args])
    else:
        for arg in args:
            if isinstance(arg, list) is False:
                prepared_args.append([arg])
            else:
                prepared_args.append(arg)

    if kwargs is None:
        if n:
            prepared_kwargs = [{} for _ in range(n)]
        else:
            prepared_kwargs = repeat({})
    elif isinstance(kwargs, dict) is True:
        if n:
            prepared_kwargs = [kwargs for _ in range(n)]
        else:
            prepared_kwargs = repeat(kwargs)
    else:
        prepared_kwargs = kwargs

    return zip(prepared_args, prepared_kwargs)


def prep_pos_arguments(pos_args: Union[list, tuple], n: int) -> list:
    """Prepare positional arguments to be used in function calls.

    Limitation of arguments: args of type list must be provided in a list of len N.

    Non-list element will be placed in a new list N times.
    """
    res_args = [[] for _ in range(n)]

    if isinstance(pos_args, (tuple, list)):
        for arg in pos_args:
            if isinstance(arg, list):
                if len(arg) != n:
                    raise ValueError('Number of List argument does not match to number of calls.')

                # list of arguments, one to one match with calls.
                for i in range(n):
                    res_args[i].append(arg[i])
            else:
                for call_args in res_args:
                    call_args.append(arg)
    elif pos_args:
        for call_args in res_args:
            call_args.append(pos_args)

    return res_args


def prep_keyword_arguments(kw_args: dict, n: int) -> list:
    """Prepare keyword arguments to be used in function calls.

    Limitation of arguments: args of type list must be provided in a list of len N.

    Non-list values will be placed in a new list N times.
    """
    if kw_args and isinstance(kw_args, dict) is False:
        raise ValueError('Keywords arguments are expected in dict format.')

    res_kwargs = [{} for _ in range(n)]

    if kw_args:
        for key, value in kw_args.items():
            if isinstance(value, list):
                if len(value) != n:
                    raise ValueError('Number of List argument does not match to number of calls.')

                for i in range(n):
                    res_kwargs[i][key] = value[i]

            else:
                for call_kwargs in res_kwargs:
                    # apply non list argument to each call.
                    call_kwargs[key] = value

    return res_kwargs


def make_positional_and_kw_args(n: int,
                                args: tuple = None,
                                kwargs: dict = None,
                                call_args: list = None,
                                call_kwargs: list = None) -> Iterator:
    """Make iterable object that will represents a call arguments based on either call format or intuitive format.

    Resulted iterable will have 2 elements tuple on each iteration  (list, dict)
    where list represens positional arguments of a call and dict - keyword arguments.

    Option A. Prepared Call arguments.
    call_args/call_kwargs expects values already grouped to be used in calls.

        tcpdump_pos = [['p1p1', '33.3.3.3', '33.3.3.4'],
                      ['p1p1', '33.3.3.3', '33.3.3.4'],
                      ['p1p2', '33.3.3.3', '33.3.3.4']]
        tcpdump_kwargs = [{'protocol': 'tcp'}, {'protocol': 'udp'}, {'protocol': 'tcp'}]
        res = make_positional_and_kw_args(3, call_args=tcpdump_pos, call_kwargs=tcpdump_kwargs)

    Option B. User intuitive option.

        interfaces = ['p1p1', 'p1p1', 'p1p2']
        src_ips = '33.3.3.3'
        dst_ips = '33.3.3.4'
        protocols = ['tcp', 'udp', 'tcp']
        res = make_positional_and_kw_args(3, args=[interfaces, src_ips, dst_ips], kwargs={'protocol': protocols})

    In both calls res will be
        [(['p1p1', '33.3.3.3', '33.3.3.4'], {'protocol': 'tcp'}),
         (['p1p1', '33.3.3.3', '33.3.3.4'], {'protocol': 'udp'}),
         (['p1p2', '33.3.3.3', '33.3.3.4'], {'protocol': 'tcp'})]

    Only one of the options may be used. Please look at the unit tests for more examples.
    """
    if any((call_args, call_kwargs)) and any((args, kwargs)):
        raise ValueError('Please use either call arguments or normal arguments. Don`t mix them.')

    if args or kwargs:
        prep_args = prep_pos_arguments(args, n)
        prep_kwargs = prep_keyword_arguments(kwargs, n)
        prepared_arguments = zip(prep_args, prep_kwargs)

    elif call_args or call_kwargs:
        prepared_arguments = prepare_arguments(call_args, call_kwargs, n=n)
    else:
        prepared_arguments = iter([([], {}) for _ in range(n)])
    prepared_arguments = [(copy.deepcopy(args), copy.deepcopy(kwargs)) for args, kwargs in prepared_arguments]
    return prepared_arguments
