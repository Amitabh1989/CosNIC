import logging
from concurrent import futures
from concurrent.futures import ThreadPoolExecutor, FIRST_EXCEPTION, ALL_COMPLETED
from typing import Callable, Union, Any

from controller.lib.linux import set_default_cli
from controller.lib.common.helpers.func_tools import define_num_of_workers, make_positional_and_kw_args


logger = logging.getLogger(__name__)


def cancel_tasks(tasks):
    cancelled = 0
    not_cancelled = 0
    logger.debug('Trying to cancel tasks... Running tasks can`t be cancelled.')
    for task in tasks:
        if task.done() is False:
            task.cancel()
            if task.cancelled():
                cancelled += 1
            else:
                not_cancelled += 1
    logger.debug(f'Successfully cancelled: {cancelled}. Failed to cancel: {not_cancelled}.')


def call_in_threads(func: Union[list, Callable],
                    *args,
                    all_args: Any = None,
                    all_kwargs: Union[list, dict] = None,
                    workers: int = None,
                    raise_err: str = '',
                    timeout: int = None,
                    total_calls: int = None,
                    **kwargs,
                    ) -> list:
    """Call a callable object(s) in threads with provide arguments.

    The main challenge here is automatically define number or threads to use.
    Provided arguments may be an endless iterator.

    # func1 will be called in threads 500 times but only 10 threads will be used simultaneously.
    call_in_threads(func1, total_calls=500, workers=10)

    This function wraps the ThreadPoolExecutor - an high level API for threading module.
    https://docs.python.org/3.6/library/concurrent.futures.html

    >>> def ping_linux(dst_ip, packets):
    ...     # Mock to demo
    ...     return dst_ip, packets
    ...
    >>> ips = ['127.0.0.1', '8.8.8.8']
    >>> num_packets=[10,4]
    >>> results = call_in_threads(ping_linux, ips, packets=num_packets)
    [('127.0.0.1' 10), ('8.8.8.8', 4)]

    This call with real ping would execute ping function in threads with next arguments:
    ping 127.0.0.1 -c 10
    ping 8.8.8.8 -c 4

    >>> from itertools import cycle
    >>>
    >>> def do_something(a, b):
    ...     # Mock to demo
    ...     return a, b
    ...
    >>> results = call_in_threads(do_something, 'a', 0, total_calls=6, workers=2)
    [('a', 0), ('a', 0), ('a', 0), ('a', 0), ('a', 0), ('a', 0)]

    *args and **kwards of this call will be treated as arguments to be passed to each function call.

    When an argument is not a list - it will be repeated for each call. If argument is a list, the length
    of that list defines number of calls if total_calls not defined and do_something is not a list.

    Assume that tcpdump() is a function that starts tcpdump and return pid of new process.

    Option A. Prepared Call arguments.
    all_args/all_kwargs expects values already grouped to be used in calls.

        tcpdump_pos = [['p1p1', '33.3.3.3', '33.3.3.4'],
                      ['p1p1', '33.3.3.3', '33.3.3.4'],
                      ['p1p2', '33.3.3.3', '33.3.3.4']]
        tcpdump_kwargs = [{'protocol': 'tcp'}, {'protocol': 'udp'}, {'protocol': 'tcp'}]
        res = call_in_threads(tcpdump, 3, all_args=tcpdump_pos, all_kwargs=tcpdump_kwargs)

    Option B. User intuitive option.

        interfaces = ['p1p1', 'p1p1', 'p1p2']
        src_ips = '33.3.3.3'
        dst_ips = '33.3.3.4'
        protocols = ['tcp', 'udp', 'tcp']
        res = call_in_threads(tcpdump, 3, interfaces, src_ips, dst_ips, protocol=protocols)

    In both calls res will be
        [(['p1p1', '33.3.3.3', '33.3.3.4'], {'protocol': 'tcp'}),
         (['p1p1', '33.3.3.3', '33.3.3.4'], {'protocol': 'udp'}),
         (['p1p2', '33.3.3.3', '33.3.3.4'], {'protocol': 'tcp'})]

    Only one of the options may be used. Please look at the unit tests for more examples.

    For more details, please  look at the make_positional_and_kw_args().

    :param func: callable object to be called in threads.
    :param all_args: list with positional arguments to be passed to the function.
    :param all_kwargs: list with keyword arguments to be passed to the function.
    :param workers: max number of workers to be used - number of parallel threads.
    :param raise_err: Define when function should raise an exception.
                    'execution' - check threads for exception during execution and raise when possible.
                                  Not reliable, may not work in come cases.
                    'complete' - check and raise exception after all executions completed.
    :param timeout: Timeout for function execution. The timeout guarantees the timeout exception raised
                    but does not guarantee that a task will be stopped by a timeout.
                    One can`t easily interrupt an arbitrary thread so if a function has a bug - it can be
                    endless execution.
    :param total_calls: Number of total calls of a callable object(s) using `worker` number of threads.
                        Optional, the function tries ti calculate the total number of calls using len of
                        func/arguments.
                        Should be defined if func is not a list and nor all_args nor all_kwargs.
    :return: list with output of the provided callable for each arguments in order of arguments.
    """
    if isinstance(func, list):
        # TODO Function does nor do a vaildation between number of functions provided and len args/kwargs.
        names = [f.__name__ for f in func]
        func_is_list = True
    else:
        names = func.__name__
        func_is_list = False

    len_arg = 0
    for arg in args:
        if isinstance(arg, list):
            len_arg = len(arg)
            break

    if not total_calls:
        # try to detect number of time to call the function.
        if func_is_list:
            total_calls = len(func)
        elif all_args or all_kwargs:
            total_calls = define_num_of_workers(all_args, all_kwargs)
        elif not all_args and not all_args and not args and not kwargs:
            total_calls = 1
        elif len_arg:
            total_calls = len_arg
        else:
            raise ValueError('Can`t calculate Number of threads. Please provide total_calls.')

    prepared_arguments = make_positional_and_kw_args(total_calls, args, kwargs, all_args, all_kwargs)

    workers = workers or total_calls
    if workers > 50:
        raise UserWarning(f'Too may workers to spawn: {workers}!')

    logger.debug(f'Execute {names} using {workers} threads.')

    with ThreadPoolExecutor(max_workers=workers) as executor:
        tasks = []
        if prepared_arguments:
            if func_is_list:
                for f, (args, kwargs) in zip(func, prepared_arguments):
                    tasks.append(executor.submit(f, *args, **kwargs))
            else:
                for args, kwargs in prepared_arguments:
                    tasks.append(executor.submit(func, *args, **kwargs))
        else:
            if func_is_list:
                for f in func:
                    tasks.append(executor.submit(f))
            else:
                for _ in range(total_calls):
                    tasks.append(executor.submit(func))

        results = []
        if raise_err == 'execution':
            progress_task = futures.wait(tasks, timeout=timeout, return_when=FIRST_EXCEPTION)
            logger.debug(f'Progress tasks: {progress_task}')
            if len(progress_task.done) == 0:
                logger.warning(f'A thread execution has not been completed in {timeout} seconds.\n')
                cancel_tasks(tasks)
                executor.shutdown(wait=False)
                raise futures.TimeoutError
            elif len(progress_task.not_done) > 0 or any(t.exception(0.01) for t in progress_task.done):
                # Check in second part handles scenario when an exception has been triggered by last task
                # and progress_task.not_done will be empty.
                exception = None
                for task in progress_task.done:
                    res = task.exception(0.01)
                    if res is None:
                        results.append(task.result(0.01))
                    else:
                        exception = res
                logger.info(f'Execution in threads has been failed with exception {repr(exception)}.\n'
                            f'Collected results for now in arbitrary order {results}.\n'
                            'Trying to shutdown the Thread executor but running threads will not be stopped.')
                cancel_tasks(progress_task.not_done)
                executor.shutdown(wait=False)
                raise exception
            else:
                for task in progress_task.done:
                    results.append(task.result(0.01))
        else:
            futures.wait(tasks, timeout=timeout, return_when=ALL_COMPLETED)
            for task in tasks:
                err = task.exception(0.01)
                if err is None:
                    results.append(task.result(0.01))
                else:
                    results.append(err)

    logger.debug(f'Threads execution result: {results}')
    if raise_err == 'complete':
        for result in results:
            if isinstance(result, Exception):
                raise result

    return results


@set_default_cli
def run_in_threads(cmds: Union[list, str], check=True, timeout=None, raise_err: str = '', cli: callable = None):
    """Run command or commands in threads using cli executor.

    Using timeout is highly recommended. In cases on 'hanged' threads e.g. 'wile true' in a thread won`t
    allow to stop execution by Ctrl+C/Ctrl+Z.

    # run a cli command in threads.
    run_in_threads(['ping 127.0.0.1 -c 3', 'ping 1 -c 5'], timeout=8, check=True)

    :params cmds: command or commands to execute in thread.
    :params check: Defines should a command raise ExeCodeException in case of 0 exit code.
    :params timeout: max time to wait until a command will be executed.
    :params raise_err: Define when function should raise an exception.
                    'execution' - check threads for exception during execution and raise asap.
                               it does not interrupt a running tasks and have little sense for this function.
                    'complete' - check and raise exception after all executions completed.
                    If not set, 'complete' wil be used is 'check' is True.
    :params cli: callable command executor which is able to execute command.
    :return: list of  commands executions outputs ino order of appearance.
             An exception raised by a an execution will be returned as Exception object if not raised.
    """
    kwargs = dict(check=check, timeout=timeout)
    if check and raise_err == '':
        raise_err = 'complete'
    return call_in_threads(cli, all_args=cmds, all_kwargs=kwargs, raise_err=raise_err)
