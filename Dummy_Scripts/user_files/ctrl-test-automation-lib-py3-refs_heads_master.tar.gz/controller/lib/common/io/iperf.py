"""
:mod:`iperf` -- Run iperf client/server
=======================================

.. module:: controller.lib.common.io.iperf
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This EI library provides some simple functions to use the iperf as well as
client/server classes that provide low-level access of throughput data and
iperf process control.

Support both Linux and Windows.

To use the iperf library, the obvious first step - you need to import the
module.

>>> from controller.lib.common.io import iperf

iperf EI has two major classes - called "Client" and "Server". The names
themselves are clear enough to tell what they do - and here are some examples.

Let's do the simple iperf testing - start the server, and run the client
through the loopback interface, namely destination IP is "127.0.0.1"

Create a server instance and start it is simple.

>>> server = iperf.Server()
>>> server.start()

.. note::

   As an example, here we start iperf server, but recommendation is to run
   iperf server as daemon so you do not need to start server separately.

.. note::

   If you see an error "Cannot find iperf. Please set the path to the iperf
   using IperfBase.set_iperf_path(<path_to_iperf>)", you need to update the
   path of iperf manually. For example,

  >>> iperf.set_iperf_path('C:\iperf\iperf.exe')

Note that "start()" function returns a integer number - "pid". You can track
status of the server using it.

Now let's create a client instance and start iperf.

>>> client = iperf.Client()
>>> client.start(dst_ip='127.0.0.1')
2015-04-30 11:20:12,554|INFO    |Starting iperf ... (command: /usr/bin/iperf  -c localhost -y C -i 1)

Because information is available on the client side, mostly you only need
to interact with the "client" object. For example, if you want to get
throughputs,

>>> client.get_throughput()
['3341287424', '5317263360', '5317328896', '5311365120']
>>> client.get_throughput()
['3341287424',
 '5317263360',
 '5317328896',
 '5311365120',
 '5327814656',
 '5346361344',
 '5358288896',
 '5345968128',
 '5356781568',
 '5366677504',
 '5138886205']


It's bit difficult to read, since they are just numbers. This is the default
output when you do NOT provide any options to get_throughput() function.

What it does is to return a list of the collected throughput in bps. Note that
iperf library collects data every second by passing an option "-i 1" to client.

Which means - when get_throughput() was called at the first time in the
above example, it only had four available data entries at that moment when
iperf client was running. After waiting 10 secs (which is a default running
time of iperf), now it shows 11 data entries - 10 throughputs data of each
interval from 0 to 10, and the sum of throughput that iperf reports at the exit.

If you are only interested the throughput that iperf reports at exit, yuo can
call a function that returns it only.

>>> client.get_sum_throughput()
'5138886205'

.. note::

   get_sum_throughput() returns None if iperf is still running

get_sum_throughput() accepts "fmt" argument which returns as the given format.
Namely you can customize hwo the return value looks like.

If you want sometihng that looks like iperf outupt? Try this.

>>> client.get_sum_throughput(
... output_format='[ %id]  %int_stime-%int_etime sec  %tx_gbytes Gbytes  %gbps Gbits/sec')
'[ 3]  0.0-10.0 sec  6.20 Gbytes  5.32 Gbits/sec'

Pretty cool, huh?

Here are variables that will be replaced by the function.

* %timestamp: timestamp
* %src_ip: source IP address
* %src_port: source port
* %dst_ip: destination IP address
* %dst_port: destination port
* %id: ID
* %int_stime: interval start time
* %int_etime: interval end time
* %tx_bytes: transferred bytes
* %tx_kbytes: transferred kbytes
* %tx_mbytes: transferred mbytes
* %tx_gbytes: transferred gbytes
* %bps: bit per second
* %kbps: kbit per second
* %mbps: mbit per second
* %gbps: gbit per second
* %Kbps: kbyte per second
* %Mbps: Mbyte per second
* %Gbps: Gbyte per second

Since we got what we wanted, let's stop the server.

>>> server.stop()
True

If it returns True, the iperf server is terminated successfully.

"""

__version__ = "1.1.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

import operator
import re
import sys
from distutils.spawn import find_executable
from typing import List

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


def convert_time(input_time):
    try:
        number, base = re.match(r'(\d+)([hms]?)$', str(input_time)).groups()
    except AttributeError:
        raise exception.ValueException(
            'The given input_time value %s is not correct. Acceptable format: '
            '<number>[h|m|s> (i.e. 3h, 45m)' % input_time)

    if base == 'm':
        return int(number) * 60
    if base == 'h':
        return int(number) * 3600

    return int(number)


class IperfData:
    """A picklable iperf data object.

    """
    if sys.version_info[0] >= 3:
        d_type = int
    else:
        u_code = str
        d_type = int
    IPERF_DATA_INDEX_MAPPING = [
        ('timestamp', int),
        ('src_ip', str),
        ('src_port', int),
        ('dst_ip', str),
        ('dst_port', int),
        ('id', int),
        ('interval', list),
        ('tx_bytes', int),
        ('bps', d_type),  # bit per second
    ]

    IPERF_UDP_DATA_INDEX_MAPPING = IPERF_DATA_INDEX_MAPPING + [
        ('jitter', float),
        ('lost_diagram', int),
        ('sent_diagram', int),
        ('percent_loss', float),
        ('received_diagram', int),
    ]

    DATA_ATTRS = [map_element[0] for map_element in IPERF_DATA_INDEX_MAPPING
                  if map_element[0] != 'interval'] + ['int_stime', 'int_etime']

    def __init__(self, iperf_data_line):
        """
        Args:
            iperf_data_line (str): A single line that iperf prints with the
                '-y C' option
        """
        self.total_sum = False
        self.interval_sum = None  # None=Unknown, True=multithread+src_port=0
        self.raw_data = None
        self.int_stime = 0
        self.int_etime = 0
        # Update the data values using the given iperf output
        self.set_converted_data(iperf_data_line)

    def __str__(self) -> str:
        return str(self.get_data_info())

    def set_converted_data(self, iperf_data_line):
        """Parse the iperf's output line, convert it to numbers and store
        them as attributes to the self.

        Args:
            iperf_data_line (str): A single line of iperf output

        """
        # Store the raw data
        self.raw_data = iperf_data_line
        iperf_data = iperf_data_line.split(',')

        if len(iperf_data) not in [len(self.IPERF_DATA_INDEX_MAPPING), len(self.IPERF_UDP_DATA_INDEX_MAPPING)]:
            raise exception.IperfDataException('Data types %s is not expected %s or %s. '
                                               'Output: %s' % (len(iperf_data), len(self.IPERF_DATA_INDEX_MAPPING),
                                                               len(self.IPERF_UDP_DATA_INDEX_MAPPING), iperf_data_line))

        data_map = self.IPERF_DATA_INDEX_MAPPING
        if len(iperf_data) != len(self.IPERF_DATA_INDEX_MAPPING):
            data_map = self.IPERF_UDP_DATA_INDEX_MAPPING

        for idx, iperf_item in enumerate(iperf_data):
            field_name, field_type = data_map[idx]
            # If interval, separate the start/end intervals and save them as float fields
            if field_name == 'interval':
                stime, etime = iperf_item.split('-')
                setattr(self, 'int_stime', float(stime))
                setattr(self, 'int_etime', float(etime))
            else:
                setattr(self, field_name, field_type(iperf_item))

    @staticmethod
    def __get_num_matched(data_value, exprs):
        """A special handler for any integer or float types compare, to support
        >, <, ! and =.

        Args:
            data_value (str, int, float): A stored value
            exprs (str, int, float): An expression to compare with parameter
                "data_value"
        """
        ACCEPTABLE_OPERATORS = {'<': operator.lt, '<=': operator.le, '>': operator.gt, '>=': operator.ge}

        if sys.version_info[0] >= 3:
            u_code = str
            d_type = int
        else:
            u_code = str
            d_type = int
        if not isinstance(data_value, (int, d_type, float)) or not isinstance(exprs, (str, u_code)):
            # Not integer/float, and the exprs is not string
            # (namely no operator exists)
            # No need to compare. Return None.
            return None

        if re.match(r'([<>=!]=?)\s*(\d+\.?\d*)', exprs):
            opr, exprs_num = re.match(r'([<>!]=?)\s*(\d+\.?\d*)', exprs).groups()
            return ACCEPTABLE_OPERATORS[opr](data_value, float(exprs_num))

        raise exception.ValueException(f'The given expression {exprs} is incorrect')

    def get_matched(self, **kwargs):
        """Return True if the data is matched with the given filter arguments

        Args:
            **kwargs: keyword arguments to check conditions i.e.) src_port=0,
                src_ip='192.168.1.1'

                If value is None, it means 'match any'. You can specify a
                custom function to check using 'func' keyword

        """
        if 'debug' in kwargs:
            import ipdb
            ipdb.set_trace()

        for field_name, value in list(kwargs.items()):
            if value is None:  # Match any
                continue  # Check the next condition. Assume matched.

            if hasattr(self, field_name):
                field_value = getattr(self, field_name)
                num_matched = self.__get_num_matched(field_value, value)

                if num_matched is None:  # Not comparable using operators
                    if field_value != value:  # If False, return.
                        return False
                elif num_matched is False:
                    return False

        if 'func' in kwargs:
            if not kwargs['func'](self):
                return False

        return True

    def get_data_info(self):
        """Return a dictionary that has the data related attributes."""
        ret_dict = {}

        for field_name in self.DATA_ATTRS:
            ret_dict[field_name] = getattr(self, field_name)

        return ret_dict

    def get_interval(self):
        """Return a running interval time of the data."""

        return self.int_etime - self.int_stime


class IperfDataHandler:
    """A handler that stores a list of IperfData objects and provides some
    functions to access data

    .. note::

        You must parse the output by calling IperfBase.parse_output()
        before accessing any data

    """
    def __init__(self, multithread):
        # A list of the data. Line separated from the iperf output
        self.multi_thread = multithread  # Becomes True when src_port=0 is found
        self.data_list = []  # any types of data for each interval

    def append(self, data):
        """Append the given IperfData object to lists.

        Args:
            data (IperfData): data object
        """
        if data.int_stime == 0 and len(self.filter(interval_sum=True)) > 0:
            # Try to find interval_sum=True. If > 0, it means this is not the
            # first data therefore should be total_sum=True
            data.total_sum = True

        if not self.multi_thread or data.src_port == 0:
            # Do not filter and update the interval_sum to False since this is
            # very expensive operations. (the default interval_sum was True)
            # Now set the default to False and set the interval_sum to True
            # only if self.multi_thread is not True (namely single thread) and
            # src_port is 0

            data.interval_sum = True

        self.data_list.append(data)

    def filter(self, input_data=None, **kwargs):
        """Return a list of data that matches with the given keyword arguments.

        If multiple conditions are given, they will be processed as "AND".

        Args:
            input_data (list): A list of data that needs to be filtered. If not
                given, all available data will be used
            **kwargs: When data.<key> == <value>, the data will be returned.
                returned. For example::

                    filter(src_port=0)

                will return a list of IperfData objects that src_port is 0.

            For data types that are integer or float, you can use the comparison
            operators. For example::

                filter(int_stime='>2')

            will return a list of IperfData objects that have int_stime is
            greater than 2.

            if key == 'func', value can be any callback function which returns
            boolean.

            Possible keywords that can be used as filter are

            * timestamp (int): timestamp
            * src_ip (str): source IP address
            * src_port (int): source port
            * dst_ip (str): destination IP address
            * dst_port (int): destination port
            * id (int): ID number that iperf assigns
            * int_stime (int): Interval start time
            * int_etime (int): Interval end time
            * tx_bytes (int): Transmitted bytes for interval
            * bps (int): Bit per second
            * total_sum (bool): True if data is the total sum that is returned by iperf at exit
            * interval_sum (bool): True if data is the sum of each interval.

        """
        ret_list = []
        input_data = input_data or self.data_list

        for data in input_data:
            if not data.get_matched(**kwargs):
                continue
            ret_list.append(data)

        return ret_list

    def get_throughput(self, output_format='%bps', **kwargs):
        kwargs['interval_sum'] = kwargs.get('interval_sum', True)
        kwargs['total_sum'] = kwargs.get('total_sum', False)
        data_list = self.filter(**kwargs)

        if len(data_list) > 0:
            return self.get_throughput_format(data_list=data_list, output_format=output_format)

        return []

    def get_sum_throughput(self, output_format='%bps', **kwargs):
        kwargs['interval_sum'] = kwargs.get('interval_sum', True)
        kwargs['total_sum'] = kwargs.get('total_sum', True)
        filtered_data_list = self.filter(**kwargs)

        return self.get_throughput_format(data_list=filtered_data_list,
                                          output_format=output_format)[-1] if len(filtered_data_list) > 0 else None

    def get_throughput_format(self, data_list, output_format='%bps'):
        """Return a throughput using the given format.

        * %timestamp: timestamp
        * %src_ip: source IP
        * %src_port: source port
        * %dst_ip: destination IP
        * %dst_port: destination port
        * %id: id
        * %int_stime: interval start time
        * %int_etime: interval end time
        * %tx_bytes: transferred bytes
        * %tx_mbytes: transferred mega bytes
        * %tx_gbytes: transferred giga bytes
        * %bps: bits per second
        * %kbps: kbits per second
        * %mbps: mbits per second
        * %gbps: gbits per second
        * %Kbps: Kbytes per second
        * %Mbps: Mbytes per second
        * %Gbps: Gbytes per second

        For example::

            output_format='%timestamp: %src_ip -> %dst_ip = %bps'

        Will print::

            20140429124841: 192.168.1.1 -> 192.168.1.2 = 10484195328

        Args:
            data_list (list): A list of data which will be used to print the
                throughput
            output_format (str): A string format how the output will be
                returned. Default is simply return a bps.

        """
        def get_sub_dict(data_obj):
            byte_divider = 1024.0
            bit_divider = 1000.0
            return {
                '%timestamp': str(data_obj.timestamp),
                '%src_ip': str(data_obj.src_ip),
                '%src_port': str(data_obj.src_port),
                '%dst_ip': str(data_obj.dst_ip),
                '%dst_port': str(data_obj.dst_port),
                '%id': str(data_obj.id),
                '%int_stime': str(data_obj.int_stime),
                '%int_etime': str(data_obj.int_etime),
                '%tx_bytes': str(data_obj.tx_bytes),
                '%tx_kbytes': '%.2f' % (data_obj.tx_bytes/byte_divider),
                '%tx_mbytes': '%.2f' % (data_obj.tx_bytes/(byte_divider ** 2)),
                '%tx_gbytes': '%.2f' % (data_obj.tx_bytes/(byte_divider ** 3)),
                '%bps': str(data_obj.bps),
                '%kbps': '%.2f' % (data_obj.bps/bit_divider),
                '%mbps': '%.2f' % (data_obj.bps/(bit_divider ** 2)),
                '%gbps': '%.2f' % (data_obj.bps/(bit_divider ** 3)),
                '%Kbps': '%.2f' % (data_obj.bps/8 * bit_divider),
                '%Mbps': '%.2f' % (data_obj.bps/(8 * bit_divider ** 2)),
                '%Gbps': '%.2f' % (data_obj.bps/(8 * bit_divider ** 3)),
            }

        ret_list = []

        for data in data_list:
            sub_dict = get_sub_dict(data)
            pattern = re.compile('|'.join(list(sub_dict.keys())))
            ret_list.append(pattern.sub(lambda x: sub_dict[x.group()], output_format))

        return ret_list


class IperfBase:
    """A base class for iperf Client and Server classes.

    """
#    IPERF_PATH = find_executable('iperf')

    def __init__(self, iperf_data_mode=True):
        self._data_handler = None
        self._iperf_proc = None
        self._exe = exe
        self.options = []
        self.IPERF_PATH = find_executable('iperf')
        log.debug(f"IPERF Path: {self.IPERF_PATH}")

        # To maintain creation compatibility with the iperf3 Client class - unused placeholder var (see iperf3 Client)
        self.legacy_mode = not iperf_data_mode

    @property
    def iperf_proc(self):
        """Return iperf subprocess.Popen object if iperf is running otherwise None

        Return:
            object: subrprocess.Popen object of iperf
        """
        return self._iperf_proc

    def set_iperf_path(self, iperf_path=None, bind_path=None):
        """Update the path of iperf.

        The default value is simply a 'iperf' namely
        the class assumes that the iperf is located in one of directories where
        the system "PATH" environment variable includes.

        If this is not true then this function should be called and updated

        Args:
            iperf_path (str): A path to the iperf. i.e.) /opt/iperf/iperf
            bind_path : Custom path to launch iperf like taskset -c iperf

        """
        if iperf_path:
            self.IPERF_PATH = iperf_path
        if bind_path:
            self.IPERF_PATH = bind_path + ' ' + self.IPERF_PATH

    @staticmethod
    def get_options(options: List[str], ret_type='str'):
        """Return dict/string type options that will be passed to the iperf when
        start() is called.

        Following options will be added by default:

          * '-y C': Will be added if '-y' is not given.
          * '-i 1': Only if -i option is not passed in options.

        Note that '-c' and '-s' options will be added depending on class. For
        example, Client() class will add '-c <IP>' if it's not given.

        Args:
            options (list): A list of iperf options that will be passed to
                iperf i.e.) ['-u', '-t 90'].

            ret_type: Return type - default is string, which returns a
                string options. If it's a "dict", it will return the dictionary
                options (key=option, value=option value)

        Returns:
            dict: key=option name, value=value
            str: String of options
        """
        ret_dict = {}
        ret_string = ''

        for option in options:
            key, value = option.split() if len(option.split()) > 1 else (option, None)
            ret_dict[key] = value
            ret_string += ' ' + key + ('' if value is None else (' ' + value))
        # Add report style option
        if '-y' not in ret_dict:
            ret_dict['-y'] = 'C'
            ret_string += ' -y C'
        # Add -i option if not specified
        if '-i' not in ret_dict:
            ret_dict['-i'] = '1'
            ret_string += ' -i 1'

        return ret_string if ret_type == 'str' else ret_dict

    def parse_output(self):
        """Parse the output of iperf and pass it to data_handler

        """
        if self.iperf_proc is None:
            log.warning('iperf has not been started yet. Do nothing.')
            return

        output = self.iperf_proc.get_output()
        log.debug('iperf output: %s' % output)

        for iperf_data_line in output.splitlines():
            # Filter out blank lines
            if iperf_data_line == '':
                continue

            if iperf_data_line.find(',') == -1:
                continue

            data = IperfData(iperf_data_line)
            self._data_handler.append(data)

    def get_data(self, **kwargs):
        """Return the data that has been collected.

        kwargs will be used for filtering data. For available filtering
        options, refer IperfDataHandler.filter()

        Args:
            **kwargs: keyword arguments that is passed to IperfDataHandler.filter

        """
        self.parse_output()
        return self._data_handler.filter(**kwargs)

    def start(self, options):
        """Start iperf. Reset the data_handler.

        """
        # Add -Y and -i 1 options and get the string options
        self.options = options
        options = self.get_options(options, ret_type='str')

        # Instantiate a datahandler which is holds a list of IperfData objects
        self._data_handler = IperfDataHandler(multithread='-P' in self.get_options(options=options, ret_type='dict'))

        if self.IPERF_PATH is None:
            log.info('Starting iperf (command: iperf %s)' % options)
            self._iperf_proc = self._exe.run('iperf' + ' ' + options)
        else:
            log.info('Starting iperf (command: %s %s)', self.IPERF_PATH, options)

            try:
                self._iperf_proc = self._exe.run(self.IPERF_PATH + ' ' + options)
            except OSError as err:
                if 'No such file' in str(err) or 'The system cannot find the file' in str(err):
                    raise exception.ConfigException('Cannot find iperf. Please set the path to the'
                                                    ' iperf using IperfBase.set_iperf_path(<path_to_iperf>) or '
                                                    'iperf.set_iperf_path(<path_to_iperf>)')

        return self.iperf_proc

    def stop(self):
        """Stop iperf and clean up the open fd"""

        if self.iperf_proc is None:
            log.warning('iperf_pid is None. This means whether the '
                        'iperf server was not started by this EI or there is a bug to '
                        'track the iperf server PID. Return True.')
            return True

        return self.iperf_proc.kill() is not None

    def poll(self):
        """Proxy to subprocess.poll()

        Returns:
            int: exitcode of the process
            None: the process is still running
        """
        return self.iperf_proc.proc.poll()


class Client(IperfBase):
    """iperf Client object that inherits functions from IperfBase

    Args:
        dst_ip (str): Destination IP address

    """
    def __init__(self, iperf_data_mode=True):
        super().__init__(iperf_data_mode)

    def get_throughput(self, output_format='%bps', **kwargs):
        """
        Return the list of numbers as 'output_format' is specified. Will not
        return the total sum throughput data since this can be separately
        returned by self.get_sum_throughput()

        Also no per thread throughput when there are multiple threads - to
        access this data should use IperfDataHandler.filter()

        Args:
            output_format (str): Refer IperfDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data

        Returns:
            list: Numbers of throughput numbers as 'output_format'
        """

        if not self._data_handler:
            log.warning('iperf has not started yet. Do nothing')
            return None

        self.parse_output()
        return self._data_handler.get_throughput(output_format=output_format, **kwargs)

    def get_sum_throughput(self, output_format='%bps', **kwargs):
        """
        This function does the same job as get_throughput() except this only
        checks and returns the last summary data that iperf reports at exit

        If such data is not available yet (namely iperf is still running) then
        will return None

        Args:
            output_format (str): Refer IperfDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data
        """

        if not self._data_handler:
            log.warning('iperf has not started yet. Do nothing')
            return None

        self.parse_output()
        return self._data_handler.get_sum_throughput(output_format=output_format, **kwargs)

    def is_done(self):
        """
        Return True if iperf stops running otherwise False.
        Raise exceptions when iperf stops but cannot get the last summary data

        Returns:
            bool: True if iperf stops running otherwise False
        """

        if self.poll() is None:
            return False

        if self.get_sum_throughput() is None:
            raise exception.IperfDataException('Failed to get the sum throughput.')
        log.debug('throughput: %s', self.get_sum_throughput())

        return True

    def start(self, dst_ip, options=None):
        """
        Start iperf client.

        Args:
            dst_ip (str): Destination IP address
            options (list): List of options that will be passed to iperf. For
                example, ['-t 10', '-u'] will be passed as '-t 10 -u'
        """

        options = options or []
        # Convert from netref.list to list when this is called over RPyC
        options = [option for option in options]
        dict_options = self.get_options(options=options, ret_type='dict')

        if '-c' not in dict_options:
            options = ['-c %s' % dst_ip] + options

        return super().start(options=options)


class Server(IperfBase):
    """iperf Server object that inherits functions from IperfBase."""

    def __init__(self):
        super().__init__()

    def start(self, options=None):
        """
        Start iperf server.

        Args:
            options (list): list of options to be passed to iperf.
                e.g.) ['-u', '-i 1']

        """
        options = options or []
        # Convert from netref.list to list when this is called over RPyC
        options = [option for option in options]
        dict_options = self.get_options(options=options, ret_type='dict')

        if '-s' not in dict_options:
            options = ['-s'] + options

        return IperfBase.start(self, options=options)


def set_iperf_path(iperf_path):
    """
    Update the path of iperf. The default value is simply a 'iperf' namely
    the class assumes that the iperf is located in one of directories where
    the system "PATH" environment variable includes.

    If this is not true then this function should be called and the path
    needs to be updated

    Args:
        iperf_path (str): A path to the iperf i.e.) /opt/iperf/iperf

    """
    IperfBase.set_iperf_path(iperf_path)
