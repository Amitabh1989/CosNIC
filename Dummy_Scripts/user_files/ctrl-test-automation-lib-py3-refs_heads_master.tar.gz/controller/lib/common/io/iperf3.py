"""
:mod:`iperf` -- Run iperf client/server
=======================================

.. module:: controller.lib.common.io.iperf
.. moduleauthor:: Pravitha Menon <pmenon@broadcom.com>

This EI library provides some simple functions to use the iperf as well as
client/server classes that provide low-level access of throughput data and
iperf process control.

Support both Linux and Windows.

To use the iperf library, the obvious first step - you need to import the
module.

>>> from controller.lib.common.io import iperf

iperf EI has two major classes - called "Client" and "Server". The names
themselves are clear enough to tell what they do - and here are some examples.

Let's do the simple iperf testing - start the server, and run the client
through the loopback interface, namely destination IP is "127.0.0.1"

Create a server instance and start it is simple.

>>> server = iperf.Server()
>>> server.start()

.. note::

   As an example, here we start iperf server, but recommendation is to run
   iperf server as daemon so you do not need to start server separately.

.. note::

   If you see an error "Cannot find iperf. Please set the path to the iperf
   using Iperf3Base.set_iperf_path(<path_to_iperf>)", you need to update the
   path of iperf manually. For example,

  >>> iperf.set_iperf_path('C:\iperf\iperf.exe')

Note that "start()" function returns a integer number - "pid". You can track
status of the server using it.

Now let's create a client instance and start iperf.

>>> client = iperf.Client()
>>> client.start(dst_ip='127.0.0.1')
2015-04-30 11:20:12,554|INFO    |Starting iperf ... (command: /usr/bin/iperf  -c localhost -y C -i 1)

Because information is available on the client side, mostly you only need
to interact with the "client" object. For example, if you want to get
throughputs,

>>> client.get_throughput()
['3341287424', '5317263360', '5317328896', '5311365120']
>>> client.get_throughput()
['3341287424',
 '5317263360',
 '5317328896',
 '5311365120',
 '5327814656',
 '5346361344',
 '5358288896',
 '5345968128',
 '5356781568',
 '5366677504',
 '5138886205']


It's bit difficult to read, since they are just numbers. This is the default
output when you do NOT provide any options to get_throughput() function.

What it does is to return a list of the collected throughput in bps. Note that
iperf library collects data every second by passing an option "-i 1" to client.

Which means - when get_throughput() was called at the first time in the
above example, it only had four available data entries at that moment when
iperf client was running. After waiting 10 secs (which is a default running
time of iperf), now it shows 11 data entries - 10 throughputs data of each
interval from 0 to 10, and the sum of throughput that iperf reports at the exit.

If you are only interested the throughput that iperf reports at exit, yuo can
call a function that returns it only.

>>> client.get_sum_throughput()
'5138886205'

.. note::

   get_sum_throughput() returns None if iperf is still running

get_sum_throughput() accepts "fmt" argument which returns as the given format.
Namely you can customize hwo the return value looks like.

If you want sometihng that looks like iperf outupt? Try this.

>>> client.get_sum_throughput(
... output_format='[ %id]  %int_stime-%int_etime sec  %tx_gbytes Gbytes  %gbps Gbits/sec')
'[ 3]  0.0-10.0 sec  6.20 Gbytes  5.32 Gbits/sec'

Pretty cool, huh?

Here are variables that will be replaced by the function.

* %timestamp: timestamp
* %src_ip: source IP address
* %src_port: source port
* %dst_ip: destination IP address
* %dst_port: destination port
* %id: ID
* %int_stime: interval start time
* %int_etime: interval end time
* %tx_bytes: transferred bytes
* %tx_kbytes: transferred kbytes
* %tx_mbytes: transferred mbytes
* %tx_gbytes: transferred gbytes
* %bps: bit per second
* %kbps: kbit per second
* %mbps: mbit per second
* %gbps: gbit per second
* %Kbps: kbyte per second
* %Mbps: Mbyte per second
* %Gbps: Gbyte per second

Since we got what we wanted, let's stop the server.

>>> server.stop()
True

If it returns True, the iperf server is terminated successfully.

"""

__version__ = "1.1.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Corporation"

import operator
# import pprint
import re
import sys
from typing import List

from distutils.spawn import find_executable
from enum import IntEnum, auto

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)

# pp_str = pprint.PrettyPrinter(3, 120, compact=True).pformat


def convert_time(input_time):
    try:
        number, base = re.match(r'(\d+)([hms]?)$', str(input_time)).groups()
    except AttributeError as exc:
        raise exception.ValueException(
            'The given input_time value %s is not correct. Acceptable format: '
            '<number>[h|m|s> (i.e. 3h, 45m)' % input_time) from exc

    if base == 'm':
        return int(number) * 60
    if base == 'h':
        return int(number) * 3600

    return int(number)


class IperfData:
    """A picklable iperf data object.

    """
    if sys.version_info[0] >= 3:
        d_type = int
    else:
        u_code = str
        d_type = int

    class IperfDataType(IntEnum):
        """Enum to identify the type of data line stored in an IperfData object"""
        INTERVAL_REG = auto()  # Numeric id and no sender/receiver tag (interval_sum if not multi-thread, !total_sum)
        INTERVAL_SUM = auto()  # 'SUM'/-1 id and no sender/receiver tag (interval_sum, !total_sum)
        RECEIVER_REG = auto()  # Numeric id and receiver tag (interval_sum if not multi-thread, total_sum)
        RECEIVER_SUM = auto()  # 'SUM'/-1 id and receiver tag (interval_sum, total_sum)
        SENDERTX_REG = auto()  # Numeric id and sender tag (interval_sum if not multi-thread, total_sum)
        SENDERTX_SUM = auto()  # 'SUM'/-1 id and sender tag (interval_sum, total_sum)

    IPERF_DATA_TYPE = IperfDataType

    # Must match the ordering of the parsed fields from each iperf data line
    # Used to create IperfData attributes dynamically
    IPERF_BASE_DATA_INDEX_MAPPING = [
        ('timestamp', str),  # YYYYMMDDhhmmss
        ('src_ip', str),
        ('src_port', int),
        ('dst_ip', str),
        ('dst_port', int),
        ('id', int),
        ('interval', list),
        ('tx_bytes', int),
        ('bps', d_type),  # bit per second
    ]
    IPERF_DATA_INDEX_MAPPING = IPERF_BASE_DATA_INDEX_MAPPING + [
        ('data_type', int),
    ]

    IPERF_UDP_DATA_INDEX_MAPPING = IPERF_BASE_DATA_INDEX_MAPPING + [
        ('jitter', float),
        ('lost_datagrams', int),
        ('sent_datagrams', int),
        ('percent_loss', float),
        # ('received_datagrams', int),
        ('data_type', int),
    ]

    # Cumulative set of IperfData attributes including the parsed, dynamic, ones from above, plus other fixed attr
    # that will be returned in dictionary form via get_data_info (user api method)
    DATA_ATTRS = [
        map_element[0] for map_element in IPERF_DATA_INDEX_MAPPING if map_element[0] != 'interval'
    ] + ['int_stime', 'int_etime', 'interval_sum', 'total_sum', 'raw_data']

    # Mapping table to map the connection info (src/dst ip/port) to each line of iperf data via the connection ID
    id_map = {}
    CONN_ID_SUM_STR = 'SUM'  # iperf output line is a summary line ([SUM] ...)
    CONN_ID_SUM_INT = -1  # Store conn ids as int - SUM becomes -1 (similar to iperf2 -y c output)

    # iperf output line parsing regex fields and grouping indexes - for connection lines and data lines
    IDX_TSTAMP = 1
    IDX_CONN_ID = 2
    ts_re = r"'?(?:(\d{14})\s*)?"
    ip_re = r'((?:\d+(?:\.\d+){3})|(?:[a-fA-F0-9:]+))'
    id_fmt_re = r'\[\s*(\d+{})\]'
    connect_line_re = re.compile(
        # [timestamp(YYYYMMDDhhmmss)], ID, src ip, src port, dst ip, dst port
        rf"^{ts_re}{id_fmt_re.format('')}\s+local\s+{ip_re}\s+port\s+(\d+)\s+connected to {ip_re}\s+port\s+(\d+)")
    IDX_SRC_ADDR = IDX_CONN_ID + 1
    IDX_SRC_PORT = IDX_CONN_ID + 2
    IDX_DST_ADDR = IDX_CONN_ID + 3
    IDX_DST_PORT = IDX_CONN_ID + 4

    id_sum_re = f'|{CONN_ID_SUM_STR}'
    secs_re = r'\d+(?:\.\d+)?'
    float_re = r'[0-9.]+'
    translate_re = re.compile(
        # TODO: Add optional \[[TR]X-C\], as a new IperfData attr - dir (default is tx if not there)
        # [timestamp(YYYYMMDDhhmmss)], ID, interval,
        rf'^{ts_re}{id_fmt_re.format(id_sum_re)}\s+({secs_re}-\s*{secs_re})\s+sec\s+'
        # bytes, Bytes Units, Mbps,
        rf'({float_re})\s+([KMGTP]?Bytes)\s+({float_re})\s+Mbits/sec\s+'
        # [UDP only: jitter, dgrams(lost, total, %lost)], 'receiver'(ie. full test summary line)
        rf'(?:({float_re})\s+ms\s+(\d+)/(\d+)\s+\(({float_re})%\))?\s+(?:\d+\s+)?(receiver|sender)?')
    IDX_INTERVAL = IDX_CONN_ID + 1  # noqa: E222
    IDX_BYTES = IDX_CONN_ID + 2  # noqa: E222
    IDX_BYTES_UNITS = IDX_CONN_ID + 3  # noqa: E222
    IDX_SPEED = IDX_CONN_ID + 4  # noqa: E222
    IDX_UDP_JITTER = IDX_CONN_ID + 5  # noqa: E222
    IDX_UDP_LOST = IDX_CONN_ID + 6  # noqa: E222
    IDX_UDP_DGRAMS = IDX_CONN_ID + 7  # noqa: E222
    IDX_UDP_LOST_PCNT = IDX_CONN_ID + 8  # noqa: E222
    IDX_SUMMARY = IDX_CONN_ID + 9  # noqa: E222

    def __init__(self, iperf_data_line):
        """
        Args:
            iperf_data_line (str): A single line that iperf3 prints with the '-f m' option

        """
        self.total_sum = False
        self.interval_sum = None  # None=Unknown, True=multithread+src_port=0
        self.raw_data = None
        self.int_stime = 0
        self.int_etime = 0
        self.initialized = False

        # Update the data values using the given iperf output
        self.set_converted_data(iperf_data_line)

    def __str__(self) -> str:
        return str(self.get_data_info())

    def set_converted_data(self, iperf_data_line):
        """Parse the iperf's output line, convert it to numbers and store
        them as attributes to the self.

        Args:
            iperf_data_line (str): A single line of iperf output

        """

        # Store the raw data
        self.raw_data = iperf_data_line

        # Translate from human readable iperf3 output to csv format as in iperf2
        # First, capture the connection IDs and map to the src and dst IPs/ports - these src/dst values are added
        # to each throughput data line by looking them up via the conn id. Create a fake -1 id for the summary lines
        # (mimics the '-y c' iperf2 behaviour in iperf lib)
        connect_line_re = IperfData.connect_line_re.search(iperf_data_line)
        if connect_line_re:
            conn_id = int(connect_line_re.group(IperfData.IDX_CONN_ID))
            src_addr = connect_line_re.group(IperfData.IDX_SRC_ADDR)
            src_port = int(connect_line_re.group(IperfData.IDX_SRC_PORT))
            dst_addr = connect_line_re.group(IperfData.IDX_DST_ADDR)
            dst_port = int(connect_line_re.group(IperfData.IDX_DST_PORT))
            IperfData.id_map.update({
                conn_id: {'src_addr': src_addr, 'src_port': src_port, 'dst_addr': dst_addr, 'dst_port': dst_port}
            })
            return
        if 'Starting Test:' in iperf_data_line:
            IperfData.id_map['num_streams'] = int(re.findall(r',\s+(\d+)\s+streams,', iperf_data_line)[0])
            return

        # Set this after all connection lines processed, but do not overwrite as each throughput line processed
        if 'num_conns' not in IperfData.id_map:
            IperfData.id_map['num_conns'] = len(IperfData.id_map)

        # Use the first connection entry as the src/dst info for including in summary lines
        # In most cases this is fine. Bidir data would have two sum lines and should really use dst port = 0
        # in the second line, but conn data is otherwise the same.
        # Reverse connection assumes the user knows and treats src/dst as opposite
        if IperfData.CONN_ID_SUM_INT not in IperfData.id_map:
            IperfData.id_map[IperfData.CONN_ID_SUM_INT] = IperfData.id_map[list(IperfData.id_map)[0]]

        translate_re = IperfData.translate_re.search(iperf_data_line)
        if not translate_re:
            # Ignore missing sender data (from iperf client) when processing output on the receive side (iperf server)
            sender_nodata_pat = rf'^{IperfData.ts_re}{IperfData.id_fmt_re.format(IperfData.id_sum_re)}(.*)'
            sender_nodata_re = re.search(sender_nodata_pat, iperf_data_line)
            if sender_nodata_re and 'sender statistics not available' in sender_nodata_re.group(3):
                timestamp = sender_nodata_re.group(1)
                conn_id = sender_nodata_re.group(2)
                if conn_id == IperfData.CONN_ID_SUM_STR:
                    data_type = IperfData.IPERF_DATA_TYPE.SENDERTX_SUM
                    conn_id = IperfData.CONN_ID_SUM_INT
                else:
                    data_type = IperfData.IPERF_DATA_TYPE.SENDERTX_REG
                    conn_id = int(conn_id)
                # log.debug(f"ID MAP: {IperfData.id_map}")
                iperf_data = [
                    timestamp,
                    IperfData.id_map[conn_id]['src_addr'],
                    IperfData.id_map[conn_id]['src_port'],
                    IperfData.id_map[conn_id]['dst_addr'],
                    IperfData.id_map[conn_id]['dst_port'],
                    conn_id,
                    '',  # interval
                    '',  # bytes
                    '',  # bps
                    int(data_type),
                ]
                log.warning(f"Sender data reported as unavailable, ignoring: {iperf_data}")
                return

            raise exception.IperfDataException(f"Following connect output, did not receive expected iperf data: "
                                               f"{iperf_data_line}, re: '{IperfData.translate_re.pattern}'")

        timestamp = translate_re.group(IperfData.IDX_TSTAMP) or ''  # str fmt (%Y%m%d%H%M%S): YYYYmmddHHMMSS
        data_type = None
        conn_id = translate_re.group(IperfData.IDX_CONN_ID)
        # log.debug(f"DATA: {translate_re.groups()}")
        # total_sum == True if sender or receiver line (final result data after runtime), else interval_sum == True
        if conn_id == IperfData.CONN_ID_SUM_STR:
            if translate_re.group(IperfData.IDX_SUMMARY) == 'receiver':
                data_type = IperfData.IPERF_DATA_TYPE.RECEIVER_SUM
            elif translate_re.group(IperfData.IDX_SUMMARY) == 'sender':
                data_type = IperfData.IPERF_DATA_TYPE.SENDERTX_SUM
            else:
                data_type = IperfData.IPERF_DATA_TYPE.INTERVAL_SUM
            conn_id = IperfData.CONN_ID_SUM_INT
        else:
            conn_id = int(conn_id)
            if translate_re.group(IperfData.IDX_SUMMARY) == 'receiver':
                data_type = IperfData.IPERF_DATA_TYPE.RECEIVER_REG
            elif translate_re.group(IperfData.IDX_SUMMARY) == 'sender':
                data_type = IperfData.IPERF_DATA_TYPE.SENDERTX_REG
            else:
                data_type = IperfData.IPERF_DATA_TYPE.INTERVAL_REG

        BYTES_BASE_MULT = 1024
        SPEED_BASE_MULT = 1000
        bytes_mult_map = {
            'bytes': 1, 'kbytes': BYTES_BASE_MULT**1, 'mbytes': BYTES_BASE_MULT**2, 'gbytes': BYTES_BASE_MULT**3,
            'bps': 1, 'kbps': SPEED_BASE_MULT**1, 'mbps': SPEED_BASE_MULT**2, 'gbps': SPEED_BASE_MULT**3}
        bytes_mult = bytes_mult_map[translate_re.group(IperfData.IDX_BYTES_UNITS).lower()]
        bps_mult = bytes_mult_map['mbps']  # We use -f m to ensure Mbits/sec

        # Build the list of data items parsed from the output lines for inclusion into an IperfData object
        iperf_data = [
            timestamp,
            IperfData.id_map[conn_id]['src_addr'],
            IperfData.id_map[conn_id]['src_port'],
            IperfData.id_map[conn_id]['dst_addr'],
            IperfData.id_map[conn_id]['dst_port'],
            conn_id,
            ''.join(translate_re.group(IperfData.IDX_INTERVAL).split()),  # remove any spaces in, eg., 'start- end'
            float(translate_re.group(IperfData.IDX_BYTES)) * bytes_mult,  # bytes from specific units as displayed
            float(translate_re.group(IperfData.IDX_SPEED)) * bps_mult,  # bps from Mbits/sec (with -f m)
        ]
        if any(translate_re.group(IperfData.IDX_UDP_JITTER, IperfData.IDX_UDP_LOST,
                                  IperfData.IDX_UDP_DGRAMS, IperfData.IDX_UDP_LOST_PCNT)):
            iperf_data += [
                float(translate_re.group(IperfData.IDX_UDP_JITTER)),
                int(IperfData.IDX_UDP_LOST),
                int(IperfData.IDX_UDP_DGRAMS),
                float(IperfData.IDX_UDP_LOST_PCNT),
            ]
        iperf_data += [int(data_type)]

        # log.debug(f"IperfDataList: {iperf_data}, {IperfData.IperfDataType(iperf_data[-1]).name}")

        if len(iperf_data) not in [len(self.IPERF_DATA_INDEX_MAPPING), len(self.IPERF_UDP_DATA_INDEX_MAPPING)]:
            raise exception.IperfDataException(
                'A number of data types %s is not expected one %s or %s. '
                'Output: %s' % (
                    len(iperf_data),
                    len(self.IPERF_DATA_INDEX_MAPPING),
                    len(self.IPERF_UDP_DATA_INDEX_MAPPING),
                    iperf_data_line
                )
            )

        data_map = self.IPERF_DATA_INDEX_MAPPING
        if len(iperf_data) != len(self.IPERF_DATA_INDEX_MAPPING):
            data_map = self.IPERF_UDP_DATA_INDEX_MAPPING

        # Create IperfData attributes dynamically from parsed iperf output line - indexing must match the data_map
        for idx, iperf_item in enumerate(iperf_data):
            field_name, field_type = data_map[idx]
            # If interval, separate the start/end intervals and save them as float fields
            if field_name == 'interval':
                stime, etime = iperf_item.split('-')
                setattr(self, 'int_stime', float(stime))
                setattr(self, 'int_etime', float(etime))
            else:
                setattr(self, field_name, field_type(iperf_item))
        self.initialized = True

    @staticmethod
    def __get_num_matched(data_value, exprs):
        """A special handler for any integer or float types compare, to support
        >, <, ! and =.

        Args:
            data_value (str, int, float): A stored value
            exprs (str, int, float): An expression to compare with parameter
                "data_value"
        """
        acceptable_operators = {
            '<': operator.lt,
            '<=': operator.le,
            '>': operator.gt,
            '>=': operator.ge,
            # '==': operator.eq,
            '!=': operator.ne,
        }

        if sys.version_info[0] >= 3:
            u_code = str
            d_type = int
        else:
            u_code = str
            d_type = int
        if not isinstance(data_value, (int, d_type, float)) or not isinstance(exprs, (str, u_code)):
            # Not integer/float, and the exprs is not string
            # (namely no operator exists)
            # No need to compare. Return None.
            return None

        if re.match(r'([<>=!]=?)\s*(\d+\.?\d*)', exprs):
            opr, exprs_num = re.match(r'([<>!]=?)\s*(\d+\.?\d*)', exprs).groups()
            return acceptable_operators[opr](data_value, float(exprs_num))

        raise exception.ValueException(f'The given expression {exprs} is incorrect')

    def get_matched(self, **kwargs):
        """Return True if the data is matched with the given filter arguments

        Args:
            **kwargs: keyword arguments to check conditions i.e.) src_port=0,
                src_ip='192.168.1.1'

                If value is None, it means 'match any'. You can specify a
                custom function to check using 'func' keyword

        """
        for field_name, value in list(kwargs.items()):
            if value is None:  # Match any
                continue  # Check the next condition. Assume matched.

            if hasattr(self, field_name):
                field_value = getattr(self, field_name)
                num_matched = self.__get_num_matched(field_value, value)

                if num_matched is None:  # Not comparable using operators
                    if field_value != value:  # If False, return.
                        return False
                elif num_matched is False:
                    return False

        if 'func' in kwargs:
            if not kwargs['func'](self):
                return False

        return True

    def get_data_info(self):
        """Return a dictionary that has the data related attributes."""
        ret_dict = {}

        for field_name in self.DATA_ATTRS:
            ret_dict[field_name] = getattr(self, field_name)

        return ret_dict

    def get_interval(self):
        """Return a running interval time of the data."""

        return self.int_etime - self.int_stime


class IperfDataHandler:
    """A handler that stores a list of IperfData objects and provides some
    functions to access data

    .. note::

        You must parse the output by calling Iperf3Base.parse_output()
        before accessing any data

    """
    def __init__(self, multithread):
        # A list of the data. Line separated from the iperf output
        self.multi_thread = multithread  # Becomes True when src_port=0 is found
        self.data_list: List[IperfData] = []  # any types of data for each interval

    def clear(self):
        self.data_list = []

    def append(self, data: IperfData):
        """Append the given IperfData object to lists.

        Args:
            data (IperfData): data object
        """

        # Skip adding the connection lines that determine the src/dst ip/port - they are processed in IperfData ctor
        # but do not result in the IperfData attributes being populated as they are not throughput/data lines
        if not data.initialized:
            log.info(f"Not adding uninitialized IperfData object to IperfDataHandler - "
                     f"expected for non-throughput output lines ({data.raw_data})")
            return

        if data.int_stime == 0 and len(self.filter_data(interval_sum=True)) > 0:
            # Try to find interval_sum=True. If > 0, it means this is not the
            # first data therefore should be total_sum=True
            data.total_sum = True

        mt_summary_types = [
            IperfData.IPERF_DATA_TYPE.INTERVAL_SUM,
            IperfData.IPERF_DATA_TYPE.RECEIVER_SUM,
            IperfData.IPERF_DATA_TYPE.SENDERTX_SUM,
        ]
        if not self.multi_thread or data.src_port == 0 or data.data_type in mt_summary_types:
            # Do not filter and update the interval_sum to False since this is
            # very expensive operations. (the default interval_sum was True)
            # Now set the default to False and set the interval_sum to True
            # only if self.multi_thread is not True (namely single thread) and
            # src_port is 0

            data.interval_sum = True

        # log.debug(f"IperfDataDict: {pp_str(data.get_data_info())}\n   "
        #           f"'data_type_str': {IperfData.IperfDataType(data.get_data_info()['data_type']).name}")
        self.data_list.append(data)

    def filter_data(self, input_data: List[IperfData] = None, **kwargs) -> List[IperfData]:
        """Return a list of data that matches with the given keyword arguments.

        If multiple conditions are given, they will be processed as "AND".

        Args:
            input_data (list): A list of data that needs to be filtered. If not
                given, all available data will be used
            **kwargs: When data.<key> == <value>, the data will be returned.
                returned. For example::

                    filter(src_port=0)

                will return a list of IperfData objects that src_port is 0.

            For data types that are integer or float, you can use the comparison
            operators. For example::
                filter(int_stime='>2')
            will return a list of IperfData objects that have int_stime is
            greater than 2.

            if key == 'func', value can be any callback function which returns
            boolean.

            Possible keywords that can be used as filter are

            * timestamp (int): timestamp
            * src_ip (str): source IP address
            * src_port (int): source port
            * dst_ip (str): destination IP address
            * dst_port (int): destination port
            * id (int): ID number that iperf assigns
            * int_stime (int): Interval start time
            * int_etime (int): Interval end time
            * tx_bytes (int): Transmitted bytes for interval
            * bps (int): Bit per second
            * total_sum (bool): True if data is the total sum that is returned by iperf at exit
            * interval_sum (bool): True if data is the sum of each interval.

        """
        ret_list = []
        input_data = input_data or self.data_list

        for data in input_data:
            if not data.get_matched(**kwargs):
                continue
            ret_list.append(data)

        return ret_list

    def get_throughput(self, output_format='%bps', **kwargs) -> List[str]:
        """Return a list that has the throughput related (summary, if multi-threaded) data"""
        kwargs['interval_sum'] = kwargs.get('interval_sum', True)
        kwargs['total_sum'] = kwargs.get('total_sum', False)
        data_list = self.filter_data(**kwargs)

        if len(data_list) > 0:
            return self.get_throughput_format(data_list=data_list, output_format=output_format)

        return []

    def get_sum_throughput(self, output_format='%bps', **kwargs):
        """Returns final summary throughput data (from rx perspective)"""
        kwargs['interval_sum'] = kwargs.get('interval_sum', True)
        kwargs['total_sum'] = kwargs.get('total_sum', True)
        recvr = IperfData.IPERF_DATA_TYPE.RECEIVER_SUM if self.multi_thread else IperfData.IPERF_DATA_TYPE.RECEIVER_REG
        kwargs['data_type'] = kwargs.get('data_type', recvr)
        filtered_data_list = self.filter_data(**kwargs)

        return self.get_throughput_format(data_list=filtered_data_list,
                                          output_format=output_format)[-1] if len(filtered_data_list) > 0 else None

    def get_throughput_format(self, data_list: List[IperfData], output_format='%bps'):
        """Return a throughput using the given format.

        * %timestamp: timestamp
        * %src_ip: source IP
        * %src_port: source port
        * %dst_ip: destination IP
        * %dst_port: destination port
        * %id: id
        * %int_stime: interval start time
        * %int_etime: interval end time
        * %tx_bytes: transferred bytes
        * %tx_mbytes: transferred mega bytes
        * %tx_gbytes: transferred giga bytes
        * %bps: bits per second
        * %kbps: kbits per second
        * %mbps: mbits per second
        * %gbps: gbits per second
        * %Kbps: Kbytes per second
        * %Mbps: Mbytes per second
        * %Gbps: Gbytes per second

        For example::

            output_format='%timestamp: %src_ip -> %dst_ip = %bps'

        Will print::

            20140429124841: 192.168.1.1 -> 192.168.1.2 = 10484195328

        Args:
            data_list (list): A list of data which will be used to print the
                throughput
            output_format (str): A string format how the output will be
                returned. Default is simply return a bps.

        """

        def get_sub_dict(data_obj: IperfData):
            byte_divider = 1024.0
            bit_divider = 1000.0
            return {
                '%timestamp': str(data_obj.timestamp),
                '%src_ip': str(data_obj.src_ip),
                '%src_port': str(data_obj.src_port),
                '%dst_ip': str(data_obj.dst_ip),
                '%dst_port': str(data_obj.dst_port),
                '%id': str(data_obj.id),
                '%int_stime': str(data_obj.int_stime),
                '%int_etime': str(data_obj.int_etime),
                '%tx_bytes': str(data_obj.tx_bytes),
                '%tx_kbytes': '%.2f' % (data_obj.tx_bytes / byte_divider),
                '%tx_mbytes': '%.2f' % (data_obj.tx_bytes / (byte_divider ** 2)),
                '%tx_gbytes': '%.2f' % (data_obj.tx_bytes / (byte_divider ** 3)),
                '%bps': str(data_obj.bps),
                '%kbps': '%.2f' % (data_obj.bps / bit_divider),
                '%mbps': '%.2f' % (data_obj.bps / (bit_divider ** 2)),
                '%gbps': '%.2f' % (data_obj.bps / (bit_divider ** 3)),
                '%Kbps': '%.2f' % (data_obj.bps / 8 * bit_divider),
                '%Mbps': '%.2f' % (data_obj.bps / (8 * bit_divider ** 2)),
                '%Gbps': '%.2f' % (data_obj.bps / (8 * bit_divider ** 3)),
                '%data_type': f'{IperfData.IperfDataType(data_obj.data_type).name}({int(data_obj.data_type)})',
            }

        ret_list = []

        for data in data_list:
            sub_dict = get_sub_dict(data)
            pattern = re.compile('|'.join(list(sub_dict.keys())))
            ret_list.append(pattern.sub(lambda x: sub_dict[x.group()], output_format))

        return ret_list


class Iperf3Base:
    """
    A base class for iperf Client and Server classes.

    """
    IPERF_PATH = find_executable('iperf3')
    if not IPERF_PATH:
        raise exception.ConfigException('IPERF3 not found; please install in system or call '
                                        '"set_iperf_path" before calling class')

    def __init__(self, iperf_data_mode=False):
        self._data_handler = None
        self._iperf_proc = None
        self._use_timestamps = False
        self._output = None
        self.options = []
        # Default is to support original mode of this lib which only supported get_sum_throughput
        # (which returned sender and receiver values in a dict).
        # 'iperf_data_mode' mimics the iperf(2) lib structure such that the two libs are interchangeable within tests
        # (for the most part - some subtle differences and enhanced features in iperf3)
        self.legacy_mode = not iperf_data_mode

    @property
    def iperf_proc(self):
        """Return iperf subprocess.Popen object if iperf is running otherwise None

        Return:
            object: subrprocess.Popen object of iperf
        """
        return self._iperf_proc

    @classmethod
    def set_iperf_path(cls, iperf_path):
        """Update the path of iperf.

        The default value is simply a 'iperf' namely
        the class assumes that the iperf is located in one of directories where
        the system "PATH" environment variable includes.

        If this is not true then this function should be called and updated

        Args:
            iperf_path (str): A path to the iperf. i.e.) /opt/iperf/iperf

        """

        cls.IPERF_PATH = iperf_path

    @staticmethod
    def get_options(options: List[str], ret_type='str'):
        """Return dict/string type options that will be passed to the iperf when
        start() is called.

        Following options will be added by default:
          * '-i 1': Only if -i option is not passed in options.
          * '-f m': Display in Mbits/sec
          * '-V': verbose output

        Note that '-c' and '-s' options will be added depending on class. For
        example, Client() class will add '-c <IP>' if it's not given.

        Note that "--timestamps='%Y%m%d%H%M%S '" will be added if the iperf3 version supports it (during start)

        Args:
            options (list): A list of iperf options that will be passed to
                iperf i.e.) ['-u', '-t 90']. If None, use self.options by
                default
            ret_type: Return type - default is string, which returns a
                string options. If it's a "dict", it will return the dictionary
                options (key=option, value=option value)

        Returns:
            dict: key=option name, value=value
            str: String of options
        """

        ret_dict = {}

        for option in options:
            # Special case for --timestamps=<format> option which uses = to separate option name and value
            splitchar = '=' if '=' in option and option.startswith('--timestamps') else None
            key, value = option.split(splitchar, 1) if len(option.split(splitchar, 1)) > 1 else (option, None)
            ret_dict[key] = value

        # Add -i option if not specified
        if '-i' not in ret_dict:
            ret_dict['-i'] = '1'
        if '-f' not in ret_dict:
            ret_dict['-f'] = 'm'
        if '-V' not in ret_dict:
            ret_dict['-V'] = None

        ret_string = ' '.join(
            [f"{k}{'=' if k == '--timestamps' else ' '}{v if v is not None else ''}" for k, v in ret_dict.items()]
        )
        return ret_string if ret_type == 'str' else ret_dict

    def get_output_hash(self, output=None):
        """Return a hash of the requested iperf output data to allow detecting changes in the data

        :param output: Perform hashing on the provided data, defaults to None which ten performs hash on self._output
        :return: None or a hash of the requested output
        """
        if output is None:
            output = self._output
        if output is None:
            return None
        return hash(output)

    def get_output(self):
        """Return the output data from running iperf (from calling start, stop)

        Only typically valid to be invoked once iperf is stopped, but it appends any output recvd in case
        it is called while still running. self._output is reset in start method
        """
        if self._output is None:
            self._output = self.iperf_proc.get_output()
        else:
            self._output += self.iperf_proc.get_output()
        return self._output

    def parse_output(self):
        """
        This function will parse the stored iperf result (refreshing it in self._output if needed)
        each time it is called, but only if there is new data or if running in legacy mode.
        Parsing in legacy mode will create and return the results dictionary
        Otherwise, IperfData objects are created and added to the data_handler for each relevant output line as well.

        return (dict): sender and receiver final throughput values
               In non-legacy mode data_handler is also updated if new data is available
        """
        iperf_result = {}  # defining dictionary for the sender and receiver results
        # Check for the Bandwidth of sender and receiver
        if self.iperf_proc is None:
            log.warning('iperf has not been started yet. Do nothing.')
            return None

        # Only do actual re-parsing of data if the output changed since last get_output,
        # otherwise use current _data_handler
        cur_hash = self.get_output_hash()
        output = self.get_output()
        data_changed = cur_hash != self.get_output_hash()
        if data_changed:
            self._data_handler.clear()  # Clear the stored data from the last parse_output, and re-parse and append
        elif not self.legacy_mode:
            # No data has changed, nothing new to parse; _datahandler is up to date
            return None
        # in legacy mode we always parse and return the summary throughput directly (_data_handler unused)

        if data_changed or self.legacy_mode:
            log.debug('iperf output before parsing:%s', output)
        if not output:
            log.warning('iperf3 results returned Null value')
            return None

        results = ''
        for iperf_data_line in output.splitlines():
            # Filter out blank lines
            if iperf_data_line == '' or 'datagram' in iperf_data_line:
                continue

            # Only include the data/stats lines (per-thread or sum, w/wo timestamp) - includes sender and receiver
            line_start_pat = f'{IperfData.ts_re}{IperfData.id_fmt_re.format(IperfData.id_sum_re)}'
            if not re.match(line_start_pat, iperf_data_line):  # process lines starting with '[YYYYMMDDhhmmss ]['
                continue

            if data_changed:
                data = IperfData(iperf_data_line)
                self._data_handler.append(data)

            # Legacy results/iperf_results dict support
            results = ' '.join(iperf_data_line.split())  # strip the extra white spaces
            results = re.sub(r'\[ ', '[', results, 1)  # support -P option with "[SUM]" vs "[ #]" => "[#]" for split
            results_list = results.split()
            # IDX_SPEED from regex grouping of data line search, happens to line up with space splitting based on groups
            # currently captured in the re. Changes to IperfData.translate_re capture groups will affect this, as might
            # the choice of options (TODO: Support bidir)
            idx_speed = IperfData.IDX_SPEED if self._use_timestamps else IperfData.IDX_SPEED - 1
            # Keeps only the last sender and last receiver lines (should be the full duration; SUM data if -P)
            # Sender data may not exist on receiver (server) side
            if re.search(' sender', results):  # exclude '(sender statistics not available)' from matching
                iperf_result['Sender'] = f'{results_list[idx_speed]}Mbits/sec'  # Using -f m (Mbits)
            elif re.search(' receiver', results):
                iperf_result['Receiver'] = f'{results_list[idx_speed]}Mbits/sec'
        log.debug(f'results: {results}')
        log.info('iperf results after parsing:%s', iperf_result)
        return iperf_result

    def get_data(self, **kwargs):
        """Return the data that has been collected.

        kwargs will be used for filtering data. For available filtering
        options, refer IperfDataHandler.filter_data()

        Args:
            **kwargs: keyword arguments that is passed to IperfDataHandler.filter_data

        """

        self.parse_output()
        return self._data_handler.filter_data(**kwargs)

    def start(self, options):
        """Start iperf. Reset the data_handler.
        Args:
            options: List of options to start the iperf
        """

        # Reset each time we start iperf such that calls to parse_output will retrieve new data and store new data
        self._output = None
        self.options = options

        # Dynamically determine if we can add the timestamps option (to replicate iperf2 -y c output content)
        try:
            exe.block_run(f"{self.IPERF_PATH} --help | grep -q '\--timestamps'", shell=True)
        except exe.exception.ExeExitcodeException:
            self._use_timestamps = False
        else:
            self._use_timestamps = True
            opt_dict = self.get_options(options, ret_type='dict')
            if '--timestamps' not in opt_dict:
                options.append(r"--timestamps='%Y%m%d%H%M%S '")
                self.options = options  # update options since timestamps added
        log.info(f"Running iperf {'with' if self._use_timestamps else 'without'} --timestamps option")

        # Instantiate a data handler which is holds a list of IperfData objects
        self._data_handler = IperfDataHandler(multithread='-P' in self.get_options(options=options, ret_type='dict'))
        options_str = self.get_options(options, ret_type='str')
        if self.IPERF_PATH is None:
            # raise exception.ConfigException('Cannot find iperf')
            log.info('Starting iperf ... (command: iperf3 %s)', options_str)
            self._iperf_proc = exe.run('iperf3' + ' ' + options_str)
        else:
            log.info('Starting iperf3 ... (command: %s %s)', self.IPERF_PATH, options_str)

            try:
                self._iperf_proc = exe.run(self.IPERF_PATH + ' ' + options_str)
            except OSError as err:
                if 'No such file' in str(err) or 'The system cannot find the file' in str(err):
                    raise exception.ConfigException(
                        'Cannot find iperf. Please set the path to the iperf using '
                        'Iperf3Base.set_iperf_path(<path_to_iperf>) or '
                        'iperf.set_iperf_path(<path_to_iperf>)'
                    )

        return self.iperf_proc

    def stop(self):
        """Stop iperf and clean up the open fd"""
        if self.iperf_proc:
            self.iperf_proc.stop()
        # Poll one more time to eliminate defunct process
        return self.poll()

    def kill(self):
        """Stop iperf and clean up the open fd"""

        if self.iperf_proc is None:
            log.warning(
                'iperf_pid is None. This means whether the '
                'iperf server was not started by this EI or there is a bug to '
                'track the iperf server PID. Return True.'
            )
            return True

        return self.iperf_proc.kill() is not None

    def poll(self):
        """Proxy to subprocess.poll()

        Returns:
            int: exitcode of the process
            None: the process is still running
        """
        return self.iperf_proc.proc.poll()


class Client(Iperf3Base):
    """iperf Client object that inherits functions from Iperf3Base

    """

    def __init__(self, iperf_data_mode=False):
        super().__init__(iperf_data_mode)

    def get_throughput(self, output_format='%bps', **kwargs):
        """
        Return the list of numbers as 'output_format' is specified. Will not
        return the total sum throughput data since this can be separately
        returned by self.get_sum_throughput()

        Also no per thread throughput when there are multiple threads - to
        access this data should use IperfDataHandler.filter_data()

        Args:
            output_format (str): Refer IperfDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data

        Returns:
            list: Numbers of throughput numbers as 'output_format'
        """

        if not self._data_handler:
            log.warning('iperf has not started yet. Do nothing')
            return None

        self.parse_output()
        return self._data_handler.get_throughput(output_format=output_format, **kwargs)

    def get_sum_throughput(self, output_format='%bps', **kwargs):
        """
        This function does the same job as get_throughput() except this only
        checks and returns the last summary data that iperf reports at exit

        If such data is not available yet (namely iperf is still running) then
        will return None

        Args:
            output_format (str): Refer IperfDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data
        """

        if not self._data_handler:
            log.warning('iperf has not started yet. Do nothing')
            return None

        output = self.parse_output()
        log.debug('iperf sum throughput: %s', output)
        if output_format is None or self.legacy_mode:
            return output  # support legacy api that returns a dict with sender and receiver throughput
        return self._data_handler.get_sum_throughput(output_format=output_format, **kwargs)

    def get_sum_throughput_legacy(self):
        """Force use of legacy iperf3 get_sum_throughput API regardless of legacy_mode setting"""
        return self.get_sum_throughput(output_format=None)

    def is_done(self):
        """
        Return True if iperf stops running otherwise False.
        Raise exceptions when iperf stops but cannot get the last summary data

        Returns:
            bool: True if iperf stops running otherwise False
        """

        if self.poll() is None:
            return False

        log.debug('throughput: %s', self.get_sum_throughput())
        if self.get_sum_throughput() is None:
            raise exception.IperfDataException(
                'Failed to get the sum throughput. Did iperf successfully exit without errors?'
            )

        return True

    def start(self, dst_ip, options=None):
        """
        Start iperf client.

        Args:
            dst_ip (str): Destination IP address
            options (list): List of options that will be passed to iperf. For
                example, ['-t 10', '-u'] will be passed as '-t 10 -u'
        """

        options = options or []
        # Convert from netref.list to list when this is called over RPyC
        options = [option for option in options]
        dict_options = self.get_options(options=options, ret_type='dict')

        if '-c' not in dict_options:
            options = ['-c %s' % dst_ip] + options

        return super().start(options=options)


class Server(Iperf3Base):
    """iperf Server object that inherits functions from Iperf3Base."""

    def __init__(self):
        super().__init__()

    def start(self, options=None):
        """
        Start iperf server.

        Args:
            options (list): list of options to be passed to iperf.
                e.g.) ['-u', '-i 1']

        """

        options = options or []
        # Convert from netref.list to list when this is called over RPyC
        options = [option for option in options]
        dict_options = self.get_options(options=options, ret_type='dict')

        if '-s' not in dict_options:
            options = ['-s'] + options

        return super().start(options)


def set_iperf_path(iperf_path):
    """
    Update the path of iperf. The default value is simply a 'iperf' namely
    the class assumes that the iperf is located in one of directories where
    the system "PATH" environment variable includes.

    If this is not true then this function should be called and the path
    needs to be updated

    Args:
        iperf_path (str): A path to the iperf i.e.) /opt/iperf/iperf

    """
    Iperf3Base.set_iperf_path(iperf_path)
