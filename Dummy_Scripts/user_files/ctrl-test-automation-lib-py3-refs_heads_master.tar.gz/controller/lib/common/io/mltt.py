"""
:mod:`mltt` -- MLTT wrapper
===========================

.. module:: controller.lib.common.io.mltt
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a wrapper Python module for MLTT. For pain and maim, MLTT needs to be
installed only on SUT, but for sock which runs network traffic, MLTT needs to
be installed on both client and server systems.

The way to start sock client is easy

>>> from controller.lib.common.io import mltt
>>> sock = mltt.Sock()
>>> sock.start(dst_ip='70.168.2.2', runtime=60)

It will run "sock" as non-blocking. To check the running status, just like
subprocess.Popen object, you can call "poll" function

>>> sock.poll()
>>>

poll() returns 'None' just like subprocess.Popen when the process is still
running.

While MLTT is running, you can get the current, avg, min and max values of
IOPs, throughput, CPU % as well as a number of errors.

>>> sock.poll()
>>> sock.get_data().iops
<iops - min: 1458.00 | max: 1472.00 | avg: 1464.10 | cur: 1466.00>

It means below:

* min: Minimum IOPs over entire running time
* max: Maximum IOPs over entire running time
* avg: Average IOPs over entire running time
* cur: Average IOPs over last 1 second

You can also access such values through attributes.

>>> data = sock.get_data()
>>> data.throughput
<throughput MB/s - min: 89.12 | max: 92.00 | avg: 90.69 | cur: 90.25>

Allowed attributes are:

* iops (IOPs)
* throughput (throughput)
* cpu_util (CPU %)
* errors (Errors)

And each attribute has also has a list of available attributes as below:

* min
* max
* avg
* cur

For example, if you want to get the maximum throughput:

>>> data.throughput.max
'92.00'

The value will be updated and return the most recent information.

>>> sock.get_data().iops
<iops - min: 1458.00 | max: 1472.00 | avg: 1463.91 | cur: 1462.00>
>>> sock.get_data().iops
<iops - min: 1458.00 | max: 1472.00 | avg: 1463.58 | cur: 1460.00>

So you can collect information whenever you need. However, you need to be
careful that you do not pull the same information multiple times because the
data is updated every second.

For example, below "iops" reports the same number because they are collected
too quickly.

>>> sock.get_data().iops
<iops - min: 1458.00 | max: 1472.00 | avg: 1463.58 | cur: 1460.00>
>>> sock.get_data().iops
<iops - min: 1458.00 | max: 1472.00 | avg: 1463.58 | cur: 1460.00>

The way to know whether it's the same data or not is to check the elapsed_time

>>> sock.get_data().elapsed_time
60

So you can ignore the next data if it has the same elapsed_time value.

Once the MLTT stops running, poll() will return exitcode.

>>> sock.poll()
0

Which means there were no errors. If you get non-zero values, you should look
at the log and check any errors. You can find MLTT log files from following:

>>> sock.temp_dir
'/tmp/tmpLvPVoW'

"""

import tempfile
import re
import socket
import os
import time

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler
from distutils.spawn import find_executable
from functools import wraps


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class MLTTDataElement(object):
    def __init__(self, name, header, row_data, **kwargs):
        """

        Args:
            header (list): A list of header of CSV
            row_data (list): A list of single row data
            kwargs: keyword arguments for attributes of object

        """
        self._name = name
        for key, value in list(kwargs.items()):
            setattr(self, key, float(row_data[header.index(value)]))

    def __repr__(self):
        attr_list = []
        for key, value in list(self.__dict__.items()):
            if key.startswith('_'):
                continue

            attr_list.append('%s: %s' % (key, value))

        return '<%s - %s>' % (self._name, ' | '.join(attr_list))


class MLTTDataHandler(object):
    """
    Process the CSV to get data

    """

    @staticmethod
    def _parse_data(command_line, start_time, header, row_data,
                    ret_type='obj'):
        """
        Return data in dictionary which has keys 'iops', 'throughput',
        'cpu_util' and 'errors' which has below attributes each:

           * Current Avg IOPS, Avg IOPS, Max IOPS, Min IOPS
           * Current Avg MB/s, Avg MB/s, Max MB/s, Min MB/s
           * Current Avg % CPU, Avg % CPU, Max % CPU, Min % CPU
           * I/O Halts, I/O Timeouts, Data Corruption

        Args:
            command_line (str): Command line to execute MLTT. Should be parsed
               from CSV
            start_time (str): Start time of the test. Should be parsed from CSV
            row_data (str): A single line of CSV which will be converted to
               a dictionary
            ret_type (str): choices=[obj|dict] return type. if obj, return an
               object which has recursive attributes of the information. If
               dict, return as a dictionary

        Return:
            dict: 'iops', 'throughput', 'cpu_util' and 'errors' keys and
               attributes

        """

        iops = MLTTDataElement(
            name='iops', header=header, row_data=row_data,
            cur='Current Avg IOPS',
            min='Min IOPS', avg='Avg IOPS', max='Max IOPS')

        throughput = MLTTDataElement(
            name='throughput MB/s', header=header,
            row_data=row_data, cur='Current Avg MB/s',
            min='Min MB/s', avg='Avg MB/s', max='Max MB/s')

        cpu_util = MLTTDataElement(
            name='cpu_util', header=header, row_data=row_data,
            cur='Current % CPU',
            min='Min % CPU', avg='Avg % CPU', max='Max % CPU')

        errors = MLTTDataElement(
            name='errors', header=header, row_data=row_data,
            halt='I/O Halts', timeout='I/O Timeouts',
            corruption='Data Corruptions')

        latency = MLTTDataElement(
            name='latency', header=header, row_data=row_data,
            min='Min Completion Time', avg='Avg Completion Time',
            max='Max Completion Time')

        elapsed_time = row_data[
            header.index('Elapsed Time')]

        if ret_type == 'obj':
            return type('MLTTData', (object,), {
                'command_line': command_line,
                'start_time': start_time,
                'iops': iops,
                'throughput': throughput,
                'cpu_util': cpu_util,
                'errors': errors,
                'latency': latency,
                'elapsed_time': elapsed_time
                }
            )

        elif ret_type == 'dict':
            return {
                'command_line': command_line,
                'start_time': start_time,
                'iops': iops.__dict__(),
                'throughput': throughput.__dict__(),
                'cpu_util': cpu_util.__dict__(),
                'errors': errors.__dict__(),
                'latency': latency.__dict__(),
                'elapsed_time': elapsed_time.__dict__(),
            }

        else:
            raise exception.ValueException(
                'ret_type %s is invalid. choices=[obj|dict]')

    @staticmethod
    def get_data(csv_filename):
        """
        Parse command line, start time, header and last csv data without
        parsing the entire file for the case when the file size is really huge.

        Considered to parse every line dynamically, but it would generate too
        much overhead. Assume following:

           * command line at line 2
           * Test start time at line 3
           * header at line 5
           * data line 6+

        And parse hard-coded line as expected data. If format is changed by
        JDSU, will update the logic to parse data dynamically.

        """

        command_line = None
        start_time = None
        header = None

        csv_file_head = log_handler.get_head(csv_filename, 10)
        if len(csv_file_head) == 0:
            # No need to parse the data further - it's an empty file
            return None

        csv_file_tail = log_handler.get_tail(csv_filename, 1)[0].split(',')

        # Parse command, start time and header from the first 10 lines of csv
        for line_num, line_data in enumerate(csv_file_head, 1):
            if line_num == 2:  # command line
                command_line = re.match(
                    'Command line: (.*)', line_data).group(1)
            elif line_num == 3:  # start time
                start_time = re.match(
                    'Test Start Time: (.*)', line_data).group(1)
            elif line_num == 5:  # header
                header = line_data.split(',')

        if not command_line or not start_time or not header:
            raise exception.MLTTDataException(
                'Failed to parse the CSV. Head output: %s' % csv_file_head
            )

        if not len(csv_file_tail) == len(header):
            raise exception.MLTTDataException(
                'A length of header and data does not match. '
                'Header: %s, Data: %s (%s) '
                % (len(header), len(csv_file_tail), csv_file_tail)
            )

        if csv_file_tail == header:
            log.warning('No data in CSV is available yet')
            return None

        return MLTTDataHandler._parse_data(
            command_line=command_line, start_time=start_time,
            header=header, row_data=csv_file_tail
        )


class MLTTBase(object):
    """
    A base class for pain, maim and sock which share lots of options.

    Args:
        prg_name (str): A name of programs. choices=[pain|main|sock]

    """
    def __init__(self, prg_name, prg_path=None, *args, **kwargs):
        self._prg_name = prg_name
        self._prg_path = prg_path
        self._proc = None
        self._temp_dir = None
        self._data_handler = MLTTDataHandler()
        self._command = None

    def get_tool_path(self, exit_on_fail=True):
        prg_path = self._prg_path or find_executable(self._prg_name)

        if prg_path is None:
            # No need to check Windows since this is for systemctl workaround
            default_prg_path = '/opt/medusa_labs/test_tools/bin'
            if os.access(os.path.join(default_prg_path, self._prg_name), 0):
                prg_path = os.path.join(default_prg_path, self._prg_name)
            else:
                msg = (f'Cannot find MLTT {self._prg_name}. If it is installed, override the path by passing '
                       f'"prg_path" argument to the constructor (e.g. sock(prg_path="/usr/bin/mltt/sock")')
                raise exception.ConfigException(msg) if exit_on_fail else log.warning(msg)
        return prg_path

    def check_license(self):
        """
        This method returns True if valid MLTT license is present else False
        :return:
        """
        has_valid_license = False
        prg_path = self.get_tool_path(exit_on_fail=False)
        timeout = time.time() + 120  # exit after max 120 sec
        if prg_path:
            cmd_line = prg_path + " -d5"
            proc_obj = exe.run(cmd_line)
            while time.time() < timeout:
                if proc_obj.poll() is None:
                    time.sleep(0.1)
                else:
                    proc_obj.stop()
                    break
            output = proc_obj.get_output()
            if output.find("License successfully checked out") != -1 or output.find(
                    "Licensed to BROADCOM (valid until") != -1:
                log.info("MLTT license detected")
                has_valid_license = True
            else:
                log.error("Unable to checkout MLTT license")
                log.error(output)
        else:
            log.warning(f"Cannot find MLTT({self._prg_name})")

        return has_valid_license

    @property
    def temp_dir(self):
        """
        Return a temporary directory where MLTT log files will be stored.

        Return:
            str: Absolute path of the temporary directory
        """
        return self._temp_dir

    @staticmethod
    def _get_options(target, runtime, options):
        """"Return command line options

        Drop "-f" due to "target" should be used to specify targets
        Drop "-Y" due to getting information every sec
        Drop "-d" due to "runtime" should be used to specify runtime

        If "-M" is not given, set to 5 due to the "-M" is automatically set to
        1 due to "-Y" value

        Args:
            target (str): Target
            runtime (int): runtime in secs
            options (list): a list of options to be passed to MLTT
        """
        options = options or []

        # For RPyC compatibility and drop '-f', '-Y' and '-d' options
        options = [option for option in options if not (
            option.startswith('-f') or
            option.startswith('-Y') or
            option.startswith('-d')
        )]

        options = ['-f%s' % target, '-d%s' % runtime, '-Y1'] + options
        if not [option for option in options if option.startswith('-M')]:
            options.append('-M60')

        return ' '.join(options)

    @property
    def proc(self):
        """
        Return subprocess.Popen process object

        Return:
            Popen: subprocess.Popen object that runs MLTT tools
        """
        return self._proc

    @property
    def command(self):
        """
        Return a shell command that is exactly passed to exe. if None, the
        process has not started yet.

        Returns:
            str: command
            None: if the process has not started yet

        """
        return self._command

    def _started_only(func, *args, **kwargs):
        @wraps(func)
        def check_started(self, *args, **kwargs):
            if self.proc is None:
                log.warning('MLTT process has not started yet')
                return False
            return func(self, *args, **kwargs)
        return check_started

    def get_option_value(self, param):
        """
        Return a value of the parameter that is passed to MLTT

        Args:
            param (str): parameter i.e.) -b

        Returns:
            str: value for the given parameter
            None: If the given parameter is not passed to MLTT
        """
        if self.command is None:
            return None

        options = self.command.split()
        for option in options:
            if re.match(param + '(.*)', option):
                return re.match(param + '(.*)', option).group(1)

        return None

    def start(self, target, runtime, options=None,*args, **kwargs):
        """Start MLTT process

        Args:
            target (str): target where IO will rnn to (-f)
            runtime (int): runtime (-d)
            options (list): A list of options that will be passed to the MLTT
                process. i.e.) ['-b64k', '-t8', '-#3']
        """

        prg_path = self.get_tool_path()
        options = self._get_options(target=target, runtime=runtime, options=options)
        cmd_line = prg_path + ' ' + options

        log.info('MLTT command: %s' % cmd_line)
        self._command = cmd_line

        # cd to temp directory so log files can be kept separately
        self._temp_dir = tempfile.mkdtemp()
        log.debug('Temporary log directory: %s' % self._temp_dir)
        self._proc = exe.run(cmd_line, max_line=256, cwd=self._temp_dir)

    def block_start(
            self, target, runtime, options=None, timeout=None, *args, **kwargs):
        """
        Start MLTT process, but as blocking.

        Args:
            target (str): target where IO will rnn to (-f)
            runtime (int): runtime (-d)
            options (list): A list of options that will be passed to the MLTT
                process. i.e.) ['-b64k', '-t8', '-#3']
            timeout (None, int): timeout value in secs. Will raise exception
                if MLTT process still runs after this time

        """

        self.start(target, runtime, options, *args, **kwargs)

        stop_time = timeout if timeout is None else (time.time() + timeout)

        while stop_time is None or time.time() < stop_time:
            exitcode = self.poll()
            if exitcode is None:
                time.sleep(1)
                continue

            if exitcode == 0:
                return True

            raise exception.MLTTExitCodeException(
                'MLTT returned non-zero exitcode %s. Output: %s'
                % (exitcode, self.get_output())
            )

        raise exception.MLTTTimeout(
            'MLTT process is still running after timeout'
        )

    @_started_only
    def stop(self):
        """
        Kill the process using subprocess.Popen.kill()

        """
        self.proc.kill()

    @_started_only
    def poll(self):
        """
        A proxy to subprocess.Popen.poll(). Return None if the process is
        still running otherwise exitcode of the process

        Returns:
            int: exitcode of the process
            None: If process is still running

        """
        exitcode = self.proc.poll()
        if exitcode is not None and exitcode != 0:
            output = [
                line for line in self.proc.get_output().splitlines() if line
            ][-10:]

            raise exception.MLTTExitCodeException(
                'MLTT is terminated with errors. Last output: %s'
                % output
            )

        return exitcode

    @_started_only
    def get_data(self):
        """
        Parse a CSV file and return data object which has following attributes:

           * iops (cur, min, avg, max)
           * throughput (cur, min, avg, max)
           * cpu_util (cur, min, avg, max)
           * errors (IO halts, timeout, data corruption)
           * latency (min, avg, max)

        Note that all data is collected from the last row of CSV - which
        reflects entire running time values

        """

        # Get the CSV file name
        csv_filename = os.path.join(
            self._temp_dir, socket.gethostname() + '.csv')

        # Check whether file exists
        if not os.path.exists(csv_filename):
            return None  # No such file.

        return MLTTDataHandler.get_data(csv_filename)

    def get_output(self):
        """
        Return console output, but only up to last 256 lines since most data
        will be parsed from the MLTT log files.

        Returns:
            str: String output of MLTT
            None: If MLTT is not running yet
        """

        return self._proc.get_output() if self._proc else None

    def get_perf_rate(self, data=None):
        """Return performance efficiency (throughput / CPU util)"""
        perf_data = data or self.get_data()

        if perf_data is None:
            log.warning('No data is available from MLTT yet')
            return None

        if perf_data.cpu_util.avg == 0:
            log.warning(
                'Cannot calculate the performance rate due to CPU util % is 0')
            return None

        return round(
            float(perf_data.throughput.avg) / float(perf_data.cpu_util.avg), 2)

    def wait(self, timeout=None):
        """Wait until the process is terminated

        Args:
            timeout (None, int): timeout in secs. Raise exceptions if the
                process keeps running after this timeout
        """

        stop_time = timeout if timeout is None else (time.time() + timeout)

        while stop_time is None or time.time() < stop_time:
            exitcode = self.poll()
            if exitcode is None:
                time.sleep(1)
                continue

            if exitcode == 0:
                return True

            raise exception.MLTTExitCodeException(
                'MLTT returned non-zero exitcode. Output: %s'
                % (self.get_output())
            )

        raise exception.MLTTTimeout(
            'MLTT process is still running after timeout'
        )


class Pain(MLTTBase):
    """Run MLTT pain"""
    def __init__(self, *args, **kwargs):
        super(Pain, self).__init__('pain', *args, **kwargs)


class Maim(MLTTBase):
    """Run MLTT pain"""
    def __init__(self, *args, **kwargs):
        super(Maim, self).__init__('maim', *args, **kwargs)


class Sock(MLTTBase):
    """
    Run MLTT sock. Inherit methods from MLTTBase.

    """
    def __init__(self, *args, **kwargs):
        super(Sock, self).__init__('sock', *args, **kwargs)

    def block_start(
            self, dst_ip, runtime, options=None, timeout=None, *args, **kwargs):
        """
        Start Sock, but as blocking.

        Args:
            dst_ip (str): Destination IP address
            runtime (int): runtime in seconds
            options (list): A list of options that are passed to sock.
                e.g.) ['-%100', '-#1']
            timeout (int): timeout value in secs. Will raise exception if
                sock process still runs after timeout.
        Return:
            bool: True if successfully stops running

        """
        super(Sock, self).block_start(
            dst_ip, runtime, options, timeout, *args, **kwargs)

    def start(self, dst_ip, runtime, options=None, *args, **kwargs):
        """
        Start Sock. Override -Y option to 1.

        Args:
            dst_ip (str): Destination IP address
            runtime (int): runtime in seconds
            options (list): A list of options that are passed to sock.
                e.g.) ['-%100', '-#1']

        """

        super(Sock, self).start(dst_ip, runtime, options, *args, **kwargs)


def unittest(dst_ip='192.168.1.1'):
    import time

    sock = Sock()
    sock.start(dst_ip=dst_ip, runtime=15)

    while sock.poll() is None:
        time.sleep(1)

    return sock.get_data()
