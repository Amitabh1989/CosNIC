__version__ = "1.1.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

import copy
import operator
import platform
import re
import sys
from distutils.spawn import find_executable
from functools import wraps

from controller.lib.core import dpdk_telemetry

if platform.uname().system.lower() == "windows":
    import wexpect as pexpect
else:
    import pexpect

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


def convert_time(input_time):
    try:
        number, base = re.match(r'(\d+)([h|m|s]?)$', str(input_time)).groups()
    except AttributeError:
        raise exception.ValueException(
            'The given input_time value %s is not correct. Acceptable format: '
            '<number>[h|m|s> (i.e. 3h, 45m)' % input_time)

    if base == 'm':
        return int(number) * 60
    elif base == 'h':
        return int(number) * 3600

    return int(number)


class PktgenData(object):
    """A picklable pktgen data object.

    """
    if sys.version_info[0] >= 3:
        d_type = int
    else:
        d_type = int
        u_code = str
    PKTGEN_DATA_INDEX_MAPPING = [
        # 179.999365 main_thread 2688 12.862 Mpps 12.875 Mpkts 6.174 Gbps 1001030 usec 79.03 avg_batch 99999 min_space
        ('timestamp', float),
        ('thread_name', str),
        ('proc_id', int),
        ('pps', float),
        ('pps_unit', str),
        ('pkts', float),
        ('pkts_unit', str),
        ('bw', float),
        ('bw_unit', str),
        ('time', int),
        ('time_unit', str),
        ('avg_batch', float),
        ('avg_batch_name', str),
        ('min_space', int),
        ('min_space_name', str)
    ]

    PKTGEN_FINAL_DATA_INDEX_MAPPING = [
        # 'Speed 12.854 Mpps Bandwidth 6.170 Gbps raw 6.170 Gbps Average batch 99.44 pkts'
        ('speed', str),
        ('final_pps', float),
        ('pps_unit', str),
        ('bw_', str),
        ('final_bw', float),
        ('bw_unit', str),
        ('raw_', str),
        ('raw', float),
        ('raw_unit', str),
        ('average', str),
        ('batch', str),
        ('final_avg_batch', float),
        ('avg_batch_unit', str)
    ]

    # PKTGEN_DATA_INDEX_MAPPING = [
    #     #179.999365 main_thread 2688 12.862 Mpps 12.875 Mpkts 6.174 Gbps 1001030 usec 79.03 avg_batch 99999 min_space
    #     ('timestamp', str),
    #     ('thread_name', str),
    #     ('proc_id', str),
    #     ('pps', str),
    #     ('pps_unit', str),
    #     ('pkts', str),
    #     ('pkts_unit', str),
    #     ('bw', str),
    #     ('bw_unit', str),
    #     ('time', str),
    #     ('time_unit', str),
    #     ('avg_batch', str),
    #     ('avg_batch_name', str),
    #     ('min_space', str),
    #     ('min_space_name', str)
    # ]
    #
    # PKTGEN_FINAL_DATA_INDEX_MAPPING = [
    #     #'Speed 12.854 Mpps Bandwidth 6.170 Gbps raw 6.170 Gbps Average batch 99.44 pkts'
    #     ('speed', str),
    #     ('pps', str),
    #     ('pps_unit', str),
    #     ('bw_', str),
    #     ('bw', str),
    #     ('bw_unit', str),
    #     ('raw_', str),
    #     ('raw', str),
    #     ('raw_unit', str),
    #     ('average', str),
    #     ('batch', str),
    #     ('avg_batch', str),
    #     ('avg_batch_unit', str)
    # ]

    DATA_ATTRS = [map_element[0] for map_element in PKTGEN_DATA_INDEX_MAPPING
                  if map_element[0] != 'interval'] + ['int_stime', 'int_etime']

    def __init__(self, pktgen_data_line):
        """
        Args:
            pktgen_data_line (str): A single line that pktgen prints with the
                '-y C' option
        """
        self.total_sum = False
        self.interval_sum = None  # None=Unknown, True=multithread+src_port=0
        self.raw_data = None
        self.int_stime = 0
        self.int_etime = 0
        # Update the data values using the given pktgen output
        self.set_converted_data(pktgen_data_line)

    def set_converted_data(self, pktgen_data_line):
        """Parse the pktgen's output line, convert it to numbers and store
        them as attributes to the self.

        Args:
            pktgen_data_line (str): A single line of pktgen output

        """
        # Store the raw data
        self.raw_data = copy.deepcopy(pktgen_data_line)
        pktgen_data_line = re.sub("\(|\[|\]|\sin\s|:|\)\.|\)", " ", pktgen_data_line)
        pktgen_data = pktgen_data_line.split()

        if len(pktgen_data) != len(self.PKTGEN_DATA_INDEX_MAPPING) \
                and len(pktgen_data) != len(self.PKTGEN_FINAL_DATA_INDEX_MAPPING):
            raise exception.PktgenDataException('Data types %s is not expected %s or %s. '
                                                'Output: %s' % (len(pktgen_data), len(self.PKTGEN_DATA_INDEX_MAPPING),
                                                                len(self.PKTGEN_FINAL_DATA_INDEX_MAPPING),
                                                                pktgen_data_line))

        data_map = self.PKTGEN_DATA_INDEX_MAPPING \
            if len(pktgen_data) == len(self.PKTGEN_DATA_INDEX_MAPPING) \
            else self.PKTGEN_FINAL_DATA_INDEX_MAPPING

        for idx in range(len(pktgen_data)):
            datatype, objtype = data_map[idx]
            setattr(self, datatype, objtype(pktgen_data[idx]))

    @staticmethod
    def __get_num_matched(data_value, exprs):
        """A special handler for any integer or float types compare, to support
        >, <, ! and =.

        Args:
            data_value (str, int, float): A stored value
            exprs (str, int, float): An expression to compare with parameter
                "data_value"
        """
        ACCEPTABLE_OPERATORS = {'<': operator.lt, '<=': operator.le, '>': operator.gt, '>=': operator.ge}

        if sys.version_info[0] >= 3:
            u_code = str
            d_type = int
        else:
            u_code = str
            d_type = int
        if not isinstance(data_value, (int, d_type, float)) or not isinstance(exprs, (str, u_code)):
            # Not integer/float, and the exprs is not string
            # (namely no operator exists)
            # No need to compare. Return None.
            return None

        if re.match(r'([<>=!]=?)\s*(\d+\.?\d*)', exprs):
            opr, exprs_num = re.match(r'([<>!]=?)\s*(\d+\.?\d*)', exprs).groups()
            return ACCEPTABLE_OPERATORS[opr](data_value, float(exprs_num))

        raise exception.ValueException('The given expression %s is incorrect' % exprs)

    def get_matched(self, **kwargs):
        """Return True if the data is matched with the given filter arguments

        Args:
            **kwargs: keywoard arguments to check conditions i.e.) src_port=0,
                src_ip='192.168.1.1'

                If value is None, it means 'match any'. You can specify a
                custom function to check using 'func' keyword

        """
        for datatype, value in list(kwargs.items()):
            if value is None:  # Match any
                continue  # Check the next condition. Assume matched.
            elif hasattr(self, datatype):
                data_value = getattr(self, datatype)
                num_matched = self.__get_num_matched(data_value, value)

                if num_matched is None:  # Not comparable using operators
                    if data_value != value:  # If False, return.
                        return False
                elif num_matched is False:
                    return False

        if 'func' in kwargs:
            if not kwargs['func'](self):
                return False

        return True

    def get_data_info(self):
        """Return a dictionary that has the data related attributes.

        """
        ret_dict = {}

        for data_type in self.DATA_ATTRS:
            ret_dict[data_type] = getattr(self, data_type)

        return ret_dict

    def get_interval(self):
        """Return a running interval time of the data.

        """
        return self.int_etime - self.int_stime


class PktgenDataHandler(object):
    """A handler that stores a list of PktgenData objects and provides some
    functions to access data

    .. note::

        You must parse the output by calling PktgenBase.parse_output()
        before accessing any data

    """

    def __init__(self):
        # A list of the data. Line separated from the pktgen output
        self.data_list = []  # any types of data for each interval

    def append(self, data):
        """Append the given PktgenData object to lists.

        Args:
            data (PktgenData): data object
        """
        self.data_list.append(data)

    def filter(self, input_data=None, **kwargs):
        """Return a list of data that matches with the given keyword arguments.

        If multiple conditions are given, they will be processed as "AND".

        Args:
            input_data (list): A list of data that needs to be filtered. If not
                given, all available data will be used
            **kwargs: When data.<key> == <value>, the data will be returned.
                returned. For example::

                    filter(src_port=0)

                will return a list of PktgenData objects that src_port is 0.

            For data types that are integer or float, you can use the comparison
            operators. For example::

                filter(int_stime='>2')

            will return a list of PktgenData objects that have int_stime is
            greater than 2.

            if key == 'func', value can be any callback function which returns
            boolean.

            Possible keywords that can be used as filter are

            * timestamp (int): timestamp
            * src_ip (str): source IP address
            * src_port (int): source port
            * dst_ip (str): destination IP address
            * dst_port (int): destination port
            * id (int): ID number that pktgen assigns
            * int_stime (int): Interval start time
            * int_etime (int): Interval end time
            * tx_bytes (int): Transmitted bytes for interval
            * bps (int): Bit per second
            * total_sum (bool): True if data is the total sum that is returned
              by pktgen at exit
            * interval_sum (bool): True if data is the sum of each interval.

        """
        ret_list = []
        input_data = input_data or self.data_list

        for data in input_data:
            for datatype in list(kwargs.keys()):
                if hasattr(data, datatype):
                    ret_list.append(data)

        return ret_list

    def get_pps(self, output_format='%bps', **kwargs):
        kwargs['pps'] = kwargs.get('pps', False)
        data_list = self.filter(**kwargs)

        if len(data_list) > 0:
            return self.get_pps_format(data_list=data_list, output_format=output_format, **kwargs)

        return []

    def get_final_pps(self, output_format='%bps', **kwargs):
        kwargs['final_pps'] = kwargs.get('final_pps', True)
        data_list = self.filter(**kwargs)

        if len(data_list) > 0:
            return self.get_pps_format(data_list=data_list, output_format=output_format, **kwargs)[-1]

        return None

    def get_final_bandwidth(self, output_format='%bps', **kwargs):
        kwargs['final_bw'] = kwargs.get('final_bw', True)
        data_list = self.filter(**kwargs)

        if len(data_list) > 0:
            return self.get_bandwidth_format(data_list=data_list, output_format=output_format, **kwargs)[-1]

    def get_pps_format(self, data_list, output_format='%bps', **kwargs):
        """Return a throughput using the given format.

        * %timestamp: timestamp
        * %src_ip: source IP
        * %src_port: source port
        * %dst_ip: destination IP
        * %dst_port: destination port
        * %id: id
        * %int_stime: interval start time
        * %int_etime: interval end time
        * %tx_bytes: transferred bytes
        * %tx_mbytes: transferred mega bytes
        * %tx_gbytes: transferred giga bytes
        * %bps: bits per second
        * %kbps: kbits per second
        * %mbps: mbits per second
        * %gbps: gbits per second
        * %Kbps: Kbytes per second
        * %Mbps: Mbytes per second
        * %Gbps: Gbytes per second

        For example::

            output_format='%timestamp: %src_ip -> %dst_ip = %bps'

        Will print::

            20140429124841: 192.168.1.1 -> 192.168.1.2 = 10484195328

        Args:
            data_list (list): A list of data which will be used to print the
                throughput
            output_format (str): A string format how the output will be
                returned. Default is simply return a bps.

        """

        def get_sub_dict(data_obj):
            byte_divider = 1024.0
            bit_divider = 1000.0
            return {
                '%timestamp': str(data_obj.timestamp),
                '%src_ip': str(data_obj.src_ip),
                '%src_port': str(data_obj.src_port),
                '%dst_ip': str(data_obj.dst_ip),
                '%dst_port': str(data_obj.dst_port),
                '%id': str(data_obj.id),
                '%int_stime': str(data_obj.int_stime),
                '%int_etime': str(data_obj.int_etime),
                '%tx_bytes': str(data_obj.tx_bytes),
                '%tx_kbytes': '%.2f' % (data_obj.tx_bytes / byte_divider),
                '%tx_mbytes': '%.2f' % (data_obj.tx_bytes / (byte_divider ** 2)),
                '%tx_gbytes': '%.2f' % (data_obj.tx_bytes / (byte_divider ** 3)),
                '%bps': str(data_obj.bps),
                '%kbps': '%.2f' % (data_obj.bps / bit_divider),
                '%mbps': '%.2f' % (data_obj.bps / (bit_divider ** 2)),
                '%gbps': '%.2f' % (data_obj.bps / (bit_divider ** 3)),
                '%Kbps': '%.2f' % (data_obj.bps / 8 * bit_divider),
                '%Mbps': '%.2f' % (data_obj.bps / (8 * bit_divider ** 2)),
                '%Gbps': '%.2f' % (data_obj.bps / (8 * bit_divider ** 3)),
            }

        ret_list = []

        for data in data_list:
            for datatype in list(kwargs.keys()):
                if hasattr(data, datatype):
                    ret_list.append(getattr(data, datatype))

        # for data in data_list:
        #     # sub_dict = get_sub_dict(data)
        #     # pattern = re.compile('|'.join(list(sub_dict.keys())))
        #     # ret_list.append(pattern.sub(lambda x: sub_dict[x.group()], output_format))
        #
        #     ret_list.append(data.pps)
        return ret_list

    def get_bandwidth_format(self, data_list, output_format=None, **kwargs):
        bw = []
        for data in data_list:
            for datatype in list(kwargs.keys()):
                if hasattr(data, datatype):
                    bw.append(getattr(data, datatype))

        # for data in data_list:
        #     # sub_dict = get_sub_dict(data)
        #     # pattern = re.compile('|'.join(list(sub_dict.keys())))
        #     # ret_list.append(pattern.sub(lambda x: sub_dict[x.group()], output_format))
        #     if getattr(data, 'final_bw'):
        #         bw.append(data.final_bw)
        return bw


class PktgenBase(object):
    """A base class for pktgen Client and Server classes.

    """

    def __init__(self, app_path=None):
        self._data_handler = None
        self._pktgen_proc = None
        self._exe = exe
        self.PKTGEN_PATH = app_path or find_executable('pkt-gen')

    @property
    def pktgen_proc(self):
        """Return pktgen subprocess.Popen object if pktgen is running otherwise None

        Return:
            object: subrprocess.Popen object of pktgen
        """
        return self._pktgen_proc

    def set_pktgen_path(self, pktgen_path=None, bind_path=None):
        """Update the path of pktgen.

        The default value is simply a 'pktgen' namely
        the class assumes that the pktgen is located in one of directories where
        the system "PATH" environment variable includes.

        If this is not true then this function should be called and updated

        Args:
            pktgen_path (str): A path to the pktgen. i.e.) /opt/pktgen/pktgen
            bind_path : Custom path to launch pktgen like taskset -c pktgen

        """
        if pktgen_path:
            self.PKTGEN_PATH = pktgen_path
        if bind_path:
            self.PKTGEN_PATH = bind_path + ' ' + self.PKTGEN_PATH

    @staticmethod
    def get_options(options, ret_type='str'):
        """Return dict/string type options that will be passed to the pktgen when
        start() is called.

        Following options will be added by default:

          * '-y C': Will be added if '-y' is not given.
          * '-i 1': Only if -i option is not passed in options.

        Note that '-c' and '-s' options will be added depending on class. For
        example, Client() class will add '-c <IP>' if it's not given.

        Args:
            options (list): A list of pktgen options that will be passed to
                pktgen i.e.) ['-u', '-t 90']. If None, use self.options by
                default
            ret_type: Return type - default is string, which returns a
                string options. If it's a "dict", it will return the dictionary
                options (key=option, value=option value)

        Returns:
            dict: key=option name, value=value
            str: String of options
        """
        ret_dict = {}
        ret_string = ''

        for option in options:
            key, value = option.split() if len(option.split()) > 1 else (option, None)
            ret_dict[key] = value
            ret_string += ' ' + key + ('' if value is None else (' ' + value))

        return ret_string if ret_type == 'str' else ret_dict

    def parse_output(self):
        """Parse the output of pktgen and pass it to data_handler

        """
        if self._pktgen_proc is None:
            log.warning('pktgen has not been started yet. Do nothing.')
            return

        output = self._pktgen_proc.get_output()
        log.debug('pktgen output: %s' % output)

        for pktgen_data_line in output.splitlines():
            # Filter out blank lines
            if pktgen_data_line is '':
                continue

            # if pktgen_data_line.find(',') == -1:
            #     continue

            if 'avg_batch' in pktgen_data_line or 'Speed' in pktgen_data_line:
                data = PktgenData(pktgen_data_line)
                self._data_handler.append(data)

    def get_data(self, **kwargs):
        """Return the data that has been collected.

        kwargs will be used for filtering data. For available filtering
        options, refer PktgenDataHandler.filter()

        Args:
            **kwargs: keyword arguments that is passed to PktgenDataHandler.filter

        """
        self.parse_output()
        return self._data_handler.filter(**kwargs)

    def start(self, options):
        """Start pktgen. Reset the data_handler.

        """
        # Add -Y and -i 1 options and get the string options
        # Instantiate a datahandler which is holds a list of PktgenData objects
        self._data_handler = PktgenDataHandler()

        options = str(self.get_options(options, ret_type='str'))
        if self.PKTGEN_PATH is None:
            log.info('Starting pktgen (command: pktgen %s)' % options)
            self._pktgen_proc = self._exe.run('pktgen' + ' ' + options)
        else:
            log.info('Starting pktgen (command: %s %s)' % (self.PKTGEN_PATH, options))

            try:
                self._pktgen_proc = self._exe.run(self.PKTGEN_PATH + ' ' + options)
            except OSError as err:
                if 'No such file' in str(err) or 'The system cannot find the file' in str(err):
                    raise exception.ConfigException('Cannot find pktgen. Please set the path to the pktgen')

        return self.pktgen_proc

    def stop(self):
        """Stop pktgen and clean up the open fd

        """
        if self._pktgen_proc is None:
            log.warning('pktgen_pid is None. Return True.')
            return False
        self._pktgen_proc.proc.send_signal(exe.subprocess.signal.SIGINT)
        self.poll()
        return True

    def poll(self):
        """Proxy to subprocess.poll()

        Returns:
            int: exitcode of the process
            None: the process is still running
        """
        return self._pktgen_proc.proc.poll()

    def get_pps(self, output_format='%bps', **kwargs):
        """
        Return the list of numbers as 'output_format' is specified. Will not
        return the total sum throughput data since this can be separately
        returned by self.get_sum_throughput()

        Also no per thread throughput when there are multiple threads - to
        access this data should use PktgenDataHandler.filter()

        Args:
            output_format (str): Refer PktgenDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data

        Returns:
            list: Numbers of throughput numbers as 'output_format'

        """
        if not self._data_handler:
            log.warning('pktgen has not started yet. Do nothing')
            return

        self.parse_output()
        return self._data_handler.get_pps(output_format=output_format, **kwargs)

    def get_final_pps(self, output_format='%bps', **kwargs):
        """
        Return the list of numbers as 'output_format' is specified. Will not
        return the total sum throughput data since this can be separately
        returned by self.get_sum_throughput()

        Also no per thread throughput when there are multiple threads - to
        access this data should use PktgenDataHandler.filter()

        Args:
            output_format (str): Refer PktgenDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data

        Returns:
            list: Numbers of throughput numbers as 'output_format'

        """
        if not self._data_handler:
            log.warning('pktgen has not started yet. Do nothing')
            return

        self.parse_output()
        return self._data_handler.get_final_pps(output_format=output_format, **kwargs)

    def get_final_bandwidth(self, output_format='%bps', **kwargs):
        """
        This function does the same job as get_throughput() except this only
        checks and returns the last summary data that pktgen reports at exit

        If such data is not available yet (namely pktgen is still running) then
        will return None

        Args:
            output_format (str): Refer PktgenDataHandler.get_throughput_format()
            kwargs: Keyword arguments to filter data

        """
        if not self._data_handler:
            log.warning('pktgen has not started yet. Do nothing')
            return

        self.parse_output()
        return self._data_handler.get_final_bandwidth(output_format=output_format, **kwargs)

    def is_done(self):
        """
        Return True if pktgen stops running otherwise False.
        Raise exceptions when pktgen stops but cannot get the last summary data

        Returns:
            bool: True if pktgen stops running otherwise False

        """
        if self.poll() is None:
            return False

        if self.get_final_bandwidth() is None:
            raise exception.PktgenDataException('Failed to get the final bandwidth.')
        else:
            log.debug('bandwidth: %s' % self.get_final_bandwidth())

        self.parse_output()
        return True


class RX(PktgenBase):
    """pktgen Client object that inherits functions from PktgenBase

    Args:
        dst_ip (str): Destination IP address

    """

    def __init__(self, app_path=None):
        super(RX, self).__init__(app_path)

    def start(self, iface, ipv=4, vary_ip=False, vary_port=None, threads=None, cpus=None, options=None):
        """
        Start pktgen client.

        Args:
            dst_ip (str): Destination IP address
            options (list): List of options that will be passed to pktgen. For
                example, ['-t 10', '-u'] will be passed as '-t 10 -u'
        """
        options = options or []
        # Convert from netref.list to list when this is called over RPyC
        options = [option for option in options]
        dict_options = self.get_options(options=options, ret_type='dict') if options else {}
        dict_options['-i'] = iface
        dict_options['-f'] = 'rx'
        if vary_ip:
            dict_options['-z'] = None
        if vary_port:
            dict_options['-Z'] = None
        if threads:
            dict_options['-p'] = threads
        if ipv:
            dict_options[f'-{ipv}'] = None
        if cpus:
            dict_options['-c'] = cpus

        options = options + [f'{k} {v if v else ""}' for k, v in dict_options.items()]
        super(RX, self).start(options=options)


class TX(RX):
    """
    pktgen Server object that inherits functions from PktgenBase.

    """

    def __init__(self, app_path=None):
        super(RX, self).__init__(app_path)

    def start(self, iface, mac_addr=None, msg_len=None, ipv=4, vary_ip=False, vary_port=None, threads=None, cpus=None,
              options=None):
        """
        Start pktgen client.

        Args:
            dst_ip (str): Destination IP address
            options (list): List of options that will be passed to pktgen. For
                example, ['-t 10', '-u'] will be passed as '-t 10 -u'
        """
        options = options or []
        # Convert from netref.list to list when this is called over RPyC
        options = [option for option in options]
        dict_options = self.get_options(options=options, ret_type='dict') if options else {}

        dict_options['-i'] = iface
        dict_options['-f'] = 'tx'
        if mac_addr:
            dict_options['-D'] = mac_addr
        if vary_ip:
            dict_options['-z'] = None
        if vary_port:
            dict_options['-Z'] = None
        if msg_len:
            dict_options['-l'] = msg_len
        if threads:
            dict_options['-p'] = threads
        if ipv:
            dict_options[f'-{ipv}'] = None
        if cpus:
            dict_options['-c'] = cpus

        options = options + [f'{k} {v if v else ""}' for k, v in dict_options.items()]
        super(RX, self).start(options=options)


class Telemetry(object):
    """
    {
        "/": ["/", "/cnxk/ethdev/info", "/cnxk/mempool/info", "/cnxk/nix/cq/ctx", "/cnxk/nix/cq/info", "/cnxk/nix/info",
              "/cnxk/nix/list", "/cnxk/nix/rq/ctx", "/cnxk/nix/rq/info", "/cnxk/nix/sq/ctx", "/cnxk/nix/sq/info",
              "/cnxk/npa/aura/info", "/cnxk/npa/aura/list", "/cnxk/npa/info", "/cnxk/npa/pool/info",
              "/cnxk/npa/pool/list", "/cryptodev/caps", "/cryptodev/info", "/cryptodev/list", "/cryptodev/stats",
              "/eal/app_params", "/eal/heap_info", "/eal/heap_list", "/eal/memzone_info", "/eal/memzone_list",
              "/eal/params", "/ethdev/info", "/ethdev/link_status", "/ethdev/list", "/ethdev/stats", "/ethdev/xstats",
              "/eventdev/dev_list", "/eventdev/dev_xstats", "/eventdev/port_list", "/eventdev/port_xstats",
              "/eventdev/queue_links", "/eventdev/queue_list", "/eventdev/queue_xstats", "/eventdev/rxa_queue_conf",
              "/eventdev/rxa_queue_stats", "/eventdev/rxa_queue_stats_reset", "/eventdev/rxa_stats",
              "/eventdev/rxa_stats_reset", "/help", "/info", "/mempool/info", "/mempool/list", "/rawdev/list",
              "/rawdev/xstats", "/security/cryptodev/crypto_caps", "/security/cryptodev/list",
              "/security/cryptodev/sec_caps"
              ]
    }
    """

    def __init__(self):
        self.pktgen_name = None
        self.sock_path = None
        self.sock, self.tel_prompt, self.output_buf_len = None, None, None

    def connect(self, file_prefix):
        self.sock_path = dpdk_telemetry.sock_path(file_prefix=file_prefix)
        self.sock, self.tel_prompt, self.output_buf_len = dpdk_telemetry.handle_socket(file_prefix=file_prefix,
                                                                                       path=self.sock_path)

    def run_tele_command(self, cmd):
        return dpdk_telemetry.run_command(cmd, self.sock, self.output_buf_len)

    def port_list(self):
        cmd = '/ethdev/list'
        return self.run_tele_command(cmd)[cmd]

    def port_info(self, port):
        cmd = '/ethdev/info'
        return self.run_tele_command(f'{cmd},{port}')[cmd]

    def port_link_status(self, port):
        cmd = '/ethdev/link_status'
        return self.run_tele_command(f'{cmd},{port}')[cmd]['status']

    def port_stats(self, port):
        cmd = '/ethdev/stats'
        return self.run_tele_command(f'{cmd},{port}')[cmd]

    def port_xstats(self, port):
        cmd = '/ethdev/xstats'
        return self.run_tele_command(f'{cmd},{port}')[cmd]


class Interactive(object):
    def __init__(self, app_path, prompt=None):
        self._exe = exe
        self.newline = '\n'
        self._prompt = prompt
        self._prg_path = app_path
        if self._prg_path is None:
            raise exception.ToolNotFoundException('app path path is not provided')

        self.pexpect_spawn_obj = None

    def started_only(func, *args, **kwargs):
        @wraps(func)
        def conn_check(self, *args, **kwargs):
            if self._prompt is None:
                raise exception.HostException('Prompt is not set yet. Please set prompt ')
            if self.pexpect_spawn_obj is None:
                raise exception.HostException('Interactive session is not started yet')
            return func(self, *args, **kwargs)

        return conn_check

    @property
    def prg_path(self):
        return f"{self._prg_path}"

    @property
    def prompt(self):
        return self._prompt

    @prompt.setter
    def prompt(self, app_prompt):
        self._prompt = app_prompt

    def run(self, app_cmd):
        """
        This method will start interactive pktgen session.
        After session is started, should call exec_command method for any command execution
        Returns: None

        """
        log.info(f"Run application using command: {app_cmd}")
        self.pexpect_spawn_obj = pexpect.spawn(app_cmd, encoding='utf-8')
        self.pexpect_spawn_obj.expect([self.prompt], timeout=60)

    def exec_command(self, cmd, **kwargs):
        kwargs.pop('shell', None)  # shell is not applicable in pktgen prompt
        kwargs.pop('silent', None)  # silent is not applicable in pktgen prompt
        options = []
        for k, v in kwargs.items():
            options.append(f'{k}' if v is None else f'{k} {v}')
        options = ' '.join(options)
        cmd = f'{cmd} {options}'
        output = self.run_command(cmd)
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~]|[0-?]*)')
        output = ansi_escape.sub('', output)
        return output

    @started_only
    def run_command(self, command, timeout=5, **kwargs):
        """
        Args:
            command: Command to be executed in pktgen interactive prompt
            timeout:
        Returns: Output of the executed command in pktgen prompt

        """
        log.info(f'Executing command, {command}')
        self.pexpect_spawn_obj.sendline(command)
        self.pexpect_spawn_obj.expect([self.prompt], timeout=timeout)
        log.info(self.pexpect_spawn_obj.before)
        return self.pexpect_spawn_obj.before

    def quit(self):
        """
        Closes the Pexpect object.
        Returns:None

        """
        cmd = "quit"
        log.info(f'Quitting the application.')
        log.info(f'Executing command, {cmd}')
        self.pexpect_spawn_obj.sendline(cmd)
        self.pexpect_spawn_obj.close()
        self.pexpect_spawn_obj = None


class PktgenDpdk(Interactive, Telemetry):

    def __init__(self, pktgen_path):
        super(PktgenDpdk, self).__init__(pktgen_path)
        self._prompt = 'Pktgen:/>'
        self.pexpect_spawn_obj = None

    def launch(self, eal_dict, app_dict):
        def prepare_args(opts):
            opts_list = []
            for k, v in opts.items():
                k = f'-{k}' if len(k) == 1 else f'--{k}'
                if isinstance(v, list):
                    for value in v:
                        opts_list.append(f'{k} {value}')
                else:
                    opts_list.append(f'{k} {v if v else ""}')
            return ' '.join(opts_list)
        eal_opts = prepare_args(eal_dict)
        app_opts = prepare_args(app_dict)
        app_cmd = f'{self._prg_path} {eal_opts} -- {app_opts}'
        log.info(f'pktgen command is {app_cmd}')
        self.run(app_cmd)
        self.connect(file_prefix=eal_dict.get('file-prefix', ""))

    def start(self, ports='all'):
        return self.exec_command(f'start {ports}')

    def stop(self, ports='all'):
        return self.exec_command(f'stop {ports}')

    def clr(self):
        return self.exec_command('clr')

    def quit(self):
        if self.sock:
            self.run_tele_command('quit')
        super().quit()

    def load_cmds(self, cmds=None):
        output = ""
        for cmd in cmds:
            output += f'{cmd} output: \n' + self.exec_command(cmd)
        return output
