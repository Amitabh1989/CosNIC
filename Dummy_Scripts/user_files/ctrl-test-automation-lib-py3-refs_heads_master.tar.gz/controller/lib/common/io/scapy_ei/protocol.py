"""
:mod:`protocol` -- Custom protocols for Scapy
=============================================

.. module:: controller.lib.common.io.scapy_ei.protocol
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Define custom protocols here.

VXLAN is back-ported from the tip of the Scapy development version.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

import logging

log = logging.getLogger(__name__)

from scapy.packet import Raw
from scapy.layers.l2 import Ether

MAC_CONTROL_PAUSE = Ether(type=0x8808, dst='01:80:c2:00:00:01') / \
                    Raw(load='\x00\x01\xff\xff' + '\x00' * 4)
