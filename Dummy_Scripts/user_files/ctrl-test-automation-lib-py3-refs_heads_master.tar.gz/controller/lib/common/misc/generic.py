"""
:mod:`generic` -- The test script template
===========================================

.. module:: controller.lib.common.misc.generic
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""


import time
import re
import os

from controller.lib.common.shell import exe
from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class generic(object):
    def __init__(self, os_type=None):
        self.os_type = os_type

    def edit_file(self, file, line_to_find, new_line):
        content = ""
        with open(file, 'r') as upma:
            content = upma.read()
        pattern = re.compile('HiiDump2\s+.*\.txt')
        new_content = (re.sub(pattern, new_line, content))

        with open(file, 'w') as upma:
            upma.write(new_content)
