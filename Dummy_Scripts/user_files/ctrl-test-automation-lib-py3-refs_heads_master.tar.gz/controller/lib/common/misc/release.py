"""
:mod:`release` -- Interact with the releases
============================================

.. module:: controller.lib.common.misc.release
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import os
import re

from controller.lib.core import exception


class BaseRelease(object):
    def __init__(self, name, rel_dir, dir_format, map_dict=None, **kwargs):
        self._name = name
        self._rel_dir = rel_dir[:-1] if rel_dir.endswith('/') else rel_dir
        self._dir_format = dir_format

    @property
    def name(self):
        return self._name

    @property
    def rel_dir(self):
        return self._rel_dir

    @property
    def dir_format(self):
        return self._dir_format

    def get_latest_version(self):
        """Return the latest version.

        Note that this method should be overriden if the version does not
        follow the format x.y.z
        """

        ver_dir_list = [
            dir_name for dir_name in os.listdir(self.rel_dir)
            if re.match(r'\d+\.\d+\.\d+$', dir_name)]
        ver_dir_list.sort(key=lambda v: list(map(int, v.split('.'))))

        return ver_dir_list[-1]

    def get_filename(self, version):
        filename = self.dir_format.format(rel_dir=self.rel_dir, ver=version)

        if not os.access(filename, 0):
            raise exception.ValueException('Cannot find %s' % filename)

        return filename


class BnxtEn(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        drv_name = 'bnxt' if 'FreeBSD' in rel_dir else 'bnxt_en'
        prefix = 'freebsd-' if 'FreeBSD' in rel_dir else ''
        dir_format = dir_format or '{rel_dir}/{ver}/' + prefix + drv_name + '-{ver}.tar.gz'
        super().__init__(drv_name, rel_dir, dir_format, **kwargs)


class BnxtRe(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        drv_name = 'bnxt' if 'FreeBSD' in rel_dir else 'bnxt_re'
        prefix = 'freebsd-' if 'FreeBSD' in rel_dir else ''
        dir_format = dir_format or '{rel_dir}/{ver}/' + prefix + drv_name + '-{ver}.tar.gz'
        super().__init__(drv_name, rel_dir, dir_format, **kwargs)


class Bnxtnd(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        dir_format = (
            dir_format or '{rel_dir}/ndis/{ver}/public/x64/Debug/bnxtnd.inf')
        super(Bnxtnd, self).__init__('bnxtnd', rel_dir, dir_format, **kwargs)

    def get_latest_version(self):
        """Return the latest version"""

        ver_dir_list = [
            dir_name for dir_name in os.listdir(self.rel_dir + '/ndis')
            if re.match('\d+\.\d+\.\d+\.\d+\$', dir_name)]
        ver_dir_list.sort(key=lambda v: list(map(int, v.split('.'))))

        return ver_dir_list[-1]


class Chimp(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        dir_format = dir_format or '{rel_dir}/{ver}/CM_A/cm_a.pkg'
        super(Chimp, self).__init__('chimp', rel_dir, dir_format, **kwargs)


class Lcdiag(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        dir_format = (
            dir_format or "{rel_dir}/{ver}/linux/lcdiag-{ver}-x86_64.tar.gz")
        super(Lcdiag, self).__init__('lcdiag', rel_dir, dir_format, **kwargs)


class Cwdiag(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        dir_format = (
            dir_format or "{rel_dir}/{ver}/win64/")
        super(Cwdiag, self).__init__('cwdiag', rel_dir, dir_format, **kwargs)


class SITRelease(BaseRelease):
    def __init__(self, rel_dir, dir_format=None, **kwargs):
        dir_format = dir_format or "{rel_dir}/INT_Cuw_{ver}"
        super(SITRelease, self).__init__(
            'sit_release', rel_dir, dir_format, **kwargs)

    def get_path(self, version):
        return self.dir_format.format(rel_dir=self.rel_dir, ver=version)

    def get_bnxtnd(self, version):
        return self.get_path(version) + '/Windows_Driver/Release'

    def get_bnxt_en(self, version):
        return self.get_path(version) + '/Linux_Driver'

    def get_cdiag(self, version, os_name):
        if os_name not in ['linux', 'win32', 'win64']:
            raise exception.ValueException(
                'Not a valid os_name. choices=[linux|win32|win64]')

        return self.get_path(version) + '/CDiag/' + os_name
