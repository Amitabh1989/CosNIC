"""
:mod:`dpdk` -- Maia DPDK Config
========================================

.. moduleauthor:: Hemanth MB <hemanth.mb@broadcom.com>

"""


import logging
import abc

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = logging.getLogger(__name__)




class BaseDpdk(object, metaclass=abc.ABCMeta):
    def __init__(self, maia_ip, sut):
        self.maia_ip = maia_ip
        self.sut = sut

    @abc.abstractmethod
    def load(self, path="/usr/share/dpdk/arm64-stingray-linuxapp-gcc/igb_uio.ko"):
        """
        :param path:
        :return:
        """
        raise NotImplemented

    @abc.abstractmethod
    def unbind(self, buses):
        """
        :param bus:
        :return:
        """
        raise NotImplemented

    @abc.abstractmethod
    def bind(self, devid):
        """
        :param devid:
        :return:
        """
        raise NotImplemented

    @abc.abstractmethod
    def hugepage(self, dname="/mnt/huge", byte="1024"):
        """
        :param dname:
        :return:
        """
        raise NotImplemented

    @abc.abstractmethod
    def delete_hugepage(self, path="/dev/hugepages"):
        """
        :param path:
        :return:
        """
        raise NotImplemented

