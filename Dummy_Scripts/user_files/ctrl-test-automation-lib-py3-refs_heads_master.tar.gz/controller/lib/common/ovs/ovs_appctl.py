"""
:mod:`ovs_config` -- ovs Config
========================================

.. moduleauthor:: Sudheer Vegesna <sudheer.sudheer@broadcom.com>

"""

import logging
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

log = logging.getLogger(__name__)


class BaseOpenSwitchAppctlCommon(object):
    def __init__(self):
        self._ovsappctl_path = find_executable('ovs-appctl')
        if self._ovsappctl_path is None:
            raise exception.ConfigException('ovs-appctl is not available')

    def vlog_set(self, module, type, level):
        """
        :return:
        """
        exe.block_run(f'{self._ovsappctl_path} vlog/set {module}:{type}:{level} ')

    def vlog_list(self, module, type, level):
        """
        :return:
        """
        command_output = exe.block_run(f'{self._ovsappctl_path} vlog/list | grep -e {module} ')
        return command_output

    def dump_flows(self, type='offloaded', **kwargs):
        """
        :return:
        """
        opts = []
        for k, v in kwargs:
            opts = [f'{k}={v}'] if v else {k}
        opts = ' '.join(opts)
        command_output = exe.block_run(f'{self._ovsappctl_path} dpctl/dump-flows -m type={type} {opts}')
        return command_output
