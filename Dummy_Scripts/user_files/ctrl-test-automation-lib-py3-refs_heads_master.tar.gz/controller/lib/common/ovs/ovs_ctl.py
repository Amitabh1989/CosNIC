"""
:mod:`ovs_vsctl` -- Abstract classes for vsctl
========================================

.. moduleauthor:: Sudheer Vegesna <sudheer.vegesna@broadcom.com>

"""

import logging
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

log = logging.getLogger(__name__)


class BaseOvsctl(object):
    def __init__(self):
        self._ovsctl_path = find_executable('ovs-ctl')
        if self._ovsctl_path is None:
            raise exception.ConfigException('ovs-ctl is not available')

    def start(self, option=None, sock=None):
        """
        :param option:
        :param sock:
        :return:
        """
        command = f'{self._ovsctl_path} '
        if option is not None:
            command += '--no-%s ' % option
        if sock is not None:
            command += r' --db-sock=""%s"" ' % sock
        command += ' start'
        exe.block_run(command, shell=True)

    def stop(self):
        """
        :param:
        :return:
        """
        exe.block_run(f'{self._ovsctl_path} stop')

    def restart(self, option=None, sock=None):
        """
        :param option:
        :param sock:
        :return:
        """
        command = f'{self._ovsctl_path}'
        if option is not None:
            command += '--no-%s' % option
        if sock is not None:
            command += r'--db-sock=""%s""' % sock
        command += ' restart'
        exe.block_run(command, shell=True)

    def status(self):
        """
        :param:
        :return: None
        """
        exe.block_run(f'{self._ovsctl_path} status')
