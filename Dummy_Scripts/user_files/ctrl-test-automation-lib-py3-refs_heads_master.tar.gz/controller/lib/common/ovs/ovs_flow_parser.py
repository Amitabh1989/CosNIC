"""
:mod:`ovs_flow_parser` -- To parse the ovs truflow, Create the Pcap file based on the rule
========================================

.. module author:: Surendra Narala <surendra-reddy.narala@broadcom.com>, Madhusudana<madhusudana.annam@broadcom.com>

Usage:

def parser(rule):
    p, a = unpack_rule(rule.strip())
    print(p, a)
    pt = MatchParser(p)
    ac = ActionParser(a)
    pd = pt.parse()
    ad = ac.parse()
    return pd, ad


rule = 'ovs-ofctl add-flow br0 "in_port=pf0_vf0,udp6,dl_src=14:23:f2:3a:3f:00,dl_dst=00:62:0b:ca:c9:80,ipv6_src=100::47f,tp_src=2815,tp_dst=2863,action=set_mac_src=24:23:f2:3a:3f:00,set_mac_dst=01:62:0b:ca:c9:80,set_ipv6_src=300::3ac,set_ipv6_dst=400::3ac,set_tp_src=1444,set_tp_dst=1444,push_vlan=0x8100,set_vlan_vid=1981,output=ens2f0v11"'
match, act = parser(rule)
print(match.ipv)
print(type(act))

with open('C:\\Users\Administrator\Downloads\ovs_flows.txt', 'r') as fd:
    flows = fd.readlines()
    for i, rule in enumerate(flows):
        if rule.strip() == '':
            continue
        print('\n')
        print(f'{i}: {rule.strip()}')
        parser(rule)

"""


import re
import ipaddress
import tempfile
import os

class Parser:

    def __init__(self, ptrn):
        self.pattern = ptrn
        self.field_val_dict = {}

    def parse(self):
        field_val_tokens = self.pattern.split(',')
        print(field_val_tokens)
        field_val_dict = {}
        for fvp in field_val_tokens:
            if not fvp.strip():
                continue
            fv = re.findall(r'(\w+)[=:]?(.*)?', fvp)[0]
            # print(fv)
            field_val_dict[fv[0]] = fv[1]
        return field_val_dict


class MatchParser(Parser):
    convertion_map = {
        'dl_src': 'src_mac', 'dl_dst': 'dst_mac',
        'nw_src': 'src_ip', 'nw_dst': 'dst_ip', 'ipv6_src': 'src_ip', 'ipv6_dst': 'dst_ip', 'dl_type': 'ipv',
        'ip_proto': 'proto', 'in_port': 'in_port', 'tp_src': 'src_port', 'tp_dst': 'dst_port',
        'tcp': ['proto', 'ipv'], 'udp': ['proto', 'ipv'], 'tcp6': ['proto', 'ipv'], 'udp6': ['proto', 'ipv'],
        'dl_vlan': 'vlan_id',
    }

    def parse(self, convert=True):
        field_val_dict = super().parse()
        if convert:
            for f, v in list(field_val_dict.items()):
                if not v.strip():
                    field_val_dict['proto'] = 'tcp' if 'tcp' in f else 'udp'
                    field_val_dict['ipv'] = '6' if '6' in f else '4'
                    field_val_dict.pop(f)
                if f in list(MatchParser.convertion_map.keys()) and type(MatchParser.convertion_map[f]) is not list:
                    print(field_val_dict)
                    field_val_dict[MatchParser.convertion_map[f]] = v
                    field_val_dict.pop(f)

            if 'ipv' in field_val_dict:
                field_val_dict['ipv'] = {'0x0800': '4', '0x86dd': '6'}.get(field_val_dict['ipv'], field_val_dict['ipv'])
            if 'proto' in field_val_dict:
                field_val_dict['proto'] = {'6': 'tcp', '17': 'udp', '132': 'sctp'}.get(field_val_dict['proto'],
                                                                                       field_val_dict['proto'])

        print(field_val_dict)
        return type('', (object,), field_val_dict)


class ActionParser(Parser):
    def parse(self, convert=True):
        field_val_dict = super().parse()
        if convert:
            for f, v in list(field_val_dict.items()):
                if not v.strip():
                    field_val_dict['drop'] = True if 'drop' in f else False

        print(field_val_dict)
        return type('', (object,), field_val_dict)



def unpack_rule(rule):
    # flow = rule.split('"')[1]
    flow = rule
    if 'action=' in rule:
        pattern, action = flow.split('action=')
    else:
        pattern = flow
        action = ''
    # pattern = pattern.replace(' ', ',')
    # action = action.replace(' ', ',')
    return pattern, action

def parser(rule):
    p, a = unpack_rule(rule.strip())
    match_pattern = MatchParser(p).parse()
    action_pattern = ActionParser(a).parse()
    return match_pattern, action_pattern
def create_packet(rules):
    """
    :param rules:  Pass the rules or rules list to generate the pcap file
    :return:  Returns the pcap file for the respected rule or rules list
    """
    from controller.lib.common.io import scapy_ei as host_scapy
    rules_list = rules if isinstance(rules, list) else [rules]
    pkt_list = list()
    for rule in rules_list:
        match, action = parser(rule)
        proto = getattr(match, 'proto', None)
        ip_v = getattr(match, 'ipv', None)
        smac = getattr(match, 'src_mac', None)
        dmac = getattr(match, 'dst_mac', None)
        sip = getattr(match, 'src_ip', None)
        dip = getattr(match, 'dst_ip', None)
        vlan = getattr(match, 'vlan_id', None)
        if proto:
            sport = getattr(match, 'src_port', None)
            dport = getattr(match, 'dst_port', None)
        else:
            sport = None
            dport = None
        l2_scapy = host_scapy.Ether
        if smac and dmac:
            l2_pkt = l2_scapy(src=smac, dst=dmac)
        elif smac:
            l2_pkt = l2_scapy(src=smac)
        elif dmac:
            l2_pkt = l2_scapy(dst=dmac)
        else:
            l2_pkt = l2_scapy(dst="12:22:34:44:56:66")
        if ip_v and (sip or dip):
            l3_scapy = host_scapy.IPv6 if ip_v == '6' else host_scapy.IP
            if sip and dip:
                l3_pkt = l3_scapy(src=sip, dst=dip)
            elif sip:
                l3_pkt = l3_scapy(src=sip)
            else:
                l3_pkt = l3_scapy(dst=dip)
        else:
            mod_sip = getattr(action, 'mod_nw_src', None)
            mod_dip = getattr(action, 'mod_nw_dst', None)
            l3_scapy = host_scapy.IP
            if mod_sip:
                ip_addr = ipaddress.ip_address(u'%s' % mod_sip)
                l3_scapy = host_scapy.IP if ip_addr.version == 4 else host_scapy.IPv6
            elif mod_dip:
                ip_addr = ipaddress.ip_address(u'%s' % mod_dip)
                l3_scapy = host_scapy.IP if ip_addr.version == 4 else host_scapy.IPv6
            l3_pkt = l3_scapy()
        if proto and (sport or dport):
            l4_scapy = host_scapy.TCP if proto == 'tcp' else host_scapy.UDP
            if sport and dport:
                l4_pkt = l4_scapy(sport=int(sport), dport=int(dport))
            elif sport:
                l4_pkt = l4_scapy(sport=int(sport))
            else:
                l4_pkt = l4_scapy(dport=int(dport))
        else:
            l4_pkt = host_scapy.TCP()
        if vlan:
            packet = l2_pkt / host_scapy.Dot1Q(vlan=int(vlan)) / l3_pkt / l4_pkt / ("x" * 1000)
        else:
            packet = l2_pkt / l3_pkt / l4_pkt / ("x" * 1000)
        pkt_list.append(packet)
    fd, pcap_file = tempfile.mkstemp(suffix='.pcap')
    os.close(fd)
    host_scapy.wrpcap(pcap_file, [p for p in pkt_list])
    return pcap_file




