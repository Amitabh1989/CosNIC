"""
:mod:ovs-ofctl
"""

import logging
import traceback
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

log = logging.getLogger(__name__)


class BaseOFCtl(object):
    def __init__(self, br_name):
        self.br_name = br_name

    def add_flow(self, in_port, proto=None, dst_mac=None, src_mac=None,
                 nw_src=None, nw_dst=None, src_port=None, dst_port=None,
                 port_mask=False, ip_mask=False, mac_mask=False,
                 actions=None, output=None, br_name=None):
        """
        :param in_port:  port name or add_flow
        :param proto:   ip protocol
        :param dst_mac: destination mac address. Used only in Ingress cases
        :param src_mac: source mac address.
        :param nw_src:   Source IP address
        :param nw_dst:     Destination IP address
        :param src_port:  Source TCP/UDP port
        :param dst_port:  Destination TCP/UDP port
        :param port_mask: Port Mask for Wildcard cases
        :param ip_mask:   IP Mask for Wildcard cases
        :param mac_mask:  MAC address mask
        :param actions: Action to be performed in as dict
        :param output:  Output port
        :param br_name: Bridge name
        :return: Returns status of the Flow creation
        """
        log.info('Creating ovs-ofctl flow')
        if ip_mask:
            ip_mask = "255.255.255.0"
        if port_mask:
            port_mask = "0xfff0"
        if mac_mask:
            mac_mask = "ff:ff:ff:ff:ff:00"

        rule_dict = dict()
        # In_port
        rule_dict['in_port'] = in_port

        # ip protocol
        if proto:
            rule_dict[str(proto).lower()] = None

        # destination mac address
        if dst_mac:
            rule_dict['dl_dst'] = f"{dst_mac}/{mac_mask}" if mac_mask else dst_mac
        if src_mac:
            rule_dict['dl_src'] = f"{src_mac}/{mac_mask}" if mac_mask else src_mac

        # Source and destination IP addresses
        if nw_src:
            rule_dict['nw_src'] = f"{nw_src}/{ip_mask}" if ip_mask else nw_src
        if nw_dst:
            rule_dict['nw_dst'] = f"{nw_dst}/{ip_mask}" if ip_mask else nw_dst

        # Source and Destination Ports
        if proto:
            if proto.lower() == 'tcp':
                if src_port:
                    rule_dict['tcp_src'] = f"{str(src_port)}/{port_mask}" if port_mask else str(src_port)
                if dst_port:
                    rule_dict['tcp_dst'] = f"{str(dst_port)}/{port_mask}" if port_mask else str(dst_port)
            elif proto.lower() == 'udp':
                if src_port:
                    rule_dict['udp_src'] = f"{str(src_port)}/{port_mask}" if port_mask else str(src_port)
                if dst_port:
                    rule_dict['udp_dst'] = f"{str(dst_port)}/{port_mask}" if port_mask else str(dst_port)
            else:
                log.warning('Unknown protocol')

        # Actions
        actions_list = []
        if actions == 'drop':
            rule_dict['actions'] = "drop"
        elif actions:
            for key, value in actions.items():
                actions_list.append(f"{key}={value}")
            rule_dict['actions'] = ",".join([",".join(actions_list), f"output:{output}"])
        else:
            rule_dict['actions'] = f"output:{output}"

        # Adding up all the rules
        rule_list = []
        for key, value in list(rule_dict.items()):
            if value is None:
                rule_list.append(key)
            else:
                rule_list.append(key + '=' + value)
        final_rule = ",".join(rule_list)
        bridge = br_name or self.br_name
        flow_command = f'add-flow {bridge} {final_rule}'

        if not run_ovs_ofctl(flow_command):
            raise exception.TestCaseFailure('Flow Creation Failed')
        if self.dump_flows():
            return True

    def add_max_flows(self, file_path=None, br_name=None, openflow_proto=None):
        if not file_path:
            raise exception.TestCaseFailure('file Path must provide to create max flows')
        bridge = br_name or self.br_name
        of_proto_ver = f'-O {openflow_proto}' if openflow_proto else ''
        flow_command = f'{of_proto_ver} add-flows {bridge} {file_path}'

        if not run_ovs_ofctl(flow_command):
            raise exception.TestCaseFailure('Flow Creation Failed')
        if self.dump_flows():
            return True

    def dump_flows(self, br_name=None, flow=None, **kwargs):
        """
        :param self:
        :param br_name: Bridge name to dump the flows
        :param flow: Flow to get specific flow details
        :return:
        """
        bridge = br_name or self.br_name
        opts = ['--names']
        for k, v in kwargs:
            opts.extend([f'{k}={v}'] if v else {k})
        opts = ' '.join(opts)
        dump_cmd = f"dump-flows {bridge} {flow}" if flow else f"dump-flows {bridge} {opts}"
        output = run_ovs_ofctl(dump_cmd)
        if 'cookie' in str(output):
            return output
        else:
            return False

    def delete_flows(self, br_name=None, flow=None):
        """
        :param br_name: Bridge name to delete flows
        :param flow: Flow to delete the specific flow
        :return:
        """
        bridge = br_name or self.br_name
        delete_cmd = f"del-flows {bridge} {flow}" if flow else f"del-flows {bridge}"
        if run_ovs_ofctl(delete_cmd):
            log.info('Flows deleted successfully')
        else:
            log.warning('Delete Flows Failed')

    def add_flows(self, br_name=None, flow=None, flow_file=None):
        bridge = br_name or self.br_name
        if flow:
            flows = [flow]
        elif flow_file:
            with open(flow_file, 'r') as fd:
                flows = fd.readlines()
        else:
            raise exception.TestCaseFailure('flow must be provided')

        for fl in flows:
            flow_command = f'add-flow {bridge} {fl}'
            if run_ovs_ofctl(flow_command) is False:
                raise exception.TestCaseFailure('Flow Creation Failed')

    def is_consistent_flow(self, br_name=None, flow=None):
        try:
            self.add_flows(br_name=br_name,flow=flow)
        except Exception:
            log.warning(f'The {flow} is not consistent')
        else:
            if self.dump_flows(flow=flow):
                self.delete_flows(flow=flow)
                return True
            else:
                return False
        return False

def run_ovs_ofctl(command):
    """
    Executes and returns the status of the command
    :param command: ovs_ofctl command to be executed
    :return: Returns True or False based on output
    """
    ovsofctl_path = find_executable('ovs-ofctl')
    if ovsofctl_path is None:
        raise exception.ConfigException('ovs-ofctl is not available')
    ofctl_cmd = f'{ovsofctl_path} {command}'
    try:
        status = exe.block_run(ofctl_cmd, shell=True)
        return status if status else True
    except Exception:
        log.error('Failed to Execute the command: %s' % ofctl_cmd)
        log.error(traceback.format_exc())
        return False
