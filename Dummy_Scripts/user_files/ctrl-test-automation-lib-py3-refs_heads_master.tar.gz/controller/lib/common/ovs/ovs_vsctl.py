"""
:mod:`ovs_vsctl` -- Abstract classes for vsctl
========================================

.. moduleauthor:: Sudheer Vegesna <sudheer.vegesna@broadcom.com>

"""
import copy
import logging
import os
import re
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

log = logging.getLogger(__name__)


class BaseOpenVSwitch(object):

    def __init__(self):
        exe.block_run('modprobe openvswitch')
        self._ovsvsctl_path = find_executable('ovs-vsctl')
        if self._ovsvsctl_path is None:
            raise exception.ConfigException('ovs-vsctl is not available')

    def init_db(self, option=''):
        """
        To initialize the Open vSwitch database if not yet initialized. If the database has already been
        initialized, the init command will have no effect.

        :return: None
        """
        exe.block_run(f'{self._ovsvsctl_path} {option} init', shell=True)

    def show(self):
        """
        Print a brief overview of database contents
        :return: database conntents as string
        """
        command_output = exe.block_run(f'{self._ovsvsctl_path} show', shell=True)
        return command_output

    def set(self, other_configs, option=""):
        """
        :param other_configs:
        :param option
        :return:
        """
        exe.block_run(f'{self._ovsvsctl_path} {option} set Open_vSwitch . other_config:{other_configs}', shell=True)

    def get(self, configs="dpdk_initialized"):
        """
        :param configs:
        :return:
        """
        command_output = exe.block_run(f'{self._ovsvsctl_path} get Open_vSwitch . {configs}', shell=True)
        return command_output

    def clear(self, other_configs="", option=""):
        """
        :param option:
        :param other_configs:
        :return:
        """
        exe.block_run(f'{self._ovsvsctl_path} {option} clear Open_vSwitch . other_config {other_configs}', shell=True)

    def reset(self):
        exe.block_run(f'{self._ovsvsctl_path} emer-reset', shell=True)

    def reset_dir(self, dirs):
        """
        :param dirs:
        :return:
        """
        raise NotImplemented

    @staticmethod
    def export_path(path=r'$PATH:/usr/local/share/openvswitch/scripts'):
        """
        :param path: path of openvswitch scripts
        :return: None
        """
        log.info('setting up the ovs PATH=%s' % path)
        os.environ["PATH"] += path

    @staticmethod
    def export_db(db=r'/usr/local/var/run/openvswitch/db.sock'):
        """
        :param db:
        :return: None
        """
        log.info('setting up the ovs DB_SOCK=%s' % db)
        os.environ["DB_SOCK"] = db

    def port_init(self, port):
        """
        :param port:
        :return:
        """
        raise NotImplemented


class BaseBridge(object):

    def __init__(self, br_name=None):
        self.br_name = br_name
        self._ovsvsctl_path = find_executable('ovs-vsctl')
        if self._ovsvsctl_path is None:
            raise exception.ConfigException('ovs-vsctl is not available')

    def add(self, datapath_type='netdev',
            protocols=r'OpenFlow10,OpenFlow11,OpenFlow12,OpenFlow13,OpenFlow14,OpenFlow15',
            other_config=None, fail_mode=None):
        """
        Create a new bridge named <br_name>. If a bridge named <br_name> already exists, the command will
        fail
        :param datapath_type: datapath type in string
        :param protocols: New bridge name
        :param other_config: New bridge name
        :param fail_mode: accepted values None/secure
        :return: command output in string
        """
        log.info(
            'Creating ovs bridge %s with datapath %s and with protocols %s ' % (self.br_name, datapath_type, protocols))
        command = f'{self._ovsvsctl_path} add-br {self.br_name}'
        bridge_cfg = []
        if datapath_type != None:
            bridge_cfg.append(f'datapath_type={datapath_type}')
        if protocols != None:
            bridge_cfg.append(f'protocols={protocols}')
        if other_config:
            bridge_cfg.append(f'other_config:{other_config}')
        if fail_mode:
            bridge_cfg.append(f'fail-mode={fail_mode}')
        if bridge_cfg:
            bridge_cfg.insert(0, f'-- set bridge {self.br_name}')
        command = f'{command} {" ".join(bridge_cfg)}'
        exe.block_run(command)

    def set(self, datapath_type, protocols):
        """
        Modify the Openflow version for bridge
        :param datapath_type:
        :param protocols: openflow10,openflow12,openflow13,openflow14
        :return: command output in string
        """
        command = f'{self._ovsvsctl_path} -- set bridge {self.br_name}'
        if datapath_type is not None:
            command += 'datapath_type=%s' % datapath_type
        if protocols is not None:
            command += 'protocols=%s' % protocols
        exe.block_run(command)

    def delete(self):
        """
        Delete the bridge named <br_name> and all of its configuration includes ports
        :return: command output in string
        """
        exe.block_run(f'{self._ovsvsctl_path} del-br {self.br_name}')

    def list(self):
        """
        :return: the names of all the bridges
        """

        command_output = exe.block_run(f'{self._ovsvsctl_path} list-br')
        return command_output

    def create_mirror(self, output_port, bridge=None, name='mymirror', output_vlan=None, select_vlan=None,
                      select_all=False, select_dst_port=None, select_src_port=None):
        """
        Modify the Openflow version for bridge
        :param output_port:
        :param output_vlan:
        :param select_vlan:
        :param select_all:
        :param select_dst_port:
        :param select_src_port:
        :param bridge:
        :param name:
        :return: command output in string
        """
        select_dst_port = copy.deepcopy(select_dst_port) or []
        select_src_port = copy.deepcopy(select_src_port) or []
        bridge = bridge or self.br_name
        log.info(f' src {select_src_port}, dst {select_dst_port},')
        final_ports = set(select_dst_port + select_src_port + [output_port])
        final_ports_command = ''
        for port in final_ports:
            final_ports_command += f'-- --id=@{port} get Port {port} '
        final_src_port_command = f'select-src-port={",".join(map(lambda x: f"@{x}", select_src_port))} ' \
            if select_src_port else ''
        final_dst_port_command = f'select-dst-port={",".join(map(lambda x: f"@{x}", select_dst_port))} ' \
            if select_dst_port else ''
        select_all_command = 'select-all=true ' if select_all else ''
        select_vlan_command = f'select-vlan={select_vlan} ' if select_vlan else ''
        output_vlan_command = f'output-vlan={output_vlan} ' if output_vlan else ''
        command = f'{self._ovsvsctl_path} -- set bridge {bridge} '
        command += f'mirrors=@m '
        command += f'{final_ports_command} '
        command += f'-- --id=@m create Mirror name={name} {select_all_command} ' \
                   f'{final_src_port_command} {final_dst_port_command} ' \
                   f'{select_vlan_command} {output_vlan_command} output-port=@{output_port} '

        exe.block_run(command)

    def list_mirror(self):
        """
        Modify the Openflow version for bridge
        :return: command output in string
        """
        command = f'{self._ovsvsctl_path} list mirror'
        exe.block_run(command)

    def delete_mirror(self, bridge=None):
        """
        Modify the Openflow version for bridge
        :return: command output in string
        """
        bridge = bridge or self.br_name
        command = f'{self._ovsvsctl_path} clear Bridge {bridge} mirrors'
        exe.block_run(command)

    def mirror_stats(self):
        """
        Modify the Openflow version for bridge
        :return: command output in string
        """
        command = f'{self._ovsvsctl_path} list mirror'
        output = exe.block_run(command)

        # Regular expressions to extract tx_bytes and tx_packets
        tx_bytes_pattern = re.compile(r'tx_bytes=(\d+)')
        tx_packets_pattern = re.compile(r'tx_packets=(\d+)')

        tx_bytes_match = tx_bytes_pattern.search(output).group(1)
        tx_packets_match = tx_packets_pattern.search(output).group(1)
        if int(tx_bytes_match) and int(tx_packets_match):
            return tx_bytes_match, tx_packets_match
        else:
            return 0, 0


class BasePort(object):

    def __init__(self, br_name):
        self.br_name = br_name
        self._ovsvsctl_path = find_executable('ovs-vsctl')
        if self._ovsvsctl_path is None:
            raise exception.ConfigException('ovs-vsctl is not available')

    def add_port(self, port, inf_type=None, options=None, port_request=None, mtu_request=None):
        """
        :param port: port to be added to bridge
        :param inf_type: interface type
        :param options: extra options to be added
        :param port_request: port request type
        :param mtu_request: mtu request type
        :return:
        """
        command = f'{self._ovsvsctl_path} add-port {self.br_name} {port} '
        if inf_type:
            command += ' -- set Interface %s type=%s ' % (port, inf_type)
        if options:
            for key, value in options.items():
                command += 'options:%s=%s ' % (key, value)
        if port_request:
            command += 'ofport_request=%s ' % port_request
        if mtu_request:
            command += 'mtu_request=%s ' % str(mtu_request)
        output = exe.block_run(command)
        if 'Error' in output:
            raise exception.ExeException(f'Failed add the port {port} with error {output}')

    def del_port(self, port):
        """
        :param port:
        :return:
        """
        exe.block_run(f'{self._ovsvsctl_path} del-port {self.br_name} {port}')

    def list_ports(self):
        """
        :return:
        """
        command_output = exe.block_run(f'{self._ovsvsctl_path} list-ports {self.br_name}')
        return command_output

    def port_to_br(self):
        """

        :return:
        """
        command_output = exe.block_run(f'{self._ovsvsctl_path} port-to-br {self.br_name}')
        return command_output

    def set_mtu(self, port, mtu):
        """

        :return:
        """
        command_output = exe.block_run(f'{self._ovsvsctl_path} set interface {port} mtu_request={mtu}')
        return command_output

    def set_vlan(self, port, vlan):
        """

        :return:
        """
        command_output = exe.block_run(f'{self._ovsvsctl_path} set port {port} tag={vlan}')
        return command_output


class HugePages(object):

    @staticmethod
    def add(huge_pages=8192):
        """

        :param huge_pages:
        :return:
        """
        exe.block_run('sysctl -w vm.nr_hugepages=%s' % huge_pages)

    @staticmethod
    def delete():
        """
        :return:
        """
        exe.block_run('sysctl -w vm.nr_hugepages=0')

    @staticmethod
    def show():
        """

        :return:
        """
        command_output = exe.block_run('grep HugePages_ /proc/meminfo')
        return command_output

    @staticmethod
    def mount(path='/mnt/huge-2M', page_size=r'pagesize=2M'):
        """
        :param path:
        :param page_size:
        :return:
        """
        exe.block_run(r'mkdir -p %s' % path)
        exe.block_run(r'mount -t hugetlbfs nodev %s -o ""%s""' % (path, page_size), shell=True)

    @staticmethod
    def umount(path='/mnt/huge-2M'):
        """

        :return:
        """
        exe.block_run(r'umount %s' % path)
        exe.block_run(r'rm -rf %s' % path)
