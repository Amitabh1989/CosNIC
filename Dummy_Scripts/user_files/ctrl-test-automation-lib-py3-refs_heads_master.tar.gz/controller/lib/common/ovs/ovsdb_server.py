"""
:mod:`maia_config` -- Maia Config
========================================

.. moduleauthor:: Hemanth MB <hemanth.mb@broadcom.com>

"""


import logging
import abc

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = logging.getLogger(__name__)




class BaseOpenVSwitchDBServer(object, metaclass=abc.ABCMeta):
    def __init__(self, maia_ip, sut):
        self.maia_ip = maia_ip
        self.sut = sut

    @abc.abstractmethod
    def server_init(self, options):
        """
        :param db_path:
        :param schema_path:
        :return:
        """
        raise NotImplemented
