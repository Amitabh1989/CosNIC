"""
:mod:`pdu` -- APC Switched Rack PDU API
=======================================================

.. module:: controller.cuw.test_script.tsl.common.tools.pdu
.. moduleauthor:: Eric Lin <eric.lin@broadcom.com>

This API is for controlling APC switched PDUs over telnet

Tested on APC AP8941 AOS v5.1.4
"""
import telnetlib
import re
import time
from typing import Literal

from controller.lib.core import log_handler

log = log_handler.get_module_logger(__name__)


class PDUException(Exception):
    pass


class PDU:
    def __init__(self, ip: str, telnet_port: int = 23):
        self.ip = ip
        self.telnet_port = telnet_port
        self.session = telnetlib.Telnet()
        self.prompt = b'APC>'

    def status(self, outlet: int) -> Literal['ON', 'OFF', 'REBOOTING']:
        """Return the status ('ON', 'OFF', 'REBOOTING') of outlet <outlet>"""
        pattern = re.compile(r'^\s*(\d+):\s*(.*\S)\s*:\s*(.*)', re.MULTILINE)
        output = self.cmd(f'status {outlet}')
        match = pattern.search(output)
        if not match:
            raise PDUException('Failed to parse output for PDU outlet status')
        if 'rebooting' in match.group(3).lower():
            return 'REBOOTING'
        if 'on' in match.group(2).lower():
            return 'ON'
        if 'off' in match.group(2).lower():
            return 'OFF'
        raise PDUException('Unexpected PDU outlet status')

    def reboot_duration(self, outlet: int) -> int:
        output = self.cmd(f'rebootduration {outlet}')
        pattern = re.compile(r'Reboot duration is (\d+)\s+seconds')
        match = pattern.search(output)
        if match:
            return int(match.group(1))
        raise PDUException('Failed to parse PDU reboot duration')

    def reboot(self, outlet: int):
        """Reboot outlet <outlet>

        There will be a delay between power off and power on according 'rebootduration' output
        """
        log.info(f'Power cycling outlet {outlet}')
        self.open()
        delay = self.reboot_duration(outlet)
        self.cmd(f'reboot {outlet}')
        time.sleep(delay/2)
        self.status(outlet)
        time.sleep(delay)
        self.status(outlet)
        self.close()

    def open(self):
        self.session.open(self.ip, self.telnet_port)
        self.session.read_until(b'User Name : ', 3).decode('ascii')
        self.session.write('apc\r\n'.encode('ascii'))
        self.session.read_until(b'Password  : ', 3).decode('ascii')
        self.session.write('apc-c\r\n'.encode('ascii'))
        self.session.read_until(self.prompt).decode('ascii')

    def close(self):
        self.cmd('exit', silent=True)
        self.session.close()

    def cmd(self, cmd, silent: bool = False) -> str:
        """Send a command to the PDU

        :param cmd:    Command to run
        :param silent: If False, log the output"""

        cmd += '\r\n'
        self.session.write(cmd.encode('ascii'))
        out = self.session.read_until(self.prompt).decode('ascii')
        if not silent:
            log.debug(out)
        return out
