"""
:mod:`exe` -- Shell command execution tool
==========================================

.. module:: controller.lib.common.shell.exe
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Run shell command. Support both Windows and Linux. It's a simple wrapper
around subprocess, but adding a feature that reading subproecss.PIPE does
not block.

.. note::
   By default, the module sets shell=False as the Python official page
   recommends. Please note that if you use shell=True, there are some problems
   that you have to handle by yourself - such as zombie processes,
   kill() only terminates a parent process, etc.

Blocking Process
----------------
The simplest way to use this is to run a process as a blocking.

>>> from controller.lib.common.shell import exe
>>> exe.block_run('ls')
'archive\\nDesktop\\nDocuments\\nDownloads\\nMusic\\nPictures\\nPublic\\n\
Templates\\nVideos\\nworkspace\\n'

It returns output when the command is successfully executed. If it detects any
non-zero exitcode, it raises exception:

>>> exe.block_run('ls /no_such_dir')
ExeExitcodeException: command ['ls', '/no_such_dir'] returned non-zero exit \
status 2. Output: ls: cannot access /no_such_dir: No such file or directory

Which means if you expect to see any non-zero exitcode from the command, you
have to handle it properly using try/except clause. Because the exception will
include some useful information, you can handle it as below:

>>> from controller.lib.core import exception
>>> try: exe.block_run('ls /no_such_dir')
... except exception.ExeExitcodeException as err:
...     print('non-exitcode. exitcode: %s' % err.exitcode)
...     print('command: %s' % err.command)
...     print('output: %s' % err.output)
non-exitcode. exitcode: 2
command: ['ls', '/no_such_dir']
output: ls: cannot access /no_such_dir: No such file or directory

Non-blocking Process
--------------------
Sometimes you need to run shell commands as non-blocking. For that case, you
can use run() method.

>>> proc = exe.run('sleep 60')
>>> proc
<controller.lib.common.shell.exe.ProcessHandler instance at 0x7f0e1a264ea8>

Which returns an object you can interact with the process. To check the status
of the process, you can call poll()

>>> proc.poll()
0

Which works same as subprocess.Popen. You get None if the process is running,
otherwise it returns exitcode of the process.

If you need to kill the process, you can call kill()

>>> proc = exe.run('sleep 60')
>>> proc.kill()
>>> proc.poll()
-9

Due to the process was forcefully terminated, its return value is non-zero.

You can parse the output of the process anytime - if the process has nothing to
return, it will return ''.

>>> proc = exe.run('echo Test')
>>> proc.get_output()
'Test\\n'
>>> proc.get_output()
''


"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2022 Broadcom Inc"

import sys
import subprocess
import time
import atexit

from threading import Thread
from queue import Queue, Empty

from controller.lib.core import exception
from controller.lib.core import log_handler

ON_POSIX = 'posix' in sys.builtin_module_names
MAX_PROCS = 1024  # Maximum processes to be tracked
log = log_handler.get_logger(__name__)


class ProcessHandler(object):
    """
    subprocess.Popen wrapper. Few guidelines:

    * Avoid 'shell=True' option as much as possible. It spawns processes
      as children and it's difficult to maintain them, especially when
      you need to terminate all processes. Note that kill() or other
      functions will likely kill only parents, not the actual child
      process.
      Another major problem is a security issue; Official Python guide
      strongly recommends not using the shell option.
    * buffer overflow might NOT happen with this wrapper since it will
      keep flushing the buffer internally using multithread, but it's
      good to be aware about the buffer.
    * At exit of Python, this module will try to kill all spawned
      processes automatically, but this will not work when "shell=True"
      is used.

    Args:
        max_line (int): Maximum number of lines that queue will store. When
           the process gets more lines, the old lines will be removed to add
           new lines. Default=None which means no limit, but this value might
           need to be updated when memory limitation issue raises.

    Returns:
        ProcessHandler: An object to interact with shell process

    """
    procs = Queue(MAX_PROCS)

    def __init__(self, max_line=None):

        self._proc = None
        self._command = None
        self._output_thread: Thread = None
        self._error_thread: Thread = None
        self._output_queue = Queue() if max_line is None else Queue(max_line)
        self._output_err_queue = Queue() if max_line is None else Queue(max_line)

    @property
    def proc(self):
        return self._proc

    @property
    def command(self):
        return self._command

    def _override_kwargs(self, kwargs):
        """
        Override some kwargs.

        """

        override_values = {
            'stdout': kwargs.get('stdout', subprocess.PIPE),
            'stderr': kwargs.get('stderr', subprocess.STDOUT),
            'bufsize': 1,
            'close_fds': ON_POSIX,
        }

        kwargs.update(override_values)

        return kwargs

    def _enqueue_output(self):
        # Rad until hitting an empty string
        for line in iter(self.proc.stdout.readline, b''):
            if self._output_queue.full():
                # Remove the old line, since the queue is full
                self._output_queue.get_nowait()
            self._output_queue.put_nowait(line)

        self.proc.stdout.close()

    def _read_buffer(self):
        self._output_thread = Thread(target=self._enqueue_output)
        self._output_thread.daemon = True  # Do not hang when the program exits
        self._output_thread.start()

    def _enqueue_err_output(self):
        # Rad until hitting an empty string
        for line in iter(self.proc.stderr.readline, b''):
            if self._output_err_queue.full():
                # Remove the old line, since the queue is full
                self._output_err_queue.get_nowait()
            self._output_err_queue.put_nowait(line)

        self.proc.stderr.close()

    def _read_err_buffer(self):
        self._error_thread = Thread(target=self._enqueue_err_output)
        self._error_thread.daemon = True  # Do not hang when the program exits
        self._error_thread.start()

    def _append_proc_handler(self):
        """
        Append the self.proc to ProcessHandler.procs. Limit the maximum length
        to MAX_PROCS so it doesn't track more than that. FIFO.

        :return:
        """

        if not ProcessHandler.procs.full():
            ProcessHandler.procs.put(self)
            return

        log.debug('Process queue is reached to maximum size %s. Removing the first terminated process... ', MAX_PROCS)

        new_queue = Queue(MAX_PROCS)

        # Not ideal perform get/put many times, but for thread safety,
        # and considering a number of loop, should be okay

        while not ProcessHandler.procs.empty():
            proc_handler = ProcessHandler.procs.get()
            if proc_handler.proc.poll() is not None:  # Terminated
                log.debug('Removing the pid %s (command: %s, exitcode: %s)',
                          proc_handler.proc.pid, proc_handler.command, proc_handler.proc.returncode)

                continue  # Not adding back to the queue; namely remove

            new_queue.put(proc_handler)

        # Update the queue pointer
        ProcessHandler.procs = new_queue

        if ProcessHandler.procs.full():
            raise exception.ExeException('Reached maximum queue. Cannot run anymore processes.')

        ProcessHandler.procs.put(self)

        return True

    def run(self, command, **kwargs):
        """
        Non-blocking shell command execution.

        stderr, bufsize and close_fds kwargs will be
        ignored and overriden.

        Note that developers should clean up all the resources
        manually including process objects and pipes no matter how the
        process is terminated.

        Start automatically thread-safe queue to keep reading buffer
        for avoiding any buffer overflow.

        You have to make sure any blocking process is terminated before
        Python exits - otherwise the process will be still running. This
        module will try to clean up, but not guaranteed.

        Args:
            command (str): Shell comamnd that should be executed
            kwargs: keyword arguments that are passed to subprocess.Popen

        """

        # Try to add self to procs before executing shell command
        self._append_proc_handler()
        # save and use the process name at all the required places if caller sends 'proc_name' as part of kwargs.
        self._proc_name = kwargs.pop('proc_name', 'unnamed_proc')
        log.debug(f'Run command: process_name:{self._proc_name} --- command:{command}')
        kwargs = self._override_kwargs(kwargs)

        self._command = command

        command = command if (
            isinstance(command, (list, tuple)) or
            ('shell' in kwargs and kwargs['shell'])) else command.split()

        self._proc = subprocess.Popen(command, **kwargs)
        if kwargs.get('stdout') == subprocess.PIPE:
            self._read_buffer()
        if kwargs.get('stderr') == subprocess.PIPE:
            self._read_err_buffer()

    def stop(self, timeout=0):
        """
        Gracefully terminate the process by sending SIGTERM.

        Some processes may take a non-zero amount of time to exit after receiving a SIGTERM. Timeout option can be used
        to wait up to <timeout> for the process to exit after receiving a SIGTERM.

        Args:
            timeout (int): Time in seconds to wait for process to exit, polling every 1s until timeout

        Returns:
            int: exitcode if process terminates
            None: if process is still running
        """
        log.debug(f'Sending SIGTERM to {self._proc_name} of command {self.command}')
        self.proc.send_signal(subprocess.signal.SIGTERM)

        rc = self.proc.poll()
        if rc is not None:
            return rc

        for _ in range(timeout):
            time.sleep(1)
            rc = self.proc.poll()
            if rc is not None:
                return rc

        log.warning(f'{self._proc_name} still running {timeout}s after sending SIGTERM to stop')
        return rc

    def kill(self, timeout=0):
        """
        Stop running the process and clean up. Proxy to os.kill(). If return
        value is None, the process should be handled separately to clean up.

        Some processes may take a non-zero amount of time to exit after receiving a KILL. Timeout option can be used
        to wait up to <timeout> for the process to exit after receiving a KILL.

        Args:
            timeout (int): Time in seconds to wait for process to exit, polling every 1s until timeout
        Returns:
            int: exitcode if process terminates
            None: if process is still running
        """
        log.debug(f'Sending KILL to {self._proc_name} of command {self.command}')
        self.proc.kill()

        rc = self.proc.poll()
        if rc is not None:
            return rc

        for _ in range(timeout):
            time.sleep(1)
            rc = self.proc.poll()
            if rc is not None:
                return rc

        log.warning(f'{self._proc_name} still running {timeout}s after sending KILL to stop')
        return rc

    def poll(self):
        """
        Proxy to subprocess.Popen.poll()

        Returns:
            int: exitcode
            None: When the process is still running

        """

        return self.proc.poll()

    def get_output(self) -> str:
        ret_list = []
        log.debug(f'Querying output for process {self._proc_name}')

        while 1:
            try:
                output = self._output_queue.get_nowait()
                # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
                # If the command output is a byte stream (as in case of Python 3.X), convert it
                # to str.
                if isinstance(output, bytes):
                    output = output.decode('utf-8', 'ignore')
            except Empty:
                return ''.join(ret_list)
            else:
                ret_list.append(output)

    def get_error(self) -> str:
        """
        """
        ret_list = []

        while 1:
            try:
                output = self._output_err_queue.get_nowait()
                # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
                # If the command output is a byte stream (as in case of Python 3.X), convert it
                # to str.
                if isinstance(output, bytes):
                    output = output.decode('utf-8', 'ignore')
            except Empty:
                return ''.join(ret_list)
            else:
                ret_list.append(output)


def block_run(command, silent=False, **kwargs) -> str:
    """
    Simple wrapper of check_output.

    Re-raise exceptions and include the output in the case that errors can
    be debugged even if exceptions are not caught.

    Args:
        command (str): Shell command that should be executed
        silent (bool/str): Enable/disable printing the output to the console. When passed
        'Absolute', not even the command is printed out.
        kwargs: keyword arguments that are passed to subprocess.check_output (e.g. timeout)

    Returns:
        string: Output of the command execution

    """
    output = None
    kwargs['stderr'] = kwargs['stderr'] if 'stderr' in kwargs else subprocess.STDOUT
    # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
    # If the command is a byte stream (as in case of Python 3.X), convert it to str.
    if isinstance(command, bytes):
        command = command.decode('utf-8')
    elif isinstance(command, list):
        command = [item.decode('utf-8') if isinstance(item, bytes) else item for item in command]

    if sys.version_info[0] >= 3:
        u_code = str
    else:
        u_code = str
    proc_name = kwargs.pop('proc_name', 'unnamed_proc')
    if not kwargs.get('shell', False):
        if isinstance(command, (str, u_code)):
            # shell is False, but the command is string. technically, this is a
            # wrong value, but just split and use it
            command = command.split()
        # When absolute silence is requested, don't even print the command out.
        if silent != 'Absolute':
            log.debug(f'Run command: process_name:{proc_name} --- command:{subprocess.list2cmdline(command)}')
    elif silent != 'Absolute':
        # shell is True. Should pass the command as it is
        log.debug(f'Run command: process_name:{proc_name} --- command:{command}')

    try:
        if "check_output" not in dir(subprocess):
            p = subprocess.Popen(command, stdout=subprocess.PIPE, **kwargs)
            output = p.communicate()[0]
        else:
            output = subprocess.check_output(command, **kwargs)
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # If the command output is a byte stream (as in case of Python 3.X), convert it to str.
        if isinstance(output, bytes):
            output = output.decode('utf-8', 'ignore')
    except subprocess.CalledProcessError as err:
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # If the error output is a byte stream (as in case of Python 3.X), convert it to str.
        cmd = err.cmd
        returncode = err.returncode
        output = err.output

        if isinstance(cmd, bytes):
            cmd = cmd.decode('utf-8')

        if isinstance(returncode, bytes):
            returncode = returncode.decode('utf-8')

        if isinstance(output, bytes):
            output = output.decode('utf-8', 'ignore')

        raise exception.ExeExitcodeException(command=cmd, exitcode=returncode, output=output)
    else:
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # If the command output is a byte stream (as in case of Python 3.X), convert it to str.
        if isinstance(output, bytes):
            output = output.decode('utf-8', 'ignore')
        # CTRL-42831: Printing dmesg on all the system for a the testcases.
        # Do not log the command output when not requested.
        if silent is False:
            log.debug('Output: %s', output)

    return output


def run(command, max_line=None, **kwargs) -> ProcessHandler:
    """
    Proxy to ProcessHandler.run()

    Args:
        command (str): Shell comamnd that should be executed
        max_line (int): Maximum number of lines that queue will store. When
           the process gets more lines, the old lines will be removed to add
           new lines. Default=None which means no limit, but this value might
           need to be updated when memory limitation issue raises.
        kwargs: keyword arguments that are passed to subprocess.Popen
    Return:
       ProcessHandler: ProcessHandler that you can interact with the process,
          such as start, stop, get_output, etc.

    """
    # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
    # If the command is a byte stream (as in case of Python 3.X), convert it to str.
    if isinstance(command, bytes):
        command = command.decode('utf-8')
    elif isinstance(command, list):
        command = [item.decode('utf-8') if isinstance(item, bytes) else item for item in command]

    ph = ProcessHandler(max_line=max_line)
    ph.run(command=command, **kwargs)
    return ph


@atexit.register
def _terminate():
    """
    Try to clean up the resources at exit. Note that if you use the option
    "shell=True" for subprocess, this will likely only kill parents.

    This should not be called by any other modules but atexit.

    """

    while not ProcessHandler.procs.empty():
        proc_handler = ProcessHandler.procs.get()
        if proc_handler.proc is not None and proc_handler.proc.poll() is None:
            proc_handler.proc.kill()
            proc_handler.proc.poll()
