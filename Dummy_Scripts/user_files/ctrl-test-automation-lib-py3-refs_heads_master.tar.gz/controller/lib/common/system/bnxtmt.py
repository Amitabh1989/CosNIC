"""
:mod:`bnxtmt` -- The test script template
===========================================

.. module:: controller.lib.common.system.bnxtmt
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""


import time
import re
import pexpect
import os

from controller.lib.common.shell import exe
from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)

class Bnxtmt(object):
    def __init__(self, bnxtmt_dir):
        self.bnxtmt_dir = bnxtmt_dir

    def exec_command(self, command_list):
        if len(command_list) != 0:
            cmd = './load.sh ' + ' '.join(command_list)
            print(cmd)
            return exe.block_run(
                './load.sh ' + ' '.join(command_list),
                cwd=self.bnxtmt_dir,
                shell=True)
        else:
            return exe.block_run(
                './load.sh ',
                cwd=self.bnxtmt_dir,
                shell=True)

    def get_cfw_ver(self):
        log.info('Getting FW version')
        os.chdir(self.bnxtmt_dir)
        p = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if p.expect('bnxtmt 1:>', timeout=60) == 0:
            p.sendline('nvm dir')
            if p.expect('bnxtmt 1:>', timeout=60) == 0:
                nvmdir = p.before
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
                print(nvmdir)
                nvm_op = nvmdir.strip().split('\n')
                for line in nvm_op:
                    templine = line.strip()
                    linearr = templine.split(" ")
                    if len(linearr) > 5:
                        if(linearr[1] == 'CFW'):
                            cfw_line = re.findall('\s*(\d+)[\s\t]+CFW[\s\t]+\d+[\s\t]+\S+\s+\S+\s+(\w+.\s*\w+.\s*\w+.\s*\w+)', line)
                            temp = cfw_line[0][1]
                            cfw_ver = "".join(temp.split())
                            print(('The CFW version is %s' % cfw_ver))
                            return cfw_ver
                    else:
                        continue
                log.info('No match found')
                return '0.0.0.0'
            else:
                return '0.0.0.0'
        else:
           return '0.0.0.0'

    def get_bnxtmt_ver(self):
        log.info('Getting BNXTMT version')
        mt_ver = self.mfg_cmd(['-ver'])
        mt_op = mt_ver.strip().split('\n')
        for line in mt_op:
            templine = line.strip()
            linearr = templine.split(" ")
            if len(linearr) > 5:
                if(linearr[-2] == 'version'):
                    bnxtmt_ver = linearr[-1]
                    print(('The BNXTMT version is %s' % bnxtmt_ver))
                    return bnxtmt_ver
            else:
                continue
        log.info('No match found')
        return '0.0.0.0'

    def pkg_install(self, cfw_filename):
        log.info('Unload the driver ... ')
        self.unload_driver()
        os.chdir(self.bnxtmt_dir)
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=60) == 0:
            child.sendline('nvm pkginstall ' + cfw_filename)
            if child.expect('bnxtmt 1:>', timeout=120) == 0:
                log.info('Package %s installed successfully' % cfw_filename) 
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
        log.info('Sleep for 10 seconds to complete upgrade ... ')
        time.sleep(10)

        log.info('Load the driver ... ')
        self.load_driver()
        time.sleep(10)

    def unload_driver(self):
        try:
            return exe.block_run('modprobe -r bnxt_en')
        except:
            exe.block_run('modprobe -r bnxt_re')
            return exe.block_run('modprobe -r bnxt_en')

    def load_driver(self):
        return exe.block_run('modprobe bnxt_en')

    def upgrade_cfw(self, cfw_filename, force=False):
        log.info('Unload the driver ... ')
        self.unload_driver()
        os.chdir(self.bnxtmt_dir)
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('nvm upgrade ' + ('-F ' if force else '') + '-cfw ' + cfw_filename)
            if child.expect('bnxtmt 1:>', timeout=30) == 0:
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
        log.info('Sleep for 10 seconds to complete upgrade ... ')
        time.sleep(10)

        log.info('Load the driver ... ')
        self.load_driver()
        time.sleep(10)

    def get_chimp_trace(self):
        """Dump some useful information. For now, dump chimp trace"""
        return self.exec_command(['chimp trace'])

    def nictest(self):
        log.info('Running nictest ... ')
        self.exec_command(['nictest -I 1'])

    def get_counter(self, iface):
        raise NotImplementedError
        # Need to get port ID
        self.exec_command(['stats mac %s' % port_id])

    def reset_chimp(self):
        log.info('Unload the driver ... ')
        self.unload_driver()
        os.chdir(self.bnxtmt_dir)
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('reset all')
            log.info('Sleep for 10 seconds to reset the chimp FW ... ')
            time.sleep(10)
            if child.expect('bnxtmt 1:>', timeout=30) == 0:
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
        log.info('Load the driver ... ')
        self.load_driver()

    def pkgdump(self):
        img_name = 'file.img'
        log.info('Creating IMG file from adapter')
        output = self.exec_command(
            ['nvm pkgdump ' + img_name]
        )
        log.info('Sleep for 10 seconds to complete building img ... ')
        time.sleep(10)
        str = 'Package file ' + img_name + ' is prepared'
        arr_out = output.strip().split('\n')
        if any(str in s for s in arr_out):
            log.info('%s is created successfully')
        else:
            log.info('Image file creation failed')

    def nvm_fill(self, nvmfill_path):
        log.info('Erasing the adapter using NVM FILL command ...')
        self.unload_driver()
        result = self.mfg_cmd(
            ['-rc ' + nvmfill_path]
        )

        log.info('Sleep for 5 seconds for NVM Fill...')
        time.sleep(5)
        result_arr = result.strip().split('\n')
        return result_arr

    def nvm_erased(self):
        print('checking the contents of the nvram')
        os.chdir(self.bnxtmt_dir)
        nvram_erased = False
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('fwutil')
            if child.expect('bnxtmt 1:>', timeout=60) == 0:
                child.sendline('nvm dir')
                if child.expect('bnxtmt 1:>', timeout=60) == 0:
                    output = child.before
                    print(output)
                    result_arr = output.strip().split('\n')
                    for each_line in result_arr:
                        if re.search('^\s1\s', output) is None:
                            print('string not found')
                            nvram_erased = True
                            break
            child.sendcontrol('c')
            time.sleep(5)
            if child.isalive() == False:
                print('bnxtmt exited successfully')
        return nvram_erased

    def entry_erase(self):
        os.chdir(self.bnxtmt_dir)
        self.unload_driver()
        entry_erase = False
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('nvm dir')
            if child.expect('bnxtmt 1:>', timeout=30) == 0:
                output_before_erase = child.before
                print('output_before_erase\n')
                print(output_before_erase)
                result_before_erase = output_before_erase.strip().split('\n')
                print(result_before_erase)
                entry_idx = 0
                entry_found = False
                for entry_idx in range(0, len(result_before_erase)):
                    if re.search(r'^\s1\s.*', result_before_erase[entry_idx]) is not None:
                        entry_found = True
                        break
                if entry_found:
                    erased_entry = result_before_erase[entry_idx].split()[1]
                    entry_idx = 0
                    entry_found = False
                    print(('entry erased: %s\n', erased_entry))
                    child.sendline('fwutil')
                    if child.expect('bnxtmt 1:>', timeout=30) == 0:
                        child.sendline('nvm erase 1')
                        if child.expect('bnxtmt 1:>', timeout=30) == 0:
                            child.sendline('nvm dir')
                            if child.expect('bnxtmt 1:>', timeout=30) == 0:
                                output_after_erase = child.before
                                print('output_after_erase\n')
                                print(output_after_erase)
                                result_after_erase = output_after_erase.strip().split('\n')
                                for entry_idx in range(0, len(result_after_erase)):
                                    if re.search(r'^\s1\s.*', result_after_erase[entry_idx]) is not None:
                                        entry_found = True
                                        break
                                if entry_found:
                                    first_entry = result_after_erase[entry_idx].split()[1]
                                    print(('first entry: %s\n', first_entry))
                                    if erased_entry != first_entry:
                                        print('entry erase successful\n')
                                        entry_erase = True
                                    else:
                                        print('entry erase unsuccessful\n')
                                        entry_erase = False

            child.sendcontrol('c')
            time.sleep(5)
            if child.isalive() == False:
                print('bnxtmt exited successfully')
        self.load_driver()
        return entry_erase

    def vpd_show(self, domain_bdf):
        os.chdir(self.bnxtmt_dir)
        bnxmt_vpd = ''
        lspci_vpd = ''
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('vpd show')
            if child.expect('bnxtmt 1:>', timeout=30) == 0:
                output = child.before
                bnxtmt_vpd = output.strip().split('\n')
                print(bnxtmt_vpd)
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
                    child=pexpect.spawn('/bin/bash')
                    if child.expect('#') == 0:
                        child.sendline('lspci -s '+ domain_bdf + ' -vvv')
                        if child.expect('#') == 0:
                            output=child.before
                            lspci_vpd = output.strip().split('\n')
                            print(lspci_vpd)
        return bnxtmt_vpd,lspci_vpd

    def cdbg_pfmac(self, mac_addr):
        log.info('Updating the MAC address to %s' % mac_addr)
        self.unload_driver()
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('cdbg pfmac ' + mac_addr)
            if child.expect('bnxtmt 1:>', timeout=60) == 0:
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
        log.info('Sleep for 5 seconds for MAC Update...')
        time.sleep(5)
        log.info('Load the driver ... ')
        self.load_driver()
        time.sleep(10)
    
    def help_command(self):
        os.chdir(self.bnxtmt_dir)
        output = ''
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('help')
            if child.expect('bnxtmt 1:>') == 0:
                output = child.before
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
                    child.close()
        return output

    def run_option(self, option):
        os.chdir(self.bnxtmt_dir)
        output = ''
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh ' + option)
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            print('bnxtmt command prompt loaded')
            print((child.before))
            output = child.before
            child.sendcontrol('c')
            time.sleep(5)
            if child.isalive() == False:
                print('bnxtmt exited successfully')
        return output

    def nvm_dir(self):
        os.chdir(self.bnxtmt_dir)
        self.unload_driver()
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            child.sendline('nvm dir')
            if child.expect('bnxtmt 1:>', timeout=30) == 0:
                output_nvm_dir = child.before
            child.sendcontrol('c')
            time.sleep(5)
            if child.isalive() == False:
                print('bnxtmt exited successfully')
        self.load_driver()
        return output_nvm_dir

    def get_nvm_cfg(self, device_num, option_num, only_value=False):
        os.chdir(self.bnxtmt_dir)
        self.unload_driver()
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            if device_num == 'dev 1':
                prompt = 'bnxtmt '+'1'+':>'
            else:
                if device_num == 'dev 2':
                    prompt = 'bnxtmt '+'2'+':>'
            print(prompt)
            child.sendline(device_num)
            if child.expect(prompt, timeout=30) == 0:
                cmd = 'nvm cfg ' + option_num + '-' if only_value is False else '='
                print(cmd)
                child.sendline(cmd)
                if child.expect(prompt, timeout=30) == 0:
                    output_nvm_cfg = child.before
                    print(output_nvm_cfg)
            child.sendcontrol('c')
            time.sleep(5)
            if child.isalive() == False:
                print('bnxtmt exited successfully')
        self.load_driver()
        return output_nvm_cfg

    def set_nvm_cfg(self,device_num, option_num, val):
        os.chdir(self.bnxtmt_dir)
        self.unload_driver()
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            if device_num == 'dev 1':
                prompt = 'bnxtmt '+'1'+':>'
            else:
                if device_num == 'dev 2':
                    prompt = 'bnxtmt '+'2'+':>'
            print(prompt)
            child.sendline(device_num)
            if child.expect(prompt, timeout=30) == 0:
                cmd = 'nvm cfg ' + option_num + '=' + val + ' save'
                print(cmd)
                child.sendline(cmd)
                if child.expect(prompt, timeout=30) == 0:
                    output_nvm_cfg = child.before
                    print(output_nvm_cfg)
                child.sendcontrol('c')
                time.sleep(5)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
        self.load_driver()
        return output_nvm_cfg

    def config_mac_addr(self, mac_addr0, mac_addr1, option):
        os.chdir(self.bnxtmt_dir)
        output = ''
        log.info('mac_addr0:%s, mac_addr1:%s' %(mac_addr0, mac_addr1))
        if option == '-mac': 
            child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh -mac ' + mac_addr0 + ' -none')
        else:
            if option == '-m':
                child = pexpect.spawn('stdbuf -i0 -o0 -e0 /load.sh -m' + ' -none')
        if child.expect(['Please enter new device 1 primary MAC address:']) == 0:
            child.sendline(mac_addr0)
            if child.expect(['Please enter new device 2 primary MAC address:']) == 0:
                child.sendline(mac_addr1)
                if child.expect(['Result = PASS']) == 0:
                    print('MAC Address set successfully')
                    print((child.before))
                    time.sleep(15)
                    output=child.read()
        return output

    def source(self, src_file):
        log.info('Updating the Source file %s' % src_file)
        self.unload_driver()
        os.chdir(self.bnxtmt_dir)
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=20) == 0:
            print(('sourcing the config file',src_file)) 
            child.sendline('source ' + src_file)
            if child.expect('bnxtmt 1:>', timeout=60) == 0:
                print('source file successfully configured') 
                child.sendcontrol('c')
                time.sleep(15)
                if child.isalive() == False:
                    print('bnxtmt exited successfully')
        log.info('Load the driver ... ')
        self.load_driver()

    def recover_adapter(self, src_cfg_file, pkg_file, mac_addr0, mac_addr1, only_pkg=False):
        adapter_recovered = False
        os.chdir(self.bnxtmt_dir)
        print('Recovering the adapter')
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        if child.expect('bnxtmt 1:>', timeout=30) == 0:
            print('bnxtmt command prompt loaded')
            child.sendline('fwutil')
            if child.expect('bnxtmt 1:>', timeout=10) == 0:
                print('bnxtmt command prompt loaded using fwutil')
                print(('installing pkg %s on the adapter' % pkg_file))
                child.sendline('nvm pkginstall ' + pkg_file)
                if child.expect('bnxtmt 1:>', timeout=120) == 0:
                    adapter_recovered = True
                    if only_pkg == True:
                        child.sendcontrol('c')
                        time.sleep(5)
                        if child.isalive() == False:
                            print('bnxtmt exited successfully')
                            print(('source the config file %s' % src_cfg_file))
                            return adapter_recovered
                    child.sendline('source ' + src_cfg_file)
                    if child.expect('bnxtmt 1:>', timeout=60) == 0:
                        print(('configuring mac_addr:%s on pf0' % mac_addr0))
                        cmd = 'nvm cfg 1=' + mac_addr0 + ' save'
                        child.sendline(cmd)
                        if child.expect('bnxtmt 1:>', timeout=10) == 0:
                            print('Moving on to dev 2')
                            child.sendline('dev 2')
                            if child.expect('bnxtmt 2:>', timeout=10) == 0:
                                print(('configuring mac_addr:%s on pf1' % mac_addr1))
                                cmd = 'nvm cfg 1=' + mac_addr1 + ' save'
                                child.sendline(cmd)
                                if child.expect('bnxtmt 2:>', timeout=10) == 0:
                                    adapter_recovered = True
                                    child.sendcontrol('c')
                                    time.sleep(5)
                                    if child.isalive() == False:
                                        print('bnxtmt exited successfully')
        return adapter_recovered

    def mfg_cmd(self, command_list):
        output = exe.block_run(
            './load.sh' + ' -none ' + ' '.join(command_list),
            cwd=self.bnxtmt_dir
            , shell=True)
        log.info('output_mfg_cmd:%s' % output)
        return output

    def sysop_cmd(self, command_list):
        output = exe.block_run(
            './load.sh' + ' -sysop ' + ' '.join(command_list),
            cwd=self.bnxtmt_dir
            , shell=True)
        log.info('output sysop_cmd: %s' % output)
        return output

    def factory_program(self, oem, img_path, npar=True, ser_num = False):
        log.info('Unload the driver ... ')
        self.unload_driver()
        if oem.lower() == 'dell':
            result = self.mfg_cmd(
                ['-no_swap -fnvm ' + img_path + (' -stride 16' if npar else '') + ' -fmac macid.txt ' +\
                ('-npar_mac' if npar else '') +  ' -log logfile.txt']
            )
        elif oem.lower() == 'hp':
            result = self.mfg_cmd(
                ['-no_swap -fnvm ' + img_path + (' -stride 16' if npar else '') + ' -fmac macid.txt ' +\
                ('-sn sn.txt -vpd ' if ser_num else '') + ('-npar_mac' if npar else '') +  ' -log logfile.txt']
            )
        elif oem.lower() == 'lenovo':
            result = self.mfg_cmd(
                ['-no_swap -fnvm ' + img_path + (' -stride 16' if npar else '') + ' -fmac macid.txt ' +\
                ('-sn2 sn2.txt -vpd ' if ser_num else '') + ('-npar_mac' if npar else '') +  ' -log logfile.txt']
            )
        elif oem.lower() == 'oracle':
            result = self.mfg_cmd(
                ['-no_swap -fnvm ' + img_path + (' -stride 16' if npar else '') + ' -fmac macid.txt ' +\
                ('-sn3 sn3.txt -vpd ' if ser_num else '') + ('-npar_mac' if npar else '') +  ' -log logfile.txt']
            )
        elif oem.lower() == 'broadcom':
            result = self.mfg_cmd(
                ['-no_swap -fnvm ' + img_path + (' -stride 16' if npar else '') + ' -fmac macid.txt ' +\
                ('-npar_mac' if npar else '') +  ' -log logfile.txt']
            )
        elif oem.lower() == 'stratus':
            result = self.mfg_cmd(
                ['-no_swap -fnvm ' + img_path + ' -noidcheck' + (' -stride 16' if npar else '') + ' -fmac macid.txt ' +\
                ('-npar_mac' if npar else '') +  ' -log logfile.txt']
            )

        result_arr = result.strip().split('\n')
        return result_arr

    def factory_test(self, cfgchk_path):
        log.info('Running the FCTTEST...')
        log.info('Unloading the driver...')
        self.unload_driver()
        result = self.sysop_cmd(
            ['-no_swap -cfgchk ' + cfgchk_path + ' -log fcttest.txt']
        )
        log.info('loading the driver...')
        self.load_driver()
        result_arr = result.strip().split('\n')
        return result_arr

    def nvmverify(self, readmac_path):
        log.info('Running the NVRAMVerify Script')
        log.info('Unloading the driver...')
        self.unload_driver()
        result = self.mfg_cmd(
            ['-rc ' + readmac_path]
        )
        log.info('loading the driver...')
        self.load_driver()
        result_arr = result.strip().split('\n')
        return result_arr

    def bnxtmt_with_cdiag(self, lcdiag_dir):
        log.info('Unloading the driver...')
        self.unload_driver()
        os.chdir(lcdiag_dir)
        child1 = pexpect.spawn('stdbuf -i0 -o0 -e0 /bin/bash')
        if child1.expect('#') == 0:
            child1.sendline('./load.sh')
            if child1.expect('1:>', timeout=20) == 0:
                print('lcdiag launched successfully')
                os.chdir(self.bnxtmt_dir)
                child2 = pexpect.spawn('./load.sh')
                if child2.expect(pexpect.EOF, timeout=30) == 0:
                    output = child2.before
                    print(output)
                    child1.sendline('exit')
                    if child1.expect('#') == 0:
                        print('lcdiag exited successfully')
        log.info('loading the driver...')
        self.load_driver()
        return output

    def multiple_bnxtmt_sessions(self):
        log.info('Unloading the driver...')
        self.unload_driver()
        os.chdir(self.bnxtmt_dir)
        child1 = pexpect.spawn('stdbuf -i0 -o0 -e0 /bin/bash')
        if child1.expect('#') == 0:
            child1.sendline('./load.sh')
            if child1.expect('1:>', timeout=20) == 0:
                print('bnxtmt launched successfully')
                os.chdir(self.bnxtmt_dir)
                child2 = pexpect.spawn('./load.sh')
                if child2.expect(pexpect.EOF, timeout=30) == 0:
                    output = child2.before
                    print(output)
                    child1.sendline('exit')
                    if child1.expect('#') == 0:
                        print('bnxtmt exited successfully')
        log.info('loading the driver...')
        self.load_driver()
        return output

    def inject_error(self, mac_addr, srt_fw=False):
        os.chdir(self.bnxtmt_dir)
        raw_mac = mac_addr.replace(':', '').upper()
        child = pexpect.spawn('stdbuf -i0 -o0 -e0 ./load.sh')
        try:
            if child.expect('bnxtmt 1:>', timeout=60) == 0:
                log.info('bnxtmt launched successfully')
                output = child.before
                dev = re.search('(\d+)\s+:.*%s' % raw_mac, output).group(1)
                new_prompt = 'bnxtmt %s:> ' % dev
                child.sendline('device %s' % dev)
                if child.expect(new_prompt, timeout=30) == 0:
                    child.sendline('unlock')
                    log.info("Crashing CRT/CHIMP on Dev %s" % dev)
                    child.sendline('mem -nochk read 0 4')
                    if srt_fw:
                        log.info("Crashing SRT on Dev %s" % dev)
                        child.sendline('mem -nochk -srt read 0 4')
                else:
                    log.error('Failed to select/find device having mac address %s' % mac_addr)
        finally:
            child.sendline('exit')
            time.sleep(5)
            if child.isalive() == False:
                log.info('bnxtmt exited successfully')
