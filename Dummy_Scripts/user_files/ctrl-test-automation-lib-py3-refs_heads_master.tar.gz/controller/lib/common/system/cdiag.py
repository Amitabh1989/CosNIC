"""
:mod:`cdiag` -- The test script template
===========================================

.. module:: controller.lib.common.system.cdiag
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""


import time
import re

from controller.lib.common.shell import exe
from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class Cdiag(object):
    def __init__(self, cdiag_dir):
        self.cdiag_dir = cdiag_dir

    def exec_command(self, command_list):
        return exe.block_run(
            ['./load.sh', '-eval', '; '.join(command_list)],
            cwd=self.cdiag_dir
        )
    
    def get_cfw_ver(self):
        log.info('Getting FW version')
        nvmdir = self.exec_command(['nvm dir'])
        nvm_op = nvmdir.strip().split('\n')
        print(('The length is %s' % len(nvm_op)))
        for line in nvm_op:
            print(('The Line is %s' %line))
            templine = line.strip()
            linearr = templine.split(" ")
            if len(linearr) > 5:
                if(linearr[1] == 'CFW'):
                    print('Enter the dragon')
                    cfw_line = re.findall('\s*(\d+)[\s\t]+CFW[\s\t]+\d+[\s\t]+\S+\s+\S+\s+(\d+.\s*\d+.\s*\d+.\s*\d+)', line)
                    temp = cfw_line[0][1]
                    cfw_ver = "".join(temp.split())
                    return cfw_ver
            else:
                continue
        return False
        
    def flash_cfw(self, cfw_filename):
        log.info('Unload the driver ... ')
        self.unload_driver()

        self.exec_command(
            ['nvm pkginstall ' + cfw_filename]
        )
        log.info('Sleep for 10 seconds to complete upgrade ... ')
        time.sleep(10)

        log.info('Load the driver ... ')
        self.load_driver()
        time.sleep(10)
        
    def unload_driver(self, sut):
        raise NotImplementedError

    def load_driver(self):
        raise NotImplementedError

    def upgrade_cfw(self, cfw_filename, force=False):
        log.info('Unload the driver ... ')
        self.unload_driver()

        self.exec_command(
            ['nvm upgrade ' + ('-F ' if force else '') + '-cfw ' + cfw_filename]
        )
        log.info('Sleep for 10 seconds to complete upgrade ... ')
        time.sleep(10)

        log.info('Load the driver ... ')
        self.load_driver()
        time.sleep(10)

    def get_chimp_trace(self):
        """Dump some useful information. For now, dump chimp trace"""
        return self.exec_command(['chimp trace'])

    def nictest(self):
        log.info('Running nictest ... ')
        self.exec_command(['nictest -I 1'])

    def get_counter(self, iface):
        raise NotImplementedError
        # Need to get port ID
        self.exec_command(['stats mac %s' % port_id])

    def reset_chimp(self):
        log.info('Unload the driver ... ')
        self.unload_driver()
        self.exec_command(
            ['reset all']
        )
        log.info('Sleep for 10 seconds to reset the chimp FW ... ')
        time.sleep(10)

        log.info('Load the driver ... ')
        self.load_driver()
        time.sleep(10)

class Lcdiag(Cdiag):
    def unload_driver(self):
        # cdiag is only for cumulus; hardcode the driver name
        try:                                                                        #If BNXT_RE is loaded and BNXT_EN is not allowing to get unloaded
            return exe.block_run('modprobe -r bnxt_en')
        except:
            exe.block_run('modprobe -r bnxt_re')
            return exe.block_run('modprobe -r bnxt_en')

    def load_driver(self):
        return exe.block_run('modprobe bnxt_en')


class Wcdiag(Cdiag):
    def unload_driver(self):
        # Will be updated once wcdiag becomes available
        pass

class Bnxtmt(Cdiag):
    def unload_driver(self):
        # cdiag is only for cumulus; hardcode the driver name
        try:                                                                        #If BNXT_RE is loaded and BNXT_EN is not allowing to get unloaded
            return exe.block_run('modprobe -r bnxt_en')
        except:
            exe.block_run('modprobe -r bnxt_re')
            return exe.block_run('modprobe -r bnxt_en')

    def load_driver(self):
        return exe.block_run('modprobe bnxt_en')