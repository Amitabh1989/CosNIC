"""
:mod:`driver` -- Back-end interface to driver operations
===========================================================

.. module:: controller.lib.common.system.driver
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>

"""

import abc

from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


log = log_handler.get_logger(__name__)


class BaseDriver(object, metaclass=abc.ABCMeta):
    """
    Can do driver operations on NIC adapter. Abstract
    backend and perform driver operations with a system depending on
    the method.

    This class uses user-space tools to do driver operation on the NIC

    Args:
        None

    Returns:
        Interface: Interface object that has methods to interact with
            the driver operations

    """

    __metaclass__ = abc.ABCMeta

    def __init__(self):
        pass

    @abc.abstractmethod
    def install(self, filename):
        """Install driver component"""
        raise NotImplementedError

    @abc.abstractmethod
    def uninstall(self, driver_name):
        """Uninstall driver component"""
        raise NotImplementedError

    @abc.abstractmethod
    def upgrade(self, filename, force=False):
        """Upgrade driver component"""
        raise NotImplementedError

    @abc.abstractmethod
    def rollback(self, driver_name):
        """Rollback driver component 
        or downgrade to inbox driver"""
        raise NotImplementedError

    @abc.abstractmethod
    def is_installed(self, driver_name):
        """Check whether driver component got installed on the machine.

        Returns:
            bool: 
                True: If driver got installed
                False: If driver is not installed
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_version(self, driver_name):
        """Gets driver version.

        Returns:
            str: Installed driver version.
            None: If driver is not installed.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_package_info(self, pkg_name):
        """Gets driver package info.

        Returns:
            dict: {Installed driver version, 
            None: If driver is not installed.
        """
        raise NotImplementedError
