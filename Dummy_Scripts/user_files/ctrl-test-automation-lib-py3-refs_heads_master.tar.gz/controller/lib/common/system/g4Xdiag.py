"""
:mod:`G4Xdiag` -- SCRUTINY_XTOOLS_ATLAS2 CLI
===========================================

.. module:: controller.lib.common.system.g4xdiag
.. moduleauthors:: Aswanth <aswanth-kumar.reddy@broadcom.com>

This module is an interface for g4xdiag utility.

usage:

    >>> BaseG4xdiag(object)

Class G4Xdiagnostics will help with functions to execute the g4xdiagnostic supported commands
and validated the content of the command based on provided the input .
More functions will be added to cover the maximum g4xdiagnostic supported commands.
"""
__version__ = "1.0.0"
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

__changeset__ = """
ID               WHO         WHEN(MM/DD/YY)   COMMENTS
==============================================================================
DCSG01748892     Aswanth      07/27/24         Add automation support for G4X diag tool  Firmware commands ISR, error counters, pcieperf
DCSG01768203     Aswanth      08/02/24         Automation support for G4X diag tool  commands for 'PEX 88xxx/PEX 89xxx Switches' and interface 'SCSI Inband'         


"""

import re
import datetime
from distutils.spawn import find_executable
import json.decoder
from typing import Dict

from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.common.system.pcie_switch_fwcli import AtlasBaseFwcli

log = log_handler.get_module_logger(__name__)


class BaseG4xdiag(AtlasBaseFwcli):

    def __init__(self, wwid: str = None, bdf: str = None, g4xdiag_path: str = None):
        """
        Intantiate switch using WWID or BDF. Only one of the two needs to be passsed in.

        :param wwid:         Unique WWID of the PCI switch
        :param bdf:          This is actually the sbdf (ss:bb:dd.f)
        :param g4xdiag_path: Path to g4Xdiagnostics.x86_64 binary
        """
        super(BaseG4xdiag, self).__init__()

        self._prg_path = g4xdiag_path or find_executable('g4Xdiagnostics.x86_64')
        if self._prg_path is None:
            raise exception.ToolNotFoundException('g4Xdiagnostics.x86_64 is not available')

        devices = self.get_devices()
        if wwid:
            for index, dev_dict in devices.items():
                if dev_dict['WWID'].lower() == wwid.lower():
                    self.index = index
                    self.wwid = wwid
                    self.bdf = dev_dict['PCIAddr']
                    break
            else:
                raise Exception(f"Provided WWID {wwid} not found")

        elif bdf:
            for index, dev_dict in devices.items():
                if dev_dict['PCIAddr'].lower() == bdf.lower():
                    self.index = index
                    self.wwid = dev_dict['WWID']
                    self.bdf = bdf
                    break
            else:
                raise Exception(f"Provided BDF {bdf} not found")

    @property
    def g4xdiag(self):
        return f"{self._prg_path} -i {self.index}"

    def exec_command(self, cmd, shell: bool = False, silent: bool = False,  **kwargs) -> Dict:
        """
        execute g4x commands
        command (str): Shell comamnd that should be executed
        kwargs: keyword arguments that are passed to build sub commands
        returns: outpput of g4X command
        Ex:-
            exec_command(cmd, mask=12, port=24)
            then final command will be "cmd  mask 12  port 24"
        """
        options = []
        for k, v in kwargs.items():
            options.append(f'{k}' if v is None else f'{k} {v}')
        options = ' '.join(options)
        cmd = f'{self.g4xdiag} --json /root/output.json {cmd} {options}'
        exe.block_run(cmd, shell=shell, silent=silent)
        out = exe.block_run(f'cat /root/output.json')
        json_data = json.loads(out)
        log.info(f"Command executed {cmd}, \n ouput_json:{json_data} \n")
        if json_data["scrutiny"]["status"]["status"] != 'success':
            raise Exception("Command not executed succsfully")
        return json_data

    def cli_exec_command(self, cmd, **kwargs) -> Dict:
        """
        To execute FW CLI commands
        :param cmd: command to be execute
        :return: ouptut of the executed command saved in json format
        """
        silent = kwargs.get("silent", True)
        cmd = f'{self.g4xdiag} cli {cmd}'
        op = exe.block_run(cmd, silent=silent)
        log.info(f"Command executed {cmd}, \n ouput:{op} \n")
        return op

    def get_devices(self) -> Dict[int, Dict[str, str]]:
        """ Return dict of dicts for all devices found in g4Xdiagnostics.x86_64 --list

        Sample raw output of "g4Xdiagnostics.x86_64 --list"
        -------------------------------------------------------------------------------
        g4Xdiagnostics v4.16.0.6 - Broadcom Inc. (c) 2024 (Bld-101.52.39.132.16.0)
        -------------------------------------------------------------------------------

          DeviceId/RevId         WWID               FwVersion        PCIAddr      Type                 Mode
          1) PEX89048 A0         -                  Not Available    00:83:00.0   Switch               PCI
          2) PEX89144 B0         500605b0:000272b8  04.17.106.00     00:98:00.0   Switch               MPI
          3) SAS35x48 B0         500056b3:df0eebff  01.16.02.00      00:65:00.0   Expander             MFI
          4) PEX89144 B0         -                  04.17.106.00     -            Switch               NT2 (PEACapable)

        Dict will contain the following keys (same as reported in g4Xdiagnostics):
        - DeviceId
        - RevId
        - WWID
        - FwVersion
        - PCIAddr
        - Type
        - Mode
        """
        output = exe.block_run(f'{self._prg_path} --list')

        return_dict = {}
        pattern = re.compile(r'\s*(\d+)\)\s*'                # Index
                             r'(\w+)\s+'                     # DeviceId
                             r'(\w+)\s+'                     # RevId
                             r'([\S:]+)\s+'                  # WWID
                             r'([\d\.]+|Not Available)+\s+'  # FwVersion
                             r'([0-9a-fA-F:\.-]+)\s+'        # PCIAddr
                             r'(\w+)\s+'                     # Type
                             r'([\S ]+)'                     # Mode
                             r'\n*')
        for index, dev_id, rev_id, wwid, fw_ver, pci_addr, dev_type, mode in re.findall(pattern, output):
            return_dict[int(index)] = {'DeviceId': dev_id,
                                       'RevId': rev_id,
                                       'WWID': wwid,
                                       'FwVersion': fw_ver,
                                       'PCIAddr': pci_addr,
                                       'Type': dev_type,
                                       'Mode': mode.strip()}
        return return_dict

    def show(self, sbr: bool = False, ftbl: bool = False) -> Dict:
        """
        Shows FW/Manufacturing information
        :param sbr: If it is true will display SBR details
        :param ftbl: If it is true will display Flash Table
        :return: ouptut of the executed command saved in json format
        """
        cmd = "show"
        if sbr:
            cmd = cmd + " -sbr"
        elif ftbl:
            cmd = cmd + " -ftbl"
        op = self.exec_command(cmd)
        return op

    def help(self, single_command: bool = False, command=None) -> Dict:
        """
        Displays help for the commands
        :param single_command: If it is true  sisplays help for single_command passed by user
        :param command:command to which help needed
        :return: ouptut of the executed command saved in json format
        """
        if single_command:
            op = exe.block_run(f'{self._prg_path} help {command}')
        else:
            op = exe.block_run(f'{self._prg_path} --help')
        return op

    def reset(self, wd: bool = False):
        """
        The command resets different components/devices/counters
        :param wd: If its True Warm/Soft reset else Issues HW reset
        :return: ouptut of the executed command saved in json format
        """
        if wd:
            cmd = "reset -wd -s"
        else:
            cmd = "reset -hw -s"
        op = self.exec_command(cmd)
        return op

    def fwlogs(self, raw: bool = False) -> Dict:
        """
        The command is to display the health logs of the device
        :param raw: If it is true prints the logs in the format that firmware uploads else in string format or partially decoded format
        :return: ouptut of the executed command saved in json format
        """
        cmd = "fwlogs"
        if raw:
            cmd = cmd + " -raw"
        op = self.exec_command(cmd)
        return op

    def erase(self, manufacturing: bool, region_index: int = 0):
        """
        To erase the flash
        :param manufacturing: If it is true erases the manufacturing region
        :param region_index: Erases the specific flash table region index
        :return: ouptut of the executed command saved in json format
        """
        if manufacturing:
            cmd = f"erase -m -s"
        else:
            cmd = f"erase -r {region_index} -s -nv"
        op = self.exec_command(cmd)
        return op

    def cfg(self, dumpall: bool = False, PageNumber: str = '0xFE00', region: int = 0) -> Dict:
        """
        This is to Dump/Read config pages
        :param dumpall: Read entire configuration
        :param PageNumber:  Read for the provided page number
        :param region: Read for the provided region
        :return: ouptut of the executed command saved in json format
        """
        if dumpall:
            cmd = "cfg -dumpall"
        else:
            cmd = f"cfg -n {PageNumber} -f {region}"
        op = self.exec_command(cmd)
        return op

    def mem(self, rd: bool = False, address: hex = 0x1, data: hex = 0x1, size: int = 1) -> Dict:
        """
        To read dwords from the memory
        :param rd: If it is true reads the memory from the specified address else  Writes the data to the specified address
        :param address: Address to which the dword value to be written
        :param data: Dword data that will be written
        :param size: No. of dwords to read from the specified address
        :return: ouptut of the executed command saved in json format
        """
        if rd:
            cmd = f"mem -rd {address} {size}"
        else:
            cmd = f"mem -wd {address} {data} -v"
        op = self.exec_command(cmd)
        return op

    def port(self, all: bool = False, port_num: int = 1) -> Dict:
        """
        This will display all the basic details of Port
        :param all: If it is true displays all ports details
        :param port_num: Displays provided port number details
        :return: ouptut of the executed command saved in json format
        """
        cmd = "port"
        if not all:
            cmd = cmd + f" -p {port_num}"
        op = self.exec_command(cmd)
        return op

    def counters_clear_display(self, clear: bool = False, port: bool = False, port_num: int = 1) -> Dict:
        """
        This will display Error counters for the given ports
        :param clear: If it is true clear error counters else display error counters
        :param port: If it is true clear/display error counters for all ports else for porivded port
        :param port_num: lear/display error counters for given port number
        :return: ouptut of the executed command saved in json format
        """
        if clear:
            cmd = f'counters -p {port_num} -clear' if port else 'counters -clear'
        else:
            cmd = f'counters -p {port_num}' if port else 'counters'
        op = self.exec_command(cmd)
        return op

    def diagnostic_buffer(self, size) -> Dict:
        """
        To Register Diagnostic Buffer
        :param size: size option should be provided if buffer is not already registered
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running diagnostic_buffer command on pcie switch")
        cmd = f"db -register -trace -size {size}"
        op = self.exec_command(cmd)
        return op

    def query_diagnostic_buffer(self):
        """
        To Query Diagnostic Buffer
        :param size: size option should be provided if buffer is not already registered
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running query_diagnostic_buffer command on pcie switch")
        cmd = "db -query -trace"
        op = self.exec_command(cmd)
        return op

    def read_diagnostic_buffer(self) -> Dict:
        """
        To Read Diagnostic Buffer
        :param size: size option should be provided if buffer is not already registered
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running read_diagnostic_buffer command on pcie switch")
        file_name = 'db_trace_' + datetime.now().strftime('%Y-%m-%d_%H_%M_%S') + '.bin'
        cmd = f"db -read -trace -file {file_name}"
        op = self.exec_command(cmd)
        return op

    def release_diagnostic_buffer(self):
        """
        To Release Diagnostic Buffer
        :param size: size option should be provided if buffer is not already registered
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running release_diagnostic_buffer command on pcie switch")
        cmd = "db -release -trace"
        op = self.exec_command(cmd)
        return op

    def unregister_diagnostic_buffer(self, size):
        """
        To Un-Register Diagnostic Buffer
        :param size: size option should be provided if buffer is not already registered
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running unregister_diagnostic_buffer command on pcie switch")
        cmd = f"db -register -trace -size {size}"
        op = self.exec_command(cmd)
        return op

    def scan(self, all: bool = False, brcm: bool = False) -> Dict:
        """
        This will display PCIe devices in the topology
        :param all: If it is true display all the devices in the topology
        :param brcm: If it is true display brcm devices in this device hierarchy else display all the pcie devices in the topology
        :return: ouptut of the executed command saved in json format
        """
        cmd = 'scan'
        if all:
            cmd = cmd + ' -all'
        elif brcm:
            cmd = cmd + ' -brcm'
        op = self.exec_command(cmd)
        return op

    def lm(self, show: bool = False, port_num: int = 0, lane_num: str = '0', ec: int = 4, ts: int = 6, vs: int = 32) -> Dict:
        """
        This perform lane margining operation
        :param show: Display report capabilities information
        :param port_num: Display capabilities information for given port number
        :param lane_num: Display capabilities information for given lane number
        :param ec: Error count
        :param ts:  Number of time steps
        :param vs: Number of voltage steps
        :return: ouptut of the executed command saved in json format
        """
        cmd = f'lm -port {port_num} -ln {lane_num}'
        cmd = cmd + ' -show'if show else  cmd + f' -ec {ec} -ts {ts} -vs {vs}'
        op = self.exec_command(cmd)
        return op

    def pcicfg(self, pci: bool = False, port: bool = False, port_num: int = 0, bdf: str = None) -> Dict:
        """
        This will display PCIe configuration for various ports/devices
        :param pci: If it is true display PCIe config space of the bdf
        :param port: If it is true display PCIe config space of the port
        :param port_num: Display PCIe config space of the given port number
        :param bdf: Display PCIe config space of the given bdf
        :return: ouptut of the executed command saved in json format
        """
        cmd = "pcicfg"
        if pci:
            bdf = bdf if bdf is not None else self.bdf
            cmd = cmd + f" -pci {bdf}"
        elif port:
            cmd = cmd +  f" -port  {port_num}"
        op = self.exec_command(cmd)
        return op

    def perf(self, loop: int, delay: int, stat: bool = False, stat_interval: int = 1) -> Dict:
        """
        This is used display the Atlas port performance
        :param loop: Number of test loops
        :param delay: Time delay for first read in millisec
        :param stat: If it is true then displays based on Statistic time interval
        :param stat_interval: Statistic time interval in millisec
        :return: ouptut of the executed command saved in json format
        """
        cmd = f"perf -loop {loop} -delay {delay}"
        if stat:
            cmd = cmd + f" -stat {stat_interval}"
        op = self.exec_command(cmd)
        return op

    def download_firmware(self, binary_file):
        """
        To download firmware
        :param binary_file: Firmware image that needs to be downloaded
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running download_firmware command on pcie switch")
        cmd = f'dl -p {binary_file} -s -nv'
        op = self.exec_command(cmd)
        return op

    def download_manufacturing(self, manufacturing_data, schema):
        """
        To download manufacturing data
        :param manufacturing_data: Mfg image which is Unit Specific Configuration Data in XML/binary format
        :param schema: Schema file for XML input
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running download_manufacturing command on pcie switch")
        cmd = f'dl -m {manufacturing_data} -xsd {schema} -s -nv'
        op = self.exec_command(cmd)
        return op

    def download_any(self, binary_file, bufferid):
        """
        To download any file to a buffer region
        :param binary_file: Binary image that needs to be downloaded
        :param bufferid: Buffer ID value where the buffer needs to be downloaded.
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running download_any command on pcie switch")
        cmd = f'dl -i {binary_file} -b {bufferid} -s'
        op = self.exec_command(cmd)
        return op

    def upload_region(self, binary_file, region_index):
        """
        To upload the specific region
        :param binary_file: File name where uploaded data stored in binary format
        :param region_index: Upload the specific flash table region. Index should be decimal value.
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_region command on pcie switch")
        cmd = f'ul -r {region_index} -o {binary_file} -s -nv'
        op = self.exec_command(cmd)
        return op

    def upload_buffer_id(self, buffer_id, file_name, template=None, schema=None):
        """
        To upload the region using buffer Id
        :param buffer_id: Buffer ID in hex value. The buffer Id should be 0 to FF and must be supported by the target
        :param file_name: File name where uploaded data will be stored.
        :param template: Relative or absolute path of the XML file
        :param schema: XML Schema definition file.
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_buffer_id command on pcie switch")
        if str(buffer_id) == '0xEF' and (template is None or schema is None):
            raise Exception('Both template and schema should be valid values')
        elif str(buffer_id) == '0xEF':
           cmd = f'ul -b {buffer_id} -o {file_name} -x {template} -xsd {schema} -s'
        else:
            cmd = f'ul -b {buffer_id} -o {file_name} -s'
        op = self.exec_command(cmd)
        return op

    def spdm_sltstatus(self, slot_val, slot_group) -> Dict:
        """
        Show certificate slot chain status
        :param slot_val: Slot to use for storage of the Import Certificate Chain Request.
        :param slot_group: Slot group to read for Certificate Chain status
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_region command on pcie switch")
        cmd = f'spdm -sltstatus -sg {slot_group} -s {slot_val}'
        op = self.exec_command(cmd)
        return op

    def spdm_ulcert(self, slot_val, slot_group, file_name):
        """
        Exports or request the FW to create a CSR file, for a particular slotgroup/slot combination
        :param slot_val: Slot to use for storage of the Import Certificate Chain Request.
        :param slot_group: Slot group to read for Certificate Chain status
        :param file_name: Write CSR data of a slot to a file.
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_region command on pcie switch")
        cmd = f'spdm -ulcert {file_name} -sg {slot_group} -s {slot_val}'
        op = self.exec_command(cmd)
        return op

    def spdm_dlcert(self, slot_val, slot_group, file_name):
        """
        Imports SPDM certificate slot chain for a particular slotgroup/slot combination.
        :param slot_val: Slot to use for storage of the Import Certificate Chain Request.
        :param slot_group: Slot group to read for Certificate Chain status
        :param file_name: Imports DER encoded Certificate Chain of a slot from the file
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_region command on pcie switch")
        cmd = f'spdm -dlcert {file_name} -sg {slot_group} -s {slot_val}'
        op = self.exec_command(cmd)
        return op

    def spdm_get(self, slot_val, slot_group, file_name) -> Dict:
        """
        Read/Get details of certificate chain slot of a specific slot in slotgroup
        :param slot_val: Slot to use for storage of the Import Certificate Chain Request.
        :param slot_group: Slot group to read for Certificate Chain status
        :param file_name: Imports DER encoded Certificate Chain of a slot from the file
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_region command on pcie switch")
        cmd = f'spdm -get {file_name} -sg {slot_group} -s {slot_val}'
        op = self.exec_command(cmd)
        return op

    def spdm_display(self) -> Dict:
        """
        Manage/Invalidates a certificate chain storage slot
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running upload_region command on pcie switch")
        cmd = f'spdm -i'
        op = self.exec_command(cmd)
        return op

    def sbr_display(self, region_index, cs_value) -> Dict:
        """
        display the information about the SBR
        :param region_index: Region index to Upload/Download/Validate/Erase
        :param cs_value: Chip Select value in decimal
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running sbr_display command on pcie switch")
        cmd = f'sbr -i -r {region_index} -cs {cs_value}'
        op = self.exec_command(cmd)
        return op

    def sbr_erase(self, region_index, cs_value):
        """
        erase the SBR for the given region
        :param region_index: Region index to Upload/Download/Validate/Erase
        :param cs_value: Chip Select value in decimal
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running sbr_erase command on pcie switch")
        cmd = f'sbr -e -r {region_index} -cs {cs_value}'
        op = self.exec_command(cmd)
        return op

    def sbr_upload(self, region_index, cs_value, file_name, xsd_file=None, op_file=None, xml_file=False):
        """
        upload the SBR region into Binary or XML file
        :param region_index: Region index to Upload/Download/Validate/Erase
        :param cs_value: Chip Select value in decimal
        :param file_name: Binary or XML file
        :param xsd_file: XML Schema definition file
        :param op_file: Output SBR XML file
        :param xml_file: if true file type should be xml file name else binary file
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running sbr_upload command on pcie switch")
        if xml_file:
            if xsd_file is None or op_file is None:
                raise Exception("Provide valid xml file names for xsd and ouput")
                cmd = f'sbr -u -r {region_index}  -x {file_name} -xsd {xsd_file} -o {op_file} -nv -cs {cs_value}'
        else:
            cmd = f'sbr -u -r {region_index} -b {file_name}  -nv -cs {cs_value}'
        op = self.exec_command(cmd)
        return op

    def sbr_download(self, region_index, cs_value, file_name, xml_file=False):
        """
        SBR image from Binary or XML file
        :param region_index: Region index to Upload/Download/Validate/Erase
        :param cs_value: Chip Select value in decimal
        :param file_name: Binary or XML file
        :param xml_file: if true file type should be xml file name else binary file
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running sbr_download command on pcie switch")
        option = 'x' if xml_file else 'b'
        cmd = f'sbr -d -r {region_index} -{option} {file_name} -nv -s -cs {cs_value} -quad'
        op = self.exec_command(cmd)
        return op

    def sbr_validate(self, region_index, cs_value, file_name):
        """
        validate the SBR binary file
        :param region_index: Region index to Upload/Download/Validate/Erase
        :param cs_value: Chip Select value in decimal
        :param file_name: binary file
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running sbr_validate command on pcie switch")
        cmd = f'sbr -v -b {file_name}'
        op = self.exec_command(cmd)
        return op

    def ltssm(self, port_number, interval_time=100, counter=16):
        """
        To perform the LTSSM check
        :param port_number: Port number in decimal value.
        :param interval_time:  Interval count in ms. Default is 100 ms
        :param counter:  Number of steps to execute and default is 16 counts.
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running ltssm command on pcie switch")
        cmd = f' ltssm -p {port_number} -t {interval_time} -c {counter}'
        op = self.exec_command(cmd)
        return op

    def list(self) -> Dict:
        """
        Lists all the supported device information and can choose the target to connect with
        :return: ouptut of the switch ID
        """
        log.info("Running ltssm command on pcie switch")
        cmd = f'--list'
        op = self.exec_command(cmd)
        return op

    def otc(self) -> Dict:
        """
        This will capture all basic device logs in one simple command for debugging
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running otc on pcie switch")
        op = self.exec_command('otc')
        return op

    def fwtrace(self) -> Dict:
        """
        The is to display the trace entries
        :return: ouptut of the executed command saved in json format
        """
        log.info("Running fwtrace on pcie switch")
        op = self.exec_command('fwtrace')
        return op


