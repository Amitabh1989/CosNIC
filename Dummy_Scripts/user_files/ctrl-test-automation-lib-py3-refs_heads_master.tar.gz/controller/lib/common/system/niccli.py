"""
:mod:`niccli` -- Scrutiny NIC CLI
===========================================

.. module:: controller.lib.common.system.niccli
.. moduleauthors:: Sekhar <@broadcom.com>, Surendra Narala <surendra-reddy.narala@broadcom.com>

This module is an interface for niccli utility.

Uasage:

Online mode,
    >>> oneline = Niccli(mac_addr='5c:6f:69:8c:a2:80', niccli_path='/root/NIC_TOOLS/NICCLI/Linux/niccli.x86_64')
must provide pf to msixmv_show
    >>> show = oneline.msixmv_show(1)
    >>> print(show)
must provide pf to msximv_config
    >>> result = oneline.msixmv_config(0, 8, {0: (0, 1)})
    >>> print(result)
    >>> show = oneline.msixmv_show(1)
    >>> print(show)

Interactive mode,

    >>> interact = InteractiveNiccli(mac_addr='5c:6f:69:8c:a2:80', niccli_path='/root/NIC_TOOLS/NICCLI/Linux/niccli.x86_64')
    >>> interact.start()
    >>> output = interact.listdev()
    >>> print(output)
    >>> interact.stop()

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import os
import platform
import re
import tempfile
from distutils.spawn import find_executable
from functools import wraps
from typing import Dict

if platform.uname().system.lower() == "windows":
    import wexpect as pexpect
else:
    import pexpect

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class BaseNiccli(object):

    def __init__(self, mac_addr, niccli_path='niccli'):
        """
        Args:
            mac_addr (str): MAC address or pci-id of the interface
             niccli_path (str): ethX name.
        """
        self._exe = exe
        self.mac_addr = mac_addr
        self.newline = '\n'
        self._prg_path = find_executable(niccli_path)
        if self._prg_path is None:
            raise exception.ToolNotFoundException(f'{niccli_path} is not available')

        nic_list = self._exe.block_run(f'{self._prg_path} --list')

        # DCSG01760289
        tool_version = self._exe.block_run(f'{self._prg_path} --version')
        match = re.search(r'NIC CLI\s+v(.*)\s+-\s+Broadcom Inc', tool_version).group(1)
        self.tool_version = int(match.split('.')[0])

        log.info(nic_list)
        iface_re = re.search(r'(\d+)\)\s+(BCM\d+).*{}'.format(mac_addr), nic_list, re.I)
        if iface_re:
            self.index = iface_re.group(1)
            self.deviceId = iface_re.group(2)
            self._niclci_prompt = self.deviceId + '>'
        else:
            raise Exception(f"Provided Mac addr/Pci id: {mac_addr} not found")

    @property
    def niccli(self):
        return f"{self._prg_path}  -i {self.index}"

    def exec_command(self, cmd, **kwargs):
        raise NotImplementedError

    def help(self, cmd=None, **kwargs):
        """

        Returns:will return help message of niccli

        """
        cmd = f'help {cmd or ""}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def restore_factory_defaults(self, force=True, **kwargs):
        """
        Restores NVM configuration to factory defaults. This command is supported only on BCM9575xxx devices
        :param force: Runs the command with force option
        :return:
        """
        # DCSG01760289
        if self.tool_version >= 225:
            command = "rfd" + (" -s" if force else "")
        else:
            command = "restore_factory_defaults" + (" -s" if force else "")

        command_output = self.exec_command(command, **kwargs)
        if "Restored NVM Factory Defaults" in command_output:
            log.info('Factory defaults executed successfully')
            return command_output
        else:
            log.error('Factory defaults operation Failed')
            return False

    def backup(self, **kwargs):
        """
        Generate nvm contents in a package file(.pkg). The .pkg file would be generated in
        the current working directory.

        Return:
            pkg_file_name: The name of the .pkg file generated on success; None on any failure.
        """
        command = "backup"
        command_output = self.exec_command(command, **kwargs)
        pkg_file_name = re.search(r'Package file (.*\.pkg)', command_output).group(1)
        return os.path.abspath(pkg_file_name)

    def idle_check(self, parse=False, **kwargs):
        """
        Parse: True: will parse the output and return True or False
               False: will return the command output
        """
        # DCSG01760289
        if self.tool_version >= 225:
            command = "idlecheck"
        else:
            command = "idle_check"
        command_output = self.exec_command(command, **kwargs)
        if parse:
            if "Idle_check PASSED" in command_output:
                return True
            return False
        return command_output

    def device_health_check(self, parse=False, **kwargs):
        # DCSG01760289
        if self.tool_version >= 225:
            cmd = 'show -health'
        else:
            cmd = 'device_health_check'
        output = self.exec_command(cmd, **kwargs)
        op = re.findall(r"(.*)\s+:\s+(.*)", output)
        dev_info = {}
        for k, v in op:
            dev_info[k.strip().replace(" ", "_")] = v
        if parse:
            if dev_info.get("Overall_Device_Health") in ["Healthy", "Good"] or dev_info.get("Device_Health") == "Good":
                return True
            return False
        return dev_info

    def set_option(self, option_string, option_value, device=False, function_value="0", validation=False, **kwargs):
        """
        This function will return output of setoption command
        option_string = name of NVM option
        option_value = value for the NVM option
        device = option is Device specific or funciotn specific
        function_value = if option supports function's then function number
        validation: False will return the command output, True will return True or False
        """
        # DCSG01760289
        if self.tool_version >= 225:
            return self.nvm_setoption(option_string, option_value, device=device, function_value=function_value,
                                      validation=validation)
        else:
            if device:
                cmd = f'setoption -name {option_string} -value {option_value}'
            else:
                cmd = f'setoption -name {option_string} -scope {function_value} -value {option_value}'

            output = self.exec_command(cmd, **kwargs)

            if validation:
                if 'successfully' in output:
                    return 1
                else:
                    log.error("Setting option failed")
                    return 0
            else:
                return output

    def nvm_setoption(self, option_string, option_value, device=False, function_value="0", validation=False, **kwargs):
        """
        This function will return output of setoption command
        option_string = name of NVM option
        option_value = value for the NVM option
        device = option is Device specific or funciotn specific
        function_value = if option supports function's then function number
        validation: False will return the command output, True will return True or False
        """
        if device:
            cmd = f'nvm -setoption {option_string} -value {option_value}'
        else:
            cmd = f'nvm -setoption {option_string} -scope {function_value} -value {option_value}'

        output = self.exec_command(cmd, **kwargs)

        if validation:
            if 'successfully' in output:
                return 1
            else:
                log.error("Setting option failed")
                return 0
        else:
            return output

    def nvm_getoption(self, option_string, device=False, function_value="0", **kwargs):
        """
        This function will return output of getoption command
        option_string = name of NVM option
        option value = value for the NVM option
        device = option is Device specific or funciotn specific
        function value = if option supports function's then function number
        """
        if device:
            cmd = f'nvm -getoption {option_string}'
        else:
            cmd = f'nvm -getoption {option_string} -scope {function_value}'

        output = self.exec_command(cmd, **kwargs)
        nvm_option_re = re.search("(.*)\s+=\s+(.*)", output)
        if nvm_option_re:
            return nvm_option_re.group(2)
        else:
            raise exception.TestCaseFailure("Failed to get {} option value".format(option_string))

    def get_option(self, option_string, device=False, function_value="0", **kwargs):
        """
        This function will return output of getoption command
        option_string = name of NVM option
        option value = value for the NVM option
        device = option is Device specific or funciotn specific
        function value = if option supports function's then function number
        """
        # DCSG01760289
        if self.tool_version >= 225:
            return self.nvm_getoption(option_string, device=device, function_value=function_value)
        else:
            if device:
                cmd = f'getoption -name {option_string}'
            else:
                cmd = f'getoption -name {option_string} -scope {function_value}'

            output = self.exec_command(cmd, **kwargs)
            nvm_option_re = re.search("(.*)\s+=\s+(.*)", output)
            if nvm_option_re:
                return nvm_option_re.group(2)
            else:
                raise exception.TestCaseFailure("Failed to get {} option value".format(option_string))

    def nvm_getoption_help(self, option_string, **kwargs):
        cmd = f'nvm -getoption {option_string} -h'
        output = self.exec_command(cmd, **kwargs)
        return output

    def option_help(self, option_string, **kwargs):
        # DCSG01760289
        if self.tool_version >= 225:
            return self.nvm_getoption_help(option_string)
        else:
            cmd = f'getoption -name {option_string} -h'
            output = self.exec_command(cmd, **kwargs)
            return output

    def dscdump(self, diaglevel=False, lane=0, **kwargs):
        """

        Args:
            diaglevel: diag level
            lane: interface index
            **kwargs:

        Returns: returns dscdump filename

        """
        cmd = f'dscdump -lane {lane} -diaglevel {diaglevel}' if diaglevel is not False else f'dscdump -lane {lane}'
        command_output = self.exec_command(cmd, **kwargs)
        core_file_name = re.search(r'Generated DscDump file (.*\.dmp)', command_output, re.I).group(1)
        core_file_name = os.path.abspath(core_file_name)
        return core_file_name

    def mtu(self, iface_index=0, **kwargs):
        """

        Args:
            iface_index: interface index
            **kwargs:

        Returns: returns mtu of the interface provided interface

        """
        cmd = f'mtu -pf {iface_index} -show'
        command_output = self.exec_command(cmd, **kwargs)
        op = re.search(r"MTU\s+:\s+(.*)", command_output)
        return op.group(1)

    def txfir(self, lane=0, get_or_set="get", modtype="PAM4", values="", **kwargs):
        """

        Args:
            lane: interface index
            get_or_set: if tx_fir to be displayed then get, if it has to be set then set
            modtype: PAM4 or
            values: values to be set
            **kwargs:

        Returns: returns the txfir show or set output

        """
        cmd = f'txfir -{get_or_set} -modtype {modtype} -lane {lane} {values or ""}'
        output = self.exec_command(cmd, **kwargs)
        op = re.findall(r"(.*)\s+:\s+(.*)", output)
        txfir_info = {}
        for k, v in op:
            txfir_info[k.strip().replace(" ", "_")] = v
        return txfir_info

    def vf(self, id=0, vf_trust=None, **kwargs):
        """
        Get trust status or Enable or Disable the trust.
        Args:
            id: vf id on which get/set thr trust
            vf_trust: enable/disable. Will set trust to Enable or Disable
            **kwargs:

        Returns: trust_status or None
        """
        cmd = f"vf -id {id} -trust {vf_trust or ''}"
        output = self.exec_command(cmd, **kwargs)
        if not vf_trust:
            status = re.search("Trusted VF :\s+(.*)", output)
            trust_status = status.group(1)
            return trust_status
        else:
            if "Command Executed Successfully" in output:
                log.info(f"vf trust is set to {vf_trust}")
            else:
                raise exception.TestCaseFailure(f"Setting vf trust to {vf_trust} failed")

    def devid(self, parse=True):
        """
        Return: Devid tuple
        """
        cmd = f'devid'
        output = self.exec_command(cmd)
        if parse:
            vendor_id = re.search('PCI Vendor ID\s*:\s*0x(\w+)', output).group(1)
            device_id = re.search('PCI Device ID\s*:\s*0x(\w+)', output).group(1)
            sub_vendor_id = re.search('PCI Subsys Vendor ID\s*:\s*0x(\w+)', output).group(1)
            sub_device_id = re.search('PCI Subsys Device ID\s*:\s*0x(\w+)', output).group(1)

            if vendor_id and device_id and sub_vendor_id and sub_device_id:
                return vendor_id, device_id, sub_vendor_id, sub_device_id
            else:
                return None
        return output

    def reset(self, reset=None, roce_loaded=False, **kwargs):
        """Reset the given device. Available only on Linux for rest raises Error

        Args:
            reset: if no switches(-cfa, -ap) passed only reset command will be executed
            roce_loaded: If set to True then expected output is "Device reset issued successfully"
        Return:
            On success return True else raises Exception

        """
        cmd = f'reset {reset or ""}'
        output = self.exec_command(cmd, **kwargs)
        log.info(output)

        if (roce_loaded is False and "device hot reset completed successfully" not in output.lower()) or \
                (roce_loaded is True and "device reset issued successfully" not in output.lower()):
            raise exception.NoActionPerformed(command=cmd, desc='Device reset is not done', output=output)

        return True

    def coredump(self, ddr=False, **kwargs):
        """
        Generate core dump file (.core). The .core file would be generated in the current
        working directory.

        Return:
            core_file_name: The name of the .core file generated on success
        """
        cmd = 'coredump -ddr' if ddr else 'coredump'
        command_output = self.exec_command(cmd, **kwargs)
        core_file_name = re.search(r'Generated CoreDump file (.*\.core)', command_output).group(1)
        core_file_name = os.path.abspath(core_file_name)
        return core_file_name

    def device_info(self, **kwargs):
        """

        Args:
            **kwargs:

        Returns: Device info dictionary

        """
        # DCSG01760289
        if self.tool_version >= 225:
            cmd = 'show'
        else:
            cmd = 'device_info'
        output = self.exec_command(cmd, **kwargs)
        op = re.findall(r"(.*)\s+:\s+(.*)", output)
        dev_info = {}
        for k, v in op:
            dev_info[k.strip().replace(" ", "_")] = v
        return dev_info

    def fwcli(self, fwcli_string, **kwargs):
        """

        Args:
            fwcli_string: provide the fwcli command to be executed

        """
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = f'fwcli "{fwcli_string}"'
        output = self.exec_command(cmd, **kwargs)
        return output

    def fw_sync(self, **kwargs):
        """
        :param kwargs:
        :return:
        """
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = 'fw_sync'
        output = self.exec_command(cmd, **kwargs)
        return True if 'FW images are already synchronized' in output else False

    def loopback(self, mode=None, **kwargs):
        """

        Args:
            mode: provide the loop abck command to be executed
            :return mode currently set if mode is not proveided, If mode is provided, sets to the mode
        """
        cmd = f'loopback {mode or ""}'
        output = self.exec_command(cmd, **kwargs)
        if mode is None:
            lb_mode = re.search(r"Configured LoopBack Mode\s+:\s+(.*)", output).group(1).strip()
            return lb_mode

        return output

    """
        install, 
        pkg_ver -> all kinds of versions
        msix vectors        
    """

    def pkgver(self, pkg=None, **kwargs):
        """Return a package version info

        Args:
            pkg (None, str): If None, does not pass the package argument
                otherwise pass it

        Return:
            dict: value=version, key=<name of property> Version
        """

        if pkg is None:
            output = self.show(command="-fwpackage")
        else:
            cmd = f"-fwpackage -pkg {pkg}"
            output = self.show(command=cmd)

        return output

    def install(self, pkg, force=False, recovery=False, rescue=False, fb_fw=None, online=False, yes=True, **kwargs):
        """
        Not fully developed. yet to develop and test

        Args:
            pkg (str): pkg file
            force (bool): force installation if True
            live (bool): live installation if True
        Return:
            output: command output
        """

        log.info('Installing %s' % pkg)
        if force is True:
            kwargs['-force'] = None
        if online is True:
            kwargs['-online'] = None
        if recovery is True:
            kwargs['-recovery'] = None
        if rescue is True:
            kwargs['-rescue'] = None
        if fb_fw:
            kwargs['-f'] = fb_fw
        if yes is True:
            kwargs['-y'] = None
        cmd = f'install {pkg}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def verify(self, pkg=None, **kwargs):
        """Verify package

        Args:
            pkg (None, str): If None, run without a package name otherwise
                pass the package name as an argument
        """
        log.info('Verify NVM contents')
        cmd = f'verify {pkg or ""}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def nvm_list(self, **kwargs):
        kwargs['shell'] = kwargs.get('shell', True)
        log.info('Displaying NVM components')
        cmd = f'nvm-list'
        output = self.exec_command(cmd, **kwargs)
        return output

    def list_eth(self, **kwargs):
        kwargs['shell'] = kwargs.get('shell', True)
        log.info('Displaying eth list ')
        cmd = f'list-eth'
        output = self.exec_command(cmd, **kwargs)
        return output

    def scan(self, all=False, string='', **kwargs):
        """

        Args:
            all:
            string: commands like '-brcm', '-vid 14e4', '-did xxxx'  etc
            **kwargs:

        Returns:

        """
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = f'scan -all' if all else f"scan {string or ''}"
        output = self.exec_command(cmd, **kwargs)
        return output

    def version(self, **kwargs):
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = f'version'
        output = self.exec_command(cmd, **kwargs)
        match = re.search(r'NIC CLI\s+v(.*)\s+-\s+Broadcom Inc', output)
        version = match.group(1) if match else None
        return version

    def pcidev(self, scan=True, **kwargs):
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = f'pcidev -scan'
        output = self.exec_command(cmd, **kwargs)
        match = re.search(r'Scrutiny NIC CLI\s+v(.*)\s+-\s+Broadcom Inc', output)
        version = match.group(1) if match else None
        return version

    def reset_ap(self, validate=False, **kwargs):
        """Resets the application processor. Available only on Linux for rest raises Error

        Args:  None

        Return:
            On success return True else False

        """
        # DCSG01760289
        if self.tool_version >= 225:
            cmd = 'reset -ap'
        else:
            cmd = 'reset_ap'
        output = self.exec_command(cmd, **kwargs)
        if validate:
            if 'Command Executed Successfully' in output:
                return True
            return False
        return output

    def saveoptions(self, output_file=None, **kwargs):
        # DCSG01760289
        if self.tool_version >= 225:
            return self.nvm_saveoptions(output_file=output_file)
        else:
            kwargs['shell'] = kwargs.get('shell', True)
            fd, temp_file = tempfile.mkstemp(suffix='.sh')
            os.close(fd)
            output_file = output_file or temp_file
            cmd = f'saveoptions -file {output_file}'
            output = self.exec_command(cmd, **kwargs)
            log.info(output)
            nvm_opt_file_name = os.path.abspath(output_file)
            return nvm_opt_file_name

    def nvm_saveoptions(self, output_file=None, **kwargs):
        kwargs['shell'] = kwargs.get('shell', True)
        fd, temp_file = tempfile.mkstemp(suffix='.sh')
        os.close(fd)
        output_file = output_file or temp_file
        cmd = f'nvm -saveoptions -file {output_file}'
        output = self.exec_command(cmd, **kwargs)
        log.info(output)
        nvm_opt_file_name = os.path.abspath(output_file)
        return nvm_opt_file_name

    def listdev(self, parse=True, **kwargs):
        cmd = 'listdev'
        output = self.exec_command(cmd, **kwargs)
        log.info('output is : %s' % output)

        if parse:
            dev_id = None
            dev_desc = None
            dev_info = {}
            for line in output.split(self.newline):
                if '#' in line:
                    dev_id = re.search(r'(\d+)(.*)#(\d+)', line.strip('\n')).group(1)
                    dev_desc = re.search(r'(\d+)(.*)', line.strip('\n')).group(1, 2)  # ret_type: List()
                    dev_desc = ''.join(dev_desc)
                    dev_info.setdefault(dev_id, {})['desc'] = dev_desc.strip()
                if dev_id and (':' in line):
                    k, v = line.split(':', 1)
                    k = k.strip()
                    v = v.strip()
                    dev_info.setdefault(dev_id, {})[k] = v
            return dev_info
        return output

    def pcie_counters(self, **kwargs):
        cmd = 'pcie -counters'
        output = self.exec_command(cmd, **kwargs)
        log.info('output is: %s' % output)
        counters = {}
        for line in output.split(self.newline):
            if ':' not in line:
                continue
            k, v = line.rsplit(':', 1)
            k = k.strip()  # k = k.strip().replace(' ', '_')
            v = v.strip()
            if v != '':  # to skip version header line
                counters[k] = v
        return counters

    def device_temperature(self, **kwargs):
        # DCSG01760289
        temps = {}
        if self.tool_version >= 225:
            cmd = 'show'
            output = self.exec_command(cmd, **kwargs)
            patterns = {'Device Temperature': r'Device Temperature\s*:\s*(\d+\s*Celsius)',
                        'PHY Temperature': r'PHY Temperature\s*:\s*(\d+\s*Celsius)',
                        'Optical Module Temperature': r'Optical Module Temperature\s*:\s*(\d+\s*Celsius)'}
            for key, pattern in patterns.items():
                match = re.search(pattern, output)
                if match:
                    temps[key] = match.group(1)
        else:
            cmd = 'device_temperature'
            output = self.exec_command(cmd, **kwargs)
            for line in output.split(self.newline):
                if ':' not in line:
                    continue
                k, v = line.rsplit(':', 1)
                k = k.strip()  # k = k.strip().replace(' ', '_')
                v = v.strip()
                temps[k] = v
        return temps

    def get_backup_power_config(self, **kwargs):
        # DCSG01760289
        if self.tool_version >= 225:
            cmd = 'backuppowercfg'
        else:
            cmd = 'get_backup_power_config'
        output = self.exec_command(cmd, **kwargs)
        temps = {}
        for line in output.split(self.newline):
            if ':' not in line:
                continue
            k, v = line.rsplit(':', 1)
            k = k.strip()  # k = k.strip().replace(' ', '_')
            v = v.strip()
            temps[k] = v
        return temps

    def moduleinfo(self, **kwargs):
        cmd = 'moduleinfo'
        output = self.exec_command(cmd, **kwargs)
        mod_info = {}
        for line in output.split(self.newline):
            if ':' not in line:
                continue
            k, v = line.rsplit(':', 1)
            k = k.strip()  # k = k.strip().replace(' ', '_')
            v = v.strip()
            mod_info[k] = v
        return mod_info

    def add_tunnel_redirect(self, tunnel_type, vf_index, save=False, **kwargs):
        """
        This function will add tunnel on given VF index
        :param tunnel_type: vxlan|vxlan_ipv4|vxlan_ipv6|ipgre
        :param vf_index is VF# on which operation has to be perform
        :returns True if success else False
        """
        # DCSG01760289
        if self.tool_version >= 225:
            # tunnel redirect is deprecated, refer ER: DCSG01361957 for details
            raise NotImplementedError("tunnel redirect is deprecated, command not supported on hardware")
        else:
            save = "-save" if save else ''
            cmd = f'add_tunnel_redirect {save} {tunnel_type} vf {vf_index}'
            output = self.exec_command(cmd, **kwargs)
            return True if "Successfully" in output else False

    def del_tunnel_redirect(self, tunnel_type, vf_index, save=False, **kwargs):
        """
        This function will add tunnel on given VF index
        :param tunnel_type: vxlan|vxlan_ipv4|vxlan_ipv6|ipgre
        :param vf_index is VF# on which operation has to be perform
        :returns True if success else False
        """
        # DCSG01760289
        if self.tool_version >= 225:
            # tunnel redirect is deprecated, refer ER: DCSG01361957 for details
            raise NotImplementedError("tunnel redirect is deprecated, command not supported on hardware")
        else:
            save = "-save" if save else ''
            cmd = f'del_tunnel_redirect {save} {tunnel_type} vf {vf_index}'
            output = self.exec_command(cmd, **kwargs)
            return True if "Successfully" in output else False

    def query_tunnel_redirect(self, tunnel_type=None, **kwargs):
        """
        This function will add tunnel on given VF index
        :param tunnel_type: vxlan|vxlan_ipv4|vxlan_ipv6|ipgre
        :param vf_index is VF# on which operation has to be perform
        :returns True if success else False
        """
        # DCSG01760289
        if self.tool_version >= 225:
            # tunnel redirect is deprecated, refer ER: DCSG01361957 for details
            raise NotImplementedError("tunnel redirect is deprecated, command not supported on hardware")
        else:
            cmd = f'query_tunnel_redirect type '
            if tunnel_type:
                cmd += f'{tunnel_type} vf'
            output = self.exec_command(cmd, **kwargs)
            tun_info = {}
            vf_index = None
            for line in output.split(self.newline):
                if ':' not in line:
                    continue
                if not tunnel_type:
                    tun_type, tun_value = line.rsplit(':', 1)
                    tun_info[tun_type.strip()] = tun_value.strip()
                else:
                    vf_index = line.split(':')[-1].strip()
            if tun_info:
                return tun_info
            else:
                return vf_index

    def cfgtunnel_query_dst_port(self, **kwargs):
        cmd = f'cfgtunnel vxlan_ipv4'
        output = self.exec_command(cmd, **kwargs)
        for line in output.split(self.newline):
            if ':' not in line:
                continue
            dst_port = line.rsplit(':')[1]
            return dst_port.strip()

    def cfgtunnel_free_dst_port(self, save=False, **kwargs):
        save = '-save' if save else ""
        cmd = f'cfgtunnel {save} vxlan_ipv4 dst_port'
        output = self.exec_command(cmd, **kwargs)
        return True if "Successfully" in output else False

    def cfgtunnel_set_dst_port(self, dst_port, save=False, **kwargs):
        save = '-save' if save else ""
        cmd = f'cfgtunnel {save} vxlan_ipv4 dst_port {dst_port}'
        output = self.exec_command(cmd, **kwargs)
        return True if "Successfully" in output else False

    def cfgtunnel_query_rss_mode(self, **kwargs):
        cmd = f'cfgtunnel rss_mode'
        output = self.exec_command(cmd, **kwargs)
        for line in output.split(self.newline):
            if ':' not in line:
                continue
            rss_mode = line.rsplit(':')[1]
            return rss_mode.strip()

    def cfgtunnel_set_rss_mode(self, mode, **kwargs):
        cmd = f'cfgtunnel rss_mode {mode}'
        output = self.exec_command(cmd, **kwargs)
        return True if "Successfully" in output else False

    def vf_trust(self, vf_index, trust=None, **kwargs):
        cmd = f'vf -id {vf_index} -trust {trust or ""}'
        output = self.exec_command(cmd, **kwargs)
        if trust:
            return True if "Successfully" in output else False
        else:
            for line in output.split(self.newline):
                if ':' not in line:
                    continue
                trust_mode = line.rsplit(':')[1]
                return trust_mode.strip()

    def livepatch(self, **kwargs):
        """
        :return: output of the live patch command executed

        """
        cmd = f'livepatch'
        output = self.exec_command(cmd, **kwargs)
        return output

    def livepatch_activate(self, target_fw=None, **kwargs):
        """
        :param target_fw: accepts 'secure_fw' or 'common_fw'
        :return: output of the live patch command executed

        """
        cmd = f'livepatch activate {target_fw or ""}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def livepatch_deactivate(self, target_fw=None, **kwargs):
        """
        :param target_fw: accepts 'secure_fw' or 'common_fw'
        :return: output of the live patch command executed

        """
        cmd = f'livepatch deactivate {target_fw or ""}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def livepatch_update(self, patch_file, target_fw=None, **kwargs):
        """
        :param patch_file: patch file path
        :param target_fw: accepts 'secure_fw' or 'common_fw'
        :return: output of the live patch command executed

        """
        cmd = f'livepatch update {target_fw or ""} {patch_file}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def show(self, command=None, parse=True, all=True, **kwargs):
        if all and command is None:
            cmd = 'show -all'
        else:
            cmd = f"show {command or ''}"
        output = self.exec_command(cmd, **kwargs)
        if parse is False:
            return output
        details = {}
        for line in output.split(self.newline):
            if ':' not in line:
                continue
            k, v = line.rsplit(':', 1)
            k = k.strip()
            v = v.strip()
            details[k] = v
        return details

    def batch_mode(self, file_name, **kwargs):
        """

        Args:
            file_name: name of the file in which niccli commands are present

        Returns: output of the commands executed

        """
        cmd = f"--batch {file_name}"
        output = self.exec_command(cmd, **kwargs)
        return output

    def get_resmgmt_profile(self, allpf=False, **kwargs):
        """
            Args:
                 allpf: will use switch -all if this argument set to True else will use -pf switch

            Returns: outof the command 'resmgmt profile'

        """
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} profile"
        output = self.exec_command(cmd, **kwargs)
        profile = re.search('Profile Type : (.*)', output)
        return profile.group(1)

    def set_resmgmt_profile(self, profile, allpf=False, **kwargs):
        """
            Args:
                 allpf: will use switch -all if this argument set to True else will use -pf switch

            Returns: True if successfully executed the command 'resmgmt profile <profiletype>'

        """
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} profile {profile}"
        resmgmt_result = self.exec_command(cmd, **kwargs).strip().split('\n')
        if any("Successfully" in line for line in resmgmt_result):
            log.info('Resource management profile Set operation completed Successfully')
            return True
        else:
            log.warning('Unexpected output seen while setting the profile with resmgmt command')
            return False

    def get_resmgmt_min_bw(self, allpf=False, **kwargs):
        """
            Args:
                 allpf: will use switch -all if this argument set to True else will use -pf switch

            Returns: returns the resmgmt minimum bandwidth dictionary

        """
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} min"
        resmgmt_result = self.exec_command(cmd, **kwargs)
        min_bw = re.findall('(PF\s*\d*)\s*=\s*(\d+)', resmgmt_result)
        return dict(min_bw)

    def set_resmgmt_min_bw(self, bandwidth, allpf=False, **kwargs):
        """
            Args:
                 bandwidth: list or string. list of bandwidths to set on each interface
                 allpf: will use switch -all if this argument set to True else will use -pf switch

            Returns: returns True on setting minimum bandwidth to the interface, on failure returns False
        """

        bw = " ".join([str(i) for i in bandwidth]) if isinstance(bandwidth, list) else str(bandwidth)
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} min {bw}"
        resmgmt_result = self.exec_command(cmd, **kwargs).strip().split('\n')
        if any("Successfully" in line for line in resmgmt_result):
            log.info('Resource management min bandwidth Set operation completed Successfully')
            return True
        else:
            log.warning('Unexpected output seen while setting the min bandwidth with resmgmt command')
            return False

    def get_resmgmt_max_bw(self, allpf=False, **kwargs):
        """
                Args:
                    allpf: will use switch -all if this argument set to True else will use -pf switch

                Returns: returns the resmgmt maximum bandwidth dictionary

        """

        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} max"
        resmgmt_result = self.exec_command(cmd, **kwargs)
        max_bw = re.findall('(PF\s*\d+)\s*=\s*(\d+)', resmgmt_result)
        return dict(max_bw)

    def set_resmgmt_max_bw(self, bandwidth, allpf=False, **kwargs):
        """
            Args:
                 bandwidth: list or string. list of bandwidths to set on each interface
                 allpf: will use switch -all if this argument set to True else will use -pf switch

            Returns: returns True on setting maximum bandwidth to the interface, on failure returns False
        """
        bw = " ".join([str(i) for i in bandwidth]) if isinstance(bandwidth, list) else str(bandwidth)
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} max {bw}"
        resmgmt_result = self.exec_command(cmd, **kwargs).strip().split('\n')
        if any("Successfully" in line for line in resmgmt_result):
            log.info('Resource management max bandwidth Set operation completed Successfully')
            return True
        else:
            log.warning('Unexpected output seen while setting the max bandwidth with resmgmt command')
            return False

    def get_resmgmt_strategy(self, allpf=False, **kwargs):
        """
                Args:
                    allpf: will use switch -all if this argument set to True else will use -pf switch

                Returns: returns the resmgmt strategy dictionary

        """
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} strategy"
        resmgmt_result = self.exec_command(cmd, **kwargs)
        strategy = re.findall('(PF\s*\d+)\s*:\s*(\w+)', resmgmt_result)
        return dict(strategy)

    def set_resmgmt_strategy(self, strategy, allpf=False, **kwargs):
        """
            Args:
                 stratey: list or string. list of strategies to set on each interface
                 allpf: will use switch -all if this argument set to True else will use -pf switch

            Returns: returns True on setting strategy to the interface, on failure returns False
        """
        strategy = " ".join([str(i) for i in strategy]) if isinstance(strategy, list) else str(strategy)
        switch = '-all' if allpf else '-pf'
        cmd = f"resmgmt {switch} strategy {strategy}"
        resmgmt_result = self.exec_command(cmd, **kwargs).strip().split('\n')
        if any("Successfully" in line for line in resmgmt_result):
            log.info('Resource management min bandwidth Set operation completed Successfully')
            return True
        else:
            log.warning('Unexpected output seen while setting the min bandwidth with resmgmt command')
            return False

    def set_ets(self, iface, tsa_map, prio_map, tc_bw_map):
        """
        Set the ets with tsa, prio and bw mapping

        Verifies all queues in tsa_map are enabled first

        todo: This does not actually set ets for <iface>. It sets ets for self.index/self.mac_addr, which is not
              guaranteed to be the same as <iface>. This applies to all methods with the <iface> arg.

        Args:
            iface: the interface on which to set ETS
            tsa_map: TSA configuration details
            prio_map: Prio map setting details
            tc_bw_map: Traffic Class bandwidth limits
        """
        if not tsa_map:
            raise exception.ConfigException(
                'Must provide TSA details to configure TSA')

        output = self.get_qos(iface)
        tsa_mapping = re.search(r'TSA_MAP:\s+(.*)', output).group(1)
        new_list = len(re.findall(r'(\d+:)', tsa_mapping))
        if new_list > len(tsa_map):
            for x in range(len(tsa_map), new_list):
                tsa_map[str(x)] = 'strict'
        log.info('Configuring TSA on interface %s to %s' % (iface, tsa_map))

        if not prio_map:
            raise exception.ConfigException(
                'Must provide priority-to-tc mapping details.')

        log.info('Configuring Bandwidth per TC on interface %s to %s' % (iface, prio_map))

        if not tc_bw_map:
            raise exception.ConfigException(
                'Must provide TC Bandwidth details.')

        log.info('Configuring Bandwidth per TC on interface %s to %s' % (iface, tc_bw_map))
        tc_bw_values = []

        for key in sorted(tc_bw_map):
            tc_bw_values.append(tc_bw_map[key])

        tsa_values = []

        for key in sorted(tsa_map):
            tsa_values.append('%s:%s' % (key, tsa_map[key]))

        prio_values = []

        for key in sorted(prio_map):
            prio_values.append('%s:%s' % (key, prio_map[key]))

        # DCSG01760289
        if self.tool_version >= 227:
            cmd = f"ets -tsa {','.join(tsa_values)} -up2tc {','.join(prio_values)} -tcbw {','.join(tc_bw_values)}"
        else:
            cmd = f"set_ets tsa={','.join(tsa_values)} priority2tc={','.join(prio_values)} tcbw={','.join(tc_bw_values)}"
        self.exec_command(cmd)

    def get_qos(self, iface):
        """
        Get the get_qos data of interface.

        Args:
            iface: The interface to get qos.
        """
        log.info(f"Getting QOS information on {iface}")
        # DCSG01760289
        if self.tool_version >= 227:
            cmd = f'getqos'
        else:
            cmd = f'get_qos'
        output = self.exec_command(cmd)
        return output

    def clear_pfc_config(self, iface):
        """Clear the existing PFC configuration on the specified interface.

        Args:
            iface: The interface to clear the PFC configuration on.
        """
        log.info(f"Clearing the PFC configuration on {iface}")
        command_output = self.get_qos(iface)
        app_pattern = re.compile(r'APP#(\d+):\s*Priority:\s*(\d+)\s*Sel:\s*(\d+)\s*(?:DSCP|UDP or DCCP):\s*(\d+)')
        app_matches = app_pattern.findall(command_output)
        for app_num, priority, sel, dscp_or_udp in app_matches:
            sel = int(sel, 16) if sel.lower().startswith('0x') else int(sel)
            dscp_or_udp = int(dscp_or_udp, 16) if dscp_or_udp.lower().startswith('0x') else int(dscp_or_udp)
            priority = int(priority, 16) if priority.lower().startswith('0x') else int(priority)
            command = f"apptlv -del -app {priority},{sel},{dscp_or_udp}"
            self.exec_command(command)

    def configure_pfc_config(self, config_mode, roce_priority, roce_dscp, cnp_dscp, profile='MP12'):
        """Clear the existing PFC configuration on the specified interface.

        Args:
            config_mode:  ROCE PFC mode
            roce_priority:   RoCE Packet Priority
            roce_dscp: RoCE Packet DSCP Value
            cnp_dscp:  RoCE CNP Packet DSCP Value
            profile:  NIC current profile

        """
        roce_ether = 4791
        roce_header = 3
        dscp_header = 5
        roce_prio = int(str(roce_priority), 0)
        roce_dscp = int(str(roce_dscp), 0)
        cnp_dscp = int(str(cnp_dscp), 0)
        config_mode = int(config_mode)
        if profile == 'MP12':
            set_bw_cmd = "ets -tsa 0:ets,1:ets,2:strict -up2tc 0:0,1:0,2:0,3:1,4:0,5:0,6:0,7:2 -tcbw 50,50"
        else:
            set_bw_cmd = "ets -tsa 0:ets,1:ets,2:ets,3:ets,4:ets,5:ets,6:ets,7:ets -up2tc " \
                         "0:0,1:3,2:4,3:5,4:6,5:1,6:2,7:7 -tcbw 10,10,10,10,10,10,30,10"

        command_list = [f"apptlv -add -app {roce_prio},{roce_header},{roce_ether}",
                        f"apptlv -add -app {roce_prio},{dscp_header},{roce_dscp}",
                        f"apptlv -add -app {config_mode},{dscp_header},{cnp_dscp}", set_bw_cmd]

        for command in command_list:
            self.exec_command(command)

    def setupcc(self, iface, config_mode, roce_priority, roce_dscp, cnp_dscp, profile='MP12'):
        """
           Setup the CC on the interface.
           Args:
            iface: The interface to configure CC value.
            config_mode:  ROCE PFC mode
            roce_priority:   RoCE Packet Priority
            roce_dscp: RoCE Packet DSCP Value
            cnp_dscp:  RoCE CNP Packet DSCP Value
            profile:  NIC current profile

        """
        self.clear_pfc_config(iface)
        self.configure_pfc_config(config_mode, roce_priority, roce_dscp, cnp_dscp, profile)
        self.set_pfc(iface, int(roce_priority))

    def set_pfc(self, iface, prios):
        """
        Set the PFC value to interface.

        Args:
            iface: The interface to set PFC value.
            prios: PFC Value to set
        """
        log.info(f"Setting PFC value on {iface}")
        # DCSG01760289
        if self.tool_version >= 227:
            command = f"pfc -enable {prios}"
        else:
            command = f"set_pfc enabled={prios}"
        self.exec_command(command)

    def set_apptlv(self, iface, priority, header_type='L2', ether_type='RoCE', ether_value=None):
        header = '3' if header_type == 'L3' else '1'
        if ether_type == 'RoCE':
            ether = '4791'
            header = '3'
        elif ether_type == 'dscp':
            ether = ether_value
            header = '5'
        else:
            ether = '12896'

        log.info('Configuring APP TLV on interface %s to priority: %s, header: %s, ether: %s'
                 % (iface, priority, header, ether))

        # DCSG01760289
        if self.tool_version >= 227:
            command = f"apptlv -add -app {priority},{header},{ether}"
        else:
            command = f"set_apptlv app={priority},{header},{ether}"
        self.exec_command(command)

    def set_ratelimit(self, iface, value):
        """
        Set the TC rate limit of interface.
        Args:
            iface: The interface to set ratelimit.
        """
        log.info(f"Set Ratelimit on {iface} to value {value}")
        # DCSG01760289
        if self.tool_version >= 227:
            command = f"tcrlmt -set -r {value}"
        else:
            command = f"ratelimit {value}"
        return self.exec_command(command)

    def get_ratelimit(self, iface):
        """
        Get the TC rate limit of interface and return those values.
        Args:
            iface: The interface to get rate limit
        """
        log.info(f"Get Ratelimit on {iface}")
        output = self.get_qos(iface)
        rate_limit = re.search(r'TC Rate Limit: (.*)', output).group(1).replace('%', '').split()
        return rate_limit

    def dump_pri2cos(self, iface):
        """
        Dump priority to TC to queue mapping on the specified interface.

        Args:
            iface: the interface on which to dump pri2cos
        """
        log.info(f"Dumping pri2cos on {iface}")
        pri2cos = {}
        # DCSG01760289
        if self.tool_version >= 227:
            output = self.listmap()
            command_output = output.strip()
        else:
            command = f"dump pri2cos"
            command_output = self.exec_command(command).strip()
        command_output = re.findall(r'(\d+)\s+(\d+)\s+(\d+)', command_output)
        # Build a map of priority to TC, queue.
        for (priority, tc, queue) in command_output:
            pri2cos[priority] = (tc, queue)

        return pri2cos

    def set_map(self, iface, pri2tc_map):
        """
        Set the priority to TC mapping on the specified interface.

        Args:
            iface:
                The interface to set the priority to TC mapping on.
            pri2tc_map:
                The dictionary of priority to TC mapping.
        """
        log.info(f"Setting pri2tc_map on {iface}")
        pri2tc = ''
        for key in sorted(pri2tc_map):
            pri2tc += ',%s:%s' % (key, pri2tc_map[key])

        # DCSG01760289
        if self.tool_version >= 227:
            command = f"up2tc -p {pri2tc[1:]}"
        else:
            command = f"set_map priority2tc={pri2tc[1:]}"
        self.exec_command(command)

    def set_bufferpool(self, iface, buffer_mode, option, direc=None, permanent=False):
        """
        Args:
            iface: The interface on which to set bufferpool
            direc: rx/tx
            option: shared | independent | ecn
            iface: The interface to set buffer pool mode configuration on
            permanent: For permanent configuration
        """
        # DCSG01760289
        if self.tool_version >= 227:
            raise NotImplementedError("buffer_pool is deprecated as of now, will implement if any leads in future")
        else:
            log.info(f"Setting buffer_pool on {iface}")
            if permanent:
                command = f"{buffer_mode} {option} permanent"
            elif direc is not None:
                command = f"{buffer_mode} {direc} {option}"
            else:
                command = f"{buffer_mode} {option}"
            command_output = self.exec_command(command)
            return command_output

    def get_bufferpool(self, iface):
        """
        Args:
            iface: The interface on which to get bufferpool
        """
        # DCSG01760289
        if self.tool_version >= 227:
            raise NotImplementedError("buffer_pool is deprecated as of now, will implement if any leads in future")
        else:
            log.info(f"Getting buffer_pool on {iface}")
            command_output = self.exec_command("buffer_pool")
            return command_output

    def set_tx_ep_limit(self, iface, port_idx=0, ep=None, max_limit=None, permanent=False):
        """
        Set the endpoint  port control on the specified interface.
        Args:
            port_idx: The port index to set the p endpoint  port control on.
            ep: Endpoints list.
            max_limit:  The max limits to set on ep
            permanent: To configure EP permanently or not
        """
        log.info(f"Setting tx_endpoint_ratelimit on {iface}")
        ep_list = ep if isinstance(ep, list) else [ep or 'ep0']
        max_limit_list = max_limit if isinstance(max_limit, list) else [max_limit]
        # DCSG01760289
        if self.tool_version >= 227:
            # txeprlmt -set -p 0 -ep0_max=50 -ep2_max=50
            command = f"txeprlmt -set -p {port_idx}"
            command1 = ''
            for endpoint, limit in zip(ep_list, max_limit_list):
                command1 += ' -%s_max %s' % (endpoint, limit)

            command += command1
            if permanent:
                command += ' -persistent'
        else:
            # tx_endpoint_ratelimit port_idx=0 ep0 max=60 ep2 max=40
            command = f"tx_endpoint_ratelimit port_idx={port_idx}"
            command1 = ''
            for endpoint, limit in zip(ep_list, max_limit_list):
                command1 += ' %s max=%s' % (endpoint, limit)

            command += command1
            if permanent:
                command += ' permanent'

        self.exec_command(command)

    def set_rx_ep_limit(self, iface, ep=None, max_limit=None, permanent=False):
        """
        Set the endpoint port control on the specified interface.
        Args:
            iface: The interface on which to set rx end point limit
            ep: Endpoints list.
            max_limit:  The max limits to set on ep
            permanent: To configure EP permanently or not
               """
        log.info(f"Setting rx_endpoint_ratelimit on {iface}")
        ep_list = ep if isinstance(ep, list) else [ep or 'ep0']
        max_limit_list = max_limit if isinstance(max_limit, list) else [max_limit]
        # DCSG01760289
        if self.tool_version >= 227:
            command = f"rxeprlmt -set"
            command1 = ''
            for endpoint, limit in zip(ep_list, max_limit_list):
                command1 += ' -%s_max %s' % (endpoint, limit)
            command += command1
            if permanent:
                command += ' -persistent'
        else:
            command = f"rx_endpoint_ratelimit"
            command1 = ''
            for endpoint, limit in zip(ep_list, max_limit_list):
                command1 += ' %s max=%s' % (endpoint, limit)
            command += command1
            if permanent:
                command += ' permanent'

        self.exec_command(command)

    def get_tx_ep_limit(self, iface, port_idx=0, permanent=False):
        """
        Get the tx ep limit of interface and return those values.

        Args:
            port_idx: Interface index
            permanent: Configured limit type
        """
        log.info(f"Getting get_tx_endpoint_ratelimits on {iface} port id {port_idx}")
        # DCSG01760289
        if self.tool_version >= 227:
            # txeprlmt -get -p <port number> [-persistent]
            command = f"txeprlmt -get -p {port_idx}"
            if permanent:
                command += ' -persistent'
        else:
            command = f"get_tx_endpoint_ratelimits port_idx={port_idx}"
            if permanent:
                command += ' permanent'
        output = self.exec_command(command)
        return output

    def set_rx_port_limit(self, iface, max_limit=50, permanent=False):
        """
        Set the port control on the specified interface for rx.
        Args:
            max_limit:  The max limit to set on port
            permanent: To configure port limit permanently
        """
        log.info(f"Setting rx_port_ratelimit on {iface} to max={max_limit}")
        # DCSG01760289
        if self.tool_version >= 227:
            # rxportrlmt -set -max <value> [-persistent]
            command = f"rxportrlmt -set -max {max_limit}"
            if permanent:
                command += ' -persistent'
        else:
            # rx_port_ratelimit max=<max_val> [permanent]
            command = f"rx_port_ratelimit max={max_limit}"
            if permanent:
                command += ' permanent'
        self.exec_command(command)

    def get_rx_port_limit(self, iface, permanent=False):
        """
        Get the rx port  limit of interface and return those values.

        Args:
            iface: The interface to get rx port limit
            permanent: Configured limit type
        """
        log.info(f"Getting get_rx_ratelimits on {iface}")
        # DCSG01760289
        if self.tool_version >= 227:
            # rxrlmt -get [-persistent]
            command = "rxrlmt -get"
            if permanent:
                command += ' -persistent'
        else:
            # get_rx_ratelimits [permanent]
            command = "get_rx_ratelimits"
            if permanent:
                command += ' permanent'
        output = self.exec_command(command)
        get_value = re.findall(r':\s+(\d+|\w+)', output)
        return get_value

    def set_tx_partition_limit(self, iface, max_limit=50, permanent=False):
        """
        Set the tx partition control on the specified interface for tx.
        Args:
            iface: The interface on which to set tx partition limit
            max_limit:  The max limit to set on port
            permanent: To configure port limit permanently
               """
        # DCSG01760289
        if self.tool_version >= 227:
            self.set_txpartitionrlmt(iface, max_limit, persistent=permanent)
        log.info(f"Setting partition_tx_ratelimit on {iface} to max {max_limit}")
        command = f"partition_tx_ratelimit max={max_limit}"
        if permanent:
            command += ' permanent'
        self.exec_command(command)

    def set_txpartitionrlmt(self, iface, max_limit, persistent=False):
        """
        Set the tx partition control on the specified interface for tx.
        Args:
            iface: The interface on which to set tx partition limit
            max_limit:  The max limit to set on partition
            persistent: To configure port limit permanently
               """
        log.info(f"Setting txpartitionrlmt on {iface} to max {max_limit}")
        command = f"txpartitionrlmt -set -max {max_limit}"
        if persistent:
            command += ' -persistent'
        self.exec_command(command)

    def get_txpartitionrlmt(self, iface, persistent=False):
        """
        Set the tx partition control on the specified interface for tx.
        Args:
            iface: The interface on which to set tx partition limit
               """
        log.info(f"Getting txpartitionrlmt on {iface}")
        command = f"txpartitionrlmt -get -persistent" if persistent else f"txpartitionrlmt -get"
        output = self.exec_command(command)
        band_width = re.search("Max\s*:\s*(\d+|None)%?", output).group(1)
        return band_width

    def set_txportrlmt(self, iface, max_limit):
        """
        Set the tx port control on the specified interface for tx.
        Args:
            iface: The interface on which to set tx partition limit
            max_limit:  The max limit to set on port
        """
        log.info(f"Setting txportrlmt on {iface} to max {max_limit}")
        command = f"txportrlmt -set -max {max_limit}"

        self.exec_command(command)

    def get_txportrlmt(self, iface):
        """
        Set the tx port control on the specified interface for tx.
        Args:
            iface: The interface on which to set tx partition limit
        """
        log.info(f"Getting txportrlmt on {iface}")
        command = f"txportrlmt -get"
        output = self.exec_command(command)
        band_width = re.search("Tx Port Rate Limit\s*:\s*(\d+|Not Applicable)", output).group(1)
        return band_width

    def get_dscp2prio(self, iface):
        """
           Get the dscp2prio of interface and return those values.
           Args:
               iface: The interface on which to get dscp2prio
        """
        log.info(f"Getting dscp2prio information on {iface}")
        command = f"dscp2prio"
        output = self.exec_command(command)
        dscp2prio_dict = {k: v for k, v in re.findall(r'priority:(\d+)\s+dscp:(\d+)', output)}
        return dscp2prio_dict

    def up2tc(self, prio_map):
        """

        Args:
            prio_map: dictionary data type with priority to traffic class as key value pairs

        Returns: None

        """
        log.info("Setting Priority to Traffic class")
        prio_values = []
        for key in sorted(prio_map):
            prio_values.append('%s:%s' % (key, prio_map[key]))
        prio_map = ",".join(prio_values)
        command = f"up2tc -p {prio_map}"
        self.exec_command(command)

    def listmap(self):
        """

        Returns: output of the command listmap -pri2cos

        """
        log.info(f"Getting pri2cos table")
        command = f"listmap -pri2cos"
        output = self.exec_command(command)
        return output

    def dscp2prio(self):
        """

        Returns: output of the command dscp2prio

        """
        log.info(f"Getting dscp2prio information")
        command = f"dscp2prio"
        output = self.exec_command(command)
        return output

    def get_egressqos(self, persistent=False):
        """
        Args:
            persistent: if sets to True query the cosq configuration from the NVRAM

        Returns: return the egressqos Queues enabled

        """
        log.info(f"querying the cosq(egress) configuration from the NVRAM")
        persistent = "-persistent" if persistent else ""
        command = f"egressqos -cosq -get {persistent}"
        output = self.exec_command(command)
        return output

    def set_egressqos(self, queue_value, persistent=False):
        """
        todo: Add -mode option

        Args:
            queue_value: a bitmask indicating which CoS queues are enabled or disabled ex: 1,3,7,15,31,63,127,255
            persistent: If the persistent set True then the configuration is written to NVRAM to save the
                            configuration across reboots

        Returns: output of the set egress command status

        """
        log.info(f"Setting egress cosq configuration to 0b{queue_value:b}")
        persistent = "-persistent" if persistent else ""
        command = f"egressqos -cosq -set -state {queue_value} {persistent}"
        output = self.exec_command(command)
        return output

    def get_ingressqos(self, persistent=False):
        """
         Args:
            persistent: if sets to True query the cosq configuration from the NVRAM

        Returns:return the ingressqos Queues enabled

        """
        log.info(f"querying the cosq(ingress) configuration from the NVRAM")
        persistent = "-persistent" if persistent else ""
        command = f"ingressqos -cosq -get {persistent}"
        output = self.exec_command(command)
        return output

    def set_ingressqos(self, queue_value, persistent=False):
        """
        todo: Add -mode option

        Args:
            queue_value:  a bitmask indicating which CoS queues are enabled or disabled ex: 1,3,7,15,31,63,127,255
            persistent: If the persistent set True then the configuration is written to NVRAM to save the
                            configuration across reboots

        Returns: output of the set egress command

        """
        log.info(f"Setting ingress cosq configuration to 0b{queue_value:b}")
        persistent = "-persistent" if persistent else ""
        command = f"ingressqos -cosq -set -state {queue_value} {persistent}"
        output = self.exec_command(command)
        return output


class InteractiveNiccli(BaseNiccli):

    def __init__(self, mac_addr, niccli_path="niccli"):
        self.pexpect_spawn_obj = None
        super(InteractiveNiccli, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)

    def started_only(func, *args, **kwargs):
        @wraps(func)
        def conn_check(self, *args, **kwargs):
            if self.pexpect_spawn_obj is None:
                raise exception.HostException('Interactive session is not started yet')
            return func(self, *args, **kwargs)

        return conn_check

    def start(self):
        """
        This method will start interactive niccli session.
        After calling method, should call run_commadn method for any method execution
        Returns: None

        """
        log.info("Entering into Device interface")
        self.pexpect_spawn_obj = pexpect.spawn(self.niccli, encoding='utf-8')
        self.pexpect_spawn_obj.expect([self._niclci_prompt], timeout=60)
        # self.pexpect_repl_obj = pexpect.replwrap.REPLWrapper(self.niccli, orig_prompt=self._niclci_prompt,
        #                                                      prompt_change=None)

    def exec_command(self, cmd, **kwargs):
        kwargs.pop('shell', None)  # shell is not applicable in niccli prompt
        kwargs.pop('silent', None)  # silent is not applicable in niccli prompt
        options = []
        for k, v in kwargs.items():
            options.append(f'{k}' if v is None else f'{k} {v}')
        options = ' '.join(options)
        cmd = f'{cmd} {options}'
        output = self.run_command(cmd)
        return output

    @started_only
    def run_command(self, command, **kwargs):
        """
        Args:
            command: Command to be executed in niccli interactive prompt

        Returns: Output of the executed command in niccli prompt

        """
        log.info(f'Run command: {command}')
        self.pexpect_spawn_obj.sendline(command)
        self.pexpect_spawn_obj.expect([self._niclci_prompt], timeout=60)
        output = self.pexpect_spawn_obj.before
        log.info(f'Output:\n{output}')
        return output
        # output = self.pexpect_repl_obj.run_command(command, **kwargs)
        # return output

    def stop(self):
        """
        Closes the Pexpect object.
        Returns:None

        """
        cmd = "quit"
        self.pexpect_spawn_obj.sendline(cmd)
        self.pexpect_spawn_obj.close()
        self.pexpect_spawn_obj = None
        # output = self.run_command(cmd)
        # self.pexpect_repl_obj = None
        # return output


class Niccli(BaseNiccli):

    def __init__(self, mac_addr, niccli_path="niccli"):
        super(Niccli, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)

    def exec_command(self, cmd, shell=False, silent=False, **kwargs):
        options = []
        for k, v in kwargs.items():
            options.append(f'{k}' if v is None else f'{k} {v}')
        options = ' '.join(options)
        cmd = f'{self.niccli} {cmd} {options}'
        output = self._exe.block_run(cmd, shell=shell, silent=silent)
        return output

    def run(self, cmd=None, **kwargs):
        """Run niccli using given keyword arguments.

        key = option, value=value. If value is None, no value is passed. For
        example,

        run(view=None) will run "niccli [-i <iface_d>] view" and
        run(view='file.pkg') will run "niccli [-i <iface_d>] view file.pkg"

        Return:
            str: output of niccli

        """
        option_list = []
        if cmd is not None:
            option_list.append(cmd)

        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + ' ' + value)
        cmd = ' '.join(option_list)
        output = self.exec_command(cmd)
        return output

    def tool_help(self, cmd='help'):
        """
        Returns: will return help message of niccli tool
        """
        cmd = f'{self._prg_path} {cmd}'
        output = self._exe.block_run(cmd)
        return output

    def list(self, oneline=False, **kwargs) -> Dict[int, Dict[str, str]]:
        """Return dict of dicts for all nics found in 'niccli --list'

        Dicts will contain the following keys (same as reported in niccli):
        - BoardId
        - Rev (Empty string if not present)
        - MAC Address
        - FwVersion
        - PCIAddr
        - Type
        - Mode
        """
        if oneline is True:
            cmd = 'list'
            output = self.exec_command(cmd, **kwargs)
        else:
            cmd = '--list'
            cmd = f'{self._prg_path} {cmd}'
            output = self._exe.block_run(cmd, **kwargs)

        pattern = r'(\d+)\)\s*(\w+)\(*(\w*)\)*\s+([a-fA-F0-9:]+)\s+([\d\.]+)\s+([\d\:\.a-fA-F]+)\s+(\w+)\s+(\w+)'
        devs_dict = {}
        for dev_info in re.findall(pattern, output):
            dev_index, board_id, board_rev, mac_addr, fw_ver, pci_addr, dev_type, dev_mode = dev_info
            devs_dict[dev_index] = {'BoardId': board_id,
                                    'Rev': board_rev,
                                    'MAC Address': mac_addr,
                                    'FwVersion': fw_ver,
                                    'PCIAddr': pci_addr,
                                    'Type': dev_type,
                                    'Mode': dev_mode}

        return devs_dict

    def msixmv_show(self, pf, **kwargs):
        option = ''
        pf = str(pf) if pf == 0 else pf
        if pf:
            option = '-all' if pf == 'all' else f'-pf {pf}'
        cmd = f'msixmv -get {option}'
        output = self.exec_command(cmd, **kwargs)
        return output

    def msixmv_config(self, pf, change_rows, vf_msix_map):
        option = f'-pf {pf}'
        cmd = f'{self.niccli} msixmv -set {option}'
        log.info(f'Run command: {cmd}')
        events = [('Enter the number of row to change', str(change_rows) + self.newline)]
        for row in range(change_rows):
            vf, msix_vector = vf_msix_map[row] if row in vf_msix_map.keys() else (self.newline, self.newline)
            events.append((f'Enter Start VF Value of Row {row}', str(vf) + self.newline))
            events.append((f'Enter MSI-X Vector Value of Row {row}', str(msix_vector) + self.newline))
        output, exitcode = pexpect.run(cmd, events=events, withexitstatus=True, timeout=5, encoding='utf-8')
        if exitcode != 0:
            raise exception.ExeExitcodeException(cmd, exitcode, output)
        output = '\n'.join([line for line in output.split('\r\n') if line.strip()])
        log.info(f'Output:\n{output}')
        return output


class BaseFwNiccli(BaseNiccli):

    def __init__(self, mac_addr, niccli_path):
        super(BaseFwNiccli, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)

    def exec_command(self, cmd, **kwargs):
        raise NotImplementedError

    def run(self, cmd=None, **kwargs):
        """Run nicclif using given keyword arguments.

        key = option, value=value. If value is None, no value is passed. For
        example,

        run(view=None) will run "niccli [-i <iface_d>] view" and
        run(view='file.pkg') will run "niccli [-i <iface_d>] view file.pkg"

        Return:
            str: output of niccli

        """
        option_list = []
        if cmd is not None:
            option_list.append(cmd)

        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + ' ' + value)
        cmd = ' '.join(option_list)
        output = self.exec_command(cmd)
        return output

    def fwcli(self, fwcli_string, **kwargs):
        """

        Args:
            fwcli_string: provide the fwcli command to be executed

        """
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = f'fwcli "{fwcli_string}"'
        output = self.exec_command(cmd, **kwargs)
        return output

    def inject_error(self, error_type="crash null_ptr", **kwargs):
        """
        :param error_type: type of error
        supported values by bnxtnvm:
        i) crash null_ptr
        ii) crash fn_ptr
        :return:
        """
        kwargs['shell'] = kwargs.get('shell', True)
        cmd = f"fwcli '{error_type}'"
        output = self.fwcli(error_type, **kwargs)
        return output


class InteractiveFwNiccli(InteractiveNiccli, BaseFwNiccli):

    def __init__(self, mac_addr, niccli_path="nicclif.x86_64"):
        self.pexpect_spawn_obj = None
        super(InteractiveFwNiccli, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)


class FwNiccli(Niccli, BaseFwNiccli):
    def __init__(self, mac_addr, niccli_path="nicclif.x86_64"):
        super(FwNiccli, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)

    def fastboot(self, fastboot_image_path=None):
        """

        Args:
            fastboot_image_path: path of the fastboot image

        Returns: output of the command fastboot

        """
        cmd = f"fastboot -s -f {fastboot_image_path}" if fastboot_image_path else f"fastboot -s"
        output = self.exec_command(cmd)
        return output

    def erase_crash_dump(self):
        """
        Erase crash dump.
        Process:
        Erase the highest nvm index of CHDMP
        Then repeat until there is no more entry for CHDMP
        :return:
        """
        # Note:
        # re-run nvmdir for each erase process in order to get an updated list of nvm index
        while True:
            cmd = "nvmdir"
            output = self.exec_command(cmd)
            log.debug(output)
            idx_list = re.findall(r"(\d+)\s+CHDMP_", output)
            if idx_list:
                log.info(f"Erasing directory index {idx_list[-1]}")
                cmd = f"nvmerase -idx {idx_list[-1]}"
                output = self.exec_command(cmd)
                if 'nvm cleared' in output and 'successful' in output:
                    log.info(f"Erased nvm index {idx_list[-1]}. Output: {output}")
                else:
                    raise Exception(f"Failed nvm erase operation. cmd: ({cmd}). Output: {output}")
            else:
                log.info("CHDMP is no longer in the output of nvmdir")
                break

    def erase_nvm_component(self, nvm_item):
        """
        Erase nvm component.
        Process:
        Erase the highest nvm index of passed nvm item
        Then repeat until there is no more entry for given nvm item
        :return:
        """
        nvm_item_dict = {'OnboardCfg': 'ONBD_CFG',
                         'CrashDmpData': 'CHDMP_D'}
        if nvm_item not in list(nvm_item_dict.keys()):
            raise Exception(f"{nvm_item} is not supported as part of the current lib support."
                            f"Please update the nvm_item_dict with the same.")
        while True:
            cmd = "nvmdir"
            output = self.exec_command(cmd)
            idx_list = re.findall(rf"(\d+)\s+{nvm_item_dict[nvm_item]}", output)
            if idx_list:
                idx_list.sort(reverse=True)
                for idx in idx_list:
                    log.info(f"Erasing directory index {idx}")
                    cmd = f"nvmerase -idx {idx}"
                    output = self.exec_command(cmd)
                    if 'nvm cleared' in output and 'successful' in output:  # Output as per the 229 SIT
                        log.info(f"Erased nvm index {idx}. Output: {output}")
                    else:
                        raise Exception(f"Failed nvm erase operation. cmd: ({cmd}). Output: {output}")
            else:
                log.info(f"{nvm_item} is no longer in the output of nvmdir")
                break

    def getresource_counts(self, **kwargs):
        kwargs['shell'] = kwargs.get('shell', True)
        log.info('Getresource counts')
        cmd = f'getresourcecounts'
        output = self.exec_command(cmd, **kwargs)
        return output

    def get_primate_data(self, option_dict, **kwargs):
        """
        Args:
            option_dict : dict example : {'trace': None} {hwrm': None, 'hste': 10 }
        Returns:cmd output
        """
        kwargs['shell'] = kwargs.get('shell', True)
        log.info('Get primate Trace  ')
        prepare_args = ''
        for option, value in option_dict.items():
            prepare_args = prepare_args + '-' + option + ' '
            if value:
                prepare_args = prepare_args + f' {value} '
        log.debug(f'prepare_args is {prepare_args}')
        cmd = f'primate {prepare_args}'
        output = self.exec_command(cmd, **kwargs)
        return output


class Nicclid(FwNiccli):

    def __init__(self, mac_addr, niccli_path="nicclid.x86.64"):
        """
        Args:
            mac_addr (str): MAC address or pci-id of the interface
             nicclid_path (str): ethX name.

        """
        super(Nicclid, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)

    def truflow_resource_info(self, dir_rx_tx=None, resource_type=None, **kwargs):
        """
        Execute truflowresourceinfo -get [-dir <rx/tx>] -type <value>.
            Note : For Thor2 , only -dir is supported
                   For Thor, -type is mandatory, -dir is optional.

        :param:
            dir_rx_tx : 'rx' or 'tx' for Thor and Thor2
                The valid values are for thor
                        0 - Rx Direction.
                        1 - Tx Direction.

            resource_type : The valid range is from 0x1 to 0xFF. Only supported for Thor

        :return:
        Raw string of the output
        """
        kwargs['shell'] = kwargs.get('shell', True)
        kwargs['silent'] = kwargs.get('silent', False)
        cmd = f'truflowresourceinfo -get'
        if dir_rx_tx:
            cmd += ' -dir ' + str(dir_rx_tx)
        if resource_type:
            cmd += ' -type ' + str(hex(resource_type))
        output = self.exec_command(cmd, **kwargs)
        return output


class NicclidInteractive(InteractiveNiccli):

    def __init__(self, mac_addr, niccli_path="nicclid.x86.64"):
        self.pexpect_spawn_obj = None
        super(NicclidInteractive, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)


class BaseNiccliLom():
    """
    Base class for NICCCLI LOM commands
    """

    def exec_command(self, cmd, **kwargs):
        raise NotImplementedError

    def get_sotp(self):
        """
        This API is used to Query SOTP configuration available in NICCLILOM tool
        :return: returns output of command
        """

        log.info("Querying existing SOTP configuration")
        command = "configuresotp -get"
        return self.exec_command(command)


class NiccliLom(Niccli, BaseNiccliLom):
    """
    Class for NICCLI LOM one line mode
    """

    def __init__(self, mac_addr, niccli_path='nicclilom.x86.64'):
        super(NiccliLom, self).__init__(mac_addr=mac_addr, niccli_path=niccli_path)

    def configure_sotp(self):
        """
        This API is used to configure SOTP configuration i.e.
        promoting card to SOTP which is available only in NICCLILOM tool
        :return: str
        """
        log.info("Setting SOTP configuration")
        command = self.niccli + " configuresotp"
        pexpect_spawn_obj = pexpect.spawn(command, encoding='utf-8')
        pexpect_spawn_obj.expect(['    - Confirm there are no active driver instances are loaded \? \(Yes\/No\) :'],
                                 timeout=5)
        pexpect_spawn_obj.sendline('Yes')
        pexpect_spawn_obj.expect(['Firmware ping succeeded.\r\n\r\n\r\n'], timeout=15)
        output = pexpect_spawn_obj.before
        pexpect_spawn_obj.close()
        return output
