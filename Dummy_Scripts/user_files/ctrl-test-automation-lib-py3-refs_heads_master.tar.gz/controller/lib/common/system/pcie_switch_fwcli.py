"""
:mod:`pcie switch fwcli` -- Scrutiny NIC CLI
===========================================

.. module:: controller.lib.common.system.pcie_switch_fwcli
.. moduleauthors:: Sekhar <@broadcom.com>

This module is an uart interface for pcie switch

Make Sure the UART connection is done to the host before using this module
Uasage:

Atlas fwcli interfacae,
    >>> atlas_fwcli = AtlasFwcli(com_port='COM4', baud_rate=115200, timeout=10)
Now you can call the fwcli commands  with proper arguments
Some examples as below
For coredump generation
    >>> atlas_fwcli.coredump()
For errorcounter
    >>> atlas_fwcli.errcounters(display_reset="display", port=16)
    >>> atlas_fwcli.errcounters(display_reset="reset", port=16)
    >>> atlas_fwcli.errcounters(display_reset="display", serdes=True)
    >>> atlas_fwcli.errcounters(display_reset="display", ram=True)
For inject trace markers
    >>> atlas_fwcli.trace(number='0x80')
For getting pcie host view
    >>> atlas_fwcli.pciehostview()

To establish a connection in test script
    >>> host_fwcli = host.import_module('controller.lib.common.system.pcie_switch_fwcli')
    >>> atlas_fwcli = host_fwcli.AtlasFwcli(com_port='COM4', baud_rate=115200, timeout=10)
and you can call the methods as shown in the above.
"""
from controller.lib.core import enhanced_serial
from controller.lib.core import exception
from controller.lib.core import log_handler

from typing import Literal, Optional
import re

log = log_handler.get_module_logger(__name__)


class DataHandler:
    def __init__(self):
        pass

    def generate_hostview_dict(self, raw_output):
        """Return dict of parsed output of pciehostview

        Example raw output:
        ================================================================================
         DS   Dev  Ven   Glbl                      Host   Host   Device
        Port  ID   ID    BDF        MPS      MRR   Port   BDF    State
        ================================================================================
          0    --   --    --        ---       --    80    ---    --
         16    --   --    --        ---       --    80    ---    --
         20    --   --    --        ---       --    80    ---    --
         24    --   --    --        ---       --    80    ---    --
         26    --   --    --        ---       --    80    ---    --
         32    --   --    --        ---       --    80    ---    --
         48   1760 14E4 19:00.0  512B/ 512B 4096B   80  90:00.0  Working
              1760 14E4 19:00.1  512B/ 512B 4096B   80  90:00.1  Working
         64    --   --    --        ---       --    80    ---    --
         96    --   --    --        ---       --    80    ---    --
        112    --   --    --        ---       --    80    ---    --
        128    --   --    --        ---       --    80    ---    --
        132    --   --    --        ---       --    80    ---    --
        136    --   --    --        ---       --    80    ---    --
        140    --   --    --        ---       --    80    ---    --
        """
        return_dict = {}
        port_pattern = re.compile(r'^\s{0,2}(\d+)(.*\n(?:^(?!\s{0,2}\d+).*?\n)*)', re.MULTILINE)
        entry_pattern = re.compile(r'^\s+'
                                   r'(\d+)\s+'              # Dev ID
                                   r'(\w+)\s+'              # Ven ID
                                   r'([0-9a-fA-F:\.]+)\s+'  # Glbl BDF
                                   r'(\w+/ \w+)\s+'         # MPS
                                   r'(\w+)\s+'              # MRR
                                   r'(\d+)\s+'              # Host Port
                                   r'([0-9a-fA-F:\.]+)\s+'  # Host BDF
                                   r'(\w+)', re.MULTILINE)  # Device State
        for ds_port, port_entries in port_pattern.findall(raw_output):
            return_dict[ds_port] = {}
            for dev_id, ven_id, glbl_bdf, mps, mrr, host_port, host_bdf, dev_state in entry_pattern.findall(port_entries):
                return_dict[ds_port][host_bdf] = {'DS Port': ds_port,
                                                  'Dev ID': dev_id,
                                                  'Ven ID': ven_id,
                                                  'Glbl BDF': glbl_bdf,
                                                  'MPS': mps,
                                                  'MRR': mrr,
                                                  'Host Port': host_port,
                                                  'Host BDF': host_bdf,
                                                  'Device State': dev_state}
        return_dict['raw_output'] = raw_output
        return return_dict


class AtlasBaseFwcli:
    def __init__(self):
        pass

    def cli_exec_command(self, cmd, **kwargs):
        raise NotImplementedError

    def cleartrace(self, **kwargs):
        """Clear the trace buffer"""
        cmd = 'cleartrace'
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def coredump(self, generate=True, **kwargs):
        """
            Generates a core dump based on the specified parameters.

            Args:
            generate (bool): if set To True, Coredump will be generated. if False Coredump will be printed to console
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.
            Returns:
            str: The result of the core dump operation or the exception message if suppress_except is True and an exception occurs.

            Example:
            >>> result = self.coredump()
            """
        cmd = "coredump generate" if generate else "coredump"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def coredumponerror(self, dsiplay_reset = "", port: int = "", **kwargs):
        """

        Args:
            dsiplay_reset: display or reset
            port: port
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.

        Returns:
            str: output of the command

        """
        cmd = f"coredumponerror {dsiplay_reset} port {port}" if dsiplay_reset else "coredumponerror"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def coredumponerror_set_error(self, errorType, port="", **kwargs):
        """
        ' set' subcommand sets the error type to coredump for specified port
                                   errorType 1 = Correctable , 2 = Non-Fatal and 3=Fatal errors
                                   and if not port is specified, it sets the error for all the ports
        Args:
            errorType: 1 | 2 | 3
            port: Port not specified then on all ports applied
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.

        Returns:

        """
        cmd = f"coredumponerror set error {errorType} {port}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def buffsize(self, BufferID_hex: str, **kwargs):
        """

        Args:
            BufferID_hex:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.

        Returns:

        """
        cmd = f"buffsize {BufferID_hex}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def date(self, new_date=None, **kwargs):
        """

        Args:
            new_date: YYYYMMDDHHMMSS format
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.

        Returns:

        """
        cmd = f"date set {new_date}" if new_date else "date"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def displaygb(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.

        Returns:

        """
        cmd = "displaygb"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def displaytraps(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not be raised.
                                              Instead, the exception will be converted to a string and returned. Default is False.

        Returns:

        """
        cmd = "displaytraps"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def eccinfo(self, display_type, **kwargs):
        """

        Args:
            display_type: "sec" | "geterrors" | "clear"
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"eccinfo {display_type}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def flashtblinfo(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = "flashtblinfo"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def history(self, **kwargs):
        """

        Args:
           silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = "history"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def hostdiagbufsize(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = "hostdiagbufsize"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def errcounters(self, display_reset, port=None, serdes=False, ram=False, **kwargs):
        """

        Args:
            display_reset: display or reset
            port: port number on which display or reset to be executed
            serdes: If This set to True display or reset of serdes will be return. Make sure port should be None
            ram: If This set to True, display or reset of Ram will be return. Make sure port, serdes should be None
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.


        Returns: output of the command

        Ex: display port 16
        reset port 16
        display serdes
        reset serdes
        display ram
        """
        if port:
            cmd = f"{display_reset} port {port}"
        elif serdes:
            cmd = f"{display_reset} serdes"
        elif ram:
            cmd = f"{display_reset} ram"
        else:
            raise exception.TestCaseFailure("Provide either to display the port details or serdes or ram")
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def fan_get(self, type, Id, **kwargs):
        """
        - Valid <ID> values are 0 - 1 for duty|rate|polarity
      - Valid <ID> values are 0 - 3 for rpm|mult|envppc
      - Valid <rate> values are 1 - 254 for set operation
      - Valid <envppc> values are 1 - 3 for set operation
      - Valid <mult> values are 0 - 3(raw/1 pulse/2 pulses/3 pulses) for set operation

        Args:
            type: duty|rate|polarity|mult|envppc
            Id: Refer above
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"fan get {type} {Id}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def fan_set(self, type, value, **kwargs):
        """
      - Valid <ID> values are 0 - 1 for duty|rate|polarity
      - Valid <ID> values are 0 - 3 for rpm|mult|envppc
      - Valid <rate> values are 1 - 254 for set operation
      - Valid <envppc> values are 1 - 3 for set operation
      - Valid <mult> values are 0 - 3(raw/1 pulse/2 pulses/3 pulses) for set operation

        Args:
            type: duty|rate|polarity|mult|envppc
            value: Refer above usage
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"fan set {type} {value}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def fan_toggle(self, Id, **kwargs):
        """
      - Valid <ID> values are 0 - 1 for duty|rate|polarity
      - Valid <ID> values are 0 - 3 for rpm|mult|envppc
      - Valid <rate> values are 1 - 254 for set operation
      - Valid <envppc> values are 1 - 3 for set operation
      - Valid <mult> values are 0 - 3(raw/1 pulse/2 pulses/3 pulses) for set operation

        Args:
            Id:  Refer above
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"fan toggle polarity {Id}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def fdl(self, BufferID_hex, Offset_hex, Erase, **kwargs):
        """

        Args:
            BufferID_hex: BufferID in Hex
            Offset_hex: Offset in hex
            Erase: Y or N
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"fdl {BufferID_hex} {Offset_hex} {Erase}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def ful(self, BufferID_hex, Offset_hex, Size: int = "", **kwargs):
        """

        Args:
            BufferID_hex: BufferID in Hex
            Offset_hex: Offset in hex
            Size: int
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"ful {BufferID_hex} {Offset_hex} {Size}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def gpiopin_get(self, gpio_pin: int = "", **kwargs):
        """

        Args:
            GPIO: gpio pin number,  00 to 63
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.


        Returns:

        """
        cmd = f"gpiopin get {gpio_pin}" if gpio_pin else "gpiopin"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def gpio_set(self, gpio_type, gpio_pin: int, value: int, **kwargs):
        """

        Args:
            gpio_type: mux|portmap|drive|term|pull
            gpio_pin: int, gpio pin number 00 to 63
            value: int
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"gpiopin set {gpio_type} {gpio_pin} {value}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def hpfail(self, clear=False, **kwargs):
        """

        Args:
            clear: Clear All Hot Plug Failure Entries if set to True
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = "hpfail clear" if clear else "hpfail"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def IALr(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"IALr {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def IALp(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"IALp {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def IALn(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"IALn {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def IALi(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"IALi {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def IALc(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"IALc {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def IALa(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"IALa {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def iicr(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"iicr {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def iicw(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"iicw {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def iicwr(self, param, **kwargs):
        """

        Args:
            param:  Used by PTrace Device Interpreter Library
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = f"iicwr {param}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def isrstat(self, reset=False, **kwargs):
        """

        Args:
            reset: if set to true then isrstat reset will get executed
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:

        """
        cmd = "isrstat reset" if reset else "isrstat"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def log(self, string, **kwargs):
        """

        Args:
            string: string to be logged
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"log {string}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def memstat(self, Handle_list: list = [], RefreshInterval: int ="", **kwargs):
        """

        Args:
            Handle_list: list of handles
            RefreshInterval: refresh interval in int
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        handles = " ".join(Handle_list)
        cmd = "memstat"
        if Handle_list:
            cmd = f"{cmd} {handles}"
        if RefreshInterval:
            f"{cmd} {handles} i={RefreshInterval}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def pciefabricview(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.


        Returns: output of the command pciehostview

        """
        cmd = "pciehostview"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def pciehostview(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.


        Returns: output of the command pciehostview

        """
        cmd = "pciehostview"
        op = self.cli_exec_command(cmd, **kwargs)
        return DataHandler().generate_hostview_dict(op)

    def pcieperf(self, iteration_count: int ="", port_masks_hex: list = [], time_counter: int = "", raw=False, **kwargs):
        """

        Args:
            iteration_count: Iterations: How many times to loop.
                                  0=Until q/Q entered. Max=255
            port_masks:  [<PortMask4(H)> <PortMask3(H)> <PortMask2(H)> <PortMask1(H)> <PortMask0(H)>]. if specified then command will be
            pcieperf it <iteration_count> pm [<PortMask4(H)> <PortMask3(H)> <PortMask2(H)> <PortMask1(H)> <PortMask0(H)>]
            time_counter: Time counters measured in ms. Default 1000
            raw: Displays counters instead of statistics. NOTE: Under heavy load counters wrap in ~2 sec
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"pcieperf it {iteration_count}"
        if port_masks_hex:
            port_masks = " ".join(port_masks_hex)
            cmd = cmd + f" pm {port_masks}"
        if time_counter:
            cmd = cmd + f" ms {time_counter}"
        if raw:
            cmd = cmd + " raw"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def pciemsg(self, domain: int, msgType: int, msgTypeSpec: int, payloadLengthDw: int, payload: int = "", **kwargs):
        """
        If the message is an Echo API command and no payload
        is specified then a pattern payload will be generated.

        Args:
            domain: int, domain
            msgType: int, msgType
            msgTypeSpec: int, msgType
            payloadLengthDw: int, payloadLengthDw
            payload: int, payload
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"pciemsg {domain} {msgType} {msgTypeSpec} {payloadLengthDw} {payload}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def pcieportprop(self, port=None, ds_host_fab="", **kwargs):
        """
      - If no arguments are specified all properties
        of all downstream and host ports are displayed
      - With port option display properties for portnum
        specified
      - With 'ds', display all the downstream ports
        properties
      - With 'host', display all the host ports properties
      - With 'fab', display all the fabric ports properties


        Args:
            port: if port is set then the command pcieportprop port <port num> will executed
            ds_host_fab:  ds | host | fab
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command

        """
        if port:
            cmd = f"pcieportprop port {port}"
        elif ds_host_fab:
            cmd = f"pcieportprop {ds_host_fab}"
        else:
            cmd = "pcieportprop"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def pcieswinfo(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.


        Returns: output of the command pciehostview

        """
        cmd = "pcieswinfo"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def rdcfg(self, PageId_hex, RegionType_hex="", **kwargs):
        """

        Args:
            PageId_hex: page id in hex
            RegionType_hex: RegionType: 0x40 = ANY DEFAULT; 0x30 = UNIT DATA; 0x20 = CONFIG; 0x10 = MFG; 0x00 = ANY
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"rdcfg {PageId_hex} {RegionType_hex}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def serdesinfo(self, list_of_ports: list = "", **kwargs):
        """

        Args:
            list_of_ports: list of ports
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        ports = " ".join(list_of_ports)
        cmd = f"serdesinfo {ports}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def sgpioinfo(self, led_sgpio, gpio_pin="", **kwargs):
        """

        Args:
            led_sgpio: lwd | sgpio
            gpio_pin: gpio pin, 0,1,2,3
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = "sgpioinfo led" if led_sgpio == "led" else f"sgpioinfo sgpio {gpio_pin}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def sgxinfo(self, istwi_sgpio, index: int ="", SGPIONum: int = "", **kwargs):
        """

        Args:
            istwi_sgpio: istwi | sgpio
            index: int, index
            SGPIONum: gpio num
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"showlogs {istwi_sgpio} {index} {SGPIONum}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showdbgportinfo(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = "showdbgportinfo"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showdluttbl(self, stn_number: int = "", **kwargs):
        """

        Args:
            stn_number: station number
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"showdluttbl {stn_number}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showlogs(self, log_type = "", **kwargs):
        """

        Args:
            log_type: "hex", "detail", "default"
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"showlogs {log_type}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showmfg(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = "showmfg"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showsecinfo(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = "showsecinfo"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showslotstatus(self, SlotGroup: int, Slot: int, **kwargs):
        """

        Args:
            SlotGroup: slot group number
            Slot: slot number
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"showslotstatus {SlotGroup} {Slot}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showspdmsecinfo(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = "showspdmsecinfo"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def showtrace(self, head_or_tail: Literal['head', 'tail'] = None, number: int = None, **kwargs):
        """

        Args:
            head_or_tail: head | tail
            number: Maximum number of entries to print if head_or_tail is specified
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed
        """
        cmd = f"showtrace {head_or_tail} {number}" if head_or_tail else "showtrace"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def thread(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:  output of the command executed

        """
        cmd = "thread"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def trace(self, number, **kwargs):
        """

        Args:
            number: Trace Number to be included in the Trace
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.


        Returns:  output of the command executed

        """
        cmd = f"trace {number}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def tracecap(self, control="", **kwargs):
        """

        Args:
            control: wrap|nowrap|pause|resume
                     - wrap will configure circular trace buffer
                     - nowrap causes tracing to stop when buffer full
                     - pause stops tracing
                     - resume starts tracing again unless buffer full
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns:output of the command

        Ex:
        Trace Capture State : Running
        Trace Capture Mode  : NoWrap

        """
        cmd = f"tracecap {control}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def tracemask(self, subsystem=None, mask="0xFFFFFFFF", persists=False, **kwargs):
        """
        When subsystem argument sent, mask is mandatory

        Args:
            subsystem: hali | fwcore | ses | pmg | bpl | oem | oob |spi | sec | smm
            mask: string  mask in hexadecimal
            persists: Set True if the mask has to retain across reboots

        Returns: output of the command

        Possible sample commands
        tracemask
        tracemask hali 0xFFFFFF
        tracemask hali 0xFFFFFF y

        Sample output: Updated 'fwcore' trace mask (00000010h -> FFFFFFFFh) Persist?:N

        """
        control = ""
        if subsystem:
            control = f"{subsystem} {mask} y" if persists else f"{subsystem} {mask}"
        cmd = f"tracemask {control}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def tracesev(self, debug_level: int = None, **kwargs):
        """

        Args:
            debug_level: debug level
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"tracesev {debug_level}" if debug_level else "tracesev"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def tracetimestamp(self, state = None, **kwargs):
        """

        Args:
            state: on or off
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"tracetimestamp {state}" if state else "tracetimestamp"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vtmon_sensorDisplay(self, **kwargs):
        """

        Args:
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"vtmon sensorDisplay"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vtmon_read(self, hex_value, **kwargs):
        """

        Args:
            hex_value: read  <Hex value of APB register address of VTMON>
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"vtmon read {hex_value}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vtmon_alarmConfig(self, config, hex_value, **kwargs):
        """

        Args:
            config:  0 | 1
            hex_value: alarmConfig <0: High Trip; 1: Low Trip> <Hex value of 11 bits Trip point>
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"vtmon alarmConfig {config} {hex_value}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vtmon_irqConfig(self, config, hex_value, **kwargs):
        """

        Args:
            config:  0 | 1
            hex_value: alarmConfig <0: High Trip; 1: Low Trip> <Hex value of 11 bits Trip point>
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"vtmon irqConfig {config} {hex_value}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vtmon_alarmIrqSel(self, hex_value, **kwargs):
        """

        Args:
            hex_value: alarmIrqSel <Hex value of bitmask to select Voltage/Temperature sensor>
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"vtmon alarmIrqSel {hex_value}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vpdshow(self, no_of_bytes_to_read, offset, **kwargs):
        """

        Args:
            no_of_bytes_to_read: NumBytesToRead in Decimal
            offset: offset in Hex
            silent (bool, optional): If True, the command output will not be logged. Default is False.
            suppress_except (bool, optional): If True, any exception raised during the execution of the command will not
                                              be raised. Instead, the exception will be converted to a string and
                                              returned. Default is False.

        Returns: output of the command executed

        """
        cmd = f"vpdshow {no_of_bytes_to_read} {offset}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op

    def vpdwrite(self, no_of_bytes_to_read, offset, pattern="", **kwargs):
        """

        Args:
            no_of_bytes_to_read: NumBytesToWrite in Decimal
            offset: offset in Hex
            pattern: Pattern Definitions. No pattern specified defaults to Sequential values.
                     Specify 8 bit pattern in hex to be repeated.
            **kwargs:

        Returns: output of the command executed

        """
        cmd = f"vpdwrite {no_of_bytes_to_read} {offset} {pattern}"
        op = self.cli_exec_command(cmd, **kwargs)
        return op


class AtlasFwcli(AtlasBaseFwcli):
    def __init__(self, com_port="COM4", baud_rate=115200, timeout=5):
        super(AtlasFwcli, self).__init__()
        self.sob = enhanced_serial.SerialConnection(com_port=com_port, baud_rate=baud_rate, timeout=timeout)
        self.sob.open_connection()

    def cli_exec_command(self, cmd, **kwargs):
        silent = kwargs.get("silent", False)
        supress_except = kwargs.get("supress_except", False)
        try:
            log.info(f"Executing the command {cmd}")
            self.sob.send_data(cmd)
            op = self.sob.receive_data()
            if not silent:
                log.info(f"Output of the command: {op}")
        except Exception as e:
            if supress_except:
                return str(e)
            raise
        return op
