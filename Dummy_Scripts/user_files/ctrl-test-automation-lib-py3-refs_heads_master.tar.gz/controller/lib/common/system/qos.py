"""
:mod:`qos` -- Back-end interface to QOS operations
===========================================================

.. module:: controller.lib.common.system.qos
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>

"""

import abc

from controller.lib.core import log_handler

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class BaseQos(object, metaclass=abc.ABCMeta):
    """
    Can do qos operations on NIC adapter. Abstract
    backend and perform qos operations with a system depending on
    the method.

    This class uses user-space tools to do qos operation on the NIC


    Returns:
        Interface: Interface object that has methods to interact with
            the adapter on qos operations

    """

    def __init__(self, iface):
        self._iface = iface

    @property
    def iface(self):
        return self._iface

    @abc.abstractmethod
    def enable(self, **kwargs):
        """Enable QOS in the NVM image"""
        raise NotImplemented

    @abc.abstractmethod
    def disable(self, **kwargs):
        """Enable QOS in the NVM image"""
        raise NotImplemented

    @abc.abstractmethod
    def set_ets_bandwidth(self, **kwargs):
        """Set QOS ets bandwidth"""
        raise NotImplemented

    @abc.abstractmethod
    def set_qos_policy(self, **kwargs):
        """Set QOS ets policy"""
        raise NotImplemented

    @abc.abstractproperty
    def get_ets_bandwidth(self, **kwargs):
        """Get ETS bandwidth"""
        raise NotImplemented

    @abc.abstractmethod
    def get_qos_policy(self, **kwargs):
        """Get QOS policy"""
        raise NotImplemented

    @abc.abstractmethod
    def verify_dcbx(self, **kwargs):
        """TO verify Whether DCBX feature installed or not"""
        raise NotImplemented

    @abc.abstractmethod
    def install_dcbx(self):
        """To install DCBX windows feature"""
        raise NotImplemented

    @abc.abstractproperty
    def verify_packet_tags(self, **kwargs):
        """To capture packets and verify the COS tags"""
        raise NotImplemented

    @abc.abstractproperty
    def get_traffic_class(self):
        """Gets Ets traffic class"""
        raise NotImplemented