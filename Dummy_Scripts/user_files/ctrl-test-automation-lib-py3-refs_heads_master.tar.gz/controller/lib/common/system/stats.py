"""
:mod:`stats` -- The test script template
===========================================

.. module:: controller.lib.common.system.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

A base module for various OS types. Handle system level statistics
information, such as interrupts, CPU utilization, etc

"""


import abc


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


class BaseStats(object, metaclass=abc.ABCMeta):
    """Base class for system level statistics"""

    def __init__(self, iface):
        self._iface = iface

    @property
    def iface(self):
        return self._iface

    @abc.abstractmethod
    def get_nic_interrupt(self):
        """Return a interrupt of the given interface

        Return value will be a list as below:

        [<interrupt CPU 0>, <interrupt CPU 1> ... ]

        Return:
            list: List of interrupts

        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_rx_offload_counter(self, **kwargs):
        """Return a raw counter for a number of packets of the receive
        side (LRO, GRO, RSC ... )

        keyword argument can be used to specify what exact counter type should
        be returned if this is supported.

        If OS does not support to report counter per queue or CPU, still
        should return a list but with a single element

        Return:
            list: [<counter CPU 0>, <counter CPU 1> ... ]

        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_tx_offload_counter(self, **kwargs):
        """Return a raw counter for a number of packets of the the receive
        side (TSO, LSO ...  )

        keyword argument can be used to specify what exact counter type should
        be returned if this is supported.

        If OS does not support to report counter per queue or CPU, still
        should return a list but with a single element

        Return:
            list: [<counter CPU 0>, <counter CPU 1> ... ]

        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_tcp_retransmitted(self, **kwargs):
        """Return a counter for a number of TCP transmitted segments

        Return:
            int: TCP retransmitted segments
        """
        raise NotImplementedError


