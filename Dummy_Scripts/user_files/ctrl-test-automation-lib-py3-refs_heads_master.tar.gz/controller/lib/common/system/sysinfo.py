"""
:mod:`sysinfo` -- System information base class
===============================================

.. module:: controller.lib.common.system.sysinfo
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

import platform
import importlib
import distro

from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class BaseSysInfo(object):
    platform = None

    @classmethod
    def get_memory(cls):
        """Return a physical memory size in KB"

        Return:
            int: physical memory size in KB
        """

        raise NotImplementedError('Not implemented')

    @classmethod
    def get_driver_info(cls, driver_list):
        """Return a list of driver version

        Each element of list is a dictionary object that has following::

            key='<driver_name>'
            value={
                'version': <driver_version>,
                'firmware': <firmware_version>,
            }

        Note that firmware version is optional; you can set it to None if
        it's not possible to get.

        Return:
            dict: driver and firmware information

        """

        raise NotImplementedError('Not implemented')

    @classmethod
    def get_sysinfo(cls, driver_list):
        """Return system information in a dictionary type

        * hostname
        * OS distribbution
        * kernel version
        * platform
        * driver name, version

        Args:
            driver_list (list): A list of drivers

        """
        if platform.system() in ['Linux', 'FreeBSD']:
            os_dist = '-'.join(distro.name())
            # os_dist = '-'.join(platform.linux_distribution())
        elif platform.system() == 'Windows':
            os_dist = 'Windows ' + ' '.join(platform.win32_ver())
        else:
            os_dist = 'Unknown'  # Unknown for now. Will add ESXi and FreeBsd

        ret_dict = {
            'Hostname': platform.node(),
            'OS': os_dist,
            'Kernel': platform.release(),
            'Arch': platform.architecture()[0],
            'Memory': cls.get_memory()}
        print(driver_list)

        if driver_list:
            ret_dict.update(cls.get_driver_info(driver_list))

        return ret_dict

    @classmethod
    def factory(cls):
        sysinfo_module = importlib.import_module('controller.lib.%s.system.sysinfo' % platform.system().lower())
        return sysinfo_module.SysInfo()


def get_sysinfo(driver_list):
    sysinfo = BaseSysInfo.factory()
    return sysinfo.get_sysinfo(driver_list)
