"""
:mod:`uart`-- The test script template
===========================================

.. module:: controller.lib.common.system.uart
.. module author:: Chandan Kumar <chakumar@broadcom.com>

Note : To use this module following needs to be defined in the sut_client_config.yml
uart_connection:
  uart_app_path: "C:\\Program Files (x86)\\teraterm5\\ttermpro.exe" # UART App on STAT server
  connection_type: "telnet" # how to connection to uart, for Raspberry 'telnet'
  uart_hostname: "citadelauto.dhcp.broadcom.net" # hostname where UART is connected
  uart_usb_port: "3051" # Host port to access UART

"""

import os
import time
import tempfile
import re
from pathlib import Path
from distutils.spawn import find_executable
from datetime import datetime

from controller.lib.common.shell import exe
from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.core.telnet import TelnetHandler

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class UartConnection(TelnetHandler):
    """
    This helps to start UART app and connection
    """

    def __init__(self, telnet_host_name, telnet_host_port, command_prompt=None, newline=None):
        """
        :param:
        telnet_host_name: Telnet hostname or IP of UART connected device e.g. Raspberry-Pi hostname
        telnet_host_port: USB port for serial communication on telnet_host_name e.g. Raspberry-Pi USB port 3051
        command_prompt: UART Prompt of connected device.
        newline: New newline char or line feed char
        """
        super().__init__(ip_addr=telnet_host_name, port=telnet_host_port,
                         command_prompt=command_prompt, newline=newline)


    def firmware_command_execution_telnet(self, fw_cmd=None):
        """
        Execute the firmware fw_cmd on UART telnet connection
        Note for CITADEL : The citadel uart does not move to prompt after printing all messages and logs.
                            We have this as workaround to log messages.
        :param:
        fw_cmd: Firmware uart command
        """
        self.connect()
        log.debug(f"Uart Log - test command:{fw_cmd}")
        self._telnet.write(b"\r")
        self._telnet.read_until(b"%", 3)  # read up to the prompt
        time.sleep(.5)
        self._telnet.read_very_eager()
        self._telnet.write(b"\r")  # if already in debugger work around
        cmd = fw_cmd + '\r'
        self._telnet.write(cmd.encode('ascii'))


class UartTeraTermApp(UartConnection):
    """
    To manage Tera Term app connection and execution
    """
    def __init__(self, uart_app_path, uart_hostname=None, connection_type=None, uart_usb_port=None, log_file=None,
                 command_prompt=None, newline=None):
        """
        :param:
        uart_app_path: Provide the UART app full path to connect UART
        uart_hostname: host name where UART USB is connected
                 It will be Raspberry PI host name or server host name
        connection_type: UART connection type.
        uart_usb_port: Telnet port number to connect
                  It will be USB Port method to connection telnet
                  E.g. 3052 if USB is connected to port 0 with baud rate of 115200
        log_file: Absolute File name to capture logs
        command_prompt: UART Prompt of connected device.
                      Note : For CITADEL, prompt is '%'
        newline: New newline char or line feed char
                     Note : For CITADEL, newline is '\r'
        """

        if not uart_app_path or uart_app_path is None and not find_executable(uart_app_path):
            log.error(f"UART app path {uart_app_path} is not available")
            raise exception.ConfigException(f"UART App {uart_app_path} not found")

        self.uart_app = f'{uart_app_path}'
        self.tt_mcast = 'ttmulticast'

        self.teraterm_telnet_conn_proc = None
        if connection_type == 'telnet':
            if command_prompt is None:
                command_prompt = [b'%']
            if newline is None:
                newline = b'\r'

            super().__init__(uart_hostname, uart_usb_port, command_prompt=command_prompt, newline=newline)

            self.telnet_host_name = uart_hostname
            self.telnet_host_port = uart_usb_port
            if log_file:
                self.telnet_log_file = str(Path(log_file))
                self.log_root_path = str(Path(log_file).parent)
            else:
                self.log_root_path = str(Path(tempfile.mktemp(prefix='firmware_uart_')))
                try:
                    os.mkdir(self.log_root_path)
                except Exception as err:
                    log.debug(f"os.mkdir err:{err}")
                ts = datetime.now().strftime("%d_%m_%Y_%H-%M-%S-%f")
                self.telnet_log_file = str(Path(self.log_root_path).joinpath(f'uart_capture_{ts}.log'))

        elif connection_type == 'ssh':
            self.ssh_host_name = uart_hostname
            self.ssh_host_port = '22'
            if log_file:
                self.ssh_log_file = str(Path(log_file))
                self.log_root_path = str(Path(log_file).parent)
            else:
                self.log_root_path = str(Path(tempfile.mktemp(prefix='host_ssh_')))
                try:
                    os.mkdir(self.log_root_path)
                except Exception as err:
                    log.debug(f"os.mkdir err:{err}")
                ts = datetime.now().strftime("%d_%m_%Y_%H-%M-%S-%f")
                self.ssh_log_file = str(Path(self.log_root_path).joinpath(f'host_ssh_{ts}.log'))

        else:
            log.warning(f"Connection Type {connection_type} is not supported.\nSupported Connection type:telnet, ssh")
            # raise exception.ConfigException(f"Conn Type {connection_type} is not supported")
        log.debug(f"Log directory tera term logs:{self.log_root_path}")

    def connect_teraterm_telnet_proc(self, log_file=None):
        """
        Start a telnet proc with teraterm session.
        It executes teraterm CLI command to start session
        It will capture command execution and firmware log in <log_file> parameter

        :param:
        log_file: file to capture logs
        """
        if log_file:
            self.telnet_log_file = log_file
        else:
            ts = datetime.now().strftime("%d_%m_%Y_%H-%M-%S-%f")
            self.telnet_log_file = str(Path(self.log_root_path).joinpath(f'teraterm_temp_{ts}.log'))
        # Below is reference example:
        # "C:\Program Files (x86)\teraterm5\ttermpro.exe" citadelauto.dhcp.broadcom.net:3090 /T=1
        # /L="C:\test_logs\teraterm\uart.log"
        self.teraterm_telnet_conn_proc = exe.ProcessHandler()
        tt_cmd = [f'{self.uart_app}', f'{self.telnet_host_name}:{self.telnet_host_port}',
                  f'/T=1', f'/MN={self.tt_mcast}', f'/L={self.telnet_log_file}']
        self.teraterm_telnet_conn_proc.run(tt_cmd, proc_name='TeraTermTelnet', shell=False)
        log.debug(f"tera term started with PID - {self.teraterm_telnet_conn_proc.proc.pid}")

    def connect_teraterm_ssh_proc(self):
        """
        Start a SSH proc with teraterm session.
        It executes teraterm CLI command to start ssh session
        It will capture command execution and firmware log in self.log_file parameter

        """
        # Below is reference example:
        # c:\Program Files (x86)\teraterm5\ttermpro.exe" 10.123.240.179:22 /ssh /2 //MN='citadel_spdm'
        # /auth=password /user=root /passwd=password
        # /L=C:\Users\chakumar\citadel_automation\emulatore_attest.log

        self.teraterm_ssh_conn_proc = exe.ProcessHandler()

        tt_ssh_cmd = [f'{self.uart_app}', f'{self.ssh_host_name}:{self.ssh_host_port}',
                      f'/ssh', f'/2', f'/MN={self.tt_mcast}', f'/auth=password', f'/user=root', f'/passwd=password',
                      f'/L={self.ssh_log_file}']
        self.teraterm_ssh_conn_proc.run(tt_ssh_cmd, proc_name='TeraTermSSH', shell=False)

        log.debug(f"tera term ssh started with PID - {self.teraterm_ssh_conn_proc.proc.pid}")

    def disconnect_teraterm_telnet_proc(self):
        """
        Terminate the teraterm telnet proc
        """
        try:
            self.teraterm_telnet_conn_proc.kill(timeout=5)
        except Exception as expt:
            log.warning(f"tera term connection close error:{expt}")
        log.debug(f"tera term connection terminated.")

    def disconnect_teraterm_ssh_proc(self):
        """
        Terminate the teraterm SSH proc
        """
        try:
            self.teraterm_ssh_conn_proc.kill(timeout=5)
        except Exception as expt:
            log.warning(f"tera term connection SSH close error:{expt}")
        log.debug(f"tera term connection SSH terminated.")

    def session_command_execution(self, fw_cmd, output_file=None, test_log=False, wait_for_events=10):
        """
        This will start a tera term connection with a log file
        create another : telnet session with telnet
        execute the command  on the telnet
        close the telnet session.
        stop the tera term
        output_file will have all output and log captured while running the command
        Validation of response and any failure could be done from the log file

        :param:
        fw_cmd: Firmware command to be executed
        output_file: file to capture the firmware event logs on execution of the fw_cmd
                    Note: Don't use file path, only file name.
        test_log: True is telnet log needs to be captured in log file
        wait_for_events: wait (sleep) time (seconds) after executing the fw_cmd to record events

        :return:
        output : output captured on execution of command
        uart_log: Log file path
        """

        output = None
        if output_file is None:
            sub_char = re.compile('([ ,])')
            file = sub_char.sub(r'_', fw_cmd)
            output_file = file+'.log'

        # close existing connections
        self.disconnect()
        self.disconnect_teraterm_telnet_proc()

        uart_log = os.path.join(self.log_root_path, output_file)
        self.connect_teraterm_telnet_proc(log_file=uart_log)
        log.debug("---- connection is done ----")

        log.debug("Try telnetlib connection")
        self.connect()

        log.info(f"execute test command:{fw_cmd}")
        if test_log is False:
            response, out = self.exec_command(fw_cmd.encode('ascii'))
            output = out.decode()
            log.debug(f"test command:{fw_cmd} completed, response:{response}")
        else:
            self.firmware_command_execution_telnet(fw_cmd)

        log.info("Wait for event to be logged on UART")
        time.sleep(wait_for_events)

        log.debug("closing connection .... ")
        self.disconnect_teraterm_telnet_proc()
        self.disconnect()
        log.debug("=== connection closed ===")

        return uart_log, output

    def execute_ttl_script_cmd(self, macro, proc_kill=True):
        """
        Execute the tera term macro script give in file

        :params:
        macro : tera term macro script (*.ttl) file
        """
        ttl_cli = [f'{self.uart_app}', f'/V', f'/M={macro}']
        log.debug(f"Running TTL Macro:{ttl_cli}")
        tt_proc = exe.run(ttl_cli, proc_name='TeraTermCommandMacro', shell=False)
        # Delay to send and complete tera term multicast
        time.sleep(5)
        tt_proc.kill() if proc_kill else None


