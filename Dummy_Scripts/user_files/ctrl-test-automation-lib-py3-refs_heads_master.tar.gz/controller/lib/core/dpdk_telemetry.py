#! /usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright(c) 2020 Intel Corporation

"""
Script to be used with V2 Telemetry.
Allows the user input commands and read the Telemetry response.

How to use:

    sp = sock_path(file_prefix='xyz')
    sock, prompt, output_buf_len = handle_socket(file_prefix='xyz', path=sp)
    output = run_command('/ethdev/list', sock, output_buf_len)
    print(output)


    pktgen_path = '/root/Pktgen-DPDK-pktgen-22.07.0/build/app/pktgen'
    eal_dict = {'l': '1-10', 'main-lcore': '2', 'n': '4', 'a': ['41:00.0', '41:00.1'], #'legacy-mem': None,
                'telemetry': None,
                'file-prefix': 'xyz'}
    app_dict = {'P': None, 'T': None, 'txd': 1024, 'rxd': 1024, 'm': "[3-4:5-6].0,[7-8:9-10].1"}

    import re
    from controller.lib.core.param.host import SUT

    sut = SUT(mgmt_ip_addr='10.123.62.213')
    sut.connect()
    pktgen = sut.import_module('controller.lib.common.io.pktgen')
    # ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~]|[0-?]*)')

    # import controller
    # import importlib
    # from controller.lib.common.io import pktgen
    # implib = sut.import_module('importlib')
    # implib.reload(pktgen)

    pgen = pktgen.PktgenDpdk(pktgen_path)
    pgen.launch(eal_dict=eal_dict, app_dict=app_dict)

    # pgen.exec_command('')
    output = pgen.exec_command('page range')
    # output = ansi_escape.sub('', output)
    print(output)


"""

import errno
import glob
import json
import os
import socket
import sys

from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)

# global vars
TELEMETRY_VERSION = "v2"
SOCKET_NAME = 'dpdk_telemetry.{}'.format(TELEMETRY_VERSION)
DEFAULT_PREFIX = 'rte'
CMDS = []


def read_socket(sock, buf_len, echo=True):
    """ Read data from socket and return it in JSON format """
    reply = sock.recv(buf_len).decode()
    try:
        ret = json.loads(reply)
    except json.JSONDecodeError:
        log.error("Error in reply: ", reply)
        sock.close()
        raise
    if echo:
        log.info(json.dumps(ret))
    return ret


def get_app_name(pid):
    """ return the app name for a given PID, for printing """
    proc_cmdline = os.path.join('/proc', str(pid), 'cmdline')
    try:
        with open(proc_cmdline) as f:
            argv0 = f.read(1024).split('\0')[0]
            return os.path.basename(argv0)
    except IOError as e:
        # ignore file not found errors
        if e.errno != errno.ENOENT:
            raise
    return None


def find_sockets(path):
    """ Find any possible sockets to connect to and return them """
    return glob.glob(os.path.join(path, SOCKET_NAME + '*'))


def print_socket_options(prefix, paths):
    """ Given a set of socket paths, give the commands needed to connect """
    cmd = sys.argv[0]
    if prefix != DEFAULT_PREFIX:
        cmd += " -f " + prefix
    for s in sorted(paths):
        sock_name = os.path.basename(s)
        if sock_name.endswith(TELEMETRY_VERSION):
            log.info("- {}  # Connect with '{}'".format(os.path.basename(s),
                                                        cmd))
        else:
            log.info("- {}  # Connect with '{} -i {}'".format(os.path.basename(s),
                                                              cmd,
                                                              s.split(':')[-1]))


def get_dpdk_runtime_dir(fp):
    """ Using the same logic as in DPDK's EAL, get the DPDK runtime directory
    based on the file-prefix and user """
    if (os.getuid() == 0):
        return os.path.join('/var/run/dpdk', fp)
    return os.path.join(os.environ.get('XDG_RUNTIME_DIR', '/tmp'), 'dpdk', fp)


def list_fp():
    """ List all available file-prefixes to user """
    path = get_dpdk_runtime_dir('')
    sockets = glob.glob(os.path.join(path, "*", SOCKET_NAME + "*"))
    prefixes = []
    if not sockets:
        log.error("No DPDK apps with telemetry enabled available")
    else:
        log.info("Valid file-prefixes:\n")
    for s in sockets:
        prefixes.append(os.path.relpath(os.path.dirname(s), start=path))
    for p in sorted(set(prefixes)):
        log.info(p)
        print_socket_options(p, glob.glob(os.path.join(path, p,
                                                       SOCKET_NAME + "*")))


def handle_socket(file_prefix, path):
    """ Connect to socket and handle user input """
    prompt = ''  # this evaluates to false in conditions
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
    global CMDS

    if os.isatty(sys.stdin.fileno()):
        prompt = '--> '
        log.info("Connecting to " + path)
    try:
        sock.connect(path)
    except OSError:
        log.info("Error connecting to " + path)
        sock.close()
        # if socket exists but is bad, or if non-interactive just return
        if os.path.exists(path) or not prompt:
            return
        # if user didn't give a valid socket path, but there are
        # some sockets, help the user out by printing how to connect
        socks = find_sockets(os.path.dirname(path))
        if socks:
            log.info("\nOther DPDK telemetry sockets found:")
            print_socket_options(file_prefix, socks)
        else:
            list_fp()
        return
    json_reply = read_socket(sock, 1024, bool(prompt))
    output_buf_len = json_reply["max_output_len"]
    app_name = get_app_name(json_reply["pid"])
    if app_name and prompt:
        log.info('Connected to application: "%s"' % app_name)

    # get list of commands for readline completion
    sock.send("/".encode())
    CMDS = read_socket(sock, output_buf_len, False)["/"]
    return sock, prompt, output_buf_len


def run_command(cmd, sock, output_buf_len):
    # interactive prompt
    try:
        if cmd == 'quit':
            sock.close()
            return
        if cmd.startswith('/'):
            sock.send(cmd.encode())
            return read_socket(sock, output_buf_len)
    except EOFError:
        pass


def readline_complete(text, state):
    """ Find any matching commands from the list based on user input """
    all_cmds = ['quit'] + CMDS
    if text:
        matches = [c for c in all_cmds if c.startswith(text)]
    else:
        matches = all_cmds
    return matches[state]


def sock_path(file_prefix, instance=0):
    list_fp()
    file_prefix = file_prefix.strip() or DEFAULT_PREFIX
    sock_path_ = os.path.join(get_dpdk_runtime_dir(file_prefix), SOCKET_NAME)
    if instance > 0:
        sock_path_ += ":{}".format(instance)
    return sock_path_
