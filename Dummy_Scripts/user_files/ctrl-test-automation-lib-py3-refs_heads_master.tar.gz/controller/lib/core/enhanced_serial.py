import serial
import time
import logging
import re
import datetime
from functools import wraps
import sys
import os, getopt, time
from binascii import *
from serial import SerialException
import serial.tools.list_ports

logger = logging.getLogger("ESerial")

ser = None  # serial port
ERRVAL = 0x4552520d

class ESerial(serial.Serial):

    # This is a regular expression for stripping terminal ASCII control sequences (CSI)
    ansi_codes = re.compile("\033\[[0-?]*[ -\/]*[@-~]")

    def __init__(self, *args, **kwargs):
        """
        # Function:    __init__
        # Purpose:     Used to initialize the COM port with additional options. As
        #              long as a COM port value is passed into the function, the
        #              channel will be opened automatically.
        # Parameters:  port:        Device name (COM3) or port number (4 = COM3)
        #
        #              See the pySerial API page below for other __init__ params
        #              http://pyserial.sourceforge.net/pyserial_api.html
        #                baudrate=9600, bytesize=EIGHTBITS, parity=PARITY_NONE, stopbits=STOPBITS_ONE, timeout=None,
        #                xonxoff=False, rtscts=False, write_timeout=None, dsrdtr=False, inter_byte_timeout=None)
        #
        #              The following Parameters need to be specified by name. For
        #              example: prompt="#" or save_output=False
        #
        #              prompt:      The prompt which the send_cmd will read to. It
        #                           can be any string or None, and defaults to '#'
        #                           if not set.
        #              send_eol:    This is the end of line character that gets
        #                           appended to the end of each command. It will
        #                           default to \n if not set.
        #              term_eol:    This is the end of line character that is used
        #                           to single the end of a terminal output line.
        #                           It will default to \r if not set.
        #              save_output: This determines whether or not the reponse
        #                           from the terminal is saved. It will default to
        #                           True if not set.
        #              verbose:     This determines whether or not the response
        #                           from the terminal is printed in the python
        #                           console window. It will default to False if
        #                           not set. However, the response will still be
        #                           logged by STAT regardless of this setting.
        # Returns:     Cygwin compatible path
        """

        self.connection = False
        # Set default value for prompt if not specified and remove from kwargs
        self.prompt = kwargs.pop("prompt", Prompt.linux)

        # Set default value for send_eol if not specified and remove from kwargs
        self.send_eol = kwargs.pop("send_eol", b'\n')

        # Set default value for term_eol if not specified and remove from kwargs
        self.term_eol = kwargs.pop("term_eol", b'\r')

        # Set default value for save_output if not specified and remove from kwargs
        self.save_output = kwargs.pop("save_output", True)

        # Set default value for verbose if not specified
        self.verbose = kwargs.pop("verbose", False)

        # Set default value for timestamps if not specified
        self.timestamps = kwargs.pop("timestamps", None)

        # Initialize the serial class. This must be done before we set the
        # timeouts or baudrate
        serial.Serial.__init__(self, *args, **kwargs)

        # Set default value for the read/write timeouts if not specified
        self.default_timeout = 6
        self.timeout = kwargs.get("timeout", self.default_timeout)
        self.writeTimeout = kwargs.get("timeout", self.default_timeout)

        # Set default value for baudrate if not specified
        self.baudrate = kwargs.get("baudrate", 115200)

        self.send_cmd("echo Connection complete")
        self.connection = True

    def exec_command(self, *args, **kwargs):
            return self.send_cmd(*args, **kwargs)

    def send_cmd(self, command, timeout=False, prompt=False, send_eol=False, log_by_line=False):
        """
        # =========================================================================
        # Function:    send_cmd
        # Purpose:     Used to send commands and receive responses over the opened
        #              serial channel
        # Parameters:  command:  The command which is being sent over the channel
        #              timeout:  This specifies the timeout for this command only.
        #                        If this is False, it will use the default value.
        #              prompt:   This specifies the prompt for this command only.
        #                        If this is False, it will use the default value.
        #              send_eol: This specifies the eol sent for this command only.
        #                        If this is False, it will use the default value.
        # Returns:     True/False if the prompt was found and a string containing
        #              the response from the terminal
        # =========================================================================
        """
        logger.info('Run command: "{}"{} {}'.format(
            command, " %s" % str(timeout) if timeout else "", '"%s"' % prompt if prompt else ""))

        # Set the timeout for a single command - handle common case of missing timeout (prompt string) by using default
        if timeout is False:
            cmd_timeout = self.timeout
        else:
            cmd_timeout = timeout
        if sys.version_info[0] >= 3:
            d_type = int
        else:
            d_type = int
        if not isinstance(cmd_timeout, (int, d_type, float)):
            logger.warning("2nd arg is not a valid timeout value - defaulting to %s secs!", str(self.default_timeout))
            cmd_timeout = self.default_timeout

        # Set the end of line character for a single command
        if prompt is False:
            cmd_prompt = self.prompt
        else:
            cmd_prompt = prompt

        # Set the end of line character for a single command
        if send_eol is not None:
            if send_eol is not False:
                command += send_eol
            else:
                command += self.send_eol

        # Write command to serial channel
        #logger.info("Running command %s", command)
        try:
            self.write(bytes(command))
            self.flush()

            # If no end-of-line character is sent, return immediately
            if send_eol is None:
                return (True, None)
        except serial.SerialTimeoutException:
            logger.error("Error: Timeout while writing to device for command %s", command)
            return (False, None)

        # Set our reponse an empty string or None if we are not saving it
        if self.save_output:
            response = ""
        else:
            response = None
            # Enable log by line if the reponse isn't saved so we have a log
            log_by_line = True

        # Initial the byte array for read()
        line = bytearray()
        leneol = len(self.term_eol)

        elapsed = 0
        start_time = time.time()

        if self.verbose:
            print("\n\n#======== Terminal Output Starts ========#\n\n")

        if cmd_prompt is not None:
            # print "\n\n========= Command prompt is not None %s" % cmd_prompt
            # Read and append characters until we match the prompt
            while re.search(cmd_prompt, line, re.M) is None:
                line += self.read()
                # Each time the an eol character is found, log the line.
                if line[-leneol:] == self.term_eol:
                    # Print to python console if verbose is True
                    if self.verbose:
                        print((self.ansi_codes.sub("", line.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")))
                    # Append line to response if save_output is True
                    if self.save_output:
                        if self.timestamps is not None:
                            response += self.timestamp()
                        cmd_out = self.ansi_codes.sub("", line.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")
                        response += cmd_out.strip() + "\n"
                    # Log line in STAT
                    if log_by_line:
                        logger.debug(line)

                    line = bytearray()

                # Check to see if we've encountered our timeout
                elapsed = time.time() - start_time
                if elapsed > cmd_timeout:
                    logger.warning("Warning: Timeout while reading from device for command %s", command)
                    # Log to STAT
                    if log_by_line:
                        logger.debug(line)
                    elif self.save_output:
                        logger.debug(response)
                    return (False, response)
        else:
            # No prompt given, so read and append characters until we timeout
            while elapsed < cmd_timeout:
                line += self.read()
                # Each time the an eol character is found, log the line.
                if line[-leneol:] == self.term_eol:
                    # Print to python console if verbose is True
                    if self.verbose:
                        print((self.ansi_codes.sub("", line.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")))
                    # Append line to response if save_output is True
                    if self.save_output:
                        if self.timestamps is not None:
                            response += self.timestamp()
                        cmd_out = self.ansi_codes.sub("", line.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")
                        response += cmd_out.strip() + "\n"
                    # Log line in STAT
                    if log_by_line:
                        logger.debug(line)

                    line = bytearray()

                elapsed = time.time() - start_time

        # Wait 200ms then append the anything left in the read buffer to line
        time.sleep(0.2)
        line += self.read(self.inWaiting())

        # Print to python console if verbose is True
        if self.verbose:
            print((self.ansi_codes.sub("", line.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")))

        # Append line to response if save_output is True
        if self.save_output:
            if self.timestamps is not None:
                response += self.timestamp()
            cmd_out = self.ansi_codes.sub("", line.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")
            response += cmd_out.strip() + "\n"
        if self.verbose:
            print("\n\n#======== Terminal Output Finish ========#\n\n")

        # Log to STAT
        if log_by_line:
            logger.debug(line)
        elif self.save_output:
            logger.debug(response)
        #print "Reponse collected =========== %s" % response
        return (True, response)

    def timestamp(self):
        """ Return current timestamp """
        if self.timestamps == "date":
            return "[{}]  ".format(datetime.datetime.fromtimestamp(time.time()).strftime('%Y.%m.%d %H:%M:%S.%f'))
        elif self.timestamps == "raw":
            return "[{}.{}]  ".format(str(time.time()).split('.')[0],
                                      str(datetime.datetime.now().microsecond).zfill(6))
        else:
            return ""

    def flush_input(self, flush_timeout=0.2, force=False):
        """ Flush the input buffers (i.e. device output). Use own method so we can log the data """
        # pyserial discards data: self.flushInput()

        if force:
            # Round down the float to an int, and use as the prompt search timeout (0.2s are added by send_cmd)
            timeout = int(flush_timeout)
            output_raw = self.send_cmd("#flush input buffer", timeout, None)[1]
        else:
            # Wait 200ms (default) then collect anything left in the read buffer for logging
            time.sleep(float(flush_timeout))
            output_raw = self.read(self.inWaiting())
        if output_raw:
            output = self.ansi_codes.sub("", output_raw.decode("utf-8", errors="ignore")).encode("utf-8", "ignore")
            logger.debug('Output(flush): %s', output)
            return output
        return ""

    @staticmethod
    def set_log_level(level):
        logger.setLevel(level)


class Prompt(object):
    """ Class of static prompts """
    uefis_boot = [r'UEFI firmware \(version', r'Press any key']
    uefi_boot = r'|'.join(uefis_boot)
    uefis = [r'Shell> ']
    uefi = r'|'.join(uefis)

    uboots = [r'[\r\n\A]=> ', r'^=> ', r'[\r\n\A]u-boot> ', r'^u-boot> ', r'autoboot', r'Northstar2#']
    uboot = r'|'.join(uboots)

    # See new_linux, if you need a less specific prompt
    # Allows matching at the beginning of a line for single or multi-line strings,
    # without requiring Multi-line regex mode (since we cannot enable that in all lower-level libraries)
    linuxs = [r'[\r\n\A]# ', r'^# ']
    linux = r'|'.join(linuxs)

    list_all = linuxs + uboots
    list_all_atf = linuxs + uefis

    default = linux
    defaults = [linux]

    # On first boot after flashing, prompt can have leading text...
    new_linux = r'# '

    # The x86 servers don't work well with '[\n\r]#'
    x86s_boot = [r'# ', r'login:']
    x86s = x86s_boot[:1]
    x86_boot = r'|'.join(x86s_boot)
    x86 = r'|'.join(x86s)

    # lcdiag app
    lcdiags = [r'[1-9]:> ']
    lcdiag = r'|'.join(lcdiags)


class ESerial_Extn(ESerial):

    def __init__(self, *args, **kwargs):
        super(ESerial_Extn, self).__init__(*args, **kwargs)
        if self.connection:
            logger.info("Connection is created")
        else:
            logger.error("Failed to open serial port connection")
        self.output = None
        self.ret_code = None

    @property
    def conn(self):
        return self

    @property
    def connected(self):
        return self.connection

    def disconnect(self):
        self.close()

    def exec_command(self, command, timeout=60, prompt=False, check_exit=True, check_ret_code=True):
        #logger.debug('Exec command "%s"' % command)
        logger.info('\n\n\n\n')
        if not self.connected:
            logger.info("connection is not open")
            return
        self.flush_input()
        cmd_output = self.send_cmd(command, timeout=timeout, prompt=prompt)
        logger.info('Output of command {0} is {1}'.format(command, cmd_output))
        if cmd_output[0] is False:
            raise Exception("Command Timed out after {} sec".format(timeout))
        cmd_output = cmd_output[1].split('\n')[1:-2]
        logger.info('Output of command {0} is {1}'.format(command, cmd_output))

        self.output = cmd_output
        if check_ret_code is False:
            return cmd_output

        time.sleep(0.2)
        ret_code = self.send_cmd('echo $? ', timeout=timeout,  prompt=prompt)
        ret_code = ret_code[1].split('\n')[1:-2][0].strip()
        logger.info("Output of ret_code = %s : %s" % (ret_code, type(ret_code)))
        if not ret_code:
            ret_code = '0'

        logger.info('Exit status of {0} is {1}'.format(command, str(ret_code)))

        if ret_code.isdigit() and int(ret_code) != 0 and 'No such file' in '\n'.join(cmd_output):
            cmd_output = []

        if check_exit and ret_code.isdigit() and int(ret_code) != 0:
            raise Exception("Command returned with non-zero exit status as %s" % ret_code)

        self.ret_code = ret_code
        return cmd_output

class sdbobj:
    """ Implements the Atlas SDB interface
    """

    def __init__(self, comport='COM1', baudrate=115200, sto=None, binmode=True):

        self._com = comport
        self._baud = baudrate
        self._sto = sto
        self.binmode = binmode
        self.connect()

    def MemoryWrite(self, addr, data):
        """ Sends dword write command to SDB port

        :param addr: AXI address to write
        :param data: DWORD to write
        :returns: number of bytes written
        """

        addrstr = unhexlify('{0:08x}'.format(addr))
        datastr = unhexlify('{0:08x}'.format(data))

        cmdstr = b'P\x04' + addrstr + datastr + b'\r'
        cmdb = bytearray(cmdstr)
        # logger.info (repr(cmdstr))
        console_cmd = 'W,4,' + format(addr, 'x') + ',' + format(data, 'x') + ' \r'
        logger.debug(console_cmd)
        console_cmdb = bytearray(console_cmd, 'utf-8')

        num = 0
        if self.binmode == True:
            num = self.ser.write(cmdb)
        else:
            num = self.ser.write(console_cmdb)  # (cmdb)
            # read back command
            tmpVal = self.ser.readline()
            # self.ser.read(len(console_cmdb)+2 ) #+2 in cosim

        # this should be the % cursor
        for ii in range(3 + 2):  # +2 needed for cosim
            tmpVal = self.ser.read()
            # logger.info("wwwww", tmpVal)
            if tmpVal == b'%':
                break

        if (tmpVal != b'%'):
            logger.info("ERROR(memw): % prompt not seen when expected.  Rerun script.")
            logger.error("ERROR(memw): % prompt not seen when expected.")
            sys.exit()
        # logger.info("COMPLETED WRITE WAIT FOR %, returning")
        return num

    def MemoryRead(self, addr):
        """ Sends dword read command to SDB port
        and returns 4 bytes read from serial port

        :param addr: AXI address to read from
        :returns: DWORD

        """
        # ERR<CR> = 0x4552520d
        # 0xd = <CR>
        try:
            addrstr = unhexlify('{0:08x}'.format(addr))

            cmdstr = b'G\x04' + addrstr + b'\r'
            cmdb = bytearray(cmdstr)
            # logger.info( repr(cmdstr))
            console_cmd = 'R,4,' + format(addr, 'x') + ' \r\n'
            console_cmdb = bytearray(console_cmd, 'utf-8')
            logger.debug(console_cmd)

            rddata_int = 0
            if self.binmode == True:
                self.ser.write(cmdb)
                rddata = bytearray(self.ser.read(4))
                rddata_int = int(hexlify(rddata), 16)
            else:
                self.ser.write(console_cmdb)
                # read back command
                tmpVal = self.ser.readline()
                # logger.info("RRRR", tmpVal)
                # this part behaves differently in linux and windows, so may need extra readline in linux
                rddata = bytearray(self.ser.readline())
                # search for any alphanumeric
                anyalphanum = re.search('[a-fA-F0-9]', rddata.decode("utf-8"))

                if anyalphanum:
                    pass
                else:
                    rddata = bytearray(self.ser.readline())
                # logger.info("rddata", rddata)
                rddata_int = int(bytes(rddata), 16)
        except ValueError:
            rddata_int = 0
            logger.info("ERROR: SDB returned invalid number")

        # this should be the % cursor
        # somehow there is 0x4 now before %
        tmpVal = 0
        for ii in range(3 + 2):  # +2 needed for cosim
            tmpVal = self.ser.read()
            # logger.info('rrrrr', tmpVal)
            if tmpVal == b'%':
                break

        if (tmpVal != b'%'):
            logger.info("ERROR(memr): % prompt not seen when expected.  Rerun script.")
            sys.exit()
        return rddata_int

    def ReadModify(self, addr, andmask=0xffffffff, ormask=0):
        """ Reads value and modifies specific bits
        and writes back modified value.

        :param addr: AXI address to read from
        :andmask: 0 bit positions to be cleared
        :ormask: 1 bit positions to be set
        :returns: DWORD

        """
        rd_data = self.MemoryRead(addr)
        rd_and = rd_data & andmask
        rd_and_or = rd_and | ormask
        self.MemoryWrite(addr, rd_and_or)

    def connect(self):
        """Connect to SDB port.  Should be called before using
        other routines.

        :param comport: serial port to connect to.  For example, 'COM1'
        :param baudrate: serial port baudrate
        :param sto: stop bits

        """

        self.ser = serial.Serial()
        self.ser.baudrate = self._baud
        self.ser.port = self._com
        self.ser.xonxoff = True
        if self._sto != None:
            # 2 second timeouts
            self.ser.timeout = self._sto
            self.ser.write_timeout = self._sto
            logger.info(('timeout=%d' % self.ser.timeout))

        logger.info(("Connecting to %s at %d baud sdb binmode=%s" % (self._com, self._baud, self.binmode)))
        try:
            self.ser.open()
            time.sleep(.1)
            # logger.info "characters in buffer=", ser.inWaiting()
            # if (ser.read() != '%'):
            # logger.info("% prompt not seen when expected.")

        except SerialException:
            logger.info('Could not open COM port', self.ser.port)
            return 1
        return 0

    def close(self):
        """Closes serial port connection
        """

        self.ser.close()

    def listcomports(self, comport="COM3"):
        """Lists available serial ports


        """
        ports = list(serial.tools.list_ports.comports())
        serialportfound = False
        logger.info("--------Serial Ports.-------------------")
        for p in ports:
            logger.info(str(p))
            if re.match(comport, str(p)):
                serialportfound = True
        logger.info("----------------------------------------")
        return serialportfound

    # def usage(self):
    #    logger.info 'sdb.py -p <COM?> -b baudrate'
    #    logger.info 'COM is SDB serial port, baudrate=baudrate'




class SerialConnection:
    def __init__(self, com_port='COM4', baud_rate=115200, timeout=5):
        self.port = com_port
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.connection = None

    def open_connection(self):
        try:
            self.connection = serial.Serial(port=self.port, baudrate=self.baud_rate, timeout=self.timeout)
            logger.info(f"Connection established on {self.port} with baudrate {self.baud_rate}")
        except serial.SerialException as e:
            logger.info(f"Failed to establish connection: {e}")

    def close_connection(self):
        if self.connection and self.connection.is_open:
            self.connection.close()
            logger.info(f"Connection on {self.port} closed")

    def send_data(self, data):

        if self.connection and self.connection.is_open:
            self.connection.write(b'\r')
            # time.sleep()
            self.connection.write(data.encode() + b'\r')  # Send data with newline characters
            self.connection.flush()
            logger.info(f"Sent data: {data}")
        else:
            logger.info("Connection is not open. Cannot send data.")

    def receive_data(self, prompt='cmd>', timeout=5):
        if self.connection and self.connection.is_open:
            end_time = time.time() + timeout
            received_lines = []
            while time.time() < end_time:
                if self.connection.in_waiting:
                    line = self.connection.readline().decode(errors='ignore').strip()
                    # logger.info(f"Debug: Received line: {line}")  # Debugging line to logger.info each received line
                    if line:
                        received_lines.append(line)
                        if line.endswith(prompt):
                            break
            response = '\n'.join(received_lines)
            logger.info(f"Received data:\n{response}")
            return response
        else:
            logger.info("Connection is not open. Cannot receive data.")
            return None

    def __del__(self):
        self.close_connection()