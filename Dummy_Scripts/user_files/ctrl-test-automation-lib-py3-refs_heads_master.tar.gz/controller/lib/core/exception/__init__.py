"""
:mod:`exception` -- STAT specific exceptions
============================================

.. module:: controller.lib.core.exception
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This module defines custom exceptions that can be used for STAT test scripts.
This allows to catch specific scope of exceptions.

"""


class STATException(Exception):
    """
    A base exception class for library or test script
    """

    pass


class ValueException(STATException):
    """
    An exception when wrong value is found
    """

    pass


class UnsupportedException(STATException):
    """
    An exception thrown when an unsupported operation is attempted.
    """

    pass


class TestCaseFailure(STATException):
    """
    An exception when test script fails and should return "Fail"
    """

    pass


class TestSuiteFailure(STATException):
    """An exception when test script fails with critical errors.

    Stop running test suite.
    """

    pass


class UnitTestException(STATException):
    """
    A base exception class for unittest failure.
    """

    pass


class ConfigException(STATException):
    """
    A base exception class for configuration issues, such as when NIC
    interface that has given MAC address.
    """

    pass


class ExeException(STATException):
    pass


class ExeExitcodeException(ExeException):
    def __init__(self, command, exitcode, output=None):
        self.command = command
        self.exitcode = exitcode
        self.output = output

    def __str__(self):
        return "command %s returned non-zero exit status %s. Output: %s" % (
            self.command,
            self.exitcode,
            self.output,
        )


class ToolNotFoundException(STATException):
    pass


class ToolMinVersionException(STATException):
    """Exception for tool version not meeting minimum requirements"""

    pass


class PktgenException(STATException):
    pass


class PktgenDataException(PktgenException):
    pass


class IperfException(STATException):
    pass


class IperfDataException(IperfException):
    pass


class NetperfException(STATException):
    pass


class NetperfDataException(NetperfException):
    pass


class NetperfExitCodeException(NetperfException):
    pass


class MLTTException(STATException):
    pass


class MLTTDataException(MLTTException):
    pass


class MLTTTimeout(MLTTException):
    pass


class MLTTExitCodeException(MLTTException):
    pass


class IBException(STATException):
    pass


class IBExitCodeException(IBException):
    pass


class IBTimeOut(IBException):
    pass


class LogHandlerException(STATException):
    pass


class RemoteLoggingException(STATException):
    pass


class EthException(STATException):
    pass


class PingException(EthException):
    pass


class EthtoolException(STATException):
    pass


class EthtoolNoChanges(EthtoolException):
    pass


class IPException(STATException):
    pass


class IPFileExists(IPException):
    pass


class IPOutOfRange(IPException):
    pass


class ScapyException(STATException):
    pass


class SockTimeout(STATException):
    pass


class HostException(STATException):
    pass


class TelnetException(IOError):
    pass


class WmicException(STATException):
    pass


class WmicNoInstance(WmicException):
    pass


class SSHException(STATException):
    pass


class TestPMDException(STATException):
    pass


class SubTestFailed(TestCaseFailure):
    pass


class DockerException(TestCaseFailure):
    pass


class NoActionPerformed(STATException):
    def __init__(self, command, desc=None, output=None):
        self.command = command
        self.desc = desc
        self.output = output

    def __str__(self):
        return f"{self.desc} : command {self.command} could not perform the desired action and returned Output: {self.output}"


class PTPException(STATException):
    pass


class NotFoundException(ConfigException):
    """
    A base exception class for any configuration issues with extended or specific message in case of
    unavailability of resources or unavailability of expected values
    """

    def __init__(self, message=None):
        self.message = message

    def __str__(self):
        return str(self.message)


class FioException(STATException):
    """
    Base Exception class for FIO tool
    """
    pass


class FioExitCodeException(FioException):
    """
    Invoked when FIO command exists with 'non Zero exit code'
    """
    pass


class FioTimeOut(FioException):
    """
    Invoked when FIO command running beyond specified time
    """
    pass
