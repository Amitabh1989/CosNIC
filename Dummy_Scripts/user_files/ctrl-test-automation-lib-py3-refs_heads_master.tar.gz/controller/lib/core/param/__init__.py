"""
:mod:`param` -- Pre-defined Object Type Parameters
==================================================

.. module:: controller.lib.core.param
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Basic Concept
-------------
When it needs to define nested environments, a list of required parameters
becomes long and hard to maintain.

Let's think about a case when you need to deal with virtual environments.
I can already think of few things that I need to take as parameters:

* Management IP address of SUT
* MAC address of DUT
* IP address of DUT
* Prefix/Netmask of DUT

And now you need more for virtual machines:

* Management IP address of VM
* MAC address of vNIC
* IP address of vNIC
* Prefix/Netmask of vNIC

... and so on. This is just a list of parameters that you need to define for
SUT side. You need this much information for SUT side as well, which will
end up something like below::

    stat_input_variables = [
        STAT_InputVariableDef(
            name='sut_mgmt_ip_addr',
            description='Management IP address of SUT',
        ),
        STAT_InputVariableDef(
            name='dut_mac_addr',
            description='MAC address of DUT',
        ),
        STAT_InputVariableDef(
            name='dut_ip_addr',
            description='IP address of DUT',
        ),
        STAT_InputVariableDef(
            name='dut_prefix',
            description='Prefix of DUT',
        ),
        STAT_InputVariableDef(
            name='sut_vm_mgmt_ip_addr',
            description='Management IP address of SUT side VM',
        ),
        STAT_InputVariableDef(
            name='sut_vm_mac_addr',
            description='MAC address of SUT side VM for Test Network',
        ),
        STAT_InputVariableDef(
            name='sut_vm_ip_addr',
            description='IP address of SUT side VM for Test Network',
        ),
        STAT_InputVariableDef(
            name='sut_vm_prefix',
            description='Prefix of SUT side VM for Test Network',
        ),
        STAT_InputVariableDef(
            name='client_mgmt_ip_addr',
            description='Management IP address of Client',
        ),
        STAT_InputVariableDef(
            name='client_mac_addr',
            description='MAC address of client NIC for Test Network',
        ),
        STAT_InputVariableDef(
            name='client_ip_addr',
            description='IP address of client NIC for Test Network',
        ),
        STAT_InputVariableDef(
            name='client_prefix',
            description='Prefix of of client NIC for Test Network',
        ),
        STAT_InputVariableDef(
            name='client_vm_mgmt_ip_addr',
            description='Management IP address of client side VM',
        ),
        STAT_InputVariableDef(
            name='client_vm_mac_addr',
            description='MAC address of client side VM for Test Network',
        ),
        STAT_InputVariableDef(
            name='client_vm_ip_addr',
            description='IP address of client side VM for Test Network',
        ),
        STAT_InputVariableDef(
            name='client_vm_prefix',
            description='Prefix of client side VM for Test Network',
        ),
    ]

Yikes, that's a looooong list of parameters ...

So, you already need to define 16 parameters in the test script, and likely,
your all test scripts that require to interact with VMs might need them all.

Namely you need to copy and paste the lots of parameters to every single test
script. And even worse? It's hard to maintain. Think about if someone asks you
to add a new parameter "IPv6 address" for IPv6 testing. The result is you need
to update every single test script so you can add the new parameter.
Not that pretty, eh? So what should we do?

The answer is this; Python supports OOP, so why don't we leverage it?

I am not going to go over about data structure - since it's bit obvious. Let's
stick with dictionary which is a great type to store information. So,
to make it short, it basically becomes like below::

    dut = {
        'mac_addr': 'xx:xx:xx:xx:xx:xx',
        'ip_addr': 'x.x.x.x',
        'prefix': x,
    },
    sut = {
        'mgmt_ip_addr': 'x.x.x.x',
        'iface': dut,
    },
    sut_vnic = {
        'mac_addr': 'xx:xx:xx:xx:xx:xx',
        'ip_addr': 'x.x.x.x',
        'prefix': x,
    },
    sut_vm = {
        'mgmt_ip_addr': 'x.x.x.x',
        'iface': sut_vnic
    },
    client_nic = {
        'mac_addr': 'xx:xx:xx:xx:xx:xx',
        'ip_addr': 'x.x.x.x',
        'prefix': x,
    },
    client = {
        'mgmt_ip_addr': 'x.x.x.x',
        'iface': client_nic,
    },
    client_vnic = {
        'mac_addr': 'xx:xx:xx:xx:xx:xx',
        'ip_addr': 'x.x.x.x',
        'prefix': x,
    },
    client_vm = {
        'mgmt_ip_addr': 'x.x.x.x',
        'iface': client_vnic
    },
    stat_input_variables = [
        name='sut',
        description='object type parameter for SUT',
        value=sut
    ],
    stat_input_variables = [
        name='sut_vm',
        description='object type parameter for SUT VM',
        value=sut
    ],
    stat_input_variables = [
        name='client',
        description='object type parameter for client',
        value=client
    ],
    stat_input_variables = [
        name='client_vm',
        description='object type parameter for client VM',
        value=client_vm
    ],


Uh, that really doesnt look shorter than the original code. The trick is because
the parameters are now objects, you can factor them out and keep re-using them
by referencing.

Namely, you can create a file "controller.cuw.test_script.config" and move
"sut", "dut", "sut_vm", "sut_vnic", "client", "client_vm", "client_vnic" to
there. And all you need to do in the test script is to import it and use
objects as below::

    from controller.cuw.test_script import config

    stat_input_variables = [
        STAT_InputVariableDef(
            name='sut',
            description='object type parameter for SUT',
            value=config.sut
        ),
        STAT_InputVariableDef(
            name='sut_vm',
            description='object type parameter for SUT VM',
            value=config.sut_vm
        ),
        STAT_InputVariableDef(
            name='client',
            description='object type parameter for client',
            value=config.client
        ),
        STAT_InputVariableDef(
            name='client_vm',
            description='object type parameter for client VM',
            value=config.client_vm
        ),
    ],

That seems much shorter now. Even better part is because now they are
references, you can be free from maintenance of hard-coded values. Whatever
changes that you make to the "controller.cuw.test_script.config.host" will be
automatically applied to all test scripts that use them.

Namely when you need to run the test script on a different SUT, you don't need
to modify every single STAT data file to update the new IP address but just
one python file ... cool, huh?

Though this still has one down side - you CANNOT configure parameters in STAT
because STAT does not understand object type parameters, because STAT does not
import but parse the script as a plain text. Therefore you cannot use
references, unfortunately. (Yes, STAT will throw exceptions if you try)

So the way to workaround this is, you pass the namespaces as a plain text.
Let's look at following lines::

    from controller.cuw.test_script import config

    stat_input_variables = [
        STAT_InputVariableDef(
            name='sut',
            description='object type parameter for SUT',
            value=config.sut
        ),

So what is exactly the value for the "sut"? It's a reference to
"controller.cuw.test_script.config.sut". And the value of that reference is
what we want to use as the sut parameter. Correct?

So what we can do is to pass the namespace as a parameter to the test script,
so the test script can import it by using the parameter value as a namespace
and expose the imported module as object type parameters.

So it becomes as below::

    stat_input_variables = [
        STAT_InputVariableDef(
            name='sut',
            description='object type parameter for SUT',
            value='controller.cuw.test_script.config.sut'
        ),
        STAT_InputVariableDef(
            name='sut_vm',
            description='object type parameter for SUT VM',
            value='controller.cuw.test_script.config.sut_vm'
        ),
        STAT_InputVariableDef(
            name='client',
            description='object type parameter for client',
            value='controller.cuw.test_script.config.client'
        ),
        STAT_InputVariableDef(
            name='client_vm',
            description='object type parameter for client VM',
            value='controller.cuw.test_script.config.client_vm'
        ),
    ]

Though converting the string value to an object is also quite repetitive task,
and "TestBase" handles this for you automatically when you add a special
prefix ``param__`` to the name.

So it becomes below::

    stat_input_variables = [
        STAT_InputVariableDef(
            name='param__sut',
            description='object type parameter for SUT',
            value='controller.cuw.test_script.config.sut'
        ),
        STAT_InputVariableDef(
            name='param__sut_vm',
            description='object type parameter for SUT VM',
            value='controller.cuw.test_script.config.sut_vm'
        ),
        STAT_InputVariableDef(
            name='param__client',
            description='object type parameter for client',
            value='controller.cuw.test_script.config.client'
        ),
        STAT_InputVariableDef(
            name='param__client_vm',
            description='object type parameter for client VM',
            value='controller.cuw.test_script.config.client_vm'
        ),
    ]

And you can access the parameters in test scripts using "self.params"::

    sut_mac_addr = self.params.sut['mac_addr']

Pre-defined Parameters
----------------------
Obviously, there are some common parameters that we use a lot across all test
scripts. And we all know that references are meaningful only if they have the
same variable name that can be called by multiple modules.

For example, when we define a parameter for run time, someone can
use a parameter name as "param__runtime" and someone else can use as
"param__run_time", and we already can see problems when two scripts use
different names for the same purposes - we need to define both of them in the
config file, which kills the purpose of using references. When we change a run
time, we want to change a single variable value, not two, or more.

For that reason, it's important to use agreed namespaces for some common
parameters. In the above example, for better understanding, I used dictionaries
and it will work fine for simple scenarios. However, but for advance usage,
we have some class based parameter objects as well as usual type (integer)
pre-defined parameters.

Here are the list.

Host Related Parameters
'''''''''''''''''''''''
param__sut (controller.lib.core.param.host.SUT)
    Instantiated object of controller.lib.core.param.host.SUT. This contains
    SUT related parameter values. Details are available at
    :ref:`lib.core.param.host`

param__client (controller.lib.core.param.host.Client)
    Instantiated object of controller.lib.core.param.host.Client. This contains
    client related parameter values. Details are available at
    :ref:`lib.core.param.host`

param__client_list (list)
    List of instantiated client objects. Test script should use this when it
    needs to access multiple clients to execute a test case.

Test Run Parameters
'''''''''''''''''''
param__runtime (int)
    A runtime for an entire test script.

param__step_runtime (int)
    A runtime for each step or loop in the test script.

This does not mean that you cannot create any other object type parameters;
you can freely define and use them in test scripts, but you must make sure
that such objects and attributes are expected from the test scripts by
mentioning in the docstring as well as having an exception handling with proper
error messages in the case that it cannot find ones.

However, if you believe there are some types of objects can be widely used and
has not defined yet, you should bring this up to the team and discuss.

And again, you CANNOT use different names of parameters if they are already
defined.

Again, check :ref:`lib.core.param.host` for more information.

"""


class ParamBase(object):
    """Base parameter class

    This class provides basic methods that should be included to all parameter
    classes.

    """

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def post_import(self):
        """Being called after the parameter is imported by test scripts.

        Any actions or methods that should be called after being imported
        should be define here.

        This method will be called only by controller.cuw.test_script.TestBase.

        """
        pass
