"""
:mod:`host` -- Pre-defined Host Parameters
==========================================

.. module:: controller.lib.core.param.host
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

When you define a host object with parameters, it provides not only values
that you define (i.e. IP address) but also methods that you can interact
with the given host.

.. note::

   The basic steps to define object parameters in test scripts are covered at
   :ref:`lib.core.param`

The most common classes that you might need to use are "Client" and "SUT".
Actually their names are almost self-explanatory.

So, how does it work? Here is the example.

>>> from controller.lib.core.param.host import Client, SUT
>>> client = Client(mgmt_ip_addr='192.168.0.2')
>>> sut = SUT(mgmt_ip_addr='192.168.0.1')

Now you can access the management IP address of client and SUT as below.

>>> client.mgmt_ip_addr
192.168.0.2
>>> sut.mgmt_ip_addr
192.168.0.1

The one required argument for Client and SUT classes are "mgmt_ip_addr". You
can pass any other keyword arguments if you want, but here are some important
arguments.

iface_list
    Maybe one of the most important parameters that you need to pass. It accepts
    a list of "controller.lib.core.param.Interface" objects, which is another
    object type parameters that define NIC interfaces. More details about the
    object is available at :ref:`lib.core.param.nic`

auto_connect
    Simple boolean. If True, the test script will automatically connect to the
    remote host before entering "run()" method. If you set to False, it means
    you need to connect to the host manually.

    The option will be ignored unless the object is called by TestBase

So you now know how to access the parameter value, and you might have a
question. Why don't we use a simple dictionary to define such parameters?

Dictionary is a great way to store information, but that's pretty much it. It
really doesn't have anything else to utilize such stored information. For
example, "sut" and "client" objects above know what the management IP address
that should be used to make RPyC connections.

So the normal way to use it is, if it's a just dictionary, it might end up
like below.

>>> sut_dict = {'mgmt_ip_addr': '192.168.0.1'}
>>> from controller.lib.host import client
>>> sut = client.connect(sut['mgmt_ip_addr'])

So the parameter is only meaningful as providing data, but nothing else. But
isn't that nice if the parameter can do all other stuff, such as connecting to
the remote host, since it has all the arguments that it needs to pass to
methods?

So yup, that's the reason why we have a class based parameter object for SUT
and Client, since it can have all extra methods that allow you to control the
targeted devices - for this case, obviously, SUT host and client host.

And Interface and DUT share the same reason why they are objects, which will
be covered at :ref:`lib.core.param.nic`.

Below is an example how you can use the SUT / Client parameters.

>>> sut = SUT(mgmt_ip_addr='192.168.0.1')
>>> sut.connect()

What it does is to connect to SUT over RPyC. Now you can access and get some
live information from the SUT. If you want to know which interface name is
being used for the management network, you can access it through the
"mgmt_iface" attribute.

>>> sut.mgmt_iface
'em1'

Since it's connected over RPyC, you can import and use Python modules.

>>> remote_exe = sut.import_module('controller.lib.common.shell.exe')
>>> remote_exe.block_run('hostname')
'sut\n'

So basically the object parameter not only lets you access the defined parameter
values, but also interact with the target device.

If you define "iface_list", you can interact with the interface as well.
This is covered at :ref:`lib.core.param.nic` I strongly recommend
to check this, since it's almost essential for all test scenarios.

"""
from collections import OrderedDict
from typing import Dict, List, TYPE_CHECKING
import os
import requests.exceptions
import urllib3.exceptions
import urllib.error
import time
import re
from contextlib import contextmanager

from controller.lib.host import client
from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.core.param import ParamBase
from controller.lib.core.param.nic import DUT

if TYPE_CHECKING:
    from controller.lib.core.param.nic import Interface
    from controller.lib.core.param.vm.virtual_machine import VirtualMachine
    from controller.lib.host.client import HostHandler

log = log_handler.get_logger(__name__)


class Host(ParamBase):
    """Host object which is a placeholder to keep related devices

    Args:
        mgmt_ip_addr (str, None): IP address/prefix of the management port. If
            None, it should be updated later (i.e. for virtual machines)
        iface_list (list): List of Interface objects

    """
    def __init__(self, mgmt_ip_addr: str, iface_list: List['Interface'] = None, auto_connect=True, sut=False,
                 driver_list=None, **kwargs):
        super().__init__(**kwargs)
        self._mgmt_ip_addr = mgmt_ip_addr
        self._host: 'HostHandler' = None
        self._modules = None
        self._sut: bool = sut
        self._vm: Dict[str, 'VirtualMachine'] = OrderedDict()
        self.iface_list: List['Interface'] = iface_list or []
        self._iface: 'Interface' = None  # a pointer to DUT
        self._auto_connect = auto_connect
        self._driver_list = driver_list or []
        self._sysinfo = None

    def post_import(self, **kwargs):
        if self._auto_connect:
            self.connect(**kwargs)
        # Get the sysinfo
        if self.sut:
            sysinfo = self.import_module('controller.lib.common.system.sysinfo')
            self._sysinfo = dict(sysinfo.get_sysinfo(self._driver_list))

    @property
    def mgmt_ip_addr(self) -> str:
        """Return management network IP address"""
        return self._mgmt_ip_addr

    @property
    def host(self) -> 'HostHandler':
        """Return "host" object, which is a RPyC proxy to the remote host"""
        return self._host

    @property
    def modules(self):
        return self._modules

    @property
    def sut(self) -> bool:
        """Return True if this is SUT host otherwise False"""
        return self._sut

    @property
    def iface(self) -> 'Interface':
        """Return "controller.lib.core.param.nic.Interface" object

        If this host has only one Interface object, automatically return that
        one. Otherwise return the Interface object that is set by running
        "set_iface" method.

        If there are more than one Interface object and "set_iface" has not
        executed, raise exception.

        """
        if self._iface:
            return self._iface

        if len(self.iface_list) == 1:
            self._iface = self.iface_list[0]
            return self._iface

        dut_iface_list = [iface for iface in self.iface_list if isinstance(iface, DUT)]

        if len(dut_iface_list) == 1:
            return dut_iface_list[0]
        # There are multiple DUT interfaces. Cannot automatically determine
        # which one should be set to iface. Raise exception
        raise exception.ConfigException('"set_iface" is not executed')

    @property
    def vm(self) -> Dict[str, 'VirtualMachine']:  # pylint: disable=C0103
        return self._vm

    @property
    def sysinfo(self):
        return self._sysinfo

    def ping(self):
        """Ping the host

        Ping the host's management IP address

        """
        return self._host.client.ping()

    def add_interfaces(self, interface_list: List['Interface']):
        """Add interface object to host.

        interface_list (list): List of Interface object that should be added to
            this host.
        """

        for interface in interface_list:
            self.iface_list.append(interface)

        if self.host:
            self.set_iface_list(interface_list)

    def remove_interface(self, interface: 'Interface'):
        """Remove interface object from host

        interface (Interface): Interface object that should be removed from
            this host
        """
        self.iface_list.remove(interface)

    def add_vm(self, vm_param: 'VirtualMachine' = None, vm_param_list: List['VirtualMachine'] = None):
        """Add a virtual machine to the SUT as a hypervisor

        Args:
            vm_param (obj): An instantiated object of
                controller.lib.core.param.vm.virtual_machine.VirtualMachine
            vm_param_list (list): Same as "vm_param" except getting a list
        """
        if vm_param:
            self._vm[vm_param.name] = vm_param
            vm_param.hypervisor = self
        elif vm_param_list:
            for vm_param in vm_param_list:
                self._vm[vm_param.name] = vm_param
                vm_param.hypervisor = self

    def remove_vm(self):
        self._vm = OrderedDict()

    def import_module(self, module_name):
        """Proxy to client.import_module

        """
        if self.host is None:
            raise exception.ConfigException('not connected to the host yet. Call connect() first.')

        return self.host.import_module(module_name)

    def connect(self, **kwargs):
        """Connect to a remote host"""
        ip_addr = self.mgmt_ip_addr.split('/')[0]
        self._host = client.connect(hostname=ip_addr, **kwargs)
        self._modules = self._host.modules

        if not self.iface_list:  # If no iface list is defined, do nothing.
            return

        if kwargs.pop('init_iface', True):
            self.set_iface_list(**kwargs)

    def disconnect(self):
        """Disconnect from the remote host"""
        for iface in self.iface_list:
            iface._ctrl = None

        self._host.disconnect()

    def get_iface(self, mac_addr=None, name=None) -> 'Interface':
        """Proxy to controller.lib.linux.eth.get_interface_by_mac_addr

        Args:
            mac_addr (str): MAC address
        """
        for iface in self.iface_list:
            if mac_addr and iface.mac_addr == mac_addr:
                return iface
            if name and iface.name == name:
                return iface

        log.warning('No such interface is detected')
        return None

    def set_sriov_iface_list(self, driver_name, **kwargs):
        if not self.iface_list:
            log.warning('iface_list is empty. Do nothing')

        eth_mod = self.host.import_module('controller.lib.common.eth')
        sriov_ifaces_on_vm = eth_mod.get_interfaces_by_driver(driver_name)
        sriov_ifaces_on_vm.sort(key=lambda iface: iface.pcidevice)  # sort the list based on pci addresses
        sriov_ifaces = [iface for iface in self.iface_list if iface.type == 'sriov']

        if len(sriov_ifaces) == len(sriov_ifaces_on_vm):
            for index in range(len(sriov_ifaces)):
                sriov_ifaces[index].mac_addr = sriov_ifaces_on_vm[index].mac_addr

        self.set_iface_list()

    def set_iface_list(self, iface_list: List['Interface'] = None, **kwargs):
        iface_list = iface_list or self.iface_list
        if not iface_list:
            log.warning('iface_list is empty. Do nothing')

        for iface in iface_list:
            iface.host = self.host
            iface.init_iface(**kwargs)

    def set_iface(self, idx=None, mac_addr=None, name=None):
        """Set one of ifaces as DUT and initialize configurations

        Args:
            idx (int): Index of the iface list
            mac_addr (str): iface that has the given MAC address will be
                assigned as DUT
            name (str): name of the interface
        """
        if idx is not None:
            self._iface = self.iface_list[idx]
        else:
            self._iface = self.get_iface(mac_addr, name)

    @property
    def mgmt_iface(self):
        """ Return the first ethernet interface object (type: BaseInterface derived type for the specific OS) """
        if not self._host:
            raise exception.ConfigException('Not connected to the host yet')

        eth = self._host.import_module('controller.lib.common.eth')
        mgmt_iface_list = eth.get_interfaces_by_ip_addr(self.mgmt_ip_addr)

        if len(mgmt_iface_list) > 0:
            # Return the first one blindly, but should be updated the logic
            return mgmt_iface_list[0]

        raise exception.ConfigException('Failed to find the management interface')

    def install_driver(self, url_list):
        """Install the driver by copying hypervisor's one to guest

        Args:
            url_list (list): A list of URL to a driver files i.e.)
                ['http://.../bnxt_en-0.1.27.tar.gz'] Note that the first file
                will be passed to "controller.lib.common.system.driver.install"
                as the "filename" argument
        """
        if not self.host:
            raise exception.ConfigException('Not connected to the host yet')

        vm_drv = self.import_module(f'controller.lib.{self.modules.platform.system().lower()}.system.driver')
        _filename = None
        _temp_dir = self.modules.tempfile.mkdtemp()

        _filename = self.download_file(url_list, _temp_dir)

        vm_drv.install(filename=_filename)
        self.host.modules.shutil.rmtree(_temp_dir)

    def uinstall_driver(self, bnxt_en=True, bnxt_re=True):
        """Uninstall the driver

        Args:
            host: In which device need to uinstall driver
        """
        self.host.exe = self.host.import_module('controller.lib.common.shell.exe')
        self.host.driver = self.host.import_module('controller.lib.linux.driver')
        output = self.host.exe.block_run('modinfo bnxt_en', shell=True)
        bnxt_en_module_path = re.search('filename:(.*)', output).group(1).strip()
        if self.host.modules.os.path.exists(bnxt_en_module_path) and bnxt_en and bnxt_en_module_path.endswith('bnxt_en.ko'):
            log.info('removing bnxt_en driver')
            self.host.modules.os.remove(bnxt_en_module_path)
        output = self.host.exe.block_run('modinfo bnxt_re', shell=True)
        bnxt_re_module_path = re.search('filename:(.*)', output).group(1).strip()
        if self.host.modules.os.path.exists(bnxt_re_module_path) and bnxt_re and bnxt_re_module_path.endswith('bnxt_re.ko'):
            log.info('removing bnxt_re driver')
            self.host.modules.os.remove(bnxt_re_module_path)

    def download_file(self, url_list, dir_path=None, windows_driver=False, download_from_ftp=False):
        """
        Download the file provided in URL in host
        DCSG01638374 - add support for pre-download components, set the given URL as local path of the component

        Args:
            url_list (list): A list of URL to a driver files i.e. ['http://.../bnxt_en-0.1.27.tar.gz']
            dir_path: files will be downloaded to given dir if provided
            windows_driver: set to True if Windows driver needs to be downloaded
            download_from_ftp: set to true if given URL is from FTP and not HTTP
        """
        if not self.host:
            raise exception.ConfigException('Not connected to the host yet')
        retry_conn = 1
        max_retry = 20
        driver_path_list = []

        if dir_path:
            _temp_dir = dir_path
        else:
            _temp_dir = self.modules.tempfile.mkdtemp()

        url_file_list = [url_list] if not isinstance(url_list, list) else url_list
        if len(url_file_list) == 0:
            raise exception.TestCaseFailure("File not present in given URL;%s" % url_file_list)
        for url in url_file_list:
            log.debug(url)

            # CTRL-45362: Automation: Fix the syntax errors identified during Py2.7 to Py3.X
            # porting.
            # Python 3.X doesn't support urllib2. So, use requests module instead.
            _tempfile = self.modules.os.path.join(_temp_dir, url.split('/')[-1])

            # DCSG01638374 - add support for pre-download components
            pre_downloaded = False
            if not str(url).lower().startswith(('http', 'ftp')):
                pre_downloaded = True

            while retry_conn <= max_retry:
                try:
                    if download_from_ftp:
                        _source = self.download_from_ftp(url)
                        self.modules.shutil.move(_source, _tempfile)
                    elif pre_downloaded:
                        _source = url       # DCSG01638374, given URL is local path for the pre-downloaded component
                        if not self.modules.os.path.exists(_source):
                            raise exception.TestCaseFailure(f"Invalid input: file {_source} does not exist on "
                                                            f"{self.name}. Please check __test_config__.yml file")
                        self.modules.shutil.copy(_source, _tempfile)
                        log.debug(f"Using the pre-downloaded component at {_source} on {self.name}. "
                                  f"Copied to {_tempfile}")
                    else:
                        _source = self.modules.requests.get(url)
                        try:
                            with self.modules.builtins.open(_tempfile, 'wb') as fileobj:
                                fileobj.write(_source.content)
                        except Exception as exc:
                            log.error(f"Failure occurred in file {_tempfile} write from url {url}")
                            raise exception.TestCaseFailure(f"Saving of downloaded file {_tempfile} failed.") from exc
                        finally:
                            _source.close()
                    break
                except (requests.exceptions.ConnectionError, urllib3.exceptions.ProtocolError,
                        urllib.error.URLError, urllib3.exceptions.NewConnectionError,
                        urllib3.exceptions.MaxRetryError) as err:
                    log.warning(f"Download from url {url} failed, retry:{retry_conn}")
                    log.debug(err)
                    if retry_conn >= max_retry:
                        raise exception.HostException(f"Failed to connect to {url} after retries {retry_conn}")
                    time.sleep(3 * retry_conn)
                    retry_conn += 1
                except Exception as exc:
                    log.error("Could not download the file from given URL, please re-check the provided URL (%s) ", url)
                    raise exception.TestCaseFailure("Failed to download the file") from exc
            if self.modules.os.path.exists(_tempfile):
                if self.modules.os.path.getsize(_tempfile) == 0:
                    log.error(f"Save file {_tempfile}, from URL {url} is 0 bytes." )
                    raise exception.TestCaseFailure(f"Save file {_tempfile}, from URL {url} is 0 bytes."
                                                    f" please re-check the URL {url}")
                if self.modules.os.path.getsize(_tempfile) < 300:  # (bytes) No URL Found download page size 288
                    with open(_tempfile, 'r') as file_read:
                        resp = file_read.readlines()
                        if any(f'URL was not found' in line for line in resp):
                            log.error(f"Given URL is not correct, please re-check the provided URL {url}")
                            raise exception.TestCaseFailure(f"Incorrect URL {url} provided")
                        else:
                            driver_path_list.append(_tempfile)
                else:
                    driver_path_list.append(_tempfile)

        log.info(driver_path_list)
        if windows_driver:
            for file_name in driver_path_list:
                if file_name.endswith('.inf'):
                    return file_name
            # if .inf file not found, raising exception
            raise exception.TestCaseFailure(f".inf file was not found in downloaded files.")
        else:
            return driver_path_list[0]

    def download_from_ftp(self, url):
        return self.modules.wget.download(url)

    @contextmanager
    def pushd(self, new_dir):
        host_os = self.import_module('os')
        previous_dir = host_os.getcwd()
        if not host_os.path.exists(new_dir):
            host_os.makedirs(new_dir)

        try:
            host_os.chdir(new_dir)
        except Exception:
            log.error(f'Failed to change directory to {new_dir}')
            raise

        try:
            yield
        finally:
            host_os.chdir(previous_dir)


class Client(Host):
    def __init__(self, mgmt_ip_addr: str, iface_list: List['Interface'] = None, **kwargs):
        super().__init__(mgmt_ip_addr, iface_list, **kwargs)


class SUT(Host):
    def __init__(self, mgmt_ip_addr: str, iface_list: List['Interface'] = None, **kwargs):
        self.ipmi = None
        super().__init__(mgmt_ip_addr, iface_list, sut=True, **kwargs)


class IPMI(ParamBase):
    def __init__(self, ipmi_host, ip_addr, username, password):
        """
        Control the target remote host using ipmitool

        Args:
            ipmi_host (str): IP address of a Linux host that has
                ipmitool as well as running stat_server.py
            ip_addr (str): IP address of the target host
            usernmae (str): IPMI username
            password (str): IPMI password

        """
        super(IPMI, self).__init__()
        self._ipmi_host = ipmi_host
        self.ip_addr = ip_addr
        self.username = username
        self.password = password

    def ipmi_ctrl(self, command):
        """Control the IPMI
        """
        ipmi_host = client.connect(self._ipmi_host)
        ipmi = ipmi_host.import_module('controller.lib.linux.system.ipmi')
        getattr(ipmi, command)(ip_addr=self.ip_addr, username=self.username, password=self.password)

    def on(self):
        self.ipmi_ctrl('on')

    def off(self):
        self.ipmi_ctrl('off')

    def cycle(self):
        self.ipmi_ctrl('cycle')

    def soft(self):
        self.ipmi_ctrl('soft')

    def status(self):
        return self.ipmi_ctrl('status')
