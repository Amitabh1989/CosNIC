#!/usr/bin/env python

import time
from . import ParamBase
from controller.lib.core import exception
from controller.lib.linux.maia.ovs import Bridge, DBServer, SwitchDaemon
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class MAIA(ParamBase):
    def __init__(self, ssh_obj, config, driver):
        self._config = config
        self._driver = driver
        self._conn = ssh_obj

        self.dbserver = DBServer(self.session)
        self.vswitchd = SwitchDaemon(self.session)

    @property
    def host_pfs(self):
        (m, h) = self._config.split('+')
        return ['PF' + str(x) for x in range(int(m),
                           int(m) + int(h))]

    @property
    def maia_pfs(self): 
        (m, h) = self._config.split('+')
        return ['PF' + str(x) for x in range(int(m))]

    @property
    def session(self):
        return self._conn

    @property
    def driver(self):
        """Return driver name"""
        return self._driver

    def start_dbserver(self):
        log.info("Starting DB server")
        if self.dbserver.start():
            log.info("DB server started")
        time.sleep(5)
        log.info("Checking if DB server daemon spawned")
        output = self.dbserver.isrunning()
        if not output: 
            log.error("FAIL: DB server start")
            return False
        return True

    def start_vswitchd(self):
        log.info("Starting Vswitchd")
        if self.vswitchd.start():
            # log.error("FAIL: Vswitchd Daemon start")
            # return False
            pass
        return True

    def setup(self):
        if not self.start_dbserver():
            raise exception.ConfigException('Failed to setup OVS DB server')
        if not self.start_vswitchd():
            raise exception.ConfigException('Failed to setup vswitchd')

    def teardown(self):
        self.vswitchd.stop()
        self.dbserver.stop()

    def restart_ovs(self):
        self.teardown()
        time.sleep(2)
        self.setup()
        time.sleep(5)

    def reboot(self, timeout=60):
        cmd = 'reboot'
        output = self.session.exec_command(cmd, timeout=timeout, check_exit=False)
        time.sleep(3)
        return output
