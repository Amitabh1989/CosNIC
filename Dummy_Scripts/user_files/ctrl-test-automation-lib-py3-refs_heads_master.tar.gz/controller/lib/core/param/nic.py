"""
:mod:`nic` -- Pre-defined NIC parameter
=======================================

.. module:: controller.lib.core.param.nic
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Basic Usage
-----------
First of all, if you have not read, please read below first.

* :ref:`lib.core.param`
* :ref:`lib.core.param.host`

Import the "Interface" class.

>>> from controller.lib.core.param.nic import Interface

"Interface" object represents a NIC and one required argument is the MAC
address, since that's the unique information to determine a NIC persistently.

>>> nic = Interface(mac_addr='00:11:22:33:44:55')

The problem here is the Interface object does not know which remote host it
needs to interact with. So let's start with instantiating the "SUT" object,
which provides a RPyC proxy to the Interface object.

>>> from controller.lib.core.param.host import SUT
>>> sut = SUT(mgmt_ip_addr='192.168.0.1')

Now you make a relation between the "sut" and "nic" as "nic" is belong to the
"sut".

>>> sut.add_interfaces([nic])

Note that "sut" accepts a list of Interface objects, since it can have more
than one NIC.

Now you can access the "nic" through "sut"

>>> sut.iface_list
[<controller.lib.core.param.nic.Interface at 0x2639a10>]
>>> sut.iface
<controller.lib.core.param.nic.Interface at 0x2639a10>
>>> sut.iface.mac_addr
'00:11:22:33:44:55'

.. warning::

   sut.iface will not set to "nic" automatically if you pass more than one
   Interface objects

"sut.iface_list" is a simple list of Interface objects that are added.
"sut.iface" is a proxy to one of Interface object - usually the interface
that you need to interact with. It's really a just a short cut to access
the Interface object, since most testing scenarios require only one Interface,
therefore you can simply access "sut.iface" instead of working with the
list and pick an element.

If you pass just one Interface object as above example, "sut.iface" will be set
to that automatically, since there is really only one that you need to interact.

Because we didn't specify anything but MAC address, most attributes will
return "None" - namely, values are not defined. For example, "ip_addr" will
return "None".

>>> sut.iface.ip_addr
>>>

Though you still can access live information from SUT through "ctrl" attribute.
This is basically a RPyC proxy to "controller.lib.<os>.eth" so you can call
any methods that the module allows.

Which means you don't need to import 'controller.lib.<os>.eth' and instantiate
an object manually by yourself.

However, before doing that, you need to connect SUT first.

>>> sut.connect()
>>> sut.iface.ctrl
<controller.lib.linux.eth.AppInterface object at 0x7feec00c0150>

And now you can interact with the NIC interface.

>>> sut.iface.ctrl.mac_addr
'00:11:22:33:44:55'
>>> sut.iface.ctrl.ip_addr
'192.168.2.101'
>>> sut.iface.ctrl.mtu
1500

So you don't need to import and create proxies to interact with the NIC.

This is quite useful to access some NIC information in the test script. For
example, when you need to ping the remote host from SUT::

>>> sut.iface.ctrl.ping(dst_ip=client.iface.ip_addr)

Interface.ip_addr vs. Interface.ctrl.ip_addr
--------------------------------------------
Sometimes developers get confused between Interface.ip_addr and
Interface.ctrl.ip_addr. Though the difference is quite simple and clear.

Interface.ip_addr is a parameter value, while Interface.ctrl.ip_addr is a
value that is returned by the remote host through the
controller.lib.<os>.eth module.

From the above example, because you did not define any IP address when you
instantiate the Interface object, "sut.iface.ip_addr" will return "None".
However, "sut.iface.ctrl.ip_addr" will still return the current IP address
since it returns live information after communicating with the remote host.

And this is same for all other attributes - such as mtu and prefix.

You can use parameter values as something default or initial values - they are
useful when you need to restore to the expected values after testing. For
example, below code will change the MTU of the interface to 9000 and then
restore to the whatever the defined value.

>>> sut.iface.ctrl.mtu = 9000  # Set the MTU to 9000 for testing
>>> sut.iface.ctlr.mtu = sut.iface.mtu  # Restore the MTU size to default

Available Arguments for Interface
---------------------------------
Please refer :py:class:`.Interface`

"""


import struct
import socket
from typing import TYPE_CHECKING

from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.core.param import ParamBase

if TYPE_CHECKING:
    from controller.lib.common.eth.interface import BaseInterface
    from controller.lib.host.client import HostHandler
    from controller.lib.common.eth.stats import BaseNIC


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


log = log_handler.get_logger(__name__)


class Interface(ParamBase):
    """NIC interface object that allows to interact with.

    Note that mac_addr and ip_addr does not reflect the most recent
    configurations - namely, if IP address or MAC address are changed through
    ip command, this object will NOT return the changed ones.

    mac_addr and ip_addr are expect values as initial setup - namely this
    information will be used to create objects to interact with the expected
    iface therefore are hard-coded and never updated.

    The real-time iface information can be collected through self.ctrl which
    is a proxy to controller.lib.<os>.eth.Interface.

    Args:
        mac_addr (str): MAC address. The only required parameter
        name (str): A name of the interface. i.e.) eth0
        ip_addr (str): IPv4 address with prefix. i.e.) x.x.x.x/x
        ip6_addr (str): IPv6 address with prefix. i.e.) x::/x
        mtu (int): MTU size
        tunnel_ip_addr (str): IP address with prefix that will be used for
            tunneling
        tunnel_ip6_addr (str): IPv6 address with prefix that will be used
            for tunneling
        vlan_ip_addr (dict): key=VLAN ID or 'all'. value=IP address with
            prefix that will be used for the VLAN ID in key
        switch_port (controller.lib.core.param.switch.Tomahawk): An object
            that is an instantiated Tomahawk class.
        speed (int): Link speed for the interface
        supported_speed (list): List of integer that the interface supports

    """
    interface_list = []

    def __init__(
            self, mac_addr, name=None, ip_addr=None, ip6_addr=None,
            mtu=None, switch_port=None, init_iface=True, **kwargs):
        super().__init__(**kwargs)
        self._host: 'HostHandler' = None
        self._mac_addr = mac_addr  # burn-in MAC address
        self._ip_addr = ip_addr  # IP address/X
        self._ip6_addr = ip6_addr
        self._name = name or None  # ethX name
        self._mtu = mtu  # MTU size
        self._init_iface = init_iface  # Initialize interface
        self._ctrl = None  # RPyC proxy
        self.switch_port = switch_port

    @property
    def host(self) -> 'HostHandler':
        return self._host

    @host.setter
    def host(self, new_host: 'HostHandler'):
        if self._host:
            log.debug(f'"host" is read-only. Do not update for Interface {self.name}.')
            return  # Read-only. Do not update.

        self._host = new_host

    @property
    def mac_addr(self):
        return self._mac_addr if self._mac_addr else None

    @mac_addr.setter
    def mac_addr(self, new_mac):
        self._mac_addr = new_mac

    @property
    def ip_addr(self):
        return self._ip_addr.split('/')[0] if self._ip_addr else None

    @property
    def netmask(self):
        if not self.prefix:
            return None
        return socket.inet_ntoa(
            struct.pack(">I", (0xffffffff << (32 - self.prefix)) & 0xffffffff))

    @property
    def ip6_addr(self):
        return self._ip6_addr.split('/')[0] if self._ip6_addr else None

    @property
    def prefix(self):
        return int(self._ip_addr.split('/')[1]) if self._ip_addr else None

    @property
    def ip6_prefix(self):
        return int(self._ip6_addr.split('/')[1]) if self._ip6_addr else None

    @property
    def name(self):
        if self._name:
            return self._name

        if self.ctrl:
            return self.ctrl.iface

        return None

    @property
    def mtu(self):
        return self._mtu

    @property
    def stats(self) -> 'BaseNIC':
        """Return statistics information in normalized form

        If multiple queues are available, should return sum of each
        parameter.

        Should override this - otherwise return self.ctrl.stats.
        """
        if self.ctrl:
            return self.ctrl.stats
        return None

    @property
    def ctrl(self) -> 'BaseInterface':
        """Proxy to controller.lib.<os>.eth

        This is a short-cut that you can directly control the interface
        using eth module. You can call any methods that are available
        in the "eth" module here as attributes.

        For example,

        >>> sut.iface.ctrl.down()

        Will bring down the interface. Technically, above a single line
        is same as below.

        >>> eth = sut.import_module('controller.lib.common.eth')
        >>> eth.get_interface_by_mac_addr(sut.iface.mac_addr)
        >>> eth.down()

        """
        if not self.host:
            log.warning('"self.host" is "None". Has the host connected?')
            return None  # No host proxy. Cannot return ctrl. return None

        try:
            # if self._ctrl and self._ctrl.mac_addr:
            if self._ctrl and self._ctrl.up:
                return self._ctrl
        except (ReferenceError, EOFError):
            log.info('Proxy to "ctrl" is lost. Re-creating.')

        # No existing eth proxy. Create one and return
        eth = self.host.import_module('controller.lib.common.eth')

        if self._name:
            # Name should not given usually, but if it's given, use it
            iface_obj = eth.get_interface(self._name)

        else:
            iface_obj = eth.get_interface_by_mac_addr(self.mac_addr)

        if not iface_obj:  # No such interface found. Return None.
            log.warning(f"Unable to find interface with Name/MAC: {self._name or self.mac_addr} - 'ctrl' is None")
            return None

        # MAC address is overriden only if it's None
        try:
            self._mac_addr = self.mac_addr or iface_obj.mac_addr
        except exception.IPException:
            # Do not update the MAC address - likely not have one (GRE iface)
            self._mac_addr = None

        self._ctrl = iface_obj
        return self._ctrl

    def init_iface(self, init_iface=None, **kwargs):
        """Initialize the interface by setting values as configured

        Factor this out from set_iface(), since some interfaces require not
        to be reset.

        If self._init_iface is False, this will be ignored unless force is True

        Args:
            init_force (bool): Initialize iface even though self._init_iface
                is False
        """

        init_iface = self._init_iface if init_iface is None else init_iface

        if not init_iface:
            log.debug(
                '"init_iface" is False. Do not initialize %s'
                % (self.name or self.mac_addr))
            return

        if not self.ctrl:
            raise exception.ConfigException(
                '"self.ctrl" is "None". No such interface %s detected.'
                % (self.name or self.mac_addr)
            )

        if self.mtu:
            log.info('%s:%s: Set MTU to %s' % (
                self.host.hostname, self.name, self.mtu))
            self.ctrl.mtu = self.mtu

        if self.ip_addr:
            log.info('%s:%s: Set IP address to %s' % (
                self.host.hostname, self.name, self.ip_addr))
            self.ctrl.ip_addr = self._ip_addr

        if self.ip6_addr:
            log.info('%s:%s: Set IPv6 address to %s' % (
                self.host.hostname, self.name, self.ip6_addr))
            self.ctrl.set_ip6_addr(self._ip6_addr, 'replace')

        # Bring up the interface
        self.ctrl.up()


class DUT(Interface):
    pass
