from .. import ParamBase
from controller.lib.switch import tomahawk
from controller.lib.switch.dell import s6000
from controller.lib.switch.dell import z9332f


class Switch(ParamBase):
    def __init__(self, switch, interface):
        super(Switch, self).__init__()
        self._switch = switch
        self._interface = interface

    def post_import(self):
        self._switch.connect()

    @property
    def switch(self):
        return self._switch

    @property
    def interface(self):
        return self._interface

    def connect(self, username='admin', password='br0adc0m$'):
        self._switch.connect(username=username, password=password)

    def disconnect(self):
        self._switch.disconnect()

    def shut(self):
        self._switch.shut(self._interface)

    def noshut(self):
        self._switch.noshut(self._interface)


class Tomahawk(Switch):
    def __init__(self, ip_addr, interface):
        super(Tomahawk, self).__init__(
            switch=tomahawk.Tomahawk.get_tomahawk(ip_addr),
            interface=interface)


class S6000(Switch):
    def __init__(self, ip_addr, interface):
        super(S6000, self).__init__(
            switch=s6000.S6000(ip_addr),
            interface=interface
        )


class Z9332F(Switch):
    def __init__(self, ip_addr, interface):
        super(Z9332F, self).__init__(
            switch=z9332f.Z9332F(ip_addr),
            interface=interface
        )

