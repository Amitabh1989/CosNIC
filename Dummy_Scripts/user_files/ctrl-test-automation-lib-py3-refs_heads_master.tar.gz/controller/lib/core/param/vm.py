from controller.lib.core.param import ParamBase
from controller.lib.core.param.host import Host
from controller.lib.core.param.nic import Interface

try:
    from virt.lib.network import test_network
except ImportError:
    print(
        'x Error: You cannot use this parameter due to "virt" package is not '
        'available')
    pass


class Bridge(Interface):
    def __init__(self, name, network_name, ip_addr, **kwargs):
        """
        Bridge parameter definition

        Args:
            name (str): Name of the bridge. i.e.) test-br0
            network_name (str): Network name which the bridge will be belong
                to.
            ip_addr (str): IP address that will be assigned to bridge, if
                necessary
            prefix (int): Prefix for the bridge

        """
        super(Bridge, self).__init__(
            mac_addr=None, name=name, ip_addr=ip_addr,
            init_iface=False, **kwargs
        )
        self.network_name = network_name

    def create(self, mode, force=False, **kwargs):
        """Create a bridge

        Due to iface names are dynamic, it should be passed here as kwargs
        here.

        Args:
            host (obj): RPyC proxy
        """
        virt_network = self.host.import_module('virt.lib.network')
        _network = virt_network.get_network(
            self.network_name, mode,
            bridge_name=self.name, ip_addr=self.ip_addr, prefix=self.prefix,
            addif=True, **kwargs)

        if _network.object and force:
            _network.destroy()

        _network.create()
        return _network

    def destroy(self, host):
        host.network = host.import_module('virt.lib.network')
        _network = host.network.get_network(self.network_name, None)
        _network.destroy()


class Pool(ParamBase):
    def __init__(self, path='/var/lib/libvirt/images'):
        super(Pool, self).__init__()
        self.path = path

    def create(self, host):
        virt_template = host.import_module('virt.lib.domain.template')
        pool = virt_template.Pool(self.path)
        pool.create()


class VM(Host):
    def __init__(
            self, hypervisor, mgmt_ip_addr, test_ip_addr_list, template,
            **kwargs):
        """
        Virtual machine object type parameter

        Args:
            hypervisor (Host): Host object parameter of hypervisor
            mgmt_ip_addr (str): Management IP address/prefix
            test_ip_addr_list (list): List of private and
                test network IP address/prefix
            template (str): Name of template to be used

        """
        super(VM, self).__init__(
            mgmt_ip_addr=mgmt_ip_addr, auto_connect=False,
            iface_list=[
                Interface(
                    ip_addr=test_ip_addr, mtu=1500,
                    mac_addr=test_network.get_mac_addr(test_ip_addr))
                for test_ip_addr in test_ip_addr_list
            ]
        )

        self._test_ip_addr_list = test_ip_addr_list
        self._hypervisor = hypervisor
        self.template = template

    def connect(self, **kwargs):
        if not self.hypervisor.host or not self.hypervisor.host.connected:
            self.hypervisor.connect(**kwargs)
        super(VM, self).connect(**kwargs)

    @property
    def hypervisor(self):
        return self._hypervisor

    @property
    def mgmt_mac_addr(self):
        mac_addr = test_network.get_mac_addr(self.mgmt_ip_addr).split(':')
        return 'b4:' + ':'.join(mac_addr[1:])

    @property
    def test_ip_addr_list(self):
        return self._test_ip_addr_list

    @property
    def test_mac_addr_list(self):
        return [
            test_network.get_mac_addr(test_ip_addr) for test_ip_addr in
            self.test_ip_addr_list
        ]

    @property
    def hostname(self):
        # Return the hostname using the very first test IP address
        return test_network.get_hostname(ip_addr=self.test_ip_addr_list[0])

    def get_vnet(self, test_ip_addr):
        """Return vnet interface of the Hypervisor that is mapped to the
        VM's interface

        """

        test_mac_addr = test_network.get_mac_addr(test_ip_addr)

        eth = self.hypervisor.import_module('eth')
        for iface in eth.get_interfaces():
            iface_obj = eth.get_interface(iface)
            if iface_obj.mac_addr[2:] == test_mac_addr[2:]:
                return iface

    def create(self, network_list=None, force=False, **kwargs):
        virt_template = self.hypervisor.import_module(
            'virt.lib.domain.template')
        template = virt_template.get_template(name=self.template)
        template.deploy(
            network_list=network_list or template.get_default_network_list(
                self.mgmt_ip_addr, self.test_ip_addr_list),
            force=force, **kwargs)

    def destroy(self):
        virt_domain = self.hypervisor.import_module('virt.lib.domain')
        _domain = virt_domain.Domain(name=self.hostname, disk_file=None)
        _domain.destroy()
