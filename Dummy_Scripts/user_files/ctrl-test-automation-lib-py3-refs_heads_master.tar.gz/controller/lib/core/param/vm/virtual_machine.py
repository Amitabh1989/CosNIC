from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.core.param.host import Host

log = log_handler.get_logger(__name__)

class VirtualMachine(Host):
    """Virtual machien object parameter definition

    Args:
        hypervisor (controller.lib.core.param.host.Host, None): Usually "sut"
            or "client" objects in config or test scripts
        vm_name (str): A name of the virtual machine
    """

    def __init__(self, vm_name, hypervisor=None, template=None, iface_list=None, gpu_pci_list=None):
        #  todo adding gpu_pci_list to vm
        self._hypervisor = hypervisor
        self._name = vm_name
        self._vmm = None
        self._tempalte = template

        super(VirtualMachine, self).__init__(mgmt_ip_addr=None, iface_list=iface_list)

    @property
    def name(self):
        return self._name

    @property
    def hypervisor(self):
        return self._hypervisor

    @hypervisor.setter
    def hypervisor(self, hypervisor):
        if self._hypervisor is not None:
            raise exception.ValueException('"hypervisor" is read-only attribute. Cannot be changed')

        self._hypervisor = hypervisor

    @property
    def vmm(self):
        return self._vmm

    def create(self, template=None, exist=None, **kwargs):
        """Create a virtual machine

        Args:
            template (str): A name of a template i.e.) rhel-7-u1 Will override
                self._template
            exist (str, None): Policy to handle existing virtual machines or
                any environments. choices=[reuse|overwrite|None] If None, will
                raise exceptions.
            **kwargs (kwargs): Any keyword arguments to be passed to virt
                template create method
        """
        if not self.hypervisor:
            raise exception.ConfigException(
                '"hypervisor" attribute has not defined')

        template = template or self._tempalte
        self._connect_hypervisor()
        test_ip_addr_dict = {}
        test_vf_dev_dict = {}
        host_os = self.hypervisor.host.modules.platform.system().lower()

        for iface in self.iface_list:
            if iface.vswitch not in test_ip_addr_dict:
                test_ip_addr_dict[iface.vswitch] = []

            if host_os == 'vmkernel':
                test_ip_addr_dict[iface.vswitch].append(iface)
            else:
                test_ip_addr_dict[iface.vswitch].append(iface._ip_addr)

        for iface in self.iface_list:
            _x = getattr(iface, 'vnic_pci', None)
            if _x is not None:
                if iface.vnic_pci not in test_vf_dev_dict:
                    test_vf_dev_dict[iface.vnic_pci] = []

                if host_os == 'vmkernel':
                    test_vf_dev_dict[iface.vnic_pci].append(iface)
                else:
                    test_vf_dev_dict[iface.vnic_pci].append(iface._ip_addr)

        _template = self.hypervisor.import_module(
            'virt.lib.common.virtual_machine.template').get_template(template)

        log.debug('Creating a virtual machine %s' % self.name)
        _template.create(name=self.name, test_ip_addr_dict=test_ip_addr_dict,
                         exist=exist, test_vf_dev_dict=test_vf_dev_dict, **kwargs)
        log.debug('\tSuccessfully created %s virtual machine' % self.name)

    def remove(self):
        self._connect_hypervisor()
        log.debug('Removing a virtual machine %s' % self.name)
        self.vmm.remove(self.name)
        log.debug('\tSuccessfully removed a virtual machine %s' % self.name)

    def post_import(self, **kwargs):
        # Do nothing, instead of connecting to the host
        return

    def _connect_hypervisor(self):
        """Connect to the hypervisor"""
        # Connect to the hypervisor if it's not connected yet
        if not self.hypervisor.host or not self.hypervisor.host.connected:
            log.debug('Connecting to a hypervisor %s'% self.hypervisor.mgmt_ip_addr)
            self.hypervisor.connect(init_iface=False)

        # Get the management IP address of a virtual machine
        try:
            vm = self.hypervisor.host.import_module(
                'virt.lib.common.virtual_machine')
        except ImportError:
            raise exception.ConfigException('Failed to import "virt" package. Is it installed?')

        self._vmm = vm.get_vm_manager()

    def connect(self, **kwargs):
        """Connect to the virtual machine

        Here, connect to the hypervisor if it's not connected yet as well as
        updating the management IP address of a virtual machine

        Args:
            **kwargs (kwargs): keyword arguments to be passed to connect()
        """
        self._connect_hypervisor()
        # Get the management IP network
        mgmt_ip_network = (self.hypervisor.mgmt_iface.ip_addr + '/' + str(self.hypervisor.mgmt_iface.prefix))

        # Update the management IP address
        self._mgmt_ip_addr = self.vmm.get_mgmt_ip_addr(
            vm_name=self.name, ip_network=mgmt_ip_network)

        if not self._mgmt_ip_addr:
            log.error('Failed to get the Management Network IP of the VM')
            raise exception.ValueException('Failed to get the management IP of VM')

        super(VirtualMachine, self).connect(**kwargs)

    def exist(self):
        """Return True if virtual machine that has the same name already
        exists otherwise False"""
        if not self.vmm:
            self._connect_hypervisor()

        return self.name in self.vmm.get_vm_list()
