from controller.lib.core.param.nic import Interface
import re
import netaddr
import sys

def get_mac_addr(ip_addr, mgmt_network=False):
    if ip_addr is None:
        return None

    if sys.version_info[0] >= 3:
        u_code =str
    else:
        u_code =str
    if isinstance(ip_addr, (str, u_code)):
        ip_addr = netaddr.IPNetwork(ip_addr)
    # Use b2:<netmask> which is a locally administrated address range
    # CTRL-45362: Automation: Fix the syntax errors identified during Py2.7 to Py3.X
    # porting.
    # Python 3.X doesn't have decode method in string class. So, use alternate ways to build the
    # MAC address of VF's.
    s = ('b4' if mgmt_network else 'b2') + \
        ('00' if mgmt_network else format(ip_addr.prefixlen, '02x')) + \
        format(int(ip_addr.ip), '08x')
    return ':'.join([s[i * 2:(i * 2) + 2] for i in range(6)])

def get_ip_addr(mac_addr):
    if not re.match(r'([0-9a-f]{2}:){5}([0-9a-f]{2})', mac_addr, re.I):
        raise exception.ValueException('MAC address "%s" is invalid' % mac_addr)

    return '.'.join([str(int(octet, 16)) for octet in mac_addr.split(':')[2:]]) + \
        '/' + str(int(mac_addr.split(':')[1]))

def get_hostname(ip_addr=None, mac_addr=None):
    if ip_addr:
        if isinstance(ip_addr, str):
            ip_addr = netaddr.IPNetwork(ip_addr)
    elif mac_addr:
        ip_addr = netaddr.IPNetwork(get_ip_addr(mac_addr))
        f_mac_addr = mac_addr.split(':')[0].lower()

        if f_mac_addr != 'b2' and f_mac_addr != 'b4':
            # Reject invalid MAC address by returning None
            return None

    return 'vm-%s-%s' % (ip_addr.ip.words[2], ip_addr.ip.words[3])

class Vnic(Interface):
    def __init__(self, mac_addr, vswitch, type=None, **kwargs):
        self._vswitch = vswitch
        self._type = type
        super(Vnic, self).__init__(mac_addr=mac_addr, **kwargs)

    @property
    def vswitch(self):
        return self._vswitch

    @property
    def type(self):
        return self._type

class VnicTemplate(Vnic):
    def __init__(self, ip_addr, vswitch, type=None, mac_addr=None, **kwargs):
        mac_addr = mac_addr if mac_addr else get_mac_addr(ip_addr=ip_addr)
        super(VnicTemplate, self).__init__(mac_addr=mac_addr, vswitch=vswitch, ip_addr=ip_addr, type=type, **kwargs)
