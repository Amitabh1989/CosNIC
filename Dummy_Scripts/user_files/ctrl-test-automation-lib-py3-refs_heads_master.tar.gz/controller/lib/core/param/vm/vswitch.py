from virt.lib.common import network


class Vswitch(object):
    def __init__(self, name, mode, **kwargs):
        self._host = None
        self._vswitch = network.get_vswitch(name=name, mode=mode, **kwargs)

    @property
    def vswitch(self):
        return self._vswitch

    def create(self):
        self.vswitch.create()

    def remove(self):
        self.vswitch.remove()
