"""
:mod:`ssh` -- Generic ssh client library
========================================

.. module::controller.lib.core.ssh
.. moduleauthor:: Surender Khetavath <surender.khetavath@broadcom.com>

Following is an example to establish a ssh connection and run commands

>>> from controller.lib.core import ssh

"""

import paramiko

from functools import wraps
from typing import List

from controller.lib.core import log_handler
from controller.lib.core import exception

__version__ = "1.0.0"
__copyright__ = "Copyright (C) 2009-2024 Broadcom Limited"

log = log_handler.get_logger(__name__)


class SSHHandler:
    """
    SSHHandler class

    A base class that accepts IP address to establish a SSH session.
    """
    def __init__(self, ip_addr, username='root', password='', port=None, auto_connect=True, **kwargs):
        """

        :param ip_addr:   Remote host IP address
        :param username:  Username to connect with. Default is 'root'
        :param password:  Password to authenticate using ssh. Default is ''
        :param port:
        :param auto_connect:
        :param kwargs:
        """
        self.ip_addr = ip_addr
        self.username = username
        self.password = password
        self.port = port or paramiko.config.SSH_PORT

        self._connected = False
        self._auto_connect = auto_connect

        self._client = paramiko.SSHClient()
        if 'env' in list(kwargs.items()):
            self.exec_command(f'export PATH=%PATH:{kwargs["env"]}')

        if self._auto_connect:
            self.connect(**kwargs)
        self.data_buffer = ""

    @property
    def conn(self):
        return self._client

    @property
    def connected(self):
        return self._connected

    def connected_only(func, *args, **kwargs):
        @wraps(func)
        def conn_check(self, *args, **kwargs):
            if not self.connected:
                raise exception.SSHException('The host is not connected yet')

            return func(self, *args, **kwargs)

        return conn_check

    def connect(self, **kwargs):

        if self.conn is None:
            self.disconnect()

        self.conn.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        log.debug('Connecting to %s ... ' % self.ip_addr)
        try:
            self.conn.connect(self.ip_addr,
                              username=self.username,
                              password=self.password,
                              port=self.port)
        except paramiko.ssh_exception.NoValidConnectionsError as err:
            log.error('Connection failed. (Error: %s) ' % str(err))
            raise exception.SSHException('Connection to %s failed' % self.ip_addr)
        log.debug('Connection to %s is established' % self.ip_addr)
        self._connected = True
        return True

    def disconnect(self):
        if self.conn is None:
            return True

        log.info('Disconnecting from host %s ... ' % self.ip_addr)
        self.conn.close()
        self._connected = False

        return True

    @connected_only
    def exec_command(self, command, timeout=5, check_exit=True) -> List[str]:
        log.info('Run command "%s"' % command)
        if self.conn is None:
            log.warning("connection obj is None")
            return
        stdin, stdout, stderr = self.conn.exec_command(command, timeout)
        exit_status = stdout.channel.recv_exit_status()
        output = stdout.readlines()
        error = stderr.readlines()
        log.debug('Exit status of {0}: {1}'.format(command, str(exit_status)))
        log.debug('Output of command {0} is: {1}'.format(command, output))
        if check_exit:
            if exit_status != 0 and error:
                if 'File exists' in str(error):
                    return True
                log.error('(Error: %s)' % str(error))
                raise exception.ExeExitcodeException(
                    command=command,
                    exitcode=exit_status,
                    output=output)
        return output
