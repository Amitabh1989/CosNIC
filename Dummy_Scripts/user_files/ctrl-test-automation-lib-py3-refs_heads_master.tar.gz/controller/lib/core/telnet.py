"""
:mod:`telnet` -- Generic telnet library
=======================================

.. module:: beast.lib.general.telnet
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This EI library handles telnet connections by parsing expected prompts.

The base class TelnetHandler requires only three arguments to connect to remote
hosts - IP address, command prompt (e.g. $ or #) and newline characters.

Following is an example to access the iProc LDK SoC through the digi
passport which allows serial access over telnet without asking telnet username
and password.

First, import the telnet module

>>> from controller.lib.core import telnet

And then instantiate the telnet object. You have to pass at least two
arguments - "ip_addr" and "command_prompt".

"ip_addr' is the IP address where telnet should connect to, and
"command_prompt" is a list of regular expressions of expected prompts.

For example, iProc LDK can have three different types of command prompts -
'u-boot> $', '# $' and 'login: $'.

.. warning::

   The command prompt must be UNIQUE and clear so it can tell to the module
   that the executed command is completed and has returned to the shell.

   Good examples::

      '^\[.*\]# $' - Match only if the line starts with '[' and ends with ']# '
      (e.g. "[root@host ~]# ")
      '^# $' - Match only if the entire line exactly matches with '# '
      (e.g. "# ", but not "# This is comment"

   Bad examples::

      '#' - Match anytime when '#' is in the command or output
      (e.g. '# this is comment")

And let's say that my digi passport telnet port number is 7002. Then the
way to instantiate the telnet object is as below:

>>> t = telnet.TelnetHandler(ip_addr='digi-passport-1', port=7002, command_prompt=['u-boot> $', '# $', 'login: $'])

Now you can connect to the remote host using "connect" method

>>> t.connect()
2014-09-02 21:36:43,667 INFO     Connecting to digi-passport-1 ...
True

Please note that this simply means that telnet connection is open. It really
does not reflect any status of the remote host.

Since we are not sure which prompt I am in, let's send a blank command - enter.

>>> t.exec_command('')
(1, '\r\n# ')

"exec_command" method returns a tuple of two elements - an index number of
matched command prompt and the output. As you can see above, it says that the
matched index is 1 - namely the second command_prompt element, '# $' so you can
know that now you are in the shell command.

So now we are in the Linux shell command, so let's exit and see the login
prompt.

>>> t.exec_command('exit')
(2, 'exit\r\n\r\r\nWelcome to Broadcom Linux\r\n\riProc login: ')

As expected, it returns the index 2 ("login: $") and its iProc login prompt.

This is useful when you need to detect which command prompt the remote host is
currently in or run commands differently depending on the prompt.

If it's always expected to see login prompts such as a Cisco switch, you can
include such process in the inherited 'connect' method.

For example, below child class automatically enters username and password when
it logs in to the Cisco switch.

.. code-block:: python

    class Cisco(TelnetHandler):
        def connect(self, username, password):
            super(Cisco, self).connect()  # Open connection to the remote

            if not self.recv(['sername'], timeout=60):  # Expect username prompt
                raise TelnetException('No login prompt is received')
            self.telnet.write(username + self.newline)  # Send username

            if not self.recv(['assword'], timeout=30):  # Expect password prompt
                raise TelnetException('No password prompt is received')
            self.telnet.write(password + self.newline)  # send password

            if not self.recv(self.command_prompt, timeout=30):  # Expect prompt
                raise TelnetException('No command prompt is received')

"""


import telnetlib

from functools import wraps

from controller.lib.core import log_handler
from controller.lib.core import exception


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2014 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class TelnetHandler(object):
    """TelnetHandler class

    A base class that accepts IP address, command prompt and newline character
    as required arguments, since these three are minimum required arguments to
    connect to telnet servers.

    :param str ip_addr: Remote host IP address
    :param list command_prompt: A list of possible command prompt in regular
       expression format.
    :param str newline: A newline character which will be used whenever sending
       commands to the remote host. Default='\r\n'

    """

    telnet_handler_list = []

    def __init__(self, ip_addr, command_prompt, port=23, newline=b'\n'):
        self.ip_addr = ip_addr
        self.port = port
        self.command_prompt = command_prompt if isinstance(
            command_prompt, list
        ) else [command_prompt]
        self.newline = newline

        self._connected = False
        self._telnet = None

        self.telnet_handler_list.append(self)

    @property
    def telnet(self):
        return self._telnet

    @property
    def connected(self):
        """
        Check self._connected whether the connection has ever made before. If
        not, simply return False. If it has been, use self.client.closed to
        track the status which is more accurate and reliable

        :return: True if self.client.closed is False else False
        """

        # If the connection has not been made, simply return False
        return self._connected

    def connected_only(func, *args, **kwargs):
        @wraps(func)
        def conn_check(self, *args, **kwargs):
            if not self.connected:
                raise exception.TelnetException('The host is not connected yet')

            return func(self, *args, **kwargs)

        return conn_check

    @connected_only
    def recv(self, expected, timeout=10):
        """
        telnetlib.Telnet.read_until() does not raise exceptions or return False
        when timeout occurs. This method will return boolean depending on the
        result.

        :param expected: List of expected characters to read until
        :param timeout: timeout
        :return: boolean
        """
        expected = expected if isinstance(expected, list) else [expected]

        index, re_obj, output = self.telnet.expect(expected, timeout)

        if index == -1:
            for line in output.splitlines():
                log.error(line)
            return False

        log.debug('received expect (idx: %s)' % index)
        for line in output.splitlines():
            log.debug(line)
        return True

    def connect(self, **kwargs):
        """
        Since this connect only handles to open connection to the remote server
        additional process might be required for any classes that inherit this
        base class.

        No swallowing exceptions here, and let test modules or EI libraries
        handle them by catching different exception types as they need.

        :return: boolean
        """

        if self.telnet is None:
            self.disconnect()

        log.info('Connecting to %s ... ' % self.ip_addr)
        self._telnet = telnetlib.Telnet(self.ip_addr, self.port, timeout=60)
        self._connected = True
        return True

    def disconnect(self):
        if self.telnet is None:
            return True

        log.info('Disconnecting from host %s ... ' % self.ip_addr)
        self.telnet.close()
        self._telnet = None
        self._connected = False

        return True

    @connected_only
    def exec_command(self, command, timeout=5):
        log.debug('Run command "%s"' % command)

        try:
            self.telnet.write(command + self.newline)
        except telnetlib.socket.error as err:
            log.warning(
                'Connection problem is detected. (Error: %s) '
                'Trying re-connect ... ' % str(err)
            )

            self.connect()
            self.telnet.write(command + self.newline)

        index, ignore, output = self.telnet.expect(self.command_prompt, timeout)
        log.debug(f'Received command prompt: {self.command_prompt[index]}, index: {index}')
        log.debug('Output:')
        for line in output.splitlines():
            log.debug(line)

        return index, output
