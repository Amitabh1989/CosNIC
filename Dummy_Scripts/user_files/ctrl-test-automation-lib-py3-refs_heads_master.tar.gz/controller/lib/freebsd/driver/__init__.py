"""
:mod:`driver` -- FreeBSD driver library
=====================================

.. module:: controller.lib.freebsd.driver
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"


import logging
import os
import re
import time

from controller.lib.common.shell import exe
from controller.lib.core import exception

log = logging.getLogger(__name__)


def load(driver_name, param=None, method='modprobe'):
    """Load driver using modprobe or insmod

    Args:
        driver_name (str): driver name to be loaded. If method is 'insmod',
            driver_name should include absolute path to the driver
        param (dict): parameters that will be passed to drivers as key=value.
        method (str): [modprobe|insmod] use different command to load driver
    """

    cmd = 'kldload'
    rdma_drv = 'bnxt_re'
    # Installing driver in /boot/modules so full build path not needed
    # brcm_drv_path = '/usr/obj/usr/src/amd64.amd64/sys/modules/bnxt/'
    # file = f'{brcm_drv_path}/{driver_name}' if '/' not in driver_name and 'bnxt' in driver_name else driver_name
    file = f"{driver_name}{'.ko' if '/' in driver_name and not driver_name.endswith('.ko') else ''}"
    exe.block_run(f'{cmd} -n -v {file}')
    time.sleep(1)
    if method in ['modprobe', 'kldload'] and str(os.path.basename(driver_name)).replace('.ko', '') == 'if_bnxt':
        try:
            exe.block_run(f'kldstat -q -n {rdma_drv}', silent=True)
        except exception.ExeExitcodeException:
            pass
        else:
            exe.block_run(f'kldunload {rdma_drv}')
            time.sleep(1)
            exe.block_run(f'kldload {rdma_drv}')

    if param:
        # TODO: set via sysctl or kenv (or via /boot/device.hints if driver supports hints)? Assumes full sysctl names
        param_list = [f'{key}={value}' for key, value in list(param.items())]
        for param_str in param_list:
            exe.block_run(f'sysctl {param_str}')


def unload(driver_name, method='rmmod'):
    """Unload driver using modprobe or rmmod

    Args:
        driver_name (str): driver name to be unloaded.
        method (str): [modprobe|rmmod] use different command to unload driver
    """
    _ = method
    # Unload roce driver first if unloading l2 driver
    rdma_drv = 'bnxt_re'
    if rdma_drv not in driver_name and get_memory_usage(rdma_drv):
        exe.block_run(f'kldunload -v {rdma_drv}')
        time.sleep(1)

    # Allow empty roce_driver in sut.iface[].roce_driver yaml config
    if driver_name and get_memory_usage(driver_name):
        exe.block_run(f'kldunload -v {driver_name}')


def get_params(driver_name):
    """Return a list of supported parameters

    Args:
        driver_name (str): driver name
    """

    parms = exe.block_run(f"grep {driver_name.replace('if_', '')}_flags /boot/loader.conf")
    return [parm.split('=')[-1].strip() for parm in parms.splitlines()]


# CTRL-48082: This method is deprecated.

def get_modinfo(driver_name):
    """Return driver information that is returned by kldstat (no modinfo in freebsd)
       Return non-empty dict if driver installed, even if not loaded (kldstat only works if loaded), as some code
       uses this method as an 'is_installed' check

    Eg.
    Id Refs Address                Size Name
    4    1 0xffffffff82a19000    23f08 if_bnxt.ko (/usr/obj/usr/src/amd64.amd64/sys/modules/bnxt/if_bnxt.ko)
        Contains modules:
                 Id Name
                517 bnxt_mgmt
                516 pci/bnxt
    Creates a dictionary with Id, Refs, Address, Size, Name, Path, Modules keys
    'Modules' is a list of dictionaries with keys: Id, Name; one list entry per module

    Args:
        driver_name (str): driver name
    """
    try:
        modinfo = exe.block_run(f"kldstat -v -n {driver_name}")
    except exe.exception.ExeExitcodeException:
        try:
            # All our brcm drivers should be installed (make install) for automation and end up in /boot/modules
            module = exe.block_run(f"ls -l /boot/modules/{driver_name}*", shell=True)
        except exe.exception.ExeExitcodeException:
            return {}
        mod_path = module.splitlines()[-1].split()[-1].strip()
        return {'Name': mod_path.split('/')[-1], 'Path': mod_path, 'version': None,
                'Id': None, 'Refs': None, 'Address': None, 'Size': None, 'Modules': []}

    hdrs = []
    info = []

    modules = []
    for line in modinfo.splitlines():
        if line.startswith('Id '):
            hdrs = line.split() + ['Path']
        elif driver_name in line:
            info = re.sub('[()]', '', line).split()
        elif 'Contains modules' in line or 'Id Name' in line:
            continue
        else:
            modules.append(dict(zip(['Id', 'Name'], line.split())))
    hdrs.append('Modules')
    info.append(modules)

    hdrs.append('version')
    # Only one kernel driver for all interfaces, and roce and l2 driver versions must(?) match
    try:
        version = exe.block_run("sysctl -n dev.bnxt.0.iflib.driver_version").splitlines()[-1].strip()
    except (exe.exception.ExeExitcodeException, IndexError):
        log.warning("Unable to get driver version via sysctl")
        version = None
    info.append(version)

    return dict(zip(hdrs, info))


def get_memory_usage(driver_name):
    """Return the memory usage of the driver - driver must be loaded for this to work

    Args:
        driver_name (str): driver name
    """
    try:
        output = exe.block_run(f'kldstat -v -n {driver_name}')
    except exe.exception.ExeExitcodeException:
        return None

    drv_stat_re = re.search(rf'([0-9a-fA-F]+) {driver_name}', output)
    if drv_stat_re:
        return int(drv_stat_re.group(1), 16)

    return None
