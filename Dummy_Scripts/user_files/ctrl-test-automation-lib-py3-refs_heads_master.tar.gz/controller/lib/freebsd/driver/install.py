"""
:mod:`install` -- FreeBSD driver install/uninstall API
======================================================

.. module:: controller.lib.freebsd.driver.install
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import json
import os
import re
import time

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.freebsd import driver
from controller.lib.freebsd import eth
from controller.lib.freebsd.eth import ethtool

log = log_handler.get_logger(__name__)

# From bnxt driver README:
# Driver Download and Compilation
# ===============================
# 1. Download and unpack driver sources.
#
# 2. Copy the driver sources to the below FreeBSD server location
#    ## cp *.[ch] /usr/src/sys/dev/bnxt/
#
# 3. Copy the Makefile available in the driver source to the below FreeBSD server location.
#    ## cp Makefile /usr/src/sys/modules/bnxt/
#
#    Note: Makefile will be part of driver source folder from 2.23 and its onward releases.
#          For releases lesser than 2.23 use inbox Makefile otherwise, compilation will fail. 
#
# 4. Compile the driver
#    a. ## make -C /usr/src/sys/modules/bnxt clean
#    b. ## make -C /usr/src/sys/modules/bnxt
#
# Additionally, we run make install and remove (rename) the built-in driver to ensure our installed driver is loaded


class InstallBase(object):
    def __init__(self, filename):
        self.filename = filename
        self.drv_name = None
        self.drv_version = None
        self.mod_name = None  # If driver and module name are different

    def install(self, reload=True, bld_dir=''):
        raise NotImplementedError

    def uninstall(self):
        raise NotImplementedError

    def upgrade(self, force=False):
        raise NotImplementedError

    def is_installed(self):
        raise NotImplementedError

    def get_version(self, **kwargs):
        raise NotImplementedError

    def get_package_info(self, pkg_name=None):
        raise NotImplementedError

    @staticmethod
    def get_install(filename, regexp=None, is_roce=False):
        """Return a instantiated class depending on the given filename

                Currently only support the source file type.

                Args:
                    filename (str): A filename with absolute path

                """

        if filename.endswith('tar.gz'):
            return SrcBase(filename, regexp, is_roce)

        if '.' not in filename:
            return PkgBase(filename)

        raise exception.ConfigException(
            'Not supported file type. Currently only support a source tar.gz')

    @staticmethod
    def get_latest_dir(dir_name):
        """Return the latest files that are in the given directory.

                No logic to validate filenames, but simply sort by versions

                Args:
                        dir_name (str): a directory name where files are located

                """
        filename_list = [filename for filename in os.listdir(dir_name)]
        filename_list.sort(key=lambda v: list(map(int, v.split('.'))))

        return filename_list[-1]


class PkgBase(InstallBase):
    def __init__(self, filename, drv_name=None):
        super().__init__(filename)
        self.pkg_name = self.get_package_info()['name']
        self.drv_name = drv_name
        self.mod_name = self.drv_name
        self.drv_version = None
        self.drv_filepath = None

    def install(self, reload=False, bld_dir=None):
        log.info('Install %s ... ', self.filename)
        exe.block_run('pkg install %s' % self.filename)
        # SrcBase args for API consistency
        _ = reload
        _ = bld_dir

    def uninstall(self):
        log.info('Uninstall %s ... ', self.pkg_name)
        exe.block_run('pkg delete %s' % self.pkg_name)

    def upgrade(self, force=False):
        log.info('Upgrading %s ... ', self.filename)
        if force:
            exe.block_run('pkg install --force %s' % self.filename)
        else:
            exe.block_run('pkg upgrade %s' % self.filename)

    def is_installed(self, method=None, drv_name=None):
        log.info("The method = %s", method)
        driver_name = self.drv_name if self.drv_name is not None else drv_name
        if method == 'modinfo':
            drv_info = driver.get_modinfo(driver_name)
            if 'version' not in drv_info:
                raise exception.ValueException('Cannot find "version" information from modinfo output')
            self.drv_version = drv_info['version']
            self.drv_filepath = drv_info['filename']
            return True
        if method == 'ethtool':
            iface_list = eth.get_interfaces_by_driver(driver_name)
            if len(iface_list) == 0:
                raise exception.ConfigException(f'No interfaces are found that use driver {driver_name}')
            iface = iface_list[0]
            drv_info = ethtool.get_drvinfo(iface)
            self.drv_version = drv_info['version']
            return True
        try:
            exe.block_run('pkg info -e %s' % self.pkg_name)
        except exception.ExeExitcodeException:
            return False
        return True

    def get_package_info(self, pkg_name=None):
        ret_dict = {}
        output = ''
        if pkg_name:
            output = exe.block_run('pkg info -R --raw-format json-compact %s' % pkg_name)
        else:
            try:
                output = exe.block_run('pkg info -R --raw-format json-compact -F %s' % self.filename)
            except exception.ExeExitcodeException:
                output = exe.block_run('pkg info -R --raw-format json-compact %s' % self.filename)
        ret_dict = json.loads(output)
        ret_dict['description'] = ret_dict.get('desc', '')

        return ret_dict

    def get_version(self, pkg_name=None):
        pkg_info = self.get_package_info(pkg_name=pkg_name)
        return pkg_info['version']

    def get_release(self, pkg_name=None):
        pkg_info = self.get_package_info(pkg_name=pkg_name)
        return pkg_info['annotations']['FreeBSD_version']

    def get_drv_path(self, pkg_name=None):
        pkg_info = self.get_package_info(pkg_name=pkg_name)
        files = list(pkg_info['files'].keys())
        for file in files:
            if file.endswith('.ko'):
                return file
        return None


class SrcBase(InstallBase):
    """A class for driver installation using tar.gz.

        Accept two arguments; filename and regular expression. Each child class
        can pass regular expression which would be used to extract driver name
        and version. If regexp is None, some methods will not work due to missing
        driver and version information

        Args:
                filename (str): An absolute path to the file.
                        i.e. /tmp/driver-1.0.tar.gz
                regexp (str): regular express to get a driver name and version.
                is_roce (bool): True if installation is for roce driver instead of L2

        """

    def __init__(self, filename, regexp=None, is_roce=False):
        super().__init__(filename=filename)
        self.drv_name = None
        self.mod_name = None
        self.drv_version = None
        self.is_roce = is_roce

        roce_usr_lib = 'libbnxtre'
        if roce_usr_lib in filename:
            self.is_roce = True
        # roce makefile location TBD on future freebsd versions with rdma driver bundled
        self.drv_path = '/usr/src/sys/modules/bnxt/bnxt_re' if self.is_roce else '/usr/src/sys/modules/bnxt'
        # set to base path used in older tarball makefiles for non-roce (bnxt_en/l2) case - will be modified if needed
        self.drv_src = '/usr/src/sys/dev/bnxt/bnxt_re' if self.is_roce else '/usr/src/sys/dev/bnxt'

        regexp = regexp or r'.*/freebsd-(\w+)-([0-9a-zA-Z\.]+)\.tar\.gz'
        if not re.match(regexp, self.filename):
            log.warning('Cannot recognize the filename. (Used regexp %s). Some methods will not be functional.', regexp)
        else:
            self.drv_name, self.drv_version = re.match(regexp, self.filename).groups()
            # RoCE driver name needs to be assigned if user installing roce and tarball is not for roce user lib
            self.drv_name = 'bnxt_re' if self.is_roce and self.drv_name != roce_usr_lib else self.drv_name
            # L2 has different module and driver names
            self.mod_name = self.drv_name if self.is_roce else f'if_{self.drv_name}'

    def install(self, reload=True, bld_dir=''):
        """Download, build and install the driver

        :param reload: Option to skip driver reload after installing new driver, defaults to True
        :param bld_dir: Option to copy src into a custom location for compile, defaults to '' which uses the system
                        folders for the drivers and the tarball extraction folder for the roce user lib
        :raises exception.TestCaseFailure: For compile failure
        :raises exe.exception.ExeExitcodeException on host shell command failures
        :return: True or raise exception
        """
        log.info(f"Installing {self.drv_name}, v{self.drv_version}...")
        if self.drv_name == 'libbnxtre':
            self.drv_path = bld_dir or '.'
            self.drv_src = self.drv_path
        else:
            self.drv_path = bld_dir or self.drv_path
        if bld_dir:
            self.drv_src = self.drv_path

        # Download puts tarball in a unique tmp folder, use it for the untar location too (eg. /tmp/tmpAEfghyeX43)
        log.info(f"Extracting files from {self.filename}...")
        exe.block_run('tar -xvzf ' + self.filename, cwd=os.path.dirname(self.filename))

        # Handle older tarball with bnxt_en only (net folder), vs bnxt_en + bnxt_re tarball
        driver_dirs = ['net', 'bnxt_re' if self.is_roce else 'bnxt_en', 'libbnxtre']
        driver_dir = driver_dirs[0]
        tar_src_dir = f"{self.filename.replace('.tar.gz', '').replace('tgz', '')}"
        for driver_dir in driver_dirs:
            if os.path.exists(f"{tar_src_dir}/{driver_dir}"):
                break
        tar_src_dir += f'/{driver_dir}'
        # Update bld dirs for l2 if this is a newer tarball with both roce and l2 drivers, and with different src paths
        if driver_dir == 'bnxt_en':
            self.drv_src += f'/{driver_dir}'
            self.drv_path += f'/{driver_dir}'

        if bld_dir:
            exe.block_run(f'rm -rf {bld_dir}; mkdir -p {bld_dir}', shell=True)
        elif self.drv_path != '.':
            # Build roce user lib in the tarball extraction location, while roce and l2 drivers are built in system dirs
            # freebsd 12.3, 12.4 do not contain built-in roce driver yet, so make sure folders exist
            exe.block_run(f'rm -rf {self.drv_src}; mkdir -p {self.drv_src}', shell=True)
            exe.block_run(f'rm -rf {self.drv_path}; mkdir -p {self.drv_path}', shell=True)

            exe.block_run(f'cp {tar_src_dir}/Makefile {self.drv_path}/Makefile')
            exe.block_run(f'cp {tar_src_dir}/*.[ch] {self.drv_path if bld_dir else self.drv_src}', shell=True)
        else:
            # Ensure we have an absolute path for use in make calls: translate '.' to the tarball extraction dir
            self.drv_path = tar_src_dir
            self.drv_src = tar_src_dir

        if self.drv_name != 'libbnxtre':
            mod_path = f'/boot/kernel/{self.mod_name}.ko'
        else:
            mod_path = f'/lib/{self.drv_name}.so.1'
        mod_out_path = self.drv_path
        log.info(f"Copied files to, and compiling from, {self.drv_path} ({self.drv_src})")
        try:
            exe.block_run(f'make -C {self.drv_path} clean')
            # Installing (into /boot/modules) seems to still result in original being loaded
            # if it exists in /boot/kernel (built-in driver), so we rename it
            if self.drv_name != 'libbnxtre':
                exe.block_run(f'make -C {self.drv_path} && make -C {self.drv_path} install', shell=True)
                exe.block_run(f'test -f {mod_path} && mv -f {mod_path} {mod_path}.orig || true', shell=True)
            else:
                exe.block_run(
                    f'make -C {self.drv_path} && cp -f {mod_out_path}/{mod_path.rsplit("/", 1)[-1]} {mod_path}',
                    shell=True)
        except Exception as exc:
            log.exception(f"Failed to build {self.drv_name}.ko driver version {self.drv_version} from {self.filename}")
            raise exception.TestCaseFailure('Driver compilation failed, please check host log file') from exc

        if reload and self.drv_name != 'libbnxtre':
            log.info(f"Reloading {self.drv_name} driver")
            try:
                driver.unload('bnxt_re')
            except exe.exception.ExeExitcodeException:
                pass
            try:
                if not self.is_roce:
                    driver.unload(self.mod_name)
            except exe.exception.ExeExitcodeException:
                pass
            time.sleep(2)

            # Load custom driver built in custom location from that location
            module_path = f'{mod_out_path}/' if bld_dir else ''
            driver.load(f'{module_path}{self.mod_name}')
            time.sleep(1)

        if not self.is_installed():
            raise exception.TestCaseFailure(f'{self.drv_name} driver with version:{self.drv_version} is not installed')
        log.info('%s driver with version:%s is installed', self.drv_name, self.drv_version)

        return True

    def uninstall(self):
        """Uninstall a recently installed driver/library - assumes install called previously"""

        if self.drv_name == 'libbnxtre':
            exe.block_run(f'mv -f /lib/{self.drv_name}.so.1 /tmp/{self.drv_name}.so.1')
        else:
            exe.block_run(f'make -C {self.drv_path} uninstall')

    def reinstall(self):
        """To be used after uninstall to put the files back in the install dirs

           Assumes install called prior to uninstall, but will install whatever is in the current build output dir
           Raises ExeExitCodeException if the file was not uninstalled (lbbnxtre not found in tmp dir, or driver
           build dir not populated or missing)
        """
        if self.drv_name == 'libbnxtre':
            exe.block_run(
                f'test -f /tmp/{self.drv_name}.so.1 && mv -f /tmp/{self.drv_name}.so.1 /lib/{self.drv_name}.so.1',
                shell=True)
        else:
            exe.block_run(f'make -C {self.drv_path} install')

    def is_installed(self, method='modinfo', lcomp=None):
        """Return True/False whether driver is installed.

        Args:
        method (str): choices=[modinfo|ethtool] ethtool is obviously only
                                usable for network drivers
        """
        if not self.drv_version or not self.drv_name:
            log.warning(
                'Cannot check driver installation due to missing driver name '
                'and/or driver version information. Return True.')
            return True

        # For roce user lib just verify that the installed file in /lib matches the one in the build dir
        if self.drv_name == 'libbnxtre':
            try:
                exe.block_run(
                    f"md5 -c $(md5 -b /lib/{self.drv_name}.so.1 | cut -d= -f2) {self.drv_path}/{self.drv_name}.so.1",
                    shell=True)
            except exe.exception.ExeExitcodeException:
                return False
            return True

        if method in ['modinfo', 'kldstat']:
            drv_info = driver.get_modinfo(self.mod_name)
            return bool(drv_info)

        if method == 'ethtool' and not self.is_roce:
            iface_list = eth.get_interfaces_by_driver(self.drv_name)
            if len(iface_list) == 0:
                raise exception.ConfigException(f'No interfaces are found that use driver {self.drv_name}')
            iface = iface_list[0]
            drv_info = ethtool.get_drvinfo(iface)
        else:
            raise exception.ValueException('method argument %s is invalid (choices=[modinfo|ethtool])')

        drv_version = drv_info['version']
        return self.drv_version == drv_version

    def get_version(self, **kwargs):
        """Return the driver version of the tarball"""

        version_key = kwargs.get('version_key', 'version')
        return driver.get_modinfo(self.mod_name)[version_key]

    def get_package_info(self, pkg_name=None):
        return super().get_package_info(pkg_name)

    def upgrade(self, force=False):
        return super().upgrade(force)


class FreeBsd(SrcBase):
    def __init__(self, filename, regexp=None, is_roce=False):
        super().__init__(filename, regexp, is_roce)


class FreeBsdPkg(PkgBase):
    def __init__(self, filename):
        super().__init__(filename)


def get_object(filename, regexp=None, is_roce=False):

    with open('/etc/os-release', 'r') as fd:
        os_data = fd.read()
        if 'freebsd' in os_data:
            return FreeBsd(filename, regexp, is_roce)
        log.warning('This OS is not supported')
        return None
