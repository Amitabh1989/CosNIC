"""
:mod:`ethtool` -- Linux tool 'ethtool' wrapper (delegates to ifconfig/sysctl for FreeBSD)
=========================================================================================

.. module:: controller.lib.freebsd.eth.ethtool
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a wrapper module of ethtool.

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import re
import traceback
from typing import Dict, List, Tuple, Union
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.freebsd.eth import ifconfig

log = log_handler.get_logger(__name__)
the_exe = exe


def use_ssh(ssh_ip_addr=None):
    """
    The function that selects the method to use to run the ethtool commands. If ssh_ip_address is
    specified, an SSH connection to that IP adress is established and that connection is used to
    run the ethtool commands. Otherwise, the usual shell exe module is used.

    Args:
        ssh_ip_addr (str): The IP address to use for running ethtool commands over SSH. When None,
        the SSH mode is exited.

    Caution:
        It is the responsibility of the caller to reset the SSH mode by calling this function
        with ssh_ip_addr=None.
    """
    from controller.lib.freebsd.system import ssh
    global the_exe

    if ssh_ip_addr is not None:
        the_exe = ssh.SSH(ssh_ip_addr)
    else:
        if isinstance(the_exe, ssh.SSH):
            the_exe.disconnect()

        the_exe = exe


def exec_ethtool(iface, opt, order=None, **kwargs):
    """Execute ethtool command.

    Args:
        iface (str): ethX name
        opt (str): option to be passed to ethtool. i.e.) '-s'
        order (list): List of keys in kwargs so the parameters are provided
            in order as defined here
        kwargs (kwargs): keyword argument which has key=parameter name and
            value=value. i.e. set_duplex('p1p1', 'full', speed=40000) will
            run "ethtool -s p1p1 duplex full speed 40000".

    """
    # a: pause (sysctl dev.bnxt.X.fc)
    # c: coalesce (sysctl dev.bnxt.4.intr_coal_*)
    # g: rings
    #   kenv dev.bnxt.2.iflib.override_nrxds=2048,256,256; kldunload if_bnxt; kldload /usr..../if_bnxt.ko
    #   dmesg |grep 'bnxt2: Using' => 256 Rx descriptors (dmesg |grep 'bnxt2: netmap queues/slots'; slots==descriptors)
    # k: features (ifconfig <feat>|-<feat>; but limited)
    #   sysctl dev.bnxt.X.hw_lro.* (LRO, GRO)
    # n/u: n-tuple (TBD)
    # w: coredump (bnxtnvm coredump)
    # t: timestamping (TBD)
    # x: hashing (partial: sysctl dev.bnxt.X.rss_type, dev.bnxt.X.rss_key)
    # l: channels (dev.bnxt.X.iflib.override_nrxqs/override_ntxqs; use kenv + driver reload, check with dmesg)
    # m: module-info/media (ifconfig -m <iface> [media <media-value>])
    # f: flash (bnxtnvm install...)
    # --reset: reset (bnxtnvm reset, devctl reset)
    # s: stats
    #   sysctl dev.bnxt.X.hwstats.* (per-queue: txq#/rxq#.*, port: port_stats.*)
    #   sysctl dev.bnxt.X.hwstats.rxq*.tpa_*
    #   sysctl dev.bnxt.X.iflib.rxq#|txq#.* (queue stats/info, not really equivalent to -s)
    # show/set-fec: fec (TBD)

    raise NotImplementedError("ethtool cmd not supported on FreeBSD - specific cmds are redirected to other apps")


def reset(iface):
    """
    Reset the specified interface.

    Args:
        iface (str): ethX name of the interface to reset.
    """
    # TODO: create devctl module
    # -d detaches drivers instead of suspending - check driver readme (suspend not yet supported: 2023/03/09)
    the_exe.block_run(f'devctl reset -d {iface}')


def get_msglvl(iface):
    """Return msglvl

    Args:
        iface (eth): ethX name

    Return:
        int: msglvl in integer

    """
    return ifconfig.get_msglvl(iface)


def set_msglvl(iface, msglvl):
    """Set msglvl

    Args:
        iface (eth): ethX name
        msglvl (hex, int): message level
    """
    ifconfig.set_msglvl(iface, msglvl)


def get_advertised_autonegotiation(iface: str):
    """ Verify if Advertised Auto Negotiation
        is enabled or disabled

    Args:
        iface (eth): ethX name
    """
    return ifconfig.get_advertised_autonegotiation(iface)


def link_status(iface) -> Literal['yes', 'no']:
    """ Link Status function will return the Link state as 'yes' or 'no'

    Args:
        iface (eth): ethX name

    Returns:
        'yes' if link is active, else 'no'. Raises exception unable to query interface
    """
    status = ifconfig.link_status(iface)
    if 'active' in status:
        return 'yes'
    return 'no'


def get_speed(iface) -> int:
    """
    Return link speed of the interface

    Args:
        iface (eth): ethX name

    Returns:
        int: link speed in Mb. -1 for unknown.

    """
    return ifconfig.get_speed(iface)


def get_supported_speeds(iface) -> List[Tuple[str, str]]:
    """
    Return the list of supported speeds on the network interface.
    Args:
        iface (eth): ethX name

    Returns:
        List of tuples with each element containing speed and duplex mode as values.
        speed is an interger in mbps and duplex is either 'Full' or 'Half' as per ethtool output
    """
    speeds_ifconfig = ifconfig.get_supported_speeds(iface)
    duplex_map = {'full-duplex': 'Full', 'half-duplex': 'Half'}
    return [(speed, duplex_map.get(duplex, duplex)) for speed, duplex in speeds_ifconfig] if speeds_ifconfig else None


def set_speed(iface, speed, **kwargs):
    """
    Set speed of the interface.

    Args:
        iface (eth): ethX name
        speed (int): New speed in Mb
    """
    ifconfig.set_speed(iface, speed, **kwargs)


def get_duplex(iface):
    """
    Return duplex mode of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: duplex mode in lower case (which ethtool accepts as values for
           duplex mode setting)
    """
    output = ifconfig.get_duplex(iface)
    return output.replace('-duplex', '')


def set_duplex(iface, duplex, **kwargs):
    """
    Set duplex mode of the interface.

    If showing 'cannot advertise duplex X' error, try to set speed and
    duplex at the same time by using the "set_speed_and_duplex" function

    Args:
        iface (str): ethX name
        duplex (str): duplex mode. choices=[full|half]
    """
    ifconfig.set_duplex(iface, duplex, **kwargs)


def get_stats(iface):
    """
    Return statistics of the interface, as sysctl returns since
    output format is different per NIC type

    Args:
        iface (str): ethX name

    Returns:
        str containing the stats
    """
    # TODO: Create sysctl module and move implementation
    drv, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    return the_exe.block_run(f'sysctl dev.{drv}.{iface_id}.hwstats')


def get_drvinfo(iface):
    """Return driver name, version and firmware versions

    Args:
        iface (str): ethX name

    Return:
        dict: key=name, version, firmware. value = values
    """
    # TODO: Create sysctl module and move implementation
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    device = f'dev.{drv_name}.{iface_id}'
    drv_ver = the_exe.block_run(f'sysctl -n {device}.iflib.driver_version').strip()
    hwrm_if = the_exe.block_run(f'sysctl -n {device}.ver.hwrm_if').strip()
    # drv_version = f'{hwrm_if}-{drv_ver}'
    fw_data = the_exe.block_run(f'sysctl -n {device}.ver.fw_ver').strip()
    fw_version, pkg_version = list(map(lambda x: x.strip(), fw_data.split('/pkg ')))

    return {'name': f'if_{drv_name}', 'version': drv_ver, 'hwrm_version': hwrm_if,
            'firmware': fw_version, 'pkg_version': pkg_version}


def get_features(iface) -> Dict[str, Tuple[str, bool]]:
    """
    Return ethtool features output. Return value is a dictionary which has a
    tuple as values (<status>, <fixed>)

    <status> is either 'on' or 'off'
    <fixed> is True or False depending on it's a fixed value or not.

    Args:
        iface (str): ethX name

    Returns:
        dict: key=feature name, value=(<status=on|off>, <fixed=bool>)
    """
    features = ifconfig.get_features(iface)
    feat_dict = {}
    for feat in features:
        # Replicate the ethtool dictionary: {field: (on|off, <fixed:bool>)}
        feat_dict[feat.replace('-', '')] = ('off' if feat.startswith('-') else 'on', 'jumbomtu' in feat)

    log.debug(f"ethtool:Features Dict[{iface}]: {feat_dict}")

    return feat_dict


def set_features(iface, feature, value):
    """
    Set offload feature settings. No error checking about changing settings
    for "fixed" features, but raise exe exception as it is.

    Args:
        iface (str): ethX name
        feature (str): Feature name. e.g.) tx-checksumming
        value (str): choices=[on|off] as ethtool -k returns

    """
    ifconfig.set_feature(iface, feature, value)


def get_coalesce(iface):
    """
    Return coalesce parameters as a dictionary.

    Args:
        iface (str): ethX name

    Return:
        dict: key=param, value=value

    """
    # TODO: sysctl module
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    output = the_exe.block_run(f'sysctl dev.{drv_name}.{iface_id} | grep intr_coal_', shell=True).strip()
    ret_dict = {
        intr_coal[0]: int(intr_coal[1])
        for line in output.splitlines() if line.startswith('dev.') for intr_coal in [line.split('.')[-1].split(':')]
    }

    # TODO: TBD:adaptive-rx/tx
    # for param, value in re.findall(r'(.*):\s+(.*)', output):
    #     if re.match(r'\d+', value):  # param, values
    #         ret_dict[param] = int(value)
    #     elif value.startswith('Adaptive'):
    #         rx, tx = re.search(r'Adaptive\s+RX:\s+(.*)\s+TX:\s+(.*)', value).groups()
    #         ret_dict['adapt_rx'] = rx.strip()
    #         ret_dict['adapt_tx'] = tx.strip()
    return ret_dict


def set_coalesce(iface, param: str, value: Union[str, int]):
    """Set coalesce parameter.

    Args:
        iface (str): ethX name
        param (str): parameter name i.e.) rx-frames or intr_coal_rx_frames
        value (str, int): str for adapt_rx and adapt_tx and int for all other parameters.
        FreeBSD support: intr_coal_tx_frames_irq, intr_coal_tx_usecs_irq, intr_coal_tx_frames, intr_coal_tx_usecs
        (same for rx)
        TBD: Adaptive Rx/Tx parameters?
    """
    # TODO: sysctl
    param = f"intr_coal_{param.replace('intr_coal_', '')}".replace('-', '_')
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    the_exe.block_run(f'sysctl dev.{drv_name}.{iface_id}.{param}={value}')


def get_pause(iface, raw=False):
    """Return pause options

    Args:
        iface (str): ethX name

    Return:
        dict: auto_neg, rx, tx, rx_neg, tx_neg keys and values
    """
    # TODO: sysctl module
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    output = the_exe.block_run(f'sysctl dev.{drv_name}.{iface_id}.fc').strip()
    ret_dict = {
        pause_param[0]: pause_param[1].strip() if raw else ('on' if pause_param[1].strip() == '1' else 'off')
        for line in output.splitlines() if line.startswith('dev.') for pause_param in [line.split('.')[-1].split(':')]
    }
    # TODO: Not available in FreeBSD?
    ret_dict['rx_neg'] = ret_dict['rx'] if ret_dict['autoneg'] else ('0' if raw else 'off')
    ret_dict['tx_neg'] = ret_dict['tx'] if ret_dict['autoneg'] else ('0' if raw else 'off')

    # ret_dict = {}
    # key_mapping = {
    #     'Autonegotiate': 'autoneg',
    #     'RX': 'rx',
    #     'TX': 'tx',
    #     'RX negotiated': 'rx_neg',
    #     'TX negotiated': 'tx_neg',
    # }

    return ret_dict


def set_pause(iface, **kwargs):
    """Set pause options

    Args:
        iface (str): ethX name
        **kwargs (kwargs): key=parameter, value=value

    """
    # TODO: sysctl dev.bnxt.X.fc.*
    raw = kwargs.get('raw', False)
    curr_cfg = {}
    curr_cfg = get_pause(iface, raw=raw)

    for key in list(kwargs.keys()):
        log.debug(('flow_control:%s, curr_cfg:%s, req_cfg:%s', key, curr_cfg[key], kwargs[key]))

        if curr_cfg[key] == kwargs[key]:
            log.debug(('%s flow control already %s', key, curr_cfg[key]))
            kwargs.pop(key)

    if len(kwargs) != 0:
        errors = []
        drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
        for param, value in kwargs.items():
            raw_value = value if raw else ('1' if value == 'on' else '0')
            try:
                the_exe.block_run(f'sysctl dev.{drv_name}.{iface_id}.fc.{param}={raw_value}')
            except exception.ExeExitcodeException as exc:
                errors.append((exc, traceback.format_exc()))

        if errors:
            err_msg = ''
            for error in errors:
                err_msg += f'\nFailed to set sysctl parameter. Exception: {error[0]}\n{error[1]}'
            raise exception.ExeException(
                f'Setting one or more pause parameters failed with the following exceptions:{err_msg}')
        # try:
        #     exec_ethtool(iface=iface, opt='-A', **kwargs)
        # except exception.ExeExitcodeException as err:
        #     if err.exitcode == 78:
        #         raise exception.EthtoolNoChanges(err.output)
        #     elif 'no pause parameters changed' in err.output:
        #         raise exception.EthtoolNoChanges(err.output)

        #     raise
    else:
        log.debug(f'set_pause ({kwargs}): Nothing to configure')


def get_channels(iface, raw=False) -> Union[Dict[str, int], Dict[str, Dict[str, int]]]:
    """Return channel information

    Args:
        iface (str): ethX name
        raw (bool): Use and return the built-in values in a single level dictionary of
                    rx, tx, other (not supported: 0), combined values
                    Otherwise, replicates the linux API ('ethtool -l' based) returning preset and curset sub-dicts

    Return:
        dict: key=queue_type, value=preset, curset. If querying channels is
            not supported, return None

    """
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    ret_dict = {'preset': {}, 'curset': {}}
    data = {'other': 0, 'combined': 0, 'rx': 0, 'tx': 0}

    try:
        unique = int(the_exe.block_run(
            f'sysctl dev.{drv_name}.{iface_id}.iflib.override_qs_enable').split(':')[-1].strip())
        data['rx'] = int(the_exe.block_run(f'sysctl dev.{drv_name}.{iface_id}.iflib.override_nrxqs')
                         .split(':')[-1].strip())
        data['tx'] = int(the_exe.block_run(f'sysctl dev.{drv_name}.{iface_id}.iflib.override_ntxqs')
                         .split(':')[-1].strip())
    except exception.ExeExitcodeException as err:
        if 'not supported' in err.output:
            log.warning('Not supported')
            return None
        raise
    # Get the max rxq#/txq# entries using cpu field for simplicity, in case where override was not used (0)
    for q in ['rx', 'tx']:
        if data[q] == 0:
            cmd = f'sysctl -N dev.{drv_name}.{iface_id}.iflib | grep .{q}q | grep .cpu'
            queue_out = the_exe.block_run(cmd, shell=True).strip()
            data[q] = max(int(queue) for queue in re.findall(rf'.iflib.{q}q(\d+).cpu', queue_out)) + 1
    data.update({'other': 0, 'combined': min(data['rx'], data['tx']) if not unique else 0})
    if raw:
        ret_dict = data
    else:
        # preset maximums are not directly available in FreeBSD - just return zeroes
        ret_dict.update({'curset': data, 'preset': {'other': 0, 'combined': 0, 'rx': 0, 'tx': 0}})

    # for queue_type in ['RX', 'TX', 'Other', 'Combined']:
    #     preset, curset = [int(queue) if len(queue) > 0 else 0
    #                       for queue in re.findall(r'%s:[\s\t]+(\d+)?' % queue_type, output)]
    #     ret_dict['preset'][queue_type.lower()] = preset
    #     ret_dict['curset'][queue_type.lower()] = curset

    return ret_dict


def set_channels(iface, channel_settings: Dict[str, int]):
    """Configure the channel using the given parameter.

    Args:
        iface: interface name
        channel_settings (dict): new channel settings. The format of the
            expected channel_settings is same as the return value of
            get_channels() (curset)
    """
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    if channel_settings['combined'] > 0:
        separate = 0
        rxq = channel_settings['combined']
        txq = channel_settings['combined']
    else:
        separate = 1
        rxq = channel_settings['rx']
        txq = channel_settings['tx']
    the_exe.block_run(f'kenv dev.{drv_name}.{iface_id}.iflib.override_qs_enable={separate}')
    the_exe.block_run(f'kenv dev.{drv_name}.{iface_id}.iflib.override_nrxqs={rxq}')
    the_exe.block_run(f'kenv dev.{drv_name}.{iface_id}.iflib.override_ntxqs={txq}')
    the_exe.block_run('kldunload if_bnxt && kldload if_bnxt', shell=True)


def get_rxfh_indir_table(iface):
    """
    Retrieves the receive flow hash indirection table and/or RSS hash key.
    :param iface: iface name
    :return:
    """
    ret_dict = {}
    table = {}
    ret_dict['table'] = table
    log.warning("rx flow hash indirection table not available on FreeBSD")

    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    output = the_exe.block_run(f'sysctl -n dev.{drv_name}.{iface_id}.rss_key').strip()
    ret_dict['key'] = output

    return ret_dict


def set_rxfh_indir_table(iface, hkey=None, start=None, equal=None, weight=None,
                         hfunc=None, context=None, delete=None):
    """
    Configures the receive flow hash indirection table and/or
              RSS hash key.

        ethtool -X|--set-rxfh-indir|--rxfh devname
              [hkey xx:yy:zz:aa:bb:cc:...]  [start N] [ equal N |
              weight W0 W1 ... | default ] [hfunc FUNC] [context CTX
              | new] [delete]
    :param iface: iface name
    :param hkey: RSS hash key of the specified network device
    :param start: For the equal and weight options, sets the starting
                  receive queue for spreading flows to N
    :param equal: Sets the receive flow hash indirection table to spread
                  flows evenly between the first N receive queues.
    :param weight: Sets the receive flow hash indirection table to spread
                  flows between receive queues according to the given
                  weights.  The sum of the weights must be non-zero and
                  must not exceed the size of the indirection table.
    :param hfunc: RSS hash function of the specified network
                  device
    :param context: RSS context to act on; either new to
                  allocate a new RSS context
    :param delete: Delete the specified RSS context
    :return:
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    options = list()
    if hkey:
        options.append(f'hkey {hkey}')

    if get_ethtool_version() >= '5.6':
        if start and (equal or weight):
            options.append(f'start {start}')

    if equal:
        options.append(f'equal {equal}')
    elif weight:
        options.append(f'weight {weight}')
    else:
        options.append(f'default')

    if hfunc:
        options.append(f'hfunc {hfunc}')

    if context:
        if delete:
            options.append(f'context {context} delete')
        else:
            options.append(f'context {context}')

    command = f'ethtool -X {iface} {" ".join(options)}'
    the_exe.block_run(command)


def get_ring(iface):
    """Return ring information

    Args:
        iface (str): ethX name

    Return:
        dict: key=queue type, value=preset, curset. If querying ring is not
            supported, return None
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    ret_dict = {'preset': {}, 'curset': {}}

    try:
        output = the_exe.block_run('ethtool -g %s' % iface)
    except exception.ExeExitcodeException as err:
        if 'not supported' in err.output:
            log.warning('Not supported')
            return None
        raise

    for queue_type in ['RX', 'RX Mini', 'RX Jumbo', 'TX']:
        preset, curset = [int(ring) for ring in re.findall(r'%s:[\s\t]+(\d+)' % queue_type, output)] or [0, 0]
        ret_dict['preset'][queue_type.lower()] = preset
        ret_dict['curset'][queue_type.lower()] = curset

    return ret_dict


def set_ring(iface, ring_settings):
    """Configure the ring parameters using the given parameter.

    Args:
        iface: "Interface name"
        ring_settings (dict): new channel settings. The rx and tx dictionary items of "curset"
    """
    # See 58434
    raise NotImplementedError("Not yet implemented for FreeBSD - requires driver reload to modify")

    settings = ' '.join(['%s %s' % (param, value) for param, value in list(ring_settings.items())])

    try:
        the_exe.block_run('ethtool -G %s %s' % (iface, settings))
    except exception.ExeExitcodeException as err:
        if 'no ring parameters changed, aborting' in err.output:
            pass
        else:
            raise


def get_nvram_dump(iface):
    """Dump NVRAM

    Args:
        iface (str): ethX name
    """
    raise NotImplementedError("Not implemented for FreeBSD")

    return the_exe.block_run('ethtool -e %s' % iface)


def get_core_dump(iface, core_path):
    """
    Generate coredump using the specified interface.

    Args:
        iface (str)    : The interface to use to generate coredump.
        core_path (str): The path to the resulting coredump file.
    """
    raise NotImplementedError("Not implemented for FreeBSD")

    command = 'ethtool -w %s data %s' % (iface, core_path)
    return the_exe.block_run(command, shell=True)


def get_iface_medium(iface):
    """ Get the medium details

    Args:
        iface (str): eth name

    Return:
        Interface medium [FIBRE/TP]
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    output = the_exe.block_run('ethtool %s' % iface)

    if re.search(r'\s*Supported ports:(\s*.*)', output):
        raw_medium = re.search(r'\s*Supported ports:(\s*.*)', output).group(1)
        medium = raw_medium.strip(' []')
        return medium
    else:
        log.error('Could not find the medium')

    return None


def add_mac_filter(iface, **kwargs):
    """
    Add a MAC filter rule with the specified L2 parameters.

    Args:
        iface (str): ethX name
        flow_type (str): Type of flow to filter; Default = 'ether'
        src_mac (str): Destination MAC address to use for filtering.
        dst_mac (str): Destination MAC address to use for filtering.
        vlan_id (int): vLAN ID to use for filtering.
        protocol (str): Ethertype to use for filtering.
        action (str): Action to take on rule hit; Default = -1 (drop).
    Return:
        test_status: True on success; False on failure.
        rule_id: The ID of the filter rule created on success; -1 on failure.
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    test_status = False
    rule_id = 0
    flow_type = kwargs.get('flow_type', 'ether')
    src_mac = kwargs.get('src_mac', None)
    dst_mac = kwargs.get('dst_mac', None)
    vlan_id = kwargs.get('vlan_id', None)
    vlan_id_mask = 0xf000
    protocol = kwargs.get('protocol', None)
    action = kwargs.get('action', -1)
    # If no parameter is specified, no filter can be created.
    if src_mac is None and dst_mac is None and protocol is None:
        raise exception.ConfigException('No parameter specified for filtering.')
    # If specified, build and execute the command.
    command = 'ethtool -U %s flow-type %s' % (iface, flow_type)
    command += '' if src_mac is None else (' src %s' % src_mac)
    command += '' if dst_mac is None else (' dst %s' % dst_mac)
    command += '' if vlan_id is None else (' vlan %s vlan-mask %s' % (vlan_id, vlan_id_mask))
    command += '' if protocol is None else (' src %s' % protocol)
    command += ' action %s' % action
    command_output = the_exe.block_run(command, shell=True)
    re_obj = re.search(r'Added rule with ID (\d+)', command_output)
    if 'Input/output error' in command_output:
        rule_id = -1
        re_obj = None
    else:
        re_obj = re.search(r'Added rule with ID (\d+)', command_output)
    # If the rule is successfully created, get the rule ID.
    if re_obj is not None:
        test_status = True
        rule_id = re_obj.group(1)

    return test_status, rule_id


def delete_mac_filter(iface, rule_id):
    """
    Delete the specified filter rule on the specified interface.

    Args:
        iface: The name of the interface to delete the filter rule on.
        rule_id: The ID of the rule to delete.
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    command = 'ethtool -U %s delete %s' % (iface, str(rule_id))
    the_exe.block_run(command, shell=True)
    return True


def list_mac_filters(iface, ntuple=False):
    """
    Get the list of MAC filter rules of the specified interface.

    Args:
        iface (str): ethX name
        ntuple:
    Return:
        rules_count: Number of rules available.
        mac_addresses: The list of destination MAC addresses used in the rules.
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    mac_addresses, filter_queue, rule_type = ([] for _ in range(3))
    rules_count = 0
    command = 'ethtool -u %s' % iface
    command_output = the_exe.block_run(command, shell=True).strip()
    rules_count = int(re.search(r'Total (\d+) rules', command_output).group(1))
    # If there are any rules, list them.
    if ntuple is True:
        if rules_count > 0:
            # expr = "Action: Direct to queue (.*)"
            filter_queue = re.findall(r"Action: Direct to queue (.*)", command_output)
            # expr = "Rule Type: (.*) over (.*)"
            rule_type = re.findall(r"Rule Type: (.*) over (.*)", command_output)
        return filter_queue, rule_type
    else:
        if rules_count > 0:
            mac_addresses = re.findall(r'Dest MAC addr:\s+([0-9a-zA-Z:]+)', command_output)
        return rules_count, mac_addresses


def set_rx_flow_hash(iface, flow_type, tuple_type):
    """
    Configures receive network flow classification options.
    Args:
        iface (str): ethX name
        flow_type (str): flow type. Ex: tcp4, udp4 etc
        tuple_type (str): tuple type. Ex: sd, sdfn etc
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    command = f'ethtool -U {iface} rx-flow-hash {flow_type} {tuple_type}'
    the_exe.block_run(command)


def get_rx_flow_hash(iface, flow_type):
    """
    Retrieves receive network flow classification options.
    Args:
        iface (str): ethX name
        flow_type (str): flow type. Ex: tcp4, udp4 etc
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    flow_hash = {}
    command = f'ethtool -u {iface} rx-flow-hash {flow_type}'
    output = the_exe.block_run(command)
    protocol_ipv = re.search(r'.*(TCP|UDP).*(IPV4|IPV6).*', output)
    if protocol_ipv:
        flow_hash['protocol'], flow_hash['ipv'] = protocol_ipv.groups()
        flow_hash['tuple'] = re.findall(r'.*(SA|DA|src\s+port|dst\s+port).*', output)
    return flow_hash


def add_tuple_filter(iface, **kwargs):
    """
    Add a tuple filter rule with the specified L2 parameters.

    Args:
        iface (str): ethX name
        protocol (str): Protocol to use for filtering, default(TCP).
        src_port (str): Source port number.
        dst_port (str): Destination port number.
        src_port (str): Source ipv4/v6 address.
        dst_port (str): Destination ipv4/v6 address.
        l4_proto (str): ICMP port number

    Return:
        test_status: True on success; False on failure.
        rule_id: The ID of the filter rule created on success; -1 on failure.
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    test_status = False
    rule_id = -1
    flow_type = kwargs.get('protocol', None)
    src_port = kwargs.get('src_port', None)
    src_port_mask = kwargs.get('src_port_mask', None)
    dst_port = kwargs.get('dst_port', None)
    dst_port_mask = kwargs.get('dst_port_mask', None)
    src_ip = kwargs.get('src_ip', None)
    src_ip_mask = kwargs.get('src_ip_mask', None)
    dst_ip = kwargs.get('dst_ip', None)
    dst_ip_mask = kwargs.get('dst_ip_mask', None)
    l4_proto = kwargs.get('l4_proto', None)
    action = kwargs.get('rx_que', None)
    # If no parameter is specified, no filter can be created.
    if action is None and flow_type is None:
        raise exception.ConfigException('No  action ring or/and flow_type specified for filtering.')
    # If specified, build and execute the command.
    command = 'ethtool -N %s flow-type %s' % (iface, flow_type)
    command += '' if src_ip is None else (' src-ip %s' % src_ip)
    command += '' if src_ip_mask is None else (' src-ip-mask %s' % src_ip_mask)
    command += '' if dst_ip is None else (' dst-ip %s' % dst_ip)
    command += '' if dst_ip_mask is None else (' dst-ip-mask %s' % dst_ip_mask)
    command += '' if src_port is None else (' src-port %s' % src_port)
    command += '' if dst_port_mask is None else (' src-port-mask %s' % src_port_mask)
    command += '' if dst_port is None else (' dst-port %s' % dst_port)
    command += '' if dst_port_mask is None else (' dst-port-mask %s' % dst_port_mask)
    command += '' if l4_proto is None else (' l4proto %s' % l4_proto)
    command += ' action %s' % action

    try:
        command_output = the_exe.block_run(command, shell=True)
    except Exception as e:
        return test_status, e

    re_obj = re.search(r'Added rule with ID (\d+)', command_output)
    # If the rule is successfully created, get the rule ID.
    if re_obj is not None:
        test_status = True
        rule_id = re_obj.group(1)
    else:
        rule_id = command_output

    return test_status, rule_id


def get_tuple_list(iface):
    """
       Return the n tuple info.
       Args:
           iface (str): ethX name.
       """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    cmd = f"ethtool -n {iface}"
    return the_exe.block_run(cmd, shell=True, silent=True).rstrip()


def get_bus_info(iface):
    """
    Return the PCI BDF of the specified interface.

    Args:
        iface (str): ethX name.
    Return:
        The PCI BDF of the interface specified.
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    command = 'ethtool -i %s' % iface
    command_output = the_exe.block_run(command)
    command_output = re.findall(r'bus-info: ([\w:\.]+)', command_output)
    return command_output[0] if len(command_output) == 1 else None


def get_module_info(iface):
    """
    Return the cable info
    Args:
        iface (str): ethX name.
    Return:
        cable info in dict format
    """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    output = the_exe.block_run('ethtool -m %s' % iface)
    module_info = {param.strip(): value.strip() for param, value in re.findall(r'(.*)\s+:\s+(.*)', output)}
    return module_info


def get_ethtool_version():
    """
    Return:
        ethtool version info in str format
    """
    raise NotImplementedError("Not implemented for FreeBSD")

    output = the_exe.block_run('ethtool --version')
    version = re.search(r'\d+.?(\d+)?', output).group(0)
    return version


def set_private_flags(iface):
    """
       Enable the numa direct on interface in MR.
       Args:
           iface (str): ethX name
       """
    raise NotImplementedError("Not implemented for FreeBSD")

    command = f"ethtool --set-priv-flags {iface} numa_direct on"
    the_exe.block_run(command)


def get_private_flags(iface):
    """
      Get the numa direct status of interface in MR.
       Args:
           iface (str): ethX name
       """
    raise NotImplementedError("Not implemented for FreeBSD")

    command = f"ethtool --show-priv-flags {iface}"
    output = the_exe.block_run(command)
    return re.search(r'numa_direct:\s+(\w+)', output).group(1)

def generate_coredump_ethtool(iface, file_name, flag=1):

    """
      Get the coredump output
       Args:
           iface (str): ethX name
           file_name (str): core file name
           flag : accepted values are 0 or 1
       """
    raise NotImplementedError("Not yet implemented for FreeBSD")

    dump_output = None
    dump_level = None
    try:
        command = "ethtool -W {} {}".format(iface.name, flag)
        dump_level = the_exe.block_run(command)
    except Exception as e:
        dump_level = str(e)
    command = f"ethtool -w {iface.name} data {file_name}"
    log.info("executing the command %s" % command)
    try:
        dump_output = the_exe.block_run(command)
    except Exception as e:
        dump_output = str(e)
    return dump_output, dump_level