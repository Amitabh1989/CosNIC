"""
:mod:`ifconfig` -- FreeBSD tool 'ifconfig' wrapper
==================================================

.. module:: controller.lib.freebsd.eth.ifconfig
.. moduleauthor:: Albert To <albertt@broadcom.com>

This module is a simple wrapper around 'ifconfig' tool which can be used for
configuring IP address, MTU, MAC address, etc.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"


import re
import time
from typing import List, Optional, Tuple, Union
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe


log = log_handler.get_logger(__name__)


def set_ip_addr(iface: str, ip_addr: str, netmask: Union[int, str] = None, method='change', is_ipv6=False):
    """
    Set IP address to the given iface. Not using IOCTL to test the application
    layer, namely "ifconfig"

    Args:
        iface (str): ethX name
        ip_addr (str): IP address in the X.X.X.X format
        netmask (int, str): Netmask in X.X.X.X or /XX format. If ipv6 is True,
           should be prefixlength. If None, not passing netmask parameter.
        method (str): [add|change|replace|del] as "ifconfig" command accepts to
           assign a new IP address.
        is_ipv6 (bool): Configure IPv6 address if True else IPv4

    Returns:
        str: Output of ifconfig command

    """

    if isinstance(netmask, str) and re.match(r'\d+\.\d+\.\d+\.\d+', netmask):
        netmask = sum([bin(int(x)).count('1') for x in netmask.split('.')])

    # Do not check parameter values further. Let "ifconfig" tool raise exceptions if any parameters are incorrect.
    # if is_ipv6 and re.match('add|del', method):
        # return exe.block_run(
        #     'ifconfig %s %s %s %s%s' % (
        #         iface, 'inet6', method, ip_addr,
        #         '/' + str(netmask) if netmask else ''
        #     )
        # )
    ip4_cidr = f"{ip_addr}{f'/{netmask}' if netmask and not is_ipv6 else ''}"
    ip6_prefix = f"{f' prefixlen {netmask}' if netmask and is_ipv6 else ''}"
    inet_type = f"inet{'6' if is_ipv6 else ''}"
    if method == 'add':
        op = exe.block_run(f"ifconfig {iface} {inet_type} {ip_addr if is_ipv6 else ip4_cidr}{ip6_prefix} {method}")
        if 'tentative' in exe.block_run(f"ifconfig {iface}"):
            time.sleep(0.2)
            for i in range(20):
                if 'tentative' not in exe.block_run(f"ifconfig {iface}"):
                    break
                time.sleep(0.2)
            else:
                log.warning(f'{iface} IPv6 stuck in "tentative" state')
        return op
    if method == 'del':
        return exe.block_run(f"ifconfig {iface} {inet_type} {ip_addr} delete")
    # TODO: Doesn't replace, just adds. Need to parse and remove all(?) existing inet[6] entries, then add
    if re.match('change|replace', method):
        return exe.block_run(f"ifconfig {iface} {inet_type} {ip_addr if is_ipv6 else ip4_cidr}{ip6_prefix}")

    raise exception.IPException(
        '%s method is NOT supported for %s address family' % (
            method, 'IPv6' if is_ipv6 else 'IPv4'
        )
    )


def get_ip_addr(iface: str, is_ipv6=False, is_netmask=False):
    """
    Return a list of IP addresses.

    Args:
        iface (str): ethX name
        is_ipv6 (bool): Get IPv6 address if True else IPv4
        netmask (bool): Return netmask along with its IP address

    Returns:
        list: IP addresses
        list: tuple of (IP address, netmask) if netmask is True

    """

    re_match_ip = r'inet6\s+([a-fA-F0-9:]+)' if is_ipv6 else r'inet\D+(\d+\.\d+\.\d+\.\d+)'
    re_match_mask = r'inet6\s+[a-fA-F0-9:]+\D+(\d+)' if is_ipv6 else r'[Mm]ask\D+(\d+\.\d+\.\d+\.\d+)'

    # TODO: Change to inet:cidr and inet6:cidr and update regex
    # What about link local IPs - make sure not first in list?
    output = exe.block_run(f'ifconfig -f inet:dotted {iface}')
    ip_addr_list = []
    for line in output.splitlines():
        ip_addr_data = ['', '']
        ip_match = re.search(re_match_ip, line)
        if not ip_match:
            continue
        ip_addr_data[0] = ip_match.group(1)
        if is_netmask:
            ip_addr_data[1] = re.search(re_match_mask, line).group(1)
        # Ensure link local IPs are at the end of the list, since users typically take the first IP
        if is_ipv6 and ip_addr_data[0].startswith('fe80::'):
            ip_addr_list.append(ip_addr_data)
        else:
            ip_addr_list.insert(0, ip_addr_data)

    return ip_addr_list


def get_mac_addr(iface: str):
    """
    Get MAC address of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: MAC address in XX:XX:XX:XX:XX:XX format

    """
    output = exe.block_run(f'ifconfig -f inet:dotted {iface}')

    try:
        # CTRL-40596: MAC Address is returned as None when using api get_mac_addr.
        # Use the correct regex to fetch the MAC address.
        return re.search(r'(ether|HWaddr)\s+([a-fA-F0-9:]+)', output).group(2)
    except Exception as exc:
        raise exception.IPException('Cannot find MAC address') from exc


def set_mac_addr(iface: str, mac_addr):
    """
    Set MAC address of the interface

    Args:
        iface (str): ethX name
        mac_addr (str): New MAC address in XX:XX:XX:XX:XX:XX format

    """

    if not re.match('[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}',
                    mac_addr):
        raise ValueError(f'MAC address must be in XX:XX:XX:XX:XX:XX format (input: {mac_addr})')

    exe.block_run(f'ifconfig {iface} ether {mac_addr}')


def get_state(iface: str):
    """
    Return "State" of the interface

    Args:
        iface (str): ethX name

    Returns:
        str: State

    """

    flags = get_flags(iface)
    state = 'UP'
    if state in flags:
        return 'up'
    return 'down'


def get_mtu(iface: str):
    """
    Return MTU of the interface

    Args:
        iface (str): ethX name

    Returns:
        int: MTU size

    """

    output = exe.block_run(f'ifconfig {iface}')
    try:
        return int(re.search(r'mtu\s+(\d+)', output).group(1))
    except AttributeError as exc:
        raise exception.IPException('Cannot find MTU information') from exc


def set_mtu(iface: str, mtu):
    """
    Set MTU of the interface

    Args:
        iface (str): ethX name
        mtu (int): MTU size

    """

    exe.block_run(f'ifconfig {iface} mtu {mtu}')


def set_state(iface: str, state):
    """
    Set "State" of the interface

    Args:
        iface (str): ethX name
        state (str): State to set ('up' or 'down').

    """

    exe.block_run(f'ifconfig {iface} {state}')


#
# linux ip -> freebsd ifconfig
#
def add_vlan(iface: str, vlan_id: int, lower_kernel=False, name=None, proto='802.1Q') -> str:
    """
    Remove vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID

    """
    _ = lower_kernel
    _ = proto
    if name:
        vlan_name = name
    else:
        vlan_name = f'vlan{vlan_id}'  # FreeBSD requires interface names of form '<knl mod name>#'

    command = f'ifconfig {vlan_name} create vlan {vlan_id} vlandev {iface}'
    try:
        exe.block_run(command)
    except exception.ExeExitcodeException as exc:
        # CTRL-46702: [Automation-RoCE]: Script fails while trying to add already existing vlan
        # interface.
        # If vLAN interface already exists, ignore the error and reuse it.
        if 'already exists' in exc.output:
            log.info(f"VLAN ID {vlan_id} already exists ({vlan_name})")
        else:
            raise exception.IPException(f'Unable to add vlan {vlan_name}. Output: {exc}') from exc
    except exception.IPFileExists:
        log.info(f"VLAN ID {vlan_id} already exists ({vlan_name})")

    return vlan_name


def remove_vlan(iface: str = None, vlan_id: int = None, vlan_name: str = None, lower_kernel=False):
    """
    Remove vlan from the interface. VLAN ID is a mandatory argument.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID
        vlan_name (str): vlan interface name
    """
    _ = lower_kernel
    if vlan_name:
        host_vlan = vlan_name
    else:
        host_vlan = f'vlan{vlan_id}'  # FreeBSD requires interface names of form '<knl mod name>#'

    command = f'ifconfig {host_vlan} destroy'
    try:
        exe.block_run(command)
    except exception.ExeExitcodeException as exc:
        raise exception.IPException(f'Unable to remove vlan {host_vlan} from {iface}. Output: {exc}') from exc


def set_promiscuous_mode(iface: str, mode):
    """
    Set promiscuous for interface

    Args:
        iface (str): ethX name
        mode (str): on/off - replicate interface used by IP module and other OSes
    """

    mode_arg = '' if mode.lower() == 'on' else '-'
    exe.block_run(f'ifconfig {iface} {mode_arg}promisc')


def set_vxlan(iface: str, method, vxlan_id, tun_name=None, group=None, remote=None, external=False, **kwargs):
    """Configure VXLAN

    Args:
        iface: ethX name
        method: [add|del] operation
        vxlan_id (int): VXLAN ID
        group (str): multicast group. Required for 'adding' VXLAN
        tun_name: Name of tunnel to be created
    """
    tun_name = (f'vxlan{vxlan_id}') if tun_name is None else tun_name
    local = kwargs.get('local', None)
    if not local:
        raise exception.ConfigException('FreeBSD vxlan tunnel requires "local" IP arg for unicast tunnel')

    if method == 'add':
        exe.block_run(f'ifconfig {tun_name} create')
        # Only 4789 dstport is supported for now so hardcoding
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        if group is not None:
            cmd = (f'ifconfig {tun_name} vxlanid {vxlan_id} vxlanlocal {local} vxlangroup {group} '
                   f'vxlandev {iface} {params}')
        elif external is True:
            raise exception.ConfigException('FreeBSD vxlan tunnel does not support "external" arg')
        else:
            cmd = f'ifconfig {tun_name} vxlanid {vxlan_id} vxlanlocal {local} vxlanremote {remote} {params}'
    else:
        cmd = f'ifconfig {tun_name} destroy'

    exe.block_run(cmd)


def create_gre(tun_name='gre'):
    """Create GRE tunnel interface

    Args:
        tun_name (str): gre interface name: create new sequentialy numbered interface if 'gre'

    Returns: The new tunnel interface name (in case a specific instacne was not specified: ie. 'gre')
    """
    return exe.block_run(f'ifconfig {tun_name} create').strip() or tun_name


def set_gre(iface: str, tun_name, method, local=None, remote=None, ttl=255, ipv6=False, **kwargs):
    """Configure GRE tunneling

    Args:
        iface (str): ethX name
        tun_name (str): gre interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    # Requires adding routes after ifconfig commands
    if method == 'add':
        inet = 'inet6' if ipv6 else 'inet'
        exe.block_run(f"ifconfig {tun_name} create || echo 'using existing interface'", shell=True)
        params = ' '.join(f'{key} {value}' for key, value in list(kwargs.items()))
        cmd = f'ifconfig {tun_name} {inet} {local} {remote} ttl {ttl} {params}'
        exe.block_run(cmd)
        local_ext = kwargs.get('local_ext', None)
        remote_ext = kwargs.get('remote_ext', None)
        if local_ext and remote_ext:
            exe.block_run(f'ifconfig {tun_name} {inet} tunnel {local_ext} {remote_ext}')
        else:
            raise exception.ConfigException(
                "Freebsd tunnel (gre) setup requires passing the local_ext(ernal) and remote_ext(ernal) IPs")
    else:
        cmd = f'ifconfig {tun_name} destroy'
        exe.block_run(cmd)


#
# linux ethtool -> freebsd ifconfig
#
def get_advertised_autonegotiation(iface: str) -> Optional[Literal['Yes', 'No']]:
    """ [API: ethtool] Verify if Advertised Auto Negotiation
        is enabled or disabled

    Args:
        iface (eth): ethX name
    """
    try:
        # output = the_exe.block_run(f"sysctl dev.{iface.rstrip('0123456789')}.{iface.replace('bnxt', '')}.fc.autoneg")
        output = exe.block_run(f'ifconfig -m {iface}')
    except exception.ExeExitcodeException:
        log.error('Failed to read interface settings')
        return None

    if 'media: Ethernet autoselect' in output:
        return 'Yes'
    return 'No'


def link_status(iface: str) -> str:
    """ [API: ethtool] Link Status function will return the Link state as 'yes' or 'no'

    Args:
        iface (eth): ethX name

    Returns:
        link status: 'active', 'no carrier'. Raises exception if unable to query interface
    """
    try:
        output = exe.block_run(f'ifconfig -m {iface}')
    except exception.ExeExitcodeException as exc:
        raise exception.EthtoolException('Cannot find Link State information from ethtool') from exc

    return re.findall(r'\s+status:\s+(.*)', output)[0]


def media_pattern(prefix, postfix='') -> str:
    """Generate and return a complete regex pattern for finding media type strings in ifconfig (-m) output

    :param prefix: str|regex to prepend to returned regex string
    :param postfix: str|regex to append to returned regex string, defaults to ''
    :return: regex pattern (string)
    """
    return rf'{prefix}[bB]ase-?[CDEFKLRST][MPRX]?\d?\S*{postfix}'


def get_media(iface: str) -> Tuple[str, str]:
    """
    Return media type info of the interface

    Eg
    media: Ethernet autoselect (1000baseT <full-duplex>)
    media: Ethernet autoselect (25GBase-CR <full-duplex,rxpause,txpause>)
    media: Ethernet 100GBaseT-CR4

    Args:
        iface (eth): ethX name

    Returns:
        list: media type, media options (eg. duplex) or empty list (media options entry may be None)

    """
    try:
        output = exe.block_run(f'ifconfig -m {iface}')
    except exception.ExeExitcodeException as exc:
        raise exception.EthtoolException('Cannot find media information') from exc

    media_pat = media_pattern(r'^\s+media: Ethernet (?:autoselect \()?((\d+)(G)?', r')(?: <(.*?)>\))?')
    media_re = re.search(media_pat, output, re.M)
    return [media_re.group(1), media_re.group(4)] if media_re else []


def get_supported_media(iface: str) -> List[str]:
    """
    Return the list of supported media types on the network interface.
    Eg.
    supported media:
            media 1000baseCX
            media 10GBase-CR1
            media 25GBase-CR
            media 40Gbase-CR4
            media 50GBase-CR2
            media 100GBase-CR4
            media autoselect
    TBD: If/when options are supported to change duplex, etc. Eg:
            media 100GBase-CR4 mediaopt full-duplex

    Args:
        iface (eth): ethX name

    Returns:
        List of media types from 'supported media' section of ifconfig -m output
    """
    output = exe.block_run(f'ifconfig -m {iface}')
    media_types = []
    if 'supported media:' in output:  # To get only supported link speed with current nvm config
        start = False
        for line in output.splitlines():
            if 'supported media:' in line:
                start = True
                continue
            if start:
                if 'nd6 options' in line:
                    break
                media_re = re.search(media_pattern(r'\s+media ((\d+)(G)?', ')'), line)
                if media_re:
                    media_types.append(media_re.group(1))

    return list(set(media_types))


def media_type_from_speed(iface: str, speed: int) -> str:
    """
    Return the media type string based on the provided speed in mbps

    Args:
        iface (eth): ethX name
        speed: Speed whose media type is to be returned from the interfaces supported media types

    Returns:
        The matching media string for the given speed and interface
    """
    media_types = get_supported_media(iface)
    for media_type in media_types:
        if re.search(media_pattern(f'({int(speed) // 1000}G|{speed})'), media_type):
            return media_type

    return None


def get_speed(iface: str) -> int:
    """
    [API: ethtool] Return link speed of the interface

    Eg
    media: Ethernet autoselect (1000baseT <full-duplex>)
    media: Ethernet autoselect (25GBase-CR <full-duplex,rxpause,txpause>)
    media: Ethernet 100GBaseT-CR4

    Args:
        iface (eth): ethX name

    Returns:
        int: link speed in Mb. -1 for unknown.

    """
    media = get_media(iface)
    speed_re = re.search(media_pattern(r'(\d+)(G)?'), media[0])
    if not speed_re:
        return -1
    speed = int(speed_re.group(1))
    if speed_re.group(2):
        speed *= 1000

    return speed


def get_supported_speeds(iface: str) -> List[Tuple[str, str]]:
    """
    [API: ethtool] Return the list of supported speeds on the network interface.

    Args:
        iface (eth): ethX name

    Returns:
        List of tuples with each element containing speed and duplex mode as values.
        speed is a string value in mbps, duplex is either 'full-duplex' or 'half-duplex' to match ifconfig
    """
    media_types = get_supported_media(iface)
    speeds = []
    for media in media_types:
        media_re = re.search(media_pattern(r'(\d+)(G)?'), media)
        if media_re:
            speed = int(media_re.group(1))
            if media_re.group(2):
                speed *= 1000
        for duplex in ['full-duplex', 'half-duplex']:
            speeds.append((str(speed), duplex))

    if speeds:
        return list(set(speeds))
    return None


def set_speed(iface: str, speed: Union[int, str], **kwargs):
    """
    [API: ethtool] Set speed of the interface.

    Args:
        iface (eth): ethX name
        speed (int|str): New speed in Mb, or 'autoselect'
    """
    _ = kwargs  # unused for now
    media_str = media_type_from_speed(iface, int(speed)) if speed not in [0, 'autoselect'] else 'autoselect'
    # TODO: Change sysctl fc.autoneg first?
    exe.block_run(f'ifconfig {iface} media {media_str}')


def get_duplex(iface: str):
    """
    [API: ethtool] Return duplex mode of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: duplex mode as per ifconfig output (full|half-duplex)
    """
    media = get_media(iface)

    try:
        return re.search(r'((\w+)-duplex)', media).group(2)
    except AttributeError as exc:
        raise exception.EthtoolException('Cannot find duplex information from ethtool') from exc


def set_duplex(iface: str, duplex, **kwargs):
    """
    [API: ethtool] Set duplex mode of the interface.

    If showing 'cannot advertise duplex X' error, try to set speed and
    duplex at the same time by using the "set_speed_and_duplex" function

    Args:
        iface (str): ethX name
        duplex (str): duplex mode. choices=[full|half]
    """
    raise NotImplementedError("bnxt driver does not currently support setting duplex mode on FreeBSD")
    # toggle = '-' if duplex == 'half' else ''
    # exe.block_run(f'ifconfig {iface} {toggle}mediaopt full-duplex')


def get_flag_field(iface: str, flag='options', normalize=True) -> List[str]:
    """ Return a list of features/options/capabilities from fields of the form: FLAG=VALUE_HEX<VALUE_FIELDS>

    Eg.
    options=e507bb<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,LRO,VLAN_HWFILTER,VLAN_HWTSO,
    NETMAP,RXCSUM_IPV6,TXCSUM_IPV6>
    =>
    ['RXCSUM', 'TXCSUM', 'VLAN_MTU', 'VLAN_HWTAGGING', 'JUMBO_MTU', 'VLAN_HWCSUM', 'TSO4', 'TSO6', 'LRO',
     'VLAN_HWFILTER', 'VLAN_HWTSO', 'NETMAP', 'RXCSUM_IPV6', 'TXCSUM_IPV6']
    if normalize:
        ['rxcsum', 'txcsum', 'vlanmtu', 'vlanhwtag', 'jumbomtu', 'vlanhwcsum', 'tso4', 'tso6', 'lro', 'vlanhwfilter',
         'vlanhwtso', 'netmap', 'rxcsum6', 'txcsum6']

    Args:
        iface (str): ethX name
        flag (str): 'options' or 'capabilities' or any other ifconfig field of the specified form
        normalize (bool): If True, normalize to the form needed when applying options to the interface

    Returns:
        list of the flag values. If normalize, the entries are converted to the form used when enabling/disabling the
        feature via ifconfig
        (lowercase with '_' removed; exception: vlanhwtagging -> vlanhwtag; ipv6 -> 6; 'jumbomtu' -> '')
    """
    fields = []
    output = exe.block_run(f'ifconfig -m -v {iface}')  # NOTE: -m needed for 'capabilities' display?!
    fields = re.search(rf'(?:^|:)\s+{flag}=([0-9a-f]+)<(.*)>', output, re.M)
    if fields:
        fields = [field.strip() for field in fields.group(2).split(',')]
        if normalize:
            fields = [field.lower().replace('_', '').replace('tagging', 'tag').replace('ipv6', '6') for field in fields]

    return fields


def set_flags(iface: str, flag: str, value: str = None):
    """ Set flag .

    Eg.
    set_flags(iface, '-debug') or set_flags(iface, 'debug', '-')

    Args:
        iface (str): ethX name
        flag (str): flag name. (e.g. debug)
        value (str): choices=[on|off|-|+] or other value
    """
    val = f' {value}' if value and value.lower() not in ['-', '+', 'on', 'off'] else ''
    flag = f'-{flag}' if value and value.lower() in ['-', 'off'] else flag
    exe.block_run(f'ifconfig {iface} {flag}{val}')


def get_flags(iface: str) -> List[str]:
    """ Return a list of enabled interface flags

    flags=8802<UP,BROADCAST,SIMPLEX,MULTICAST> metric 0 mtu 1500
    =>
    ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST']

    Args:
        iface (str): ethX name

    Returns:
        list of the interface flags, like admin state, broadcast, multicast, etc.
    """
    return get_flag_field(iface, 'flags', False)


def get_options(iface: str) -> List[str]:
    """ Return a list of enabled features/options

    options=e507bb<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,LRO,VLAN_HWFILTER,VLAN_HWTSO,
    RXCSUM_IPV6,TXCSUM_IPV6>
    =>
    ['rxcsum', 'txcsum', 'vlanmtu', 'vlanhwtag', 'jumbomtu', 'vlanhwcsum', 'tso4', 'tso6', 'lro', 'vlanhwfilter',
     'vlanhwtso', 'rxcsum6', 'txcsum6']

    Args:
        iface (str): ethX name

    Returns:
        list of the features converted to the form used when enabling/disabling the feature via ifconfig
        (lowercase with '_' removed; exception: vlanhwtagging -> vlanhwtag; ipv6 -> 6; 'jumbomtu' -> '')
    """
    return get_flag_field(iface, 'options')


def get_capabilities(iface: str) -> List[str]:
    """ Return a list of available/supported features/options

    capabilities=f507bb<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,LRO,VLAN_HWFILTER,
    VLAN_HWTSO,NETMAP,RXCSUM_IPV6,TXCSUM_IPV6>
    =>
    ['rxcsum', 'txcsum', 'vlanmtu', 'vlanhwtag', 'jumbomtu', 'vlanhwcsum', 'tso4', 'tso6', 'lro', 'vlanhwfilter',
     'vlanhwtso', 'netmap', 'rxcsum6', 'txcsum6']

    Args:
        iface (str): ethX name

    Returns:
        list of all the features converted to the form used when enabling/disabling the feature via ifconfig
        (lowercase with '_' removed; exception: vlanhwtagging -> vlanhwtag; ipv6 -> 6; 'jumbomtu' -> '')
    """
    return get_flag_field(iface, 'capabilities')


def get_enabled_features(iface: str) -> List[str]:
    """ Return the enabled features - see get_options """
    return get_options(iface)


def get_disabled_features(iface: str) -> List[str]:
    """ Return the disabled features: get_capabilities() - get_get_enabled_features() """
    features = get_capabilities(iface)
    enabled = get_enabled_features(iface)
    disabled = [f'-{field}' for field in set(features) - set(enabled)]
    return disabled


def get_all_features(iface: str) -> List[str]:
    """ Return all the features, using the ifconfig syntax: -<feat> for disabled """
    enabled = get_enabled_features(iface)
    disabled = get_disabled_features(iface)
    log.debug(f"ifconfig:Features[{iface}]: ON({enabled}) OFF({disabled})")
    return enabled + disabled


def get_features(iface: str) -> List[str]:
    """ [API: ethtool] Return a list of all features indicating status (feat/-feat)

    Args:
        iface (str): ethX name
    """
    # When getting features, check sysctl and create 'gro' and 'lro' feature entry based on dev.bnxt.0.hw_lro fields
    # lro feature is used to set HW LRO via kenv/sysctl; sw_lro is a virtual feature created to map to ifconfig lro
    # such that setting the lro feature affects HW LRO as is expected in linux etc.
    # LRO ifconfig setting should exist (even though not fully working in 226/227)
    # GRO not yet supported - should always get 0
    drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
    device = f'dev.{drv_name}.{iface_id}'
    lro_en = exe.block_run(f'sysctl -n {device}.hw_lro.enable').strip()
    gro_mode = exe.block_run(f'sysctl -n {device}.hw_lro.gro_mode').strip()
    all_feats = get_all_features(iface)
    add_feat = []
    if 'gro' not in ','.join(all_feats):
        gro_feat = f"{'' if gro_mode == '1' and lro_en == '1' else '-'}gro"
        add_feat.append(gro_feat)
    # Swap sw_lro for lro entry returned by feature query (lro should exist). Scripts use sw_lro, lro for sw lro, hw lro
    for lro_str in ['lro', '-lro']:
        try:
            lro_idx = all_feats.index(lro_str)
        except ValueError:
            continue
        else:
            all_feats[lro_idx] = lro_str.replace('lro', 'sw_lro')
            break
    if 'sw_lro' not in ','.join(all_feats):
        raise exe.exception.EthException(f"Failed to find (sw) lro feature in ifconfig output for {iface}")
    # Add HW lro entry based on sysctl values
    hw_lro_feat = f"{'' if lro_en == '1' and gro_mode == '0' else '-'}lro"
    add_feat.append(hw_lro_feat)
    if add_feat:
        all_feats.extend(add_feat)

    if 'lro' in all_feats and 'sw_lro' in all_feats:
        log.warning("Both SW and HW LRO are enabled!")

    return all_feats


def set_hw_gro_lro(device: str, feat: str, enable: bool):
    """ Workaround: Use kenv as ifconfig either not working (lro), or feature not yet supported (gro)

    :param device: iface name in sysctl format: "dev.<driver>.<instance>"
    :param feat: feature name as per ifconfig options setting ('gro' or 'lro')
    :param enable (bool): True if feature should be enabled, else False
    """
    if 'lro' in feat:
        exe.block_run(f'kenv -v {device}.hw_lro.enable={int(enable)}')
        exe.block_run(f'kenv -v {device}.hw_lro.gro_mode={int(not enable)}')
    if 'gro' in feat:
        exe.block_run(f'kenv -v {device}.hw_lro.enable={int(enable)}')
        exe.block_run(f'kenv -v {device}.hw_lro.gro_mode={int(enable)}')
    exe.block_run('kldunload if_bnxt && sleep 1 && kldload if_bnxt', shell=True)


def translate_gro_lro(iface: str, feat: str):
    """ Translate lro to gro based on hw_lro.gro_mode

    When setting features, assign 'lro' instead of 'gro' (doesn't exist in ifconfig options) and
    set dev.bnxt.0.hw_lro.gro_mode to 1, and dev.bnxt.0.hw_lro.enable to 1

    :param iface: (str): ethX name
    :param feat: (str): Feature name. e.g.) lro
    :return: translated feature name (lro or gro)
    """
    # Allow setting SW LRO via 'sw_lro' feature, while 'lro' sets HW LRO which currently requires kenv
    if 'sw_lro' in feat:
        return feat.replace('sw_', '', 1)
    if 'gro' in feat or 'lro' in feat:
        drv_name, iface_id = re.findall(r'(bnxt)(\d+)', iface)[0]
        device = f'dev.{drv_name}.{iface_id}'
        try:
            exe.block_run(f'sysctl {device}.hw_lro; kenv -v {device}.hw_lro.gro_mode; kenv -v {device}.hw_lro.enable',
                          shell=True)
        except exception.ExeExitcodeException:
            pass
        if 'gro' in feat:
            # TODO: GRO not yet supported
            feat = ''
            # set_hw_gro_lro(device, feat, enable=bool(not feat.startswith('-')))
            log.error("GRO not yet supported in FreeBSD")
        if 'lro' in feat:
            set_hw_gro_lro(device, feat, enable=bool(not feat.startswith('-')))
        try:
            exe.block_run(f'sysctl {device}.hw_lro; kenv -v {device}.hw_lro.gro_mode; kenv -v {device}.hw_lro.enable',
                          shell=True)
        except exception.ExeExitcodeException:
            pass
    return feat


def set_feature(iface: str, feature: str, value: str = None):
    """ [API: ethtool] Set offload feature settings.

    No error checking about changing settings for "fixed" features, but raise exe exception as it is.

    Args:
        iface (str): ethX name
        feature (str): Feature name. e.g.) tx-checksumming
        value (str): choices=[on|off] as ethtool -k returns
    """
    val = f' {value}' if value and value.lower() not in ['-', '+', 'on', 'off'] else ''
    feat = f'-{feature}' if value and value.lower() in ['-', 'off'] else feature

    # HW LRO currently needs kenv, as ifconfig setting doesn't work; GRO not yet supported at all
    set_feat = translate_gro_lro(iface, feat)

    if set_feat:
        # Skip cmd if 'translation' resulted in empty feat value (eg. GRO not supported)
        exe.block_run(f'ifconfig {iface} {set_feat}{val}')
    else:
        log.warning(f"Skipping ifconfig feature setting for {feat} - not currently supported")


def set_features(iface: str, **kwargs):
    """ [API: ethtool] Set offload feature settings.

    No error checking about changing settings for "fixed" features, but raise exe exception as it is.

    Args:
        iface (str): ethX name
        kwargs (dict): Pairs of feature, value entries.
                       feature (str): Feature name. (e.g. tx-checksumming),
                       value (str): choices=[on|off] as ethtool -k returns
    """
    features = ''
    for feature, value in kwargs.items():
        val = f' {value}' if value and value.lower() not in ['-', '+', 'on', 'off'] else ''
        feat = f'-{feature}' if value and value.lower() in ['-', 'off'] else feature

        # When setting features, assign 'lro' instead of 'gro' and set dev.bnxt.0.hw_lro.gro_mode to 1
        set_feat = translate_gro_lro(iface, feat)

        if set_feat:
            features += f' {set_feat}{val}'
        else:
            log.warning(f"Skipping ifconfig feature setting for {feat} - not currently supported")

    exe.block_run(f'ifconfig {iface}{features}')


def get_msglvl(iface: str) -> int:
    """Return msglvl as int (0 or 1 for freebsd as we can only enable/disable debugging)

    Args:
        iface (eth): ethX name

    Return:
        int: msglvl in integer

    """
    return int('DEBUG' in get_flag_field(iface, 'flags'))


def set_msglvl(iface: str, msglvl: int):
    """Set msglvl (enable or disable debug flag)

    Args:
        iface (eth): ethX name
        msglvl (hex, int): message level
    """
    debug = 'debug' if msglvl else '-debug'
    exe.block_run(f'ifconfig {iface} {debug}')
