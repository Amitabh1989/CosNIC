"""
:mod:`app_interface` --
===========================================

.. module:: controller.lib.freebsd.eth.app_interface
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""
import ipaddress
import json
import re
import socket
import struct
from typing import Dict, List, Tuple, Union

from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.common.shell import exe
from controller.lib.common.eth.interface import BaseInterface
from controller.lib.freebsd.system import stats as sysstats
from controller.lib.freebsd.eth import ethtool
from controller.lib.freebsd.eth import ip, ifconfig
from controller.lib.freebsd.eth import stats as ethstats


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

log = log_handler.get_logger(__name__)


class AppInterface(BaseInterface):
    """
    Can control a single Ethernet interface using this object. Abstract
    backend and perform different interactions with a system depending on
    the method.

    This class uses ip, ifconfig and ethtool. To use specific application,
    should use the application wrapper instead of this.

    Args:
        iface (str): ethX name

    Returns:
        Interface: Interface object that has methods to interact with
            the Ethernet interface

    """

    def __init__(self, iface):
        super(AppInterface, self).__init__(iface)
        # CTRL-45522: [controller-0.3.9b.19] roce_driver_feature_stress.py fails as the offload
        # feature for tx-ipip-segmentation name changed in 216 driver.
        # Build a mapping between "extinct" and "existing" feature names.
        # Example: 'tx-ipip-segmentation' that is present till kernel 4.6 is renamed (split??) to
        # 'tx-ipxip4-segmentation' and 'tx-ipxip6-segmentation'. Also, 'tx-sit-segmentation' is
        # removed. So, ignore that.
        #
        # Notes:
        # [1] This map should be updated as and when the feature names change.
        # [2] Keep the mapped value in a list even though there's just one value.
        self.__feature_name_map = {
            'tx-ipip-segmentation': ['tx-ipxip4-segmentation'],
            'tx-sit-segmentation': [],
            # ethtool => FreeBSD ifconfig mappings
            'rx-checksum': ['rxcsum', 'rxcsum6'],
            'rx': ['rxcsum', 'rxcsum6'],
            'rx6': ['rxcsum6'],
            'tx-checksum-ipv4': ['txcsum'],
            'tx-checksum-ipv6': ['txcsum6'],
            'tx': ['txcsum', 'txcsum6'],
            'tx6': ['txcsum6'],
            'tx-tcp-segmentation': ['tso4', 'tso6'],
            'tx-tcp-ecn-segmentation': ['tso4', 'tso6'],
            'tx-tcp-mangleid-segmentation': ['tso4', 'tso6'],
            'tx-tcp6-segmentation': ['tso6'],
            'generic-segmentation-offload': ['gso'],
            'generic-receive-offload': ['gro'],
            'large-receive-offload': ['lro'],
            'rx-vlan-offload': ['vlanhwcsum'],  # TBD
            'tx-vlan-offload': ['vlanhwtso'],  # TBD
            'rx-vlan-filter': ['vlanhwfilter'],
            'tx-vlan-stag-hw-insert': ['vlanhwtag'],
        }

        self.sysctl_iface_name = 'dev.{}.{}'.format(*re.findall(r'(bnxt)(\d+)', iface)[0]) if 'bnxt' in iface else None

    def up(self):
        """
        Bring up the interface.

        """

        exe.block_run('ifconfig %s up' % self.iface)

    def down(self):
        """
        Bring down the interface

        """

        exe.block_run('ifconfig %s down' % self.iface)

    @property
    def ip_addr(self):
        """
        Return IPv4 address of the interface. Use "ip" but returns the only
        first IP address if there are multiple as IP alias to match the
        behavior with ifconfig.

        Returns:
            str: IP address of the interface
            None: If No IP address is assigned

        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface)
        return ip_addr_list[0].split('/')[0] if len(ip_addr_list) > 0 else None

    @ip_addr.setter
    def ip_addr(self, new_ip_addr):
        """
        Set IP address of the interface. use "ip" but behaves as ifconfig -
        namely

           * If no IP address was assigned, the new IP address will be assigned
           * If IP address was already assigned, the new IP address will
             replace it
           * If 'new_ip_addr' is 0.0.0.0, will remove the IP address

        To interact with "ip" directly, should use "ip" wrapper instead.

        Args:
            new_ip_addr (str): New IP address of the interface with subnet.
                format shuold be x.x.x.x/x

        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface)

        if len(ip_addr_list) > 0:
            log.debug('Remove IP addresses before assigning ... ')
            for ip_addr in ip_addr_list:
                ip.set_ip_addr(iface=self.iface, ip_addr=ip_addr, method='del',)

        if new_ip_addr is None or new_ip_addr == '0.0.0.0':
            return

        ip.set_ip_addr(iface=self.iface, ip_addr=new_ip_addr)

    @property
    def ip6_addr(self):
        """
        Return IPv6 addresses of the interface.
        Note that IOCTL does not support IPv6 - therefore using proc instead

        Returns:
            list: List of IPv6 addresses

        """

        return [
            ip6.split('/')[0] for ip6 in ip.get_ip_addr(
                iface=self.iface, ipv6=True)
        ]

    @ip6_addr.setter
    def ip6_addr(self, new_ip6_addr):
        """Add a new IPv6 address to the interface

        Args:
            new_ip6_addr (str): IPv6 address with prefix
        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface, ipv6=True)
        if len(ip_addr_list) > 0:
            log.debug('Remove IP addresses before assigning ... ')
            for ip_addr in ip_addr_list:
                ip.set_ip_addr(
                    iface=self.iface, ip_addr=ip_addr, method='del', ipv6=True)
        ip.set_ip_addr(
            iface=self.iface, ip_addr=new_ip6_addr, method='add', ipv6=True)

    def set_ip6_addr(self, new_ip6_addr, method, **kwargs):
        """
        Set IPv6 address to the given iface.

        Args:
            new_ip_addr (str): New IP address of the interface
                with prefix preceded by '/' (e.g. <ipv6 addr>/<prefix>)
            method (str): [add|change|replace|del] as "ip" command accepts to
                assign IP address.

        """

        ip.set_ip_addr(
            iface=self.iface, ip_addr=new_ip6_addr, method=method, ipv6=True)

    @property
    def netmask(self):
        """Return netmask of the interface.

        Returns:
            str: netmask of the interface

        """
        if not self.prefix:
            return None

        return socket.inet_ntoa(
            struct.pack(">I", (0xffffffff << (32 - self.prefix)) & 0xffffffff))

    @property
    def prefix(self):
        """Return prefix of the interface

        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface)
        if len(ip_addr_list) > 0:
            # Return the first IP address / Netmask
            ip_addr, prefix = ip_addr_list[0].split('/')
            return int(prefix)

        return None

    @property
    def ip6_prefix(self):
        """Return IPv6 prefix of the interface as a dictionary.

        key is a IP address and value is the prefix, since it's expected to see
        multiple addresses
        """
        ret_dict = {}

        for ip6_addr in ip.get_ip_addr(iface=self.iface, ipv6=True):
            addr, prefix = ip6_addr.split('/')
            ret_dict[addr] = prefix

        return ret_dict

    @property
    def mac_addr(self):
        """
        Return MAC addres of the interface

        Returns:
            str: MAC address of the interface
        """

        return ip.get_mac_addr(iface=self.iface)

    @mac_addr.setter
    def mac_addr(self, new_mac_addr):
        """
        Set MAC address of the interface

        Args:
            new_mac_addr (str): New MAC address of the interface
            in XX:XX:XX:XX:XX:XX format

        """

        new_mac_addr = new_mac_addr.lower()
        ip.set_mac_addr(iface=self.iface, mac_addr=new_mac_addr)

    @property
    def state(self):
        """
        Return link admin status. 'up', 'down' and 'unknown'

        Returns:
            str: link status
        """
        return ip.get_state(iface=self.iface)

    @property
    def link_status(self):
        """
        Return link status. 'yes' (== 'active'), else 'no' ('no carrier': not connected, remote down, etc.)

        Returns:
            str: link status
        """
        return ethtool.link_status(iface=self.iface)

    @property
    def mtu(self):
        """
        Return MTU of the interface

        Returns:
            int: MTU of the interface

        """

        return ip.get_mtu(iface=self.iface)

    @mtu.setter
    def mtu(self, new_mtu):
        """
        Set MTU size of the interface

        Args:
            new_mtu (int): New MTU of the interface
        """

        ip.set_mtu(iface=self.iface, mtu=new_mtu)

    def supported_speeds(self):
        """
        Return the list of supported speeds on the network interface.
        :return:  List of tuples with each element containinng speed and duplex mode as values.
        """
        return ethtool.get_supported_speeds(iface=self.iface)

    @property
    def speed(self):
        """
        Return link speed of the interface. Use ethtool.

        Returns:
            int: link speed in Mb. -1 = unknown

        """

        return ethtool.get_speed(iface=self.iface)

    @speed.setter
    def speed(self, new_speed):
        """
        Set speed of the interface using ethtool, but speed/duplex together as
        "ethtool -s <iface> speed <new_speed> duplex <original duplex>"

        Args:
            new_speed (int): New speed of the interface

        """

        ethtool.set_speed(iface=self.iface, speed=new_speed)

    @property
    def duplex(self):
        """
        Return duplex mode of the interface. Use ethtool.

        Returns:
            str: dupldx mode. 0 = half, 1 = full, 0xff = unknown.
        """

        return ethtool.get_duplex(iface=self.iface)

    @duplex.setter
    def duplex(self, new_duplex):
        """
        Set duplex mode of the interface using ethtool, but speed/duplex
        together as "ethtool -s <iface> speed <original speed> <new_duplex>"

        Args:
            new_duplex (str): full/half

        """

        ethtool.set_duplex(
            iface=self.iface, duplex=new_duplex, speed=self.speed)

    @property
    def stats(self) -> ethstats.Cumulus:
        """
        Return statistics of the interface. Use ethtool. Only return the
        basic unicast/multicast/broadcast statistics since it's not possible
        to know the NIC type here.

        Should use controller.lib.freebsd.eth.stats if you need to access TPA
        related counters.

        Returns:
            dict: key=parameter, value=value
        """

        return ethstats.get_stats(self.iface)

    @property
    def drvinfo(self):
        """
        Return driver information of the interface. Use ethtool.

        Return value should have following keys:

        * name: driver name
        * version: driver version
        * firmware: Optional. firmware information including name and version

        Returns:
            dict: driver information
        """
        return ethtool.get_drvinfo(iface=self.iface)

    def dump(self, **kwargs):
        """
        Dump the NIC property in dict.

        Returns:
            dict: key=param, value=value
        """

        attr_list = [
            'ip_addr', 'ip6_addr', 'netmask', 'mac_addr', 'state',
            'mtu', 'speed', 'duplex', 'drvinfo'
        ]

        ret_dict = {}

        for attr in attr_list:
            ret_dict[attr] = getattr(self, attr)

        return ret_dict

    @property
    def features(self) -> Dict[str, Tuple[str, bool]]:
        """
        Return ethtool -k output in dictionary.
        key is a name of feature and value is a tuple, which has below:

        <status> is either 'on' or 'off'
        <fixed> is True or False depending on it's a fixed value or not.

        Returns:
            dict: features

        """
        return ethtool.get_features(iface=self.iface)

    def set_feature(self, **kwargs):
        """
        Set offload feature settings. No error checking about changing settings
        for "fixed" features, but raise exe exception as it is.

        For example::

        >>> from controller.lib.freebsd import eth
        >>> eth1 = eth.get_interface('eth1')
        >>> eth1.set_features(**{'tx-checksum-ipv4': 'off'})

        Args:
            **kwargs (kwargs): key=feature name, value=value. Because feature
                names have some unsupported letters in names, should pass
                this argument as a dictionary
        """
        # CTRL-45522: [controller-0.3.9b.19] roce_driver_feature_stress.py fails as the offload
        # feature for tx-ipip-segmentation name changed in 216 driver.
        # If setting a feature fails, retry with its mapped name(s).
        try:
            ifconfig.set_features(self.iface, **kwargs)
        except Exception as exc:
            if 'bad command line' in str(exc) or 'bad value' in str(exc):
                for key, value in kwargs.items():
                    # If there's no mapped name for the feature, bail out.
                    if key not in self.__feature_name_map:
                        raise exc

                    for mapped_feature_name in self.__feature_name_map.get(key, []):
                        try:
                            ifconfig.set_features(self.iface, **{mapped_feature_name: value})
                        except Exception:
                            log.exception("Failed set %s (%s) to %s", mapped_feature_name, key, value)
                            raise
            else:
                log.error("Exception modifying %s feature(s) setting with no alternate names. (%s)",
                          list(kwargs.keys()), str(exc))
                raise exc

    def set_features(self, param=None, value=None, param_dict=None):
        """For backward compatibility - same as set_feature()

        Args:
            param (str): A name of a parameter
            value (str): A new value for the parameter
            param_dict (dict): A dictionary where key=param and value=value.
                Can be used when changing multiple parameters at the same time.
                If this is given, param and value are ignored
        """

        if param_dict:
            self.set_feature(**param_dict)
            return

        if not param or not value:
            raise exception.ValueException('Both "param" and "value" should be given')

        self.set_feature(**{param: value})

    @property
    def coalesce(self):
        """Return ethtool -c output in dictionary

        key is a name of parameter and value is integer, except adaptive rx/tx
        which has 'on' and 'off' as possible values

        """
        return ethtool.get_coalesce(iface=self.iface)

    def set_coalesce(self, param, value):
        """Set value of the coalesce parameter

        Acceptable parameter / values are as what coalesce() returns

        Args:
            param (str): parametner name i.e.) rx-frames
            value (str, int): str for adaptive rx/tx and integer for all other
                parameters

        """
        ethtool.set_coalesce(iface=self.iface, param=param, value=value)

    @property
    def interrupt(self):
        """Return interrupt numbers that are parsed from /proc/interrupts

        Return:
            dict: key=interrupt id, value=interrupt info including counters
        """

        int_matrix = [
            int_info['int'] for int_info in list(sysstats.get_nic_interrupt(
                iface=self.iface).values())]

        ret_value = {
            cpu_num: sum(int_num) for cpu_num, int_num in
            enumerate(zip(*int_matrix))}
        log.info('Interrupts %s', ret_value)
        if any(isinstance(el, list) for el in list(ret_value.values())):
            for idx in range(0, len(list(ret_value.values()))):
                ret_value['total'] = sum(list(ret_value.values())[idx])
        else:
            ret_value['total'] = sum(ret_value.values())
        return ret_value

    @property
    def smp_affinity(self) -> Dict[int, List[int]]:
        """Return CPU affinity list

        Return:
            dict: key=interrupt id, value=affinity in list of CPU index. i.e.)
                [0,6] means the affinity is set to CPU 0 and CPU 6
        """
        ret_dict = {}
        # Need to determine the width/padding used in the dev.<iface>.iflib.rxq# entries. Eg. if 10 queues,
        # numbered from 0, then only 1 digit expected, but if 11 queues used, then expect 2 digits with 0 padding
        rxq_num_digits = len(str(self.queue['rx'] - 1))
        # TODO: sysctl module
        output = exe.block_run(f"vmstat -i | grep {self.iface}:rxq", shell=True)
        for line in output.strip().splitlines():
            line_match = re.findall(rf'irq(\d+):\s{self.iface}:rxq(\d+)', line)
            if not line_match:
                continue
            irq, queue = line_match[0]
            # vmstat and sysctl rxq/txq numbering is different. vmstat doesn't use 0 padding, but sysctl does as needed
            cpu_id = int(exe.block_run(
                         f'sysctl -n {self.sysctl_iface_name}.iflib.rxq{queue.zfill(rxq_num_digits)}.cpu').strip())
            ret_dict[int(irq)] = [cpu_id]

        return ret_dict

    @smp_affinity.setter
    def smp_affinity(self, affinity_dict: Dict[int, List[int]]):
        """Set affinitiy list

        Args:
            affinity_dict: key=interrupt id, value=affinity in list of CPU
                index. i.e.) [0,6] will set affinity to CPU 0 and CPU 6
        """
        # Need to determine the width/padding used in the dev.<iface>.iflib.rxq# entries. Eg. if 10 queues,
        # numbered from 0, then only 1 digit expected, but if 11 queues used, then expect 2 digits with 0 padding
        rxq_num_digits = len(str(self.queue['rx'] - 1))
        output = exe.block_run(f"vmstat -i | grep {self.iface}:rxq", shell=True)
        for line in output.strip().splitlines():
            line_match = re.findall(rf'irq(\d+):\s{self.iface}:rxq(\d+)', line)
            if not line_match:
                continue
            irq, queue = line_match[0]
            # Only support a single CPU? cpuset working? sysctl var is read only
            cpus_csv = ','.join(map(str, affinity_dict[int(irq)]))
            exe.block_run(f"cpuset -l {cpus_csv} -x {irq}")
            # vmstat and sysctl rxq/txq numbering is different. vmstat doesn't use 0 padding, but sysctl does as needed
            exe.block_run(f'sysctl {self.sysctl_iface_name}.iflib.rxq{queue.zfill(rxq_num_digits)}.cpu')
            exe.block_run(f"cpuset -g -x {irq}")

    @property
    def netstats(self):
        """Return all netstat -s stats

        Return:
            dict: key=parameter, value=value
        """
        output = json.loads(exe.block_run('netstat -s --libxo json').strip())

        return output['statistics']

    @property
    def netstat(self) -> Dict[str, int]:
        """Return /proc/net/netstat (linux nstat -s) equivalent (roughly): netstat -s tcp and ip values

        Return:
            dict: key=parameter, value=value
            json output is flattened for tcp (two levels: eg. tcp-<counter>, tcp-sack-<counter>)
            and ip (one level: eg. ip-<counter>)
        """
        output = self.netstats

        # Freebsd: "tcp-discard-bad-checksum":203007; Linux: TCPMD5Failure? ie. names are different
        tcp_keys = [k for k, val in output['tcp'].items() if isinstance(val, dict)]
        ret_dict = {f'tcp-{k}': val for k, val in output['tcp'].items() if k not in tcp_keys}
        for tcp_key in tcp_keys:
            ret_dict.update({f'tcp-{tcp_key}-{k}': val for k, val in output['tcp'][tcp_key].items()})
        ret_dict.update({f'ip-{k}': val for k, val in output['ip'].items()})

        return ret_dict

    @property
    def snmp(self):
        """Return /proc/net/snmp

        Return:
            dict: key=parameter, value=value
        """
        return self.netstats

    @property
    def flow_control(self):
        """Return the flow control setting"""
        setting = ethtool.get_pause(self.iface)
        if setting['autoneg'] == 'on':
            return 'auto_neg'
        elif setting['rx'] == 'on' and setting['tx'] == 'off':
            return 'rx'
        elif setting['rx'] == 'on' and setting['tx'] == 'on':
            return 'rx_tx'
        elif setting['rx'] == 'off' and setting['tx'] == 'on':
            return 'tx'
        else:
            return 'disabled'

    @flow_control.setter
    def flow_control(self, new_mode):
        """Set the flow control to the new setting"""
        try:
            if new_mode == 'rx':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='on', tx='off')
            elif new_mode == 'tx':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='off', tx='on')
            elif new_mode == 'rx_tx':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='on', tx='on')
            elif new_mode == 'auto_neg':
                ethtool.exec_ethtool(
                    iface=self.iface, opt='-A', autoneg='on')
            elif new_mode == 'disabled':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='off', tx='off')

        except exception.EthtoolNoChanges:
            pass

    @property
    def route(self):
        """ Return route information of the current iface using netstat -rn.
            Different field names than linux (using /proc/net/route)

        Return:
            list: List of routing entries for iface

        """
        ret_dict = {}

        output = json.loads(exe.block_run('netstat -rn --libxo json').strip())
        for inet_entry in output['statistics']['route-information']['route-table']['rt-family']:
            inet_type = str(inet_entry['address-family']).replace('Internet6', 'ipv6').replace('Internet', 'ipv4')
            for route_entry in inet_entry['rt-entry']:
                # Flatten the dictionary so each route entry includes ipv4/v6 info
                route_entry['address-family'] = inet_type
                if route_entry['interface-name'] not in ret_dict:
                    ret_dict[route_entry['interface-name']] = []
                ret_dict[route_entry['interface-name']].append(route_entry)
        log.debug(f"Route info: {ret_dict}")

        if self.iface not in ret_dict:
            return None  # No routing table for the interface. Return None.

        return ret_dict[self.iface]

    def set_route(self, method, dst, gateway=None):
        ip.set_route(self.iface, method, dst, gateway)

    @property
    def sysclass_stats(self):
        """Statistics information from /sys/class/net/<eth_name>/statistics (linux-> 'netstat -ib' for freebsd)
        """
        # drv, iface_id = re.findall(r'(bnxt)(\d+)', self.iface)[0]
        netstats = json.loads(exe.block_run('netstat -ib --libxo json').strip())
        # dir_path = '/sys/class/net/%s/statistics' % self.iface
        ret_dict = {}

        excl_keys = ["name", "flags", "mtu", "network", "address"]
        for row in netstats['statistics']['interface']:
            if 'Link#' not in row['network'] or self.iface != row['name']:
                continue
            for field, value in row.items():
                if field in excl_keys:
                    continue
                ret_dict[field] = value

        # for stats_name in os.listdir(dir_path):
        #     with open(dir_path + '/' + stats_name, 'r') as fileobj:
        #         ret_dict[stats_name] = int(fileobj.read().strip())

        return ret_dict

    @property
    def queue(self) -> Dict[str, int]:
        """Return queue settings"""
        curset = ethtool.get_channels(self.iface)['curset']
        return {'rx': curset['rx'], 'tx': curset['tx']}

    @queue.setter
    def queue(self, queue_dict: Dict[str, int]):
        """Configure the channel using the given parameter.

        Args:
            queue_dict (dict): {'rx': <rx_queue_num>, 'tx': <tx_queue_num>}
        """
        ethtool.set_channels(self.iface, queue_dict)

    @property
    def channel(self):
        """Return channel settings
        """
        return ethtool.get_channels(self.iface)

    @channel.setter
    def channel(self, channel_settings):
        """Configure the channel using the given parameter.

        Args:
            channel_settings (dict): new channel settings. The format of the
                expected channel_settings is same as the return value of
                get_channels()
        """
        ethtool.set_channels(self.iface, channel_settings)

    @property
    def ring(self):
        """ Return ring settings
        """
        return ethtool.get_ring(self.iface)

    @ring.setter
    def ring(self, ring_settings=None):
        """ Configure the ring parameters using the dictionary argument
        """
        ethtool.set_ring(self.iface, ring_settings)

    @property
    def medium(self):
        """Return the transmission medium type [FIBRE/TP]

        """
        return ethtool.get_iface_medium(iface=self.iface)

    def ring_sizes(self):
        """ Return ring sizes individually
        """
        curset = ethtool.get_ring(self.iface)
        return {'rx': curset['rx'], 'tx': curset['tx'], 'rx-jumbo': curset['rx jumbo']}

    def set_ethtool(self, opt, order=None, **kwargs):
        """Proxy to controller.lib.freebsd.eth.ethtool.exec_ethtool

        Args:
            opt (str): option that will be passed to ethtool. i.e.) '-s'
            order (list): List of keys in kwargs so the parameters are provided
                in order as defined here
            kwargs (kwargs): keyword arguments which key=parameter value=
                value. i.e.) set_ethtool('-s', speed=40000, duplex='half') will
                run ethtool -s <iface> speed 40000 duplex half. Note that no
                order of the options is guaranteed, so you need to pass "order"
                if you need to keep the order of parameters.

        """
        return ethtool.exec_ethtool(
            iface=self.iface, opt=opt, order=order, **kwargs)

    def ping(self, dst_ip, count=10, **kwargs) -> bool:
        """Ping the remote host"""

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        try:
            exe.block_run('ping -c %s %s %s' % (
                count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def iface_ping(self, dst_ip, count=10, **kwargs):
        """ Ping to the remote host from a specific interface
        """

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        try:
            exe.block_run('ping -I %s -c %s %s %s' % (
                self.iface, count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def ping6(self, dst_ip, count=10, **kwargs):
        """Ping over IPv6 to remote host"""
        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())
        ]

        try:
            exe.block_run('ping6 -c %s %s %s' % (
                count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def iface_ping6(self, dst_ip, count=10, **kwargs):
        """Ping over IPv6 to remote host"""
        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())
        ]

        try:
            exe.block_run('ping6 -I %s -c %s %s %s' % (
                self.iface, count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def add_vlan(self, vlan_id):
        """Add VLAN using the given VLAN ID"""
        return ip.add_vlan(iface=self.iface, vlan_id=vlan_id)

    def remove_vlan(self, vlan_id):
        """Delete VLAN using the given VLAN ID"""
        ip.remove_vlan(iface=self.iface, vlan_id=vlan_id)

    @property
    def vlan_iface_list(self):
        ret_list = []

        # NOTE: Seems like this api is unused in general. It doesn't work for freebsd
        # (get_interfaces doesn't return vlans, and the re is for linux vlan naming). Only fix if needed.
        for iface in get_interfaces():
            if re.match(self.name + r'\.(\d+)', iface):
                vlan_iface = self.__class__(iface=iface)
                ret_list.append(vlan_iface)

        return ret_list

    @property
    def vlan_id(self) -> Union[int, None]:
        """Return a VLAN ID using the iface name

        Namely this interface should have been created using add_vlan() - if
        this is manually created and does not have the expected VLAN interface
        name format (vlan<vlan_id), then this will not work.
        """
        vlan_re = re.search('vlan(\d+)', self.iface)
        return int(vlan_re.group(1)) if vlan_re else vlan_re

    @property
    def sriov(self):
        """Return a number of VFs and total VFs.

        {
            'num': <sriov_numbfs>
            'total': <sriov_totalvfs>
        }

        If SR-IOV is not enabled, return None
        """
        raise NotImplementedError("sriov is not implemented for FreeBSD")

        # if not os.access(
        #         '/sys/class/net/%s/device/sriov_totalvfs' % self.iface, 0):
        #     return None

        # ret_dict = {}

        # with open(
        #     '/sys/class/net/%s/device/sriov_numvfs' % self.iface, 'r'
        # ) as fileobj:
        #     ret_dict['num'] = int(fileobj.read().strip())

        # with open(
        #     '/sys/class/net/%s/device/sriov_totalvfs' % self.iface, 'r'
        # ) as fileobj:
        #     ret_dict['total'] = int(fileobj.read().strip())

        # return ret_dict

    @sriov.setter
    def sriov(self, new_num):
        """Set the number of VFs"""
        raise NotImplementedError("sriov setter is not implemented for FreeBSD")
        # if not os.access(
        #         '/sys/class/net/%s/device/sriov_totalvfs' % self.iface, 0):
        #     raise exception.ConfigException('SR-IOV is disabled')

        # with open(
        #     '/sys/class/net/%s/device/sriov_numvfs' % self.iface, 'w'
        # ) as fileobj:
        #     fileobj.write(str(new_num))

    @property
    def pcidevice(self):
        """ Return PCI device name
            eg. sysctl output (int values!): slot=0 function=1 dbsf=pci0:101:0:1
        """
        output = exe.block_run(f'sysctl {self.sysctl_iface_name}.%location')
        bdf_raw_list = re.findall(r'dbsf=pci(\d+):(\d+):(\d+):(\d+)', output)[0]
        bdf_list = [f'{int(field):x}' for field in bdf_raw_list]
        return '{}:{}:{}.{}'.format(*bdf_list)  # pylint: disable=C0209

    @property
    def local_cpulist(self) -> List[int]:
        """ Return a list of the CPUs localized for the given NIC (interface)

        :return: List of cpu indexes
        """
        # Can use sysctl hw.ncpu to get num cpus, vm.ndomains to get #sockets, kern.sched.topology_spec to see topology
        # With 2 domains(sockets), 2 threads/core, the cpus are numbered by thread first (per kern.sched.topology_spec),
        # such that cpu0 and cpu1 are on core0; cpu2, cpu3 are on core1. So use even or odd cpus to get different cores
        # TODO: Use lstopo/hwloc or similar to determine local cpus
        try:
            cpus = exe.block_run(f'sysctl -n {self.sysctl_iface_name}.%local_cpus').strip()
            cpulist = cpus.replace(':', ' ').replace(',', ' ').split()
        except Exception:
            # Fallback to ALL CPUs until a method is available to get 'local' CPUs reliably in freebsd
            num_cpus = int(exe.block_run('sysctl -n hw.ncpu').strip())
            cpulist = list(range(num_cpus))
        return sorted(cpulist)

    @property
    def numa_node(self):
        # TODO: Use lstopo?
        # vm.ndomains, vm.numa.disabled (if vm.numa)
        if exe.block_run('sysctl -n vm.ndomains').strip() == '1':
            return 0

        raise NotImplementedError("numa_node is not yet implemented for FreeBSD")
        # if not os.access(
        #         '/sys/class/net/%s/device/numa_node' % self.iface, 0):
        #     return None

        # with open(
        #     '/sys/class/net/%s/device/numa_node' % self.iface, 'r'
        # ) as fileobj:
        #     numa_node = fileobj.read().strip()
        # return int(numa_node)

    def devlink(self, mode='switchdev'):
        """Set iface to switchdev mode"""
        raise NotImplementedError("devlink is not implemented for FreeBSD")
        # exe.block_run('devlink dev eswitch set pci/%s mode %s' % (self.pcidevice, mode))

    def vf_reps(self, port_id=None):
        """Return the names of VF representors along with the details returned by `get_vfs_info`.

        This function uses OS commands and should be called on the host, e.g. via rpyc.

        Output format is:
        .. code-block:
            {
                0: {
                    'businfo': '0000:98:00.0',
                    'name': 'p2p1_0',
                    'mac': '00:01:02:03:04:05',
                    'vfr_name': 'eth0'
                },
                1: {
                    'businfo': '0000:98:00.1',
                    'name': 'p2p1_1',
                    'mac': '00:01:02:03:04:06',
                    'vfr_name': 'eth1'
                }
            }

        :param interface: The name of the interface to get the VF representor info of.
        :return: A dict containing the info of VF representors.
        """
        raise NotImplementedError("vf_reps is not implemented for FreeBSD")

        # _sysfs_net = '/sys/class/net'
        # vf_list = self.vf_list
        # vf_rep_info = {}

        # vf_id = 0
        # for vf_name, vf_pci in vf_list.items():
        #     vf_rep_info[vf_id] = {}
        #     vf_rep_info[vf_id]['name'] = vf_name
        #     vf_rep_info[vf_id]['businfo'] = vf_pci
        #     vf_rep_info[vf_id]['vfr_name'] = 'unavailable'
        #     vf_id += 1

        # with open(f'{_sysfs_net}/{self.iface}/phys_switch_id', 'r') as f:
        #     pf_switch_id = f.read().strip()

        # sysfs_net_entries = os.walk(_sysfs_net)

        # for _, ifaces, _ in sysfs_net_entries:
        #     for iface in ifaces:
        #         if iface != self.iface:
        #             try:
        #                 with open(f'{_sysfs_net}/{iface}/phys_switch_id', 'r') as f:
        #                     switch_id = f.read().strip()

        #                 if switch_id == pf_switch_id:
        #                     with open(f'{_sysfs_net}/{iface}/phys_port_name', 'r') as f:
        #                         port_name = f.read().strip()
        #                         port_name = re.search(r'pf(\d)vf(\d+)', port_name)
        #                         if port_name:
        #                             pf_id = int(port_name.group(1))
        #                             vf_id = int(port_name.group(2))
        #                             if port_id in [None, pf_id]:
        #                                 vf_rep_info[vf_id]['vfr_name'] = iface

        #             except OSError:
        #                 pass

        # log.debug(f'VF representor info of {self.iface}: {vf_rep_info}.')
        # return vf_rep_info

    @property
    def vf_list(self):
        raise NotImplementedError("vf_list is not implemented for FreeBSD")
        # from collections import OrderedDict
        # from controller.lib.freebsd import eth
        # pci_dev_vfs_list = OrderedDict()
        # vf_pci_devids = {}
        # pf_pci_id = os.path.realpath('/sys/class/net/%s/device' % self.iface).split('/')[-1]
        # for vf_iface in eth.get_interfaces_by_driver('bnxt_en'):
        #     vf_phy_pci_id = os.path.realpath('/sys/class/net/%s/device/physfn' % vf_iface.name).split('/')[-1]
        #     if pf_pci_id == vf_phy_pci_id:
        #         vf_pci_id = os.path.realpath('/sys/class/net/%s/device' % vf_iface.name).split('/')[-1]
        #         vf_pci_devids[vf_pci_id] = vf_iface.name
        #         vf_iface.up()

        # for pci_id, vf_name in sorted(vf_pci_devids.items()):
        #     pci_dev_vfs_list[vf_name] = pci_id
        # return pci_dev_vfs_list

    @property
    def roce_first_port(self) -> str:
        """Return the first roce port number of the interface (expect 1)"""
        roce_iface = self.roce
        port_output = exe.block_run(f'sysctl -N sys.class.infiniband.{roce_iface}.ports | head -1', shell=True)
        return port_output.splitlines()[-1].split('.')[-1]

    def set_roce_version(self, roce_v2=True):
        """Set the default roce mode to v1 or v2"""
        if roce_v2:
            log.info('Setting RoCE Version to V2...')
            version = 'RoCE v2'
        else:
            log.info('Setting RoCE Version to V1...')
            version = 'IB/RoCE v1'

        port = self.roce_first_port
        exe.block_run(f'sysctl sys.class.infiniband.{self.roce}.default_roce_mode_port{port}="{version}"')

    @property
    def roce(self) -> str:
        """ Return the associated roce interface name"""

        # output syntax: sys.class.infiniband.{ndev}.ports.{port}.gid_attrs.ndevs.{gid_idx}={iface}
        ndev_data = exe.block_run(f'sysctl -e sys.class.infiniband | grep gid_attrs.ndevs | grep {self.iface}',
                                  shell=True)
        return ndev_data.splitlines()[-1].split('=')[0].split('.')[3]

    @property
    def roce_state(self) -> str:
        """ Return the state (lowercase str) of the RoCE interface """
        roce_iface = self.roce
        port = self.roce_first_port
        state_data = exe.block_run(f'sysctl -e sys.class.infiniband.{roce_iface}.ports.{port}.state')
        # '1: DOWN', '2: INIT', '3: ARMED', '4: ACTIVE', '5: ACTIVE_DEFER' => 'down', 'init', ...
        raw_state = state_data.splitlines()[-1].split('=')[-1].strip()
        return raw_state.split(':')[-1].strip().lower()

    @property
    def roce_phys_state(self) -> str:
        """ Return the physical state (lowercase str) of the RoCE interface """
        roce_iface = self.roce
        port = self.roce_first_port
        state_data = exe.block_run(f'sysctl -e sys.class.infiniband.{roce_iface}.ports.{port}.phys_state')
        # '1: DOWN', '2: INIT', '3: ARMED', '4: ACTIVE', '5: ACTIVE_DEFER' => 'down', 'init', ...
        raw_state = state_data.splitlines()[-1].split('=')[-1].strip()
        return raw_state.split(':')[-1].strip().lower()

    @property
    def roce_rate(self) -> Tuple[float, int]:
        """ Return the rate of the RoCE interface as a list: speed (Gbps) and width (speed multiplier)
            Multiplier is with respect to one of the relevant defined infiniband rates: QDR(10), EDR(25), HDR(50)
        """
        roce_iface = self.roce
        port = self.roce_first_port
        state_data = exe.block_run(f'sysctl -e sys.class.infiniband.{roce_iface}.ports.{port}.rate')
        # Eg. 25 Gb/sec (1X EDR) => return (25, 1)
        raw_rate = state_data.splitlines()[-1].split('=')[-1].strip()
        # Handle special case where rate is 2.5 Gbps when phy link is down/inactive (return speed as float)
        rate = list(map(float, re.findall(r'([0-9.]+)\s+Gb/sec\s+\((\d)X\s[DEFHQS]DR\)', raw_rate)[0]))
        rate[1] = int(rate[1])
        return rate

    @property
    def roce_speed(self) -> float:
        """ Return the speed of the RoCE interface in Gbps """
        return self.roce_rate[0]

    def roce_gid(self, ip_addr) -> List[str]:
        """ Return a list of GUID indices for the RoCE interface and specific IP address

        :param ip_addr: Get GIDs for the specific IP
        :return: A list which we expect contains the v1 GID and v2 GID for the IP, in that order
        """
        def is_matching_gid(gid, ip):
            gid_list = gid.strip().split(':')
            if int(''.join(gid_list), 16) == 0:
                return False
            # Handle IPv4 (last two words; last 4 octets) and IPv6
            gid_ip_idx = -2 if int(gid_list[0], 16) == 0 else 0
            gid_ip = ipaddress.ip_address(int(''.join(gid_list[gid_ip_idx:]), 16)).compressed
            if gid_ip == ipaddress.ip_address(ip).compressed:
                return True
            return False

        gid_idxs = []
        roce_iface = self.roce
        port = self.roce_first_port
        # TODO: BUG? ndevs only has entries for half the GIDs (as if only v1 or only v2 GIDs existed)
        # ndev_data = exe.block_run(f'sysctl -e sys.class.infiniband | grep gid_attrs.ndevs | grep {self.iface}',
        #                           shell=True)
        # all_gid_idxs = re.findall(rf'\.(\d+)={self.iface}', ndev_data)
        # all_gid_idxs.reverse()  # gids listed in decreasing order in sysctl

        # for gid_idx in all_gid_idxs:
        #     gid_data = exe.block_run(f'sysctl -n sys.class.infiniband.{roce_iface}.ports.{port}.gids.{gid_idx}')
        #     gid = gid_data.splitlines()[-1].strip()
        #     if is_matching_gid(gid, ip_addr):
        #         gid_idxs.append(int(gid_idx))

        output = exe.block_run(f"sysctl -e sys.class.infiniband.{roce_iface}.ports.{port}.gids")
        gids = re.findall(rf'sys.class.infiniband.{roce_iface}.ports.{port}.gids.(\d+)=(.*)', output)
        if int(gids[0][0]) != 0:
            gids.reverse()
        # Exclude 'zero' GIDs, and check for match to specified IP
        gid_idxs = map(
            int, (gid[0] for gid in gids if int(''.join(gid[1].split(':')), 16) and is_matching_gid(gid[1], ip_addr)))

        return list(map(str, sorted(gid_idxs)))

    def roce_v1_gid(self, ip_addr=None) -> str:
        """ Return the RoCE V1 gid for the RoCE interface and IP """
        ipaddr = self.ip_addr if not ip_addr else ip_addr
        gid_list = self.roce_gid(ipaddr)
        if len(gid_list) == 1:
            raise exception.HostException(f'RoCE V1 support is deprecated, no v1 GID for {ipaddr}. {gid_list}')
        if gid_list:
            return gid_list[0]
        raise exception.HostException(f'RoCE v1 GID not found for {ipaddr}. {gid_list}')

    def roce_v2_gid(self, ip_addr=None) -> str:
        """ Return the RoCE V2 gid for the RoCE interface and IP """
        ipaddr = self.ip_addr if not ip_addr else ip_addr
        gid_list = self.roce_gid(ipaddr)
        if gid_list and len(gid_list) == 2:
            return gid_list[1]
        raise exception.HostException(f'RoCE v2 GID not found for {ipaddr}. {gid_list}')

    @property
    def roce_stats(self) -> Dict[str, str]:
        """ Return the stats of the RoCE interface """
        roce_iface = self.roce
        port = self.roce_first_port
        stats_data = exe.block_run(f'sysctl -e sys.class.infiniband.{roce_iface}.ports.{port}.hw_counters')
        stats_dict = dict(re.findall(r'\.hw_counters\.(\w+)=(.*)', stats_data))

        # Also support using the linux names that come from the kernel debug roce 'info' sysfs folder
        compat_map = {
            'link_state': 'link state',
            'max_qp': 'Max QP',
            'max_srq': 'Max SRQ',
            'max_cq': 'Max CQ',
            'max_mr': 'Max MR',
            'max_mw': 'Max MW',
            'max_ah': 'Max AH',
            'max_pd': 'Max PD',
            'active_qp': 'Active QP',
            'active_srq': 'Active SRQ',
            'active_cq': 'Active CQ',
            'active_mr': 'Active MR',
            'active_mw': 'Active MW',
            'active_ah': 'Active AH',
            'active_pd': 'Active PD',
            'qp_watermark': 'QP Watermark',
            'srq_watermark': 'SRQ Watermark',
            'cq_watermark': 'CQ Watermark',
            'mr_watermark': 'MR Watermark',
            'mw_watermark': 'MW Watermark',
            'ah_watermark': 'AH Watermark',
            'pd_watermark': 'PD Watermark',
            'resize_cq_count': 'Resize CQ count',
            'recoverable_errors': 'Recoverable Errors',
            'rx_pkts': 'Rx Pkts',
            'rx_bytes': 'Rx Bytes',
            'tx_pkts': 'Tx Pkts',
            'tx_bytes': 'Tx Bytes',
            'cnp_tx_pkts': 'CNP Tx Pkts',
            'cnp_rx_pkts': 'CNP Rx Pkts',
            'roce_only_rx_pkts': 'RoCE Only Rx Pkts',
            'roce_only_rx_bytes': 'RoCE Only Rx Bytes',
            'roce_only_tx_pkts': 'RoCE Only Tx Pkts',
            'roce_only_tx_bytes': 'RoCE Only Tx Bytes',
        }
        # Add entries using the compat_map values as roce_stats keys
        for bsd_key, lin_key in compat_map.items():
            if bsd_key in stats_dict:
                stats_dict[lin_key] = stats_dict[bsd_key]
        return stats_dict

    @property
    def qPairs(self) -> Dict[str, str]:  # pylint: disable=C0103
        """ Return the number of Active Queue Pairs of the RoCE interface """
        stats = self.roce_stats
        qpairs = {}
        if stats:
            qpairs['Active QP'] = str(stats['Active QP'])
            qpairs['Max QP'] = str(stats['Max QP'])
        return qpairs


def get_interface_by_driver(driver):
    """Return a list of ethX that uses the given driver

    Args:
        driver (str): driver name

    Return:
        list: list of ethX names
    """

    ret_list = []
    for pci_data in exe.block_run(f'pciconf -l | grep ^{driver}', shell=True).splitlines():
        iface = pci_data.split('@', 1)[0]
        ret_list.append(AppInterface(iface=iface))

    return ret_list


def get_interfaces():
    """Simply return all ethX interface names
    """

    return [pci.split('@', 1)[0] for pci in exe.block_run('pciconf -l | grep class=0x0200', shell=True).splitlines()]
