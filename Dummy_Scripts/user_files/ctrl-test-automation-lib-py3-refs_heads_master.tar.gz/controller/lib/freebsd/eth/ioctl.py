"""
:mod:`ioctl` -- Ethernet IOCTL header
=====================================

.. module:: controller.lib.freebsd.ioctl
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This module is a simple header file for communicating with Ethernet IOCTL.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"


from ctypes import *


IFNAMSIZ = 16
IFHWADDRLEN = 6


# linux/if.h
class If(object):
    IFF_UP = 1 << 0


# sockio.h
class SIOC(object):
    SIOCGIFCONF = 0x8912
    SIOCGIFINDEX = 0x8933
    SIOCGIFFLAGS =  0x8913
    SIOCSIFFLAGS =  0x8914
    SIOCGIFHWADDR = 0x8927
    SIOCSIFHWADDR = 0x8924
    SIOCGIFADDR = 0x8915
    SIOCSIFADDR = 0x8916
    SIOCGIFMTU = 0x8921
    SIOCSIFMTU = 0x8922
    SIOCETHTOOL = 0x8946
    SIOCGIFNETMASK = 0x891B
    SIOCSIFNETMASK = 0x891C


# ethtool.h
class Ethtool(object):
    ETHTOOL_GSET = 0x00000001  # Get settings.
    ETHTOOL_SSET = 0x00000002  # Set settings.
    ETHTOOL_GDRVINFO = 0x00000003  # Get driver info.
    ETHTOOL_GREGS = 0x00000004  # Get NIC registers.
    ETHTOOL_GWOL = 0x00000005  # Get wake-on-lan options.
    ETHTOOL_SWOL = 0x00000006  # Set wake-on-lan options.
    ETHTOOL_GMSGLVL = 0x00000007  # Get driver message level
    ETHTOOL_SMSGLVL = 0x00000008  # Set driver msg level.
    ETHTOOL_NWAY_RST = 0x00000009  # Restart autonegotiation.

    ETHTOOL_GLINK = 0x0000000a
    ETHTOOL_GEEPROM = 0x0000000b  # Get EEPROM data
    ETHTOOL_SEEPROM = 0x0000000c  # Set EEPROM data.
    ETHTOOL_GCOALESCE = 0x0000000e  # Get coalesce config
    ETHTOOL_SCOALESCE = 0x0000000f  # Set coalesce config.
    ETHTOOL_GRINGPARAM = 0x00000010  # Get ring parameters
    ETHTOOL_SRINGPARAM = 0x00000011  # Set ring parameters.
    ETHTOOL_GPAUSEPARAM = 0x00000012  # Get pause parameters
    ETHTOOL_SPAUSEPARAM = 0x00000013  # Set pause parameters.
    ETHTOOL_GRXCSUM = 0x00000014  # Get RX hw csum enable (ethtool_value)
    ETHTOOL_SRXCSUM = 0x00000015  # Set RX hw csum enable (ethtool_value)
    ETHTOOL_GTXCSUM = 0x00000016  # Get TX hw csum enable (ethtool_value)
    ETHTOOL_STXCSUM = 0x00000017  # Set TX hw csum enable (ethtool_value)
    ETHTOOL_GSG = 0x00000018  # Get scatter-gather enable
    ETHTOOL_SSG = 0x00000019  # Set scatter-gather enable
    ETHTOOL_TEST = 0x0000001a  # execute NIC self-test.
    ETHTOOL_GSTRINGS = 0x0000001b  # get specified string set
    ETHTOOL_PHYS_ID = 0x0000001c  # identify the NIC
    ETHTOOL_GSTATS = 0x0000001d  # get NIC-specific statistics
    ETHTOOL_GTSO = 0x0000001e  # Get TSO enable (ethtool_value)
    ETHTOOL_STSO = 0x0000001f  # Set TSO enable (ethtool_value)
    ETHTOOL_GPERMADDR = 0x00000020  # Get permanent hardware address
    ETHTOOL_GUFO = 0x00000021  # Get UFO enable (ethtool_value)
    ETHTOOL_SUFO = 0x00000022  # Set UFO enable (ethtool_value)
    ETHTOOL_GGSO = 0x00000023  # Get GSO enable (ethtool_value)
    ETHTOOL_SGSO = 0x00000024  # Set GSO enable (ethtool_value)
    ETHTOOL_GFLAGS = 0x00000025  # Get flags bitmap(ethtool_value)
    ETHTOOL_SFLAGS = 0x00000026  # Set flags bitmap(ethtool_value)
    ETHTOOL_GPFLAGS = 0x00000027  # Get driver-private flags bitmap
    ETHTOOL_SPFLAGS = 0x00000028  # Set driver-private flags bitmap

    ETHTOOL_GRXFH = 0x00000029  # Get RX flow hash configuration
    ETHTOOL_SRXFH = 0x0000002a  # Set RX flow hash configuration
    ETHTOOL_GGRO = 0x0000002b  # Get GRO enable (ethtool_value)
    ETHTOOL_SGRO = 0x0000002c  # Set GRO enable (ethtool_value)
    ETHTOOL_GRXRINGS = 0x0000002d  # Get RX rings available for LB
    ETHTOOL_GRXCLSRLCNT = 0x0000002e  # Get RX class rule count
    ETHTOOL_GRXCLSRULE = 0x0000002f  # Get RX classification rule
    ETHTOOL_GRXCLSRLALL = 0x00000030  # Get all RX classification rule
    ETHTOOL_SRXCLSRLDEL = 0x00000031  # Delete RX classification rule
    ETHTOOL_SRXCLSRLINS = 0x00000032  # Insert RX classification rule
    ETHTOOL_FLASHDEV = 0x00000033  # Flash firmware to device
    ETHTOOL_RESET = 0x00000034  # Reset hardware
    ETHTOOL_SRXNTUPLE = 0x00000035  # Add an n-tuple filter to device
    ETHTOOL_GRXNTUPLE = 0x00000036  # deprecated
    ETHTOOL_GSSET_INFO = 0x00000037  # Get string set info
    ETHTOOL_GRXFHINDIR = 0x00000038  # Get RX flow hash indir'n table
    ETHTOOL_SRXFHINDIR = 0x00000039  # Set RX flow hash indir'n table

    ETHTOOL_GFEATURES = 0x0000003a  # Get device offload settings
    ETHTOOL_SFEATURES = 0x0000003b  # Change device offload settings
    ETHTOOL_GCHANNELS = 0x0000003c  # Get no of channels
    ETHTOOL_SCHANNELS = 0x0000003d  # Set no of channels
    ETHTOOL_SET_DUMP = 0x0000003e  # Set dump settings
    ETHTOOL_GET_DUMP_FLAG = 0x0000003f  # Get dump settings
    ETHTOOL_GET_DUMP_DATA = 0x00000040  # Get dump data
    ETHTOOL_GET_TS_INFO = 0x00000041  # Get time stamping and PHC info
    ETHTOOL_GMODULEINFO = 0x00000042  # Get plug-in module information
    ETHTOOL_GMODULEEEPROM = 0x00000043  # Get plug-in module eeprom
    ETHTOOL_GEEE = 0x00000044  # Get EEE settings
    ETHTOOL_SEEE = 0x00000045  # Set EEE settings

    ETHTOOL_GRSSH = 0x00000046  # Get RX flow hash configuration
    ETHTOOL_SRSSH = 0x00000047  # Set RX flow hash configuration
    ETHTOOL_GTUNABLE = 0x00000048  # Get tunable configuration
    ETHTOOL_STUNABLE = 0x00000049  # Set tunable configuration


# IPv4
class in4_addr(Structure):
    _fields_ = [('s_addr', c_uint32)]


class sockaddr_in4(Structure):
    _fields_ = [
        ('sin_family', c_ushort),
        ('sin_port', c_ushort),
        ('sin_addr', in4_addr),
        ('sin_zero', (c_ubyte * 8))  # padding
    ]


class sockaddr(Union):
    # linux/socket.h
    _fields_ = [
        ('sa_family', c_ushort),  # AF_xxx
        ('sa_data', (c_ubyte * 14)),
        ('in4', sockaddr_in4),
    ]


class ifmap(Structure):
    _fields_ = [
        ('mem_start', c_ulong),
        ('mem_end', c_ulong),
        ('base_addr', c_ushort),
        ('irq', c_char),
        ('dma', c_char),
        ('port', c_char),
    ]


class ifr_ifru(Union):
    # Refer netdevice man. Different from uapi/linux/if.h
    _fields_ = [
        ('ifr_addr', sockaddr),
        ('ifr_dstaddr', sockaddr),
        ('ifr_broadaddr', sockaddr),
        ('ifr_netmask', sockaddr),
        ('ifr_hwaddr', sockaddr),
        ('ifr_flags', c_short),
        ('ifr_ifindex', c_int),
        ('ifr_metric', c_int),
        ('ifr_mtu', c_int),
        ('ifr_map', ifmap),
        ('ifr_slave', (c_char*IFNAMSIZ)),
        ('ifr_newname', (c_char*IFNAMSIZ)),
        ('ifr_data', c_void_p),
    ]


class ifreq(Structure):
    _anonymous_ = ('ifr_ifru',)
    _fields_ = [
        ('ifr_name', (c_char * IFNAMSIZ)),
        ('ifr_ifru', ifr_ifru)
    ]


# IPv6
class in6_u(Union):
    _fields_ = [
        ('u6_addr8', (c_uint8 * 16)),
        ('u6_addr16', (c_uint16 * 8)),
        ('u6_addr32', (c_uint32 * 4)),
    ]


class in6_addr(Structure):
    _anonymous_ = ('in6_u',)
    _fields_ = [('in6_u', in6_u)]


class sockaddr_in6(Structure):
    _fields_ = [
        ('sin6_family', c_ushort),
        ('sin6_port', c_uint16),
        ('sin6_flowinfo', c_uint32),
        ('sin6_addr', in6_addr),
        ('sin6_scope_id', c_uint32),
    ]


class in6_ifreq(Structure):
    _fields_ = [
        ('ifr_addr', in6_addr),
        ('ifr6_prefixlen', c_uint32),
        ('ifr6_ifindex', c_uint),
    ]


ETHTOOL_FWVERS_LEN = 32
ETHTOOL_BUSINFO_LEN = 32

# linux/ethtool.h
class ethtool_cmd(Structure):
    _fields_ = [
        ('cmd', c_uint32),
        ('supported', c_uint32),
        ('advertising', c_uint32),
        ('speed', c_uint16),
        ('duplex', c_uint8),
        ('port', c_uint8),
        ('phy_address', c_uint8),
        ('transceiver', c_uint8),
        ('autoneg', c_uint8),
        ('mdio_support', c_uint8),
        ('maxtxpkt', c_uint32),
        ('maxrxpkt', c_uint32),
        ('speed_hi', c_uint16),
        ('eth_tp_mdix', c_uint8),
        ('eth_tp_midx_ctrl', c_uint8),
        ('ip_advertising', c_uint32),
        ('reseerved', (c_uint32 * 2)),
    ]

class ethtool_drvinfo(Structure):
    _fields_ = [
        ('cmd', c_uint32),
        ('driver', c_char * 32),
        ('version', c_char * 32),
        ('fw_version', c_char *ETHTOOL_FWVERS_LEN ),
        ('bus_info', c_char * ETHTOOL_BUSINFO_LEN),
        ('reserved1', c_char * 32),
        ('reserved2', c_char * 12),
        ('n_priv_flags', c_uint32),
        ('n_stats', c_uint32),
        ('testinfo_len', c_uint32),
        ('eedump_len', c_uint32),
        ('regdump_len', c_uint32),
    ]


def ethtool_stats_factory(n_stats, **kwargs):
    class ethtool_stats(Structure):
        _fields_ = [
            ('cmd', c_uint32),
            ('n_stats', c_uint32),
            ('data', (n_stats * c_uint64)),
        ]

    return ethtool_stats(**kwargs)


def ethtool_gstrings_factory(gstring_len, **kwargs):
    """
    enum for stringset

    ETH_SS_TEST = 0
    ETH_SS_STATS = 1
    ETH_SS_PRIV_FLAGS = 2
    ETH_SS_NTUPLE_FILETERS = 3
    ETH_SS_FEATUERS = 4
    ETH_SS_RSS_HAS_FUNCS = 5
    """

    class ethtool_gstrings(Structure):
        _fields_ = [
            ('cmd', c_uint32),
            ('string_set', c_uint32),
            ('len', c_uint32),
            ('data', (gstring_len * (32 * c_char))),
        ]

    return ethtool_gstrings(cmd=Ethtool.ETHTOOL_GSTRINGS, **kwargs)