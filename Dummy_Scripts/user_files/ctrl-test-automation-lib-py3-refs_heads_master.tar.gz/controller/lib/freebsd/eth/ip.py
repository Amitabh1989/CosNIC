"""
:mod:`ip` -- Linux tool 'ip' wrapper (delegates to ifconfig for FreeBSD)
========================================================================

.. module:: controller.lib.freebsd.eth.ip
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This module is a simple wrapper around 'ip' tool which can be used for
configuring IP address, routing, etc.

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import re
import ipaddress
from typing import Callable, List

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.freebsd import set_default_cli
from controller.lib.freebsd.eth import ifconfig

log = log_handler.get_logger(__name__)
the_exe = exe


def trim_iface_name(function):
    """
    The decorator that trims the interface name if it's larger than 15 bytes as newer versions of
    "ip" tool expect interface names to be < 15 bytes.
    """
    # CTRL-45596: [controller-0.3.9b19] Many vlan scripts failing as STAT tried to create vlan
    # interfaces which exceeds MAX limit of 15 characters for interface name created via "ip link".
    # Use the trimmed interface name to work with newer "ip" command.
    def inner(iface, *args, **kwargs):
        iface = iface[-15:]
        return function(iface, *args, **kwargs)

    return inner


def use_ssh(ssh_ip_addr=None):
    """
    The function that selects the method to use to run the ip commands. If ssh_ip_address is
    specified, an SSH connection to that IP adress is established and that connection is used to
    run the ip commands. Otherwise, the usual shell exe module is used.

    Args:
        ssh_ip_addr (str): The IP address to use for running ip commands over SSH. When None, the
        SSH mode is exited.

    Caution:
        It is the responsibility of the caller to reset the SSH mode by calling this function
        with ssh_ip_addr=None.
    """
    from controller.lib.freebsd.system import ssh
    global the_exe

    if ssh_ip_addr is not None:
        the_exe = ssh.SSH(ssh_ip_addr)
    else:
        if isinstance(the_exe, ssh.SSH):
            the_exe.disconnect()

        the_exe = exe


@trim_iface_name
def up(iface: str):  # pylint: disable=C0103
    """ Bring up the interface

    Args:
        iface (str): ethX name

    """
    ifconfig.set_state(iface, 'up')


@trim_iface_name
def down(iface: str):
    """ Bring down the interface

    Args:
        iface (str): ethX name
    """
    ifconfig.set_state(iface, 'down')


@trim_iface_name
def set_ip_addr(iface: str, ip_addr: str, method='add', ipv6=False):
    """
    Set IP address to the given iface. Not using IOCTL to test the application
    layer, namely "ip"

    Args:
        iface (str): ethX name
        ip_addr (str): IP address in the X.X.X.X/X format which includes subnet
        method (str): [add|change|replace|del] as "ip" command accepts to
           assign a new IP address.
        ipv6 (bool): Configure IPv6 address if True else IPv4

    Returns:
        str: Output of ip command

    """
    # convert the ip_addr to ip_addr and netmask
    try:
        ip_addr, netmask = ip_addr.split('/')
    except ValueError as err:
        raise exception.ValueException(
            f'Invalid IP address/netmask argument {ip_addr}. Must be x.x.x.x/x format') from err

    if netmask and isinstance(netmask, str) and re.match(r'\d+\.\d+\.\d+\.\d+', netmask):
        netmask = sum(bin(int(x)).count('1') for x in netmask.split('.'))

    # ip_addr = '%s/%s' % (ip_addr, netmask)
    # Do not check parameter values further. Let "ip" tool raise exceptions
    # if any parameters are incorrect.
    try:
        return ifconfig.set_ip_addr(iface, ip_addr, netmask, method, ipv6)
    except exception.ExeExitcodeException as err:
        if 'File exists' in err.output:
            raise exception.IPFileExists(f'Same IP address is already assigned. Output: {err.output}') from err
        raise  # Raise all other exception types


@trim_iface_name
def get_ip_addr(iface: str, ipv6=False):
    """
    Return a list of IP addresses.

    Args:
        iface (str): ethX name
        ipv6 (bool): Get IPv6 address if True else IPv4

    Returns:
        list: IP addresses
        list: tuple of (IP address, netmask) if netmask is True

    """
    try:
        ip_addrs = ifconfig.get_ip_addr(iface, ipv6, is_netmask=True)
    except Exception:
        return []
    ip_addr_list = []
    for ip_addr, netmask in ip_addrs:
        if netmask and isinstance(netmask, str) and re.match(r'\d+\.\d+\.\d+\.\d+', netmask):
            netmask = sum(bin(int(x)).count('1') for x in netmask.split('.'))
        ip_addr_list.append(f"{ip_addr}{f'/{netmask}' if netmask else ''}")

    return ip_addr_list


@trim_iface_name
def get_mac_addr(iface: str):
    """
    Get MAC address of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: MAC address in XX:XX:XX:XX:XX:XX format

    """
    return ifconfig.get_mac_addr(iface)


@trim_iface_name
def set_mac_addr(iface: str, mac_addr):
    """
    Set MAC address of the interface

    Args:
        iface (str): ethX name
        mac_addr (str): New MAC address in XX:XX:XX:XX:XX:XX format

    """
    if not re.match('[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}',
                    mac_addr):
        raise ValueError(f'MAC address must be in XX:XX:XX:XX:XX:XX format (input: {mac_addr})')

    ifconfig.set_mac_addr(iface, mac_addr)


@trim_iface_name
def get_flags(iface: str) -> List[str]:
    """
    Get flag values of the interface.

    Args:
        iface (str): ethX name

    Returns: List of flag names (strings) or raise exception.IPException

    """
    return ifconfig.get_flags(iface)


@trim_iface_name
def get_state(iface: str):
    """
    Return "State" of the interface

    Args:
        iface (str): ethX name

    Returns:
        str: state ( up or down ).

    """
    return ifconfig.get_state(iface)


@trim_iface_name
def get_mtu(iface: str):
    """
    Return MTU of the interface

    Args:
        iface (str): ethX name

    Returns:
        int: MTU size

    """
    return ifconfig.get_mtu(iface)


@trim_iface_name
def set_mtu(iface: str, mtu):
    """
    Set MTU of the interface

    Args:
        iface (str): ethX name
        mtu (int): MTU size

    """
    ifconfig.set_mtu(iface, mtu)


@trim_iface_name
def add_veth_pair(endpoint1, endpoint2):
    """
    veth devices are created in interconnected pairs.
    TODO: veth => epair in freebsd (use ifconfig). Requires epair kernel module (/boot/loader.conf: if_epair_load="YES")

    Args:
        endpoint1 (str): veth endpoint1 name
        endpoint2 (str): veth endpoint2 name

    """
    raise NotImplementedError("Not yet supported for freebsd (veth=>epair)")
    # ifconfig.add_veth_pair(endpoint1, endpoint2)


@trim_iface_name
def add_vlan(iface: str, vlan_id, lower_kernel=False, name=None, proto='802.1Q') -> str:
    """
    Remove vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID

    Returns: vlan name

    """
    return ifconfig.add_vlan(iface, vlan_id, lower_kernel, name, proto)


def remove_vlan(iface: str = None, vlan_id: int = None, vlan_name: str = None, lower_kernel=False):
    """
    Remove vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID
        vlan_name (str): vlan interface name
    """
    ifconfig.remove_vlan(iface, vlan_id, vlan_name, lower_kernel)


@trim_iface_name
def set_promiscuous_mode(iface: str, mode):
    """
    Set promiscuous for interface

    Args:
        iface (str): ethX name
        mode (str): on/off

    """
    ifconfig.set_promiscuous_mode(iface, mode)


@trim_iface_name
def set_route(iface: str, method, dst, gateway=None):
    """Set route

    Note that you must provide one of optional arguments, gateway and iface.

    Args:
        iface (str): ethX name
        method (str): [add|del] method to be passed to "ip" command.
        dst (str): Destination IP range with netmask i.e.) x.x.x.x/x
        gateway (None, str): route will be added using 'via' if this is given
            otherwise 'dev' will be used using iface

    """
    if not (gateway or iface):
        raise exception.ValueException('at least one of gateway and iface arguments should be passed')
    if gateway:
        cmd = f'route {method} -host {dst} {gateway}'
    else:
        is_ipv6 = bool(ipaddress.ip_address(dst).version == 6)
        iface_ip = get_ip_addr(iface, ipv6=is_ipv6)[0].split('/')[0]
        cmd = f'route {method} -host {dst} {iface_ip}'

    try:
        the_exe.block_run(cmd)
    except exception.ExeExitcodeException as err:
        if 'route already in table' in err.output:
            raise exception.IPFileExists('The same route is already assigned')
        raise
    finally:
        the_exe.block_run('netstat -rn; netstat -ni', shell=True)


@trim_iface_name
def set_macvlan(macvlan_iface_name, iface=None, method='add', mode='bridge'):
    """Set macvlan interface

    Args:
        iface (str): The interface name over which the macvlan interface is to be created
        method (str): [add/del] Add or Delete the macvlan interface
    """
    macvlan_iface_name = macvlan_iface_name[-15:]

    if method == 'add':
        cmd = 'ip link add %s link %s type macvlan mode %s' % \
            (macvlan_iface_name, iface, mode)
    else:
        cmd = 'ip link delete %s' % (macvlan_iface_name)

    the_exe.block_run(cmd)


@trim_iface_name
def set_vxlan(iface: str, method, vxlan_id, tun_name=None, group=None, remote=None, external=False, **kwargs):
    """Configure VXLAN

    Args:
        iface: ethX name
        method: [add|del] operation
        vxlan_id (int): VXLAN ID
        group (str): multicast group. Required for 'adding' VXLAN
        tun_name: Name of tunnel to be created
    """
    ifconfig.set_vxlan(iface, method, vxlan_id, tun_name, group, remote, external, **kwargs)


@trim_iface_name
def set_geneve(iface: str, method, geneve_id, tun_name=None, remote=None, **kwargs):
    """Configure Geneve

    Args:
        iface: ethX name
        method: [add|del] operation
        geneve_id (int): GENEVE ID
        tun_name: Name of tunnel to be created
    """
    # TODO: Freebsd: No native geneve support
    tun_name = (f'geneve.{geneve_id}') if tun_name is None else tun_name

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        cmd = 'ip link add %s type geneve id %s remote %s %s' % \
            (tun_name, geneve_id, remote, params)
    else:
        cmd = f'ip link delete {tun_name}'

    exe.block_run(cmd)


def create_gre(tun_name='gre'):
    """Create GRE tunnel interface

    Args:
        tun_name (str): gre interface name: create new sequentialy numbered interface if 'gre'

    Returns: The new tunnel interface name (in case a specific instacne was not specified: ie. 'gre')
    """
    return ifconfig.create_gre(tun_name)


@trim_iface_name
def set_gre(iface: str, tun_name, method, local=None, remote=None, ttl=255, ipv6=False, **kwargs):
    """Configure GRE tunneling

    Args:
        iface (str): ethX name
        tun_name (str): gre interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    ifconfig.set_gre(iface, tun_name, method, local, remote, ttl, ipv6, **kwargs)


@trim_iface_name
def set_ipip(iface: str, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    # TODO: Freebsd: gif via ifconfig
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip tunnel add %s mode ipip local %s remote %s ttl %s dev %s' % (tun_name, local, remote, ttl, iface)
    else:
        cmd = f'ip tunnel del {tun_name}'

    the_exe.block_run(cmd)


@trim_iface_name
def set_ipip6(iface: str, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    # TODO: Freebsd: gif via ifconfig
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip -6 tunnel add %s mode ipip6 local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = f'ip tunnel del {tun_name}'

    the_exe.block_run(cmd)


@trim_iface_name
def set_ip6ip(iface: str, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    # TODO: Freebsd: gif via ifconfig
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip tunnel add %s mode sit local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = f'ip tunnel del {tun_name}'

    the_exe.block_run(cmd)


@trim_iface_name
def set_ip6ip6(iface: str, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    # TODO: Freebsd: gif via ifconfig
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip -6 tunnel add %s mode ip6ip6 local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = f'ip tunnel del {tun_name}'

    the_exe.block_run(cmd)


@trim_iface_name
def set_sit(iface: str, tun_name, method, local=None, remote=None, mode='any', **kwargs):
    """Configure sit tunneling

    Args:
        iface (str): ethX name
        tun_name (str): sit interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        mode (str) : supported modes are ip6ip | ipip | mplsip | any
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        cmd = 'ip link add name %s type sit local %s remote %s mode %s dev %s %s' % \
              (tun_name, local, remote, mode, iface, params)
    else:
        cmd = f'ip link delete {tun_name}'

    the_exe.block_run(cmd)


@trim_iface_name
def set_ip6tnl(iface: str, tun_name, method, local=None, remote=None, mode='any', **kwargs):
    """Configure ip6tnl tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip6tnl interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        cmd = 'ip link add name %s type ip6tnl local %s remote %s mode %s dev %s %s' % \
              (tun_name, local, remote, mode, params, iface)
    else:
        cmd = f'ip link delete {tun_name}'

    the_exe.block_run(cmd)


def get_next_network_ip(ip_addr, v6=False):
    ip_addr, subnet = ip_addr.split("/") if '/' in ip_addr else (ip_addr, '')

    if v6:
        new_ip = ipaddress.ip_address(str(ip_addr)) + 2 ** 96
    else:
        new_ip = ipaddress.ip_address(str(ip_addr)) + 256

    if subnet:
        new_network_ip_addr = ipaddress.ip_network(str(new_ip)+'/'+subnet, strict=False)
    else:
        new_network_ip_addr = new_ip

    return new_network_ip_addr


def get_next_ip(ip_addr):
    # This ip address generated will try to match to the client tunnel ip in case of 'baremetal vxlan' config.
    #  So if client tunnel ip changes then the '+2' should be changed accordingly.
    new_ip = ipaddress.ip_address(str(ip_addr)) + 2
    return new_ip


@trim_iface_name
def get_vf_state(iface: str, vf_id):
    """
    Get the configured link state of the VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (int): The ID of the VF.
    Return:
        str: The configured link state of the VF (auto | enable | disable | None).
    """
    vf_state = None
    command = f'ip link show {iface}'
    command_output = the_exe.block_run(command)

    for each_line in command_output.split('\n'):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_state = re.search(r'link-state[\s]*([a-z]*)[,]*', each_line).group(1)
            break

    return vf_state


@trim_iface_name
def set_vf_state(iface: str, vf_id, vf_state):
    """
    Set the link state of the VF.

    Args:
        iface (str)   : The name of the PF interface.
        vf_id (int)   : The ID of the VF.
        vf_state (str): The link state to set.
    """
    command = 'ip link set %s vf %s state %s' % (iface, str(vf_id), vf_state)
    the_exe.block_run(command)


@trim_iface_name
def get_vf_rate(iface: str, vf_id):
    """
    Get the configured Max_TX_Rate of the VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (int): The ID of the VF.
    Return:
        str: The configured MAX_TX_RATE of the VF (Integer value only).
    """
    vf_rate = None
    command = f'ip link show {iface}'
    command_output = the_exe.block_run(command)

    for each_line in command_output.split('\n'):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_rate = re.search(r'max_tx_rate[\s]*(\d+)[,]*', each_line).group(1)
            break

    return vf_rate


@trim_iface_name
def set_vf_rate(iface: str, vf_id, vf_rate):
    """
Set the TX rate of the VF.

Args:
    iface (str)   : The name of the PF interface.
    vf_id (int)   : The ID of the VF.
    vf_rate (int): Rate value to be set.
"""
    command = 'ip link set %s vf %s rate %s' % (iface, vf_id, vf_rate)
    the_exe.block_run(command)


@trim_iface_name
def get_vf_vlan(iface: str, vf_id):
    """
    Get the VLAN id of the specified VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (str): The ID of the VF.
    Return:
        VLAN ID of the specified VF or None.
    """
    vf_vlan = None
    command = f'ip -o link show {iface}'
    command_output = the_exe.block_run(command, shell=True)

    for each_line in command_output.split('\\ '):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_vlan = re.search(r'vlan[\s]*(\d+)[,]*', each_line).group(1)
            break

    return vf_vlan


@trim_iface_name
def set_vf_vlan(iface: str, vf_id, vlan_id):
    """
    Set the vLAN ID on the VF.

    Args:
        iface (str)   : The name of the PF interface.
        vf_id (int)   : The ID of the VF.
        vf_state (str): The vLAN ID to set.
    """
    command = 'ip link set %s vf %s vlan %s' % (iface, str(vf_id), vlan_id)
    the_exe.block_run(command)


@trim_iface_name
def set_vf_mac(iface: str, vf_id, vf_mac):
    """
    Set the mac address for the specified  VF.

    Args:
        iface (str)   : The name of the PF interface.
        vf_id (int)   : The ID of the VF.
        vf_mac (str): mac_address value to be set.
    """
    command = 'ip link set %s vf %s mac %s' % (iface, vf_id, vf_mac)
    the_exe.block_run(command)


@trim_iface_name
def get_vf_mac(iface: str, vf_id):
    """
    Get the MAC address of the specified VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (str): The ID of the VF.
    Return:
        The MAC address of the specified VF or None.
    """
    vf_mac_address = None
    command = f'ip -o link show {iface}'
    command_output = the_exe.block_run(command, shell=True)

    for each_line in command_output.split('\\ '):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_mac_address = re.search(r'(MAC|ether)[\s]+([a-zA-Z0-9:]+)', each_line).group(2)
            break

    return vf_mac_address


def get_iface_name(mac_address):
    """
    Get the name of the interface with the MAC address specified.

    Args:
        mac_address (str): The MAC address of the interface.
    Return:
        The name of the interface with the specified MAC address or None.
    """
    iface_name = None
    command = 'ip -o link show'
    command_output = the_exe.block_run(command, shell=True)
    re_obj = re.search(rf'[0-9]+:[\s]+([\w]+).*link/ether[\s]+{mac_address}', command_output)

    if re_obj is not None:
        iface_name = re_obj.group(1)

    return iface_name


@trim_iface_name
def set_vf_trust(iface: str, vf_id, vf_trust_state=False):
    """
    Set the VF trust state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to configure the trust on.
        vf_trust_state: The trust state to configure (True=on; False=off).
    """
    trust_state = 'on' if vf_trust_state is True else 'off'
    command = 'ip link set dev %s vf %s trust %s' % (iface, vf_id, trust_state)
    # Configuring VF trust using ip command is not supported in all kernel versions.
    # So, expect failures and ignore it.
    try:
        the_exe.block_run(command, shell=True)
    except Exception:
        pass


@trim_iface_name
def get_vf_trust(iface: str, vf_id):
    """
    Get the VF trust state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to get the trust state of.
    Return:
        trust_state: True if trust is "on", False otherwise.
    """
    trust_state = False
    command = f'ip link show {iface}'
    command_output = the_exe.block_run(command, shell=True)
    trust_states = re.findall(f'vf {str(vf_id)}.*trust (on|off)', command_output.strip())

    if len(trust_states) > 0 and trust_states[0] == 'on':
        trust_state = True

    return trust_state


@trim_iface_name
def set_vf_mac(iface: str, vf_id, mac_address):
    """
    Set MAC address of the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to set MAC address of.
        mac_address: The MAC address to set.
    """
    command = 'ip link set dev %s vf %s mac %s' % (iface, vf_id, mac_address)
    the_exe.block_run(command, shell=True)


@trim_iface_name
def get_mcast_addr(iface: str):
    """
    Get the multicast addresses the specified interface is a part of.

    Args:
        iface: The name of the PF interface.
    Return:
        maddrs: A dictionary with multicast group ID as the key and a list of multicast
            addresses as the value.
    """
    maddrs = {}
    command = f'ip maddr show dev {iface}'
    item_list = the_exe.block_run(command, shell=True).split('\n')

    for item in item_list:
        if ':\t' in item:
            group_id = item.split(':')[0]
            maddrs[group_id] = []
        elif item != '':
            maddrs[group_id].append(item.strip())

    return maddrs


@trim_iface_name
def configure_mcast_addr(iface: str, maddr, action='add'):
    """
    Add/delete a static multicast address to/from the specified interface.

    Args:
        iface: The name of the PF interface.
        maddr: The multicast address to add/delete.
    """
    command = 'ip maddr %s %s dev %s' % (action, maddr, iface)
    the_exe.block_run(command, shell=True)
    return True

@trim_iface_name
def set_vf_spoof(iface: str, vf_id, spoofchk=True):
    """
    Set the VF spoof state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to configure the spoof.
        spoofchk: spoof to configure (True=on; False=off).
    """
    spoofchk = 'on' if spoofchk is True else 'off'
    command = 'ip link set dev %s vf %s spoofchk %s' % (iface, vf_id, spoofchk)
    the_exe.block_run(command, shell=True)


@trim_iface_name
def get_vf_spoof(iface: str, vf_id):
    """
    Get the VF spoof state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to get the spoof state.
    Return:
        spoof_state: True if spoof is "on", False otherwise.
    """
    spoof_state = False
    command = f'ip link show {iface}'
    command_output = the_exe.block_run(command, shell=True)
    spoof_states = re.findall(f'vf {str(vf_id)}.*spoof checking (on|off)', command_output.strip())

    if spoof_states[0] == 'on':
        spoof_state = True

    return spoof_state


@trim_iface_name
@set_default_cli
def attach_iface_to_pid_namespace(iface: str, pid: int, cli: Callable = None):
    """Attach the interface to the network namespace of the process specified.

    :param iface: The name of the interface.
    :param pid: The process ID to attach the interface to.
    :param cli: The command executor.
    """
    command = f'ip link set {iface} netns {pid}'
    return cli(command)
