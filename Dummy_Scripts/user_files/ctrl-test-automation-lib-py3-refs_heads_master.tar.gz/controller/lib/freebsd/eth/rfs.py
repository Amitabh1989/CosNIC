"""
:mod:`rfs` -- Ethernet RFS library
===========================================

.. module:: controller.lib.freebsd.eth.rfs
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"


from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


def get_flow_entries():
    """Get RFS flow entry number

    Args:
        rfs_entry_num (int): A number of rfs entry number

    """
    log.warning("aRFS not supported on FreeBSD")
    return 0


def set_flow_entries(rfs_entry_num):
    """Set RFS flow entry number

    Update /proc/sys/net/core/rps_sock_flow_entries

    Args:
        rfs_entry_num (int): A number of rfs entry number
    """
    log.warning(f"aRFS not supported on FreeBSD: set_flow_entries({rfs_entry_num})")


def set_flow_cnt(iface, queue_list=None):
    """Set flow counter

    Update /psys/class/net/device/queues/rx-queue/rps_flow_cnt

    Args:
        iface (str): ethX name
        queue_list (list): List that has a flow counter for each queue. The
            length of the list must match with the number of queues.
            If None, will use (RFS flow entry/queue length)

    """
    log.warning(f"aRFS not supported on FreeBSD: set_flow_cnt({iface}, {queue_list})")
