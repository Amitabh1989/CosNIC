"""
:mod:`stats` -- Ethernet interface statistics library
=====================================================

.. module:: controller.lib.freebsd.eth.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a library that converts ethtool statistics output information into
an object type.

Currently only supports bnxt driver for FreeBSD - clients must have brcm nics

"""
from typing import List

import regex as re

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.eth.stats import BaseNIC, CounterBase
from controller.lib.freebsd.eth import ethtool


log = log_handler.get_logger(__name__)


class Cumulus(BaseNIC):
    driver_name = 'if_bnxt'

    def __init__(self, counters: List[str] = None):
        counter_list = [
            'ucast_packets', 'ucast_bytes',
            'mcast_packets', 'mcast_bytes',
            'bcast_packets', 'bcast_bytes',
            'total_discard_pkts', 'pause_frames',
            '64b_frames', '65b_127b_frames',
            '128b_255b_frames', '256b_511b_frames',
            '512b_1023b_frames', '1024b_1518b_frames',
            '1519b_2047b_frames', '2048b_4095b_frames',
            '4096b_9216b_frames', '9217b_16383b_frames',
            'pfc_ena_frames_pri0', 'pfc_ena_frames_pri1',
            'pfc_ena_frames_pri2', 'pfc_ena_frames_pri3',
            'pfc_ena_frames_pri4', 'pfc_ena_frames_pri5',
            'pfc_ena_frames_pri6', 'pfc_ena_frames_pri7',
        ]
        if counters:
            counter_list += counters

        super().__init__(*counter_list)
        self.tpa = CounterBase(*['packets', 'bytes', 'events', 'aborts', 'errors', 'eligible_pkt', 'eligible_bytes',
                                 'hds_pkt'])
        self.cache_miss_count = CounterBase(*['cfcq', 'cfcs', 'cfcc', 'cfcm'])

    def get_diff(self, old_stats, new_stats=None, **kwargs) -> 'Cumulus':
        new_stats = new_stats or self
        diff_stats = super().get_diff(old_stats, new_stats)
        diff_stats.tpa = new_stats.tpa.get_diff(old_stats.tpa, new_stats.tpa)

        return diff_stats

    @staticmethod
    def get_stats(iface) -> 'Cumulus':
        """Update attributes to reflect the current statistics

        Args:
            iface (str): ethX name
        """
        # output = exe.block_run('ethtool -S ' + iface, silent=True)
        output = ethtool.get_stats(iface)
        counters = list(
            {counter[0] for counter in re.findall(r'\.(?:[rt]xq\d+\.|port_stats\.[rt]x_)(.*):\s+(\d+)', output)})
        cumulus = Cumulus(counters=counters)

        # Handle rx/tx packets and bytes
        for counter in re.findall(r'hwstats\.([rt]x)q(\d+)\.([umb]cast)_(packets|bytes|pkts):\s+(\d+)', output):
            xdir, queue, cast_type, counter_type, value = counter

            if counter_type == 'pkts':
                counter_type = 'packets'
            cast_counter_type = cast_type + '_' + counter_type
            cumulus.set_stats_counter(xdir, queue, cast_counter_type, value)

            # Add cast value to packets / bytes
            cumulus.set_stats_counter(xdir, queue, counter_type, value)

        # Handle drop / error counters
        for drop_err_counter in re.findall(
                r'hwstats\.([rt]x)q(\d+)\.(drops|buf_errors|error_pkts|l4_csum_errors):\s+(\d+)', output):
            xdir, queue, counter_type, value = drop_err_counter
            cumulus.set_stats_counter(xdir, queue, counter_type, value)

        # stats other than [umb]cast, tpa and drops/errors. Uses negative look-ahead (?!)
        excl_pat = 'tpa|drops|buf_errors|error_pkts|l4_csum_errors|[umb]cast'
        for other_counters in re.findall(rf'hwstats\.([rt]x)q(\d+)\.((?:(?!(?:{excl_pat})).)*):\s+(\d+)', output):
            xdir, queue, counter_type, value = other_counters
            cumulus.set_stats_counter(xdir, queue, counter_type, value)

        # Handle TPA counters
        # CTRL-40983: TPA scripts are aborting while checking for TPA counters, as counter name
        # has changed on Thor B0 with latest fw and driver.
        # Fix the regex and the logic to support both Cumulus and Thor supplied stats counters.
        for tpa_counter in re.findall(
                r'hwstats\.rxq(\d+)\.(?:rx_tpa|tpa)_(packets|.*bytes|events|aborts|.*pkts|errors):\s+(\d+)', output):
            queue, counter_type, value = tpa_counter

            # In Thor, the name of 'packets' is changed to 'pkt'. Thankfully, the name of 'bytes'
            # is still 'bytes'. So, translate 'pkt' into 'packets'.
            #
            # The resulting counters data structure would look like below:
            #
            # +================+============+================+
            # | PROPERTY       | Cu/Wh+     | THOR           |
            # +================+============+================+
            # | packets        | packets    | pkt            |
            # +----------------+------------+----------------+
            # | bytes          | bytes      | bytes          |
            # +----------------+------------+----------------+
            # | events         | events     | N/A (None)     |
            # +----------------+------------+----------------+
            # | aborts         | aborts     | N/A (None)     |
            # +----------------+------------+----------------+
            # | errors         | N/A (None) | errors         |
            # +----------------+------------+----------------+
            # | eligible_pkt   | N/A (None) | eligible_pkt   |
            # +----------------+------------+----------------+
            # | eligible_bytes | N/A (None) | eligible_bytes |
            # +----------------+------------+----------------+
            if counter_type == 'pkts':
                counter_type = 'packets'

            cumulus.set_stats_counter('tpa', queue, counter_type, value)

        for counter in re.findall(r'hwstats\.port_stats\.([rt]x)_(.*):\s+(\d+)', output, re.MULTILINE):
            xdir, counter_type, value = counter
            cumulus.set_stats_counter(xdir, 0, counter_type, value)

        # for counter in re.findall('\s+(cache_miss_count)_(.*):\s+(\d+)', output, re.MULTILINE):
        #     xdir, counter_type, value = counter
        #     cumulus.set_stats_counter(xdir, 0, counter_type, value)

        log.debug(f'STATS[{iface}]: {id(cumulus)}, {type(cumulus)}, {id(cumulus.rx)}\nRX:{cumulus.rx}\nTX:{cumulus.tx}')

        return cumulus


def get_stats(iface) -> Cumulus:  # FreeBSD currently only has one BaseNIC derived type
    """Return statistics information of the given iface

    Args:
        iface (str): ethX name
    """
    drv_name = ethtool.get_drvinfo(iface)['name']

    for subclass in BaseNIC.__subclasses__():
        if drv_name == subclass.driver_name:
            return subclass.get_stats(iface)
    raise exception.ValueException(f'Not supported driver {drv_name}')
