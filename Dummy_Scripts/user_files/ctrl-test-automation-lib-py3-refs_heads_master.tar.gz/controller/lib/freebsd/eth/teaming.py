"""
:mod:`teaming` -- Bonding/Teaming library
=========================================

.. module:: controller.lib.freebsd.eth.teaming
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import logging
import re
import time

from controller.lib.common.shell import exe
from controller.lib.freebsd import eth


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"


log = logging.getLogger(__name__)

# TODO: Redirect to ifconfig (add lagg methods to ifconfig)
# kldload if_lagg // echo 'if_lagg_load="YES"' >> /boot/loader.conf
# ifconfig laggN create # MUST use lagg# naming to create a lagg interface
# ifconfig lagg0 laggproto failover lagghash l2,l3,l4 laggport bnxt0 laggport bnxt1 10.24.116.2 netmask 255.255.255.192
# # bnxt0 (master), bnxt1 (slave)
# may need: route add default 10.24.116.100 # IP from assigned lagg ip and network
#
# laodbalance and lacp use RSS, to use local hash instead: ifconfig <lagg_iface> -use_flowid
# sysctl defaults:
# net.link.lagg.lacp.default_strict_mode: 1
# net.link.lagg.lacp.debug: 0
# net.link.lagg.default_flowid_shift: 16
# net.link.lagg.default_use_flowid: 0
# net.link.lagg.failover_rx_all: 0


def get_bonding_dev():
    return exe.block_run('ifconfig -l -g lagg').split()


def add_bonding(slave_list, mode, bonding_devname='lagg0'):
    """
    Set bonding device.

    Args:
        bonding_devname (str): Name of the bonding device
        mode (str, int): bonding mode
    """
    exe.block_run('kldload if_lagg')

    exe.block_run(f'ifconfig {bonding_devname} create')

    # Bring down the bonding device before changing mode
    iface_ctrl = eth.get_interface(iface=bonding_devname)
    iface_ctrl.down()

    mode_map = {
        'balance-rr': 'roundrobin',
        'active-backup': 'failover',
        'balance-xor': 'loadbalance',
        'broadcast': 'broadcast',
        '802.3ad': 'lacp',
        'balance-tlb': 'loadbalance',  # not equivalent to linux
        'balance-alb': 'loadbalance',  # not equivalent to linux
        'none': 'none',  # disable
    }
    try:
        mode = get_available_mode()[int(mode)]
    except (ValueError, IndexError):
        pass
    mode = mode_map.get(mode, mode)
    # set hashin as in linux implementation - TBD?
    lagg_opts = ' lagghash l3,l4' if mode == 'lacp' else ''
    exe.block_run(f'ifconfig {bonding_devname} laggproto {mode}{lagg_opts}')

    for iface in slave_list:
        add_slave(iface, bonding_devname)

    iface_ctrl.up()


def del_bonding(bonding_devname='lagg0'):
    log.info('Remove all slaves ... ')
    for iface in get_slaves(bonding_devname):
        del_slave(iface, bonding_devname)

    log.info('Remove bonding device ... ')

    exe.block_run(f'ifconfig {bonding_devname} destroy')

    log.info('Unloading the driver ... ')
    exe.block_run('kldunload if_lagg')


def get_slaves(bonding_devname='lagg0'):
    """Return all slaves that are belong to the given bonding device
    """
    slaves = []
    for line in exe.block_run(f'ifconfig {bonding_devname} | grep laggport').splitlines():
        slaves.append(line.split(':', 1)[-1].split()[0].strip())
    return slaves


def add_slave(iface, bonding_devname='lagg0', method='+'):
    """Add iface as a slave to the bonding device

    Args:
        iface (str): ethX name which will becmoe a slave
        bonding_devname (str): bonding device name
        method (str): choices=[+|-]. Should not override
    """
    # Remove all assigned IP addresses
    iface_ctrl = eth.get_interface(iface)
    iface_ctrl.ip_addr = None

    iface_ctrl.down()
    time.sleep(1)

    for ipv6, ipv6_prefix in list(iface_ctrl.ip6_prefix.items()):
        iface_ctrl.set_ip6_addr(ipv6 + '/' + ipv6_prefix, 'del')

    method = '' if method == '+' else method
    exe.block_run(f'ifconfig {bonding_devname} {method}laggport {iface}')

    iface_ctrl.up()


def del_slave(iface, bonding_devname='lagg0'):
    """Remove slave iface from the bonding device

    Args:
        iface (str): ethX name which will becmoe a slave
        bonding_devname (str): bonding device name

    """
    add_slave(iface, bonding_devname, method='-')


def set_param(bonding_devname='lagg0', **kwargs):
    """Set bonding related parameter

    key = param name, value = value
    Mode change is not allowed
    """
    for key, value in list(kwargs.items()):
        exe.block_run(f'ifconfig {bonding_devname} {key} {value}')


def get_bond_info(bonding_devname):
    """Return information about bonding device

    Args:
        bonding_devname (str): name of bonding device
    """
    ret_dict = {}
    multiline_field = False
    for line in exe.block_run(f'ifconfig -v {bonding_devname}').splitlines():
        if 'lagg' not in line and not multiline_field:
            continue
        lagg_mode = re.findall(r'(laggproto)\s(\S+)(?:\s(lagghash)\s(.*))?', line)
        if lagg_mode:
            print(f'LINE1: {line}')
            ret_dict.update({lagg_opt[i]: lagg_opt[i+1] for lagg_opt in lagg_mode
                             for i in range(0, len(lagg_opt), 2) if lagg_opt[i] and lagg_opt[i+1]})
        if 'lagg options' in line or 'lagg statistics' in line:
            multiline_field = True
            print(f'CHG: {multiline_field}')
            continue
        if re.search(r'^\s*(groups|media|status|laggport):', line):
            multiline_field = False
            print(f'CHG: {multiline_field}')
        if multiline_field:
            print(f'LINE2: {line}')
            ret_dict.update(([field.strip() for field in line.split(':', 1)],))
            flags = re.search(r'^\s*flags=([0-9a-f])<(.*?)>', line)
            if flags:
                print(f'LINE3: {line}')
                ret_dict.update({'flags_int': flags.group(1), 'flags': flags.group(2)})
        elif 'laggport' in line:
            port_entry = [field.strip() for field in line.split(':', 1)]
            iface = port_entry[1].split()[0].strip()
            iface_opts = re.findall(r'flags=([0-9a-f])<(.*?)>', port_entry[1])[0][1]
            ret_dict.update({iface: iface_opts})

    return ret_dict


def get_available_mode():
    return [
        'balance-rr',  # roundrobin
        'active-backup',  # failover
        'balance-xor',  # loadbalance
        'broadcast',  # N/A
        '802.3ad',  # lacp
        'balance-tlb',  # N/A
        'balance-alb',  # N/A
        # none (disable)
    ]
