"""
:mod:`tunnel` -- FreeBSD tunneling library
==========================================

.. module:: controller.lib.freebsd.eth.tunnel
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library provides some basic functions to interact with various tunnel
types, such as NVGRE, VXLAN and IP-to-IP.
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

from controller.lib.common.shell import exe
from controller.lib.core import log_handler
from controller.lib.freebsd import driver, eth
from controller.lib.freebsd.eth import ip

log = log_handler.get_logger(__name__)


class TunnelBase(object):
    def __init__(self, iface):
        self.iface = iface
        self._ctrl = None
        self.tun_name = None

    def add(self, *args, **kwargs):
        pass

    def delete(self, *args, **kwargs):
        pass

    def set_ip_addr(self, ip_addr, *args, **kwargs):
        pass

    @staticmethod
    def add_tunnel(iface, tunnel_ip_addr, *args, **kwargs):
        pass

    @property
    def ctrl(self):
        if not self._ctrl:
            if self.tun_name:
                self._ctrl = eth.get_interface(self.tun_name)
        return self._ctrl


class Vxlan(TunnelBase):
    def __init__(self, iface, vxlan_id, tun_name):
        super(Vxlan, self).__init__(iface)
        self.vxlan_id = vxlan_id
        self.tun_name = tun_name
        if not self.tun_name:
            self.tun_name = f'vxlan{vxlan_id}'
        self.tun_name = self.tun_name[-15:]

    def add(self, group=None, remote=None, external=False, **kwargs):
        driver.load('if_vxlan')
        if remote is not None:
            ip.set_vxlan(iface=self.iface, method='add', vxlan_id=self.vxlan_id, tun_name=self.tun_name, remote=remote,
                         **kwargs)
        elif external is True:
            ip.set_vxlan(
                iface=self.iface, tun_name=self.tun_name, vxlan_id=self.vxlan_id, method='add', external=external,
                **kwargs)
        else:
            ip.set_vxlan(
                iface=self.iface, method='add', vxlan_id=self.vxlan_id, tun_name=self.tun_name, group=group, **kwargs)
        ip.up(self.tun_name)

    def delete(self):
        ip.set_vxlan(iface=self.iface, method='del', vxlan_id=self.vxlan_id, tun_name=self.tun_name)

    def set_ip_addr(self, ip_addr):
        ip.set_ip_addr(self.tun_name, ip_addr)

    @staticmethod
    def add_tunnel(iface, tunnel_ip_addr, vxlan_id, group=None, remote=None, tun_name=None, **kwargs):
        """Configure VXLAN interface
        """
        if group is None and remote is None:
            return None

        if group is not None and remote is not None:
            remote = None

        vxlan = Vxlan(iface=iface, vxlan_id=vxlan_id, tun_name=tun_name)
        try:
            if remote is not None:
                vxlan.add(remote=remote, **kwargs)
            else:
                vxlan.add(group=group, **kwargs)
            vxlan.set_ip_addr(ip_addr=tunnel_ip_addr)
        finally:
            return vxlan


class Geneve(TunnelBase):
    def __init__(self, iface, geneve_id, tun_name):
        super(Geneve, self).__init__(iface)
        self.geneve_id = geneve_id
        self.tun_name = tun_name
        if not self.tun_name:
            self.tun_name = 'geneve.%s' % geneve_id
        self.tun_name = self.tun_name[-15:]
        raise NotImplementedError("Geneve tunnels not yet implemented for FreeBSD")

    def add(self, group=None, remote=None, **kwargs):
        driver.load('geneve')
        ip.set_geneve(
            iface=self.iface, method='add', geneve_id=self.geneve_id, tun_name=self.tun_name, remote=remote, **kwargs)
        ip.up(self.tun_name)

    def delete(self):
        ip.set_geneve(iface=self.iface, method='del', geneve_id=self.geneve_id, tun_name=self.tun_name)

    def set_ip_addr(self, ip_addr):
        ip.set_ip_addr(self.tun_name, ip_addr)

    @staticmethod
    def add_tunnel(iface, tunnel_ip_addr, geneve_id, group=None, remote=None, tun_name=None, **kwargs):
        """Configure GENEVE interface
        """
        geneve = Geneve(iface=iface, geneve_id=geneve_id, tun_name=tun_name)
        try:
            geneve.add(remote=remote, **kwargs)
            geneve.set_ip_addr(ip_addr=tunnel_ip_addr)
        except Exception as exc:
            log.info(exc)
        finally:
            return geneve


class Gre(TunnelBase):
    def __init__(self, iface, tun_name):
        super(Gre, self).__init__(iface)
        # CTRL-42597: DPDK: Command used by STAT to create GRE tunnel is failing on RHEL8.
        # Newer versions of "iproute" tool reject interface names larger than 16 bytes.
        # So, trim the interface name if it's longer than 16 bytes.
        driver.load('if_gre')
        if not tun_name:
            self.tun_name = ip.create_gre('gre')
        else:
            self.tun_name = tun_name
            self.tun_name = self.tun_name[-15:]
            ip.create_gre(self.tun_name)

    def add(self, local, remote, ipv6=False, **kwargs):
        ip.set_gre(
            iface=self.iface, tun_name=self.tun_name, method='add',
            local=local, remote=remote, ipv6=ipv6, **kwargs
            )
        # TODO: ip.set_route()
        ip.up(self.tun_name)

    def delete(self):
        ip.set_gre(iface=self.tun_name, tun_name=self.tun_name, method='del')

    def set_ip_addr(self, ip_addr):
        ip.set_ip_addr(self.tun_name, ip_addr)

    @staticmethod
    def add_tunnel(iface, tunnel_ip_addr, local, remote, ipv6=False, tun_name=None, **kwargs):
        # CTRL-42597: DPDK: Command used by STAT to create GRE tunnel is failing on RHEL8.
        # Newer versions of "iproute" tool reject interface names larger than 16 bytes.
        # So, trim the interface name if it's longer than 16 bytes.
        gre = Gre(iface=iface, tun_name=tun_name)

        try:
            gre.add(local=local, remote=remote, ipv6=ipv6, **kwargs)
            gre.set_ip_addr(ip_addr=tunnel_ip_addr)
        except Exception as exc:
            log.info(exc)
        finally:
            return gre


class IP_in_IP(TunnelBase):
    def __init__(self, iface, tun_name, tun_mod_name="ipip"):
        super(IP_in_IP, self).__init__(iface)
        # CTRL-42597: DPDK: Command used by STAT to create GRE tunnel is failing on RHEL8.
        # Newer versions of "iproute" tool reject interface names larger than 16 bytes.
        # So, trim the interface name if it's longer than 16 bytes.
        driver.load('if_gif')
        if not tun_name:
            self.tun_name = 'gif0'  # ip.create_gif('gif')
        else:
            self.tun_name = tun_name
        self.tun_name = self.tun_name[-15:]
        self.tun_mod_name = tun_mod_name
        # ip.create_gif(self.tun_name)
        raise NotImplementedError("IP-in-IP tunnels not yet implemented for FreeBSD")

    def add(self, local, remote):
        set_method = getattr(ip, 'set_gif_%s' % self.tun_mod_name)
        set_method(iface=self.iface, tun_name=self.tun_name, method='add', local=local, remote=remote)
        ip.up(self.tun_name)

    def delete(self):
        set_method = getattr(ip, 'set_gif_%s' % self.tun_mod_name)
        set_method(iface=self.iface, tun_name=self.tun_name, method='del')

    def set_ip_addr(self, ip_addr, peer):
        exe.block_run('ip addr add dev %s %s peer %s' % (self.tun_name, ip_addr, peer))

        peer = peer[0: peer.find('/')]
        ip.set_route(self.tun_name, "add", peer)

    @staticmethod
    def add_tunnel(iface, tunnel_ip_addr, peer_ip_addr, local, remote, mod_name="ipip", tun_name=None):
        # CTRL-42597: DPDK: Command used by STAT to create GRE tunnel is failing on RHEL8.
        # Newer versions of "iproute" tool reject interface names larger than 16 bytes.
        # So, trim the interface name if it's longer than 16 bytes.
        ip_in_ip = IP_in_IP(iface=iface, tun_name=tun_name, tun_mod_name=mod_name)

        try:
            ip_in_ip.add(local=local, remote=remote)
            ip_in_ip.set_ip_addr(ip_addr=tunnel_ip_addr, peer=peer_ip_addr)
        finally:
            return ip_in_ip
