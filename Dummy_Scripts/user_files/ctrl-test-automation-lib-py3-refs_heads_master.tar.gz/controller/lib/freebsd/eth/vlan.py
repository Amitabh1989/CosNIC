"""
:mod:`tunnel` -- FreeBSD tunneling library
==========================================

.. module:: controller.lib.freebsd.eth.tunnel
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library provides some basic functions to interact with various tunnel
types, such as NVGRE, VXLAN and IP-to-IP.
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import re
from typing import Union

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.freebsd import eth
from controller.lib.freebsd.eth import ip

log = log_handler.get_logger(__name__)


class Vlan(object):
    def __init__(self, iface: str, vlan_id: Union[int, str], vlan_name: str = None, proto='802.1Q'):
        self.iface = iface
        self.vlan_id = int(str(vlan_id))
        self.vlan_name = vlan_name if vlan_name and re.match(r'vlan\d+', vlan_name) else f'vlan{self.vlan_id}'
        self.proto = proto
        self._ctrl = None

    @property
    def ctrl(self):
        if not self._ctrl:
            self._ctrl = eth.get_interface(self.vlan_name)
        return self._ctrl

    @property
    def name(self) -> str:
        return self.ctrl.name

    def add(self, **kwargs):
        try:
            self.vlan_name = ip.add_vlan(iface=self.iface, vlan_id=self.vlan_id,
                                         name=self.vlan_name, proto=self.proto)
        except exception.IPFileExists:
            log.info('vlan id %s already exists', self.vlan_id)
        except exception.IPException as exc:
            raise exception.TestCaseFailure('Failed to Create VLAN Interface') from exc
        else:
            ip.up(self.vlan_name)

    def delete(self, force=False):
        try:
            ip.remove_vlan(iface=self.iface, vlan_name=self.vlan_name)
        except exception.IPException as exc:
            if force and f'{self.vlan_name} does not exist' in str(exc):
                log.warning(f"{self.vlan_name}({self.vlan_id}) already destroyed (not found)")
            else:
                raise

    def set_ip_addr(self, ip_addr, ipv6=False):
        ip.set_ip_addr(self.vlan_name, str(ip_addr), ipv6=ipv6)


def add_vlan(iface: str, vlan_id: Union[int, str], ip_addr: str = None, vlan_name: str = None, proto='802.1Q', 
             ipv6=False, **kwargs) -> Vlan:
    """
    Configure VLAN interface
    """
    vlan = Vlan(iface=iface, vlan_id=vlan_id, vlan_name=vlan_name, proto=proto)
    vlan.add(**kwargs)
    if ip_addr:
        vlan.set_ip_addr(ip_addr=ip_addr, ipv6=ipv6)
    return vlan
