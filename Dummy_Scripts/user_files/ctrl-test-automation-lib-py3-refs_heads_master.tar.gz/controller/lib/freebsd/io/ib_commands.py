"""
:mod:`ib_commands` -- IB Commands Wrapper.
=========================================

.. module:: controller.lib.freebsd.io.ib_commands
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for IB IO commands. Listed below are the
functionalities provided by this module:

1. Run 'ib_send_bw' command.
2. Run 'ib_read_bw' command.
3. Run 'ib_write_bw' command.
4. Run 'ib_send_lat' command.
5. Run 'ib_read_lat' command.
6. Run 'ib_write_lat' command.
7. Run 'ib_atomic_bw' command.

NOTE: FreeBSD support TBD: May require changes to get latency and throughput results if ib* output is different
"""

from controller.lib.linux.io.ib_commands import IBCommandController, IBCommandServer, IBCommandClient

__all__ = ['IBCommandController', 'IBCommandServer', 'IBCommandClient']
