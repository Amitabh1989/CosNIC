"""
:mod:`iperf` -- iperf wrapper library.
======================================
.. module:: controller.lib.freebsd.io.iperf
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for iperf over SSH. It uses the iperf library in controller.lib.common.io
over the SSH channel.
"""
from controller.lib.linux.io.iperf import (IperfServer, IperfClient)
__all__ = ['IperfServer', 'IperfClient']
