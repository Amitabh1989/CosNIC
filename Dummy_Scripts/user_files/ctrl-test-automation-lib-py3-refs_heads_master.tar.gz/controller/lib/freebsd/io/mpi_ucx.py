"""
:mod:`mpi_ucx` -- OpenMPI UCX tool wrapper.
=========================================

.. module:: controller.lib.freebsd.io.mpi_ucx
.. moduleauthor:: Michael Pate <michael.pate@broadcom.com>

"""

from controller.lib.linux.io.mpi_ucx import MpiController
__all__ = ['MpiController']
