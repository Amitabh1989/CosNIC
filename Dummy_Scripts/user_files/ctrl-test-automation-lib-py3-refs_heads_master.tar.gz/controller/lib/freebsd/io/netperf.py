"""
:mod:`netperf` -- netperf wrapper library
==================================================================================

.. module:: controller.lib.freebsd.io.netperf
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

This is a wrapper method for netperf 2.6

"""
from controller.lib.linux.io.netperf import (NetperfBase, Netperf, NetServer, Netperf_RR)
__all__ = ['NetperfBase', 'Netperf', 'NetServer', 'Netperf_RR']
