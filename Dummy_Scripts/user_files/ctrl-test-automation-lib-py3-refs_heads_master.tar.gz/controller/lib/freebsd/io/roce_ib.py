"""
:mod:`roce_ib.py` -- roce ib traffic library
==================================================================================

.. module:: controller.lib.freebsd.io.roce_ib
.. moduleauthor:: Michael Pate <michael.pate@broadcom.com>

CTRL-48082: This module is deprecated please use controller.lib.freebsd.io.ib_commands
"""

from controller.lib.linux.io.roce_ib import IBSendBase, IBClient, IBServer

__all__ = ['IBSendBase', 'IBClient', 'IBServer']
