"""
:mod:`rping` -- rping Wrapper.
=========================================

.. module:: controller.lib.freebsd.io.rping
.. moduleauthor:: Michael Pate <michael.pate@broadcom.com>

This is a wrapper python module for rping command. Freebsd reuses linux implementation

"""
from controller.lib.linux.io.rping import RpingController, RpingServer, RpingClient

__all__ = ['RpingController', 'RpingServer', 'RpingClient']
