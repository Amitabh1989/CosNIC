"""
:mod:`scapy_ei` -- Scapy EI
===========================================================

.. module:: controller.lib.freebsd.io.scapy_ei
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

.. warning::
   Some scapy operations require root privilege

This library provides wrapped functions around scapy module. Though this works
almost as proxy to most scapy modules. For example,

>>> from controller.lib.freebsd.io import scapy_ei
>>> scapy_ei.send(scapy_ei.IP(dst='192.168.1.1')/scapy_ei.ICMP())

is identical to

>>> from scapy.all import *
>>> send(IP(dst='192.168.1.1'/ICMP()))

The main purpose of this module is to override some scapy functions to resolve
compatibility issues with RPyC, including object instantiation.

Due to this module works as a transparent proxy to scapy module, usage should
be very similar to scapy module itself.

Here is one example.  Let's create a Ping request packet to the IP
'192.168.1.1'. Layers that ICMP should have are:

   * Ethernet
   * IP
   * ICMP

The way to create a packet is to stack such layers using '/'.

'/' works as a divider of layers, and first layer means lower layer.
For example, to build a ICMP packet that has above three layers:

>>> icmp_packet = scapy_ei.Ether()/scapy_ei.IP(dst='192.168.1.1')/scapy_ei.ICMP()

Above command stacks three layers - Ethernet, IP and then ICMP. Note that
we specified the IP destiatnion as '192.168.1.1', which one information that
scapy cannot fill out originally.

Speaking of which, scapy is smart enough to fill out most information for you
automatically. Think about all missing information that we did not provide
above - no src and dst MAC addresses, no src IP address, etc. We just left
them as blank. And - scapy will fill out for you.

Imagine when you ping a remote host - mostly the only information that you
need to provide is the destination IP address, because OS can automatically
determine Ethernet layer for you. Scapy does the same thing.

.. warning::
   When you create a packet on SUT over RPyC, layers that you use also should
   be called over RPyC otherwise scapy will use the localhost
   (possibly Harness) network nformation to fill out some missing
   values, such as source MAC address.

So let's take a look at the packet that we just crafted.

>>> icmp_packet
<Ether  type=0x800 |<IP  frag=0 proto=icmp dst=192.168.1.1 |<ICMP  |>>>

It has mostly empty information, but they will be automatically filled as I
mentioned above. If you want to see that, you can run show()

>>> icmp_packet.show()
###[ Ethernet ]###
  dst       = 00:00:0c:07:ac:28
  src       = 00:50:56:ab:0f:07
  type      = 0x800
###[ IP ]###
     version   = 4
     ihl       = None
     tos       = 0x0
     len       = None
     id        = 1
     flags     =
     frag      = 0
     ttl       = 64
     proto     = icmp
     chksum    = None
     src       = 10.13.246.88
     dst       = 192.168.1.1
     \options   \
###[ ICMP ]###
        type      = echo-request
        code      = 0
        chksum    = None
        id        = 0x0
        seq       = 0x0

So now you can see that all Ethernet type, dst, src are filled out - as well as
the source IP address. Now let's send this packet.

>>> scapy_ei.send(icmp_packet)
.
Sent 1 packets.

That's it.

For more details how to use scapy, please refer at `here`_.

.. _here: http://www.secdev.org/projects/scapy/doc/index.html

"""
# Reuse existing linux module.
# Allow use like: from controller.lib.freebsd.io import scapy_ei; scapy_ei.Ether()/scapy_ei.IP(), etc.
from controller.lib.linux.io.scapy_ei import *  # noqa(flake8): F401 pylint: disable=W0622
