"""
:mod:`protocol` -- Custom protocols for Scapy
=============================================

.. module:: controller.lib.freebsd.io.scapy_ei.protocol
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Define custom protocols here.

VXLAN is back-ported from the tip of the Scapy development version.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"

from controller.lib.linux.io.scapy_ei.protocol import MAC_CONTROL_PAUSE

__all__ = ['MAC_CONTROL_PAUSE']
