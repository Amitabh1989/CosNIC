"""
:mod:`tcpdump` -- tcpdump wrapper library
=========================================

.. module:: controller.lib.freebsd.io.tcpdump
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for tcpdump

"""
from controller.lib.linux.io.tcpdump import (TCPDump)
__all__ = ['TCPDump']
