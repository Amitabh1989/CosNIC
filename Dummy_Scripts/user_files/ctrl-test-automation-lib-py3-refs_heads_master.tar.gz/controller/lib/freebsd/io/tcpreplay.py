"""
:mod:`tcpreplay` -- tcpreplay library
==================================================================================

.. module:: controller.lib.freebsd.io.tcpreplay
.. moduleauthor:: Madhusudana <madhusudana.annam@broadcom.com>

This is a method for tcpreplay 3.2.5 and above

"""
from controller.lib.linux.io.tcpreplay import (Tcpreplay)
__all__ = ['Tcpreplay']
