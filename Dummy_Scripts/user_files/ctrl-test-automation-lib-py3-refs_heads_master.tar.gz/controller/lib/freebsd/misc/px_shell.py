""" Shell module is written to create a spawned shell using pexpect and provide the handle to the user.
CTRL-48082: Deprecated do not use.
"""
import pexpect
from pexpect import ExceptionPexpect, TIMEOUT, EOF, spawn

from controller.lib.linux.misc.px_shell import ExceptionPxssh, px_shell

__all__ = ['pexpect', 'ExceptionPexpect', 'TIMEOUT', 'EOF', 'spawn', 'ExceptionPxssh', 'px_shell']
