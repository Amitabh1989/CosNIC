"""
:mod:`bnxtnvm` -- bnxtnvm tool wrapper
======================================

.. module:: controller.lib.freebsd.system.bnxtnvm
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

from controller.lib.linux.system.bnxtnvm import (BaseBnxtnvm,
                                                 install, verify, pkgver, devid, device_info, set_option, get_option)
__all__ = ['BaseBnxtnvm', 'install', 'verify', 'pkgver', 'devid', 'device_info', 'set_option', 'get_option']
