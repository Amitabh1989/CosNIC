"""
:mod:`devlink` -- devlink wrapper library.
==========================================
.. module:: controller.lib.freebsd.system.devlink
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for devlink.
"""
import re
import logging

from controller.lib.common.shell import exe
from controller.lib.freebsd.system import ssh

log = logging.getLogger(__name__)


class Devlink():
    """
    The class that implements the devlink command. The below listed devlink command are currently
    supported.

        - health
        - port
    """
    def __init__(self, **kwargs):
        """
        The Devlink constructor.
        """
        self.__exe = exe
        raise NotImplementedError("devlink not yet supported in FreeBSD")

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the devlink command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the devlink command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running devlink command over SSH.
            When None, the SSH mode is exited.
        """
        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def health(self, **kwargs):
        """
        The method that runs the health command.

        Return:
            health_data (dict): A dictionary containing various health related details of the pci
            devices.
        """
        health_data = {}
        device = attribute = None
        command = 'devlink health'
        command_output = self.__exe.block_run(command)

        for line in command_output.split('\n'):
            # Strip off the carriage return charcter in the line.
            line = line.strip()

            if 'pci/' in line:
                device = line.split('pci/')[1][:-1]
                health_data[device] = {}
            elif 'reporter ' in line:
                attribute = line.split('reporter ')[1]
                health_data[device][attribute] = {}
            elif device is not None and attribute is not None:
                items = re.findall('(\w+) (\w+)', line)

                for key, value in items:
                    health_data[device][attribute][key] = value

        return health_data

    def port(self, **kwargs):
        """
        The method that runs the port command.

        Return:
            port_data (dict): A dictionary containing various port details of the pci devices.
        """
        port_data = {}
        command = 'devlink port'
        command_output = self.__exe.block_run(command)

        for line in command_output.split('\n'):
            # Strip off the carriage return charcter in the line.
            line = line.strip()

            if 'pci' in line:
                device = re.search('pci/(.+)/', line).group(1)
                port_data[device] = {}
                items = line.split(' ')[1:]
                items_count = int(len(items) / 2)

                for index in range(items_count):
                    port_data[device][items[index * 2]] = items[(index * 2) + 1]

        return port_data

