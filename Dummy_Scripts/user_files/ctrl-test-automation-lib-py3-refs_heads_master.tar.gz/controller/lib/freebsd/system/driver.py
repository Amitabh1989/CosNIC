"""
:mod:`driver` -- FreeBSD driver installation wrapper
====================================================

.. module:: controller.lib.freebsd.driver
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

CTRL_48082: This file is deprecated
"""


from controller.lib.core import exception
from controller.lib.common.system.driver import BaseDriver
from controller.lib.freebsd.driver import install as bsd_drv


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Corporation"


class FreeBsdDriver(BaseDriver):
    def __init__(self):
        super().__init__()
        self._handler = None
        self._handler_type = None

    @property
    def handler(self):
        return self._handler

    def install(self, filename, regexp=None, is_roce=False, reload=True, bld_dir=''):
        """Device driver install using the appropriate mechanism based on file type (tarball supported)

        :param filename: Device driver tarball absolute path
        :param regexp (str): regular express to get a driver name and version.
        :param is_roce (bool): True if installation is for roce driver instead of L2
        :param reload: Option to skip driver reload after installing new driver, defaults to True
        :param bld_dir: Option to copy src into a custom location for compile, defaults to '' which uses the system
                        folders for the drivers and the tarball extraction folder for the roce user lib
        :raises exception.ValueException: If filename is not a pkg or tarball
        """
        if filename.endswith('tar.gz'):
            self._handler = bsd_drv.SrcBase(filename=filename, regexp=regexp, is_roce=is_roce)
            self._handler_type = 'src'
        elif '.' not in filename:
            self._handler = bsd_drv.PkgBase(filename=filename)
            self._handler_type = 'pkg'
        else:
            raise exception.ValueException(
                'Unsupported package type. Only support tar.gz or pkg')

        self.handler.install(reload, bld_dir)

    def uninstall(self, driver_name):
        raise NotImplementedError

    def upgrade(self, filename, force=False):
        raise NotImplementedError

    def rollback(self, driver_name):
        raise NotImplementedError

    def is_installed(self, driver_name):
        raise NotImplementedError

    def get_version(self, driver_name):
        raise NotImplementedError

    def get_package_info(self, pkg_name):
        raise NotImplementedError


def install(filename, regexp=None, is_roce=False, reload=True, bld_dir=''):
    bsd_driver = FreeBsdDriver()
    bsd_driver.install(filename, regexp, is_roce, reload, bld_dir)
