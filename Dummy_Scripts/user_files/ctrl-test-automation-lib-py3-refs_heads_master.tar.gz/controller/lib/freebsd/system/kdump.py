"""
:mod:`kdump` -- kdump wrapper library.
======================================
.. module:: controller.lib.freebsd.system.kdump
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for kdump commands.
"""
import time
import logging

from controller.lib.common.shell import exe
from controller.lib.freebsd.system import ssh

log = logging.getLogger(__name__)

class Kdump():
    """
    The class that implements the kdump commands.
    """
    def __init__(self, **kwargs):
        """
        The Kdump constructor.
        """
        self.__exe = exe
        self.__kdump_path = kwargs.get('kdump_path', '/var/crash')
        # Strip off the trailing '/' character.
        if self.__kdump_path[-1] == '/':
            self.__kdump_path = self.__kdump_path[:-1]

        self.__sysrq = kwargs.get('sysrq', '/proc/sys/kernel/sysrq')
        self.__sysrq_trigger = kwargs.get('sysrq_trigger', '/proc/sysrq-trigger')

        raise NotImplementedError("kdump not supported on FreeBSD")

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the kdump command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the kdump command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running kdump command over SSH.
            When None, the SSH mode is exited.
        """
        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def configure(self, **kwargs):
        """
        The method that configures kdump.

        Args:
            iface (str): The name of the interface.
            fw_image_url (str): The URL to the nitro firmware image.
        Return:
            folder_list (list): A list of currently available folders in the crash dump path.
        """
        command = 'systemctl restart kdump'
        self.__exe.block_run(command)
        command = 'ls %s' % self.__kdump_path
        folder_list = self.__exe.block_run(command).split()
        return folder_list

    def crash(self):
        """
        The method that forces the system to crash.
        """
        command = 'echo 1 > %s' % self.__sysrq
        self.__exe.block_run(command, shell=True)
        time.sleep(1)
        command = 'echo c > %s' % self.__sysrq_trigger
        # Since the machine crashes after this command, expect timeout exception and ignore it.
        try:
            self.__exe.block_run(command, shell=True)
        except Exception:
            pass

    def verify(self, old_folder_list):
        """
        """
        return_status = False
        command = 'ls %s' % self.__kdump_path
        folder_list = self.__exe.block_run(command).split()
        new_folders = list(set(folder_list) - set(old_folder_list))
        # Remove the newly created crash dump folder.
        for folder in new_folders:
            command = 'rm -rf %s/%s' % (self.__kdump_path, folder)
            self.__exe.block_run(command)
            return_status = True

        return return_status

