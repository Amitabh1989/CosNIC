"""
:mod:`lldptool` -- Wrapper for lldptool
================================================================================

.. module:: controller.lib.freebsd.system.lldptool
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

"""


import os
import time
from controller.lib.freebsd.system import service
from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.common.shell import exe
from distutils.spawn import find_executable

log = log_handler.get_logger(__name__)


class LLDPTool(object):
    def __init__(self, iface):
        self.iface = iface
        self.__lldp = service.Service('lldpd')
        self.__lldp_path = find_executable('lldpcli')
        self.__direction = None
        raise NotImplementedError("lldp not yet supported on FreeBSD - must map lldptool to lldpcli")

    def clean_up(self):
        try:
            os.remove('/var/lib/lldpad/lldpad.conf')
        except Exception:
            pass

    def start(self):
        self.__lldp.start()
        time.sleep(5)
        if not self.__lldp.status:
            raise exception.ConfigException('Failed to start lldp service!')

    def restart(self):
        self.__lldp.restart()
        time.sleep(5)
        if not self.__lldp.status:
            raise exception.ConfigException('Failed to restart lldp service!')

    def stop(self):
        self.__lldp.stop()
        time.sleep(5)
        if self.__lldp.status:
            raise exception.ConfigException('Failed to stop lldp service!')

    @property
    def status(self):
        return self.__lldp.status

    def get_tlv(self, tlv_id):
        tlv_output = exe.block_run('%s -i %s get-tlv -V %s %s'
                                   % (self.__lldp_path, self.iface, tlv_id, '-n' if self.__direction in ['rx', 'rxtx'] else ''))
        log.info(tlv_output)
        return tlv_output

    def set_tlv(self, tlv_id):
        return '%s -i %s set-tlv -V %s' % (self.__lldp_path, self.iface, tlv_id)

    def get_lldp(self, lldp_param):
        lldp_output = exe.block_run('%s -i %s get-lldp %s'
                                   % (self.__lldp_path, self.iface, lldp_param))
        log.info(lldp_output)
        return lldp_output

    def set_lldp(self, lldp_param):
        return '%s -i %s set-lldp %s' % (self.__lldp_path, self.iface, lldp_param)

    def config_adminStatus(self, direction='rxtx'):
        if not direction in ['rx', 'tx', 'rxtx']:
                        raise exception.ConfigException(
                            '%s is an unrecognized option! Please provide either rx/tx/rxtx as options')
        log.info('Configuring LLDP to %s on interface %s'
                 % ('receive' if direction == 'rx' else 'transmit' if direction == 'tx' else 'receive and transmit', self.iface))
        exe.block_run(self.set_lldp('adminStatus') + '=%s' % direction)
        self.__direction = direction

    def config_pfc(self, priority):
        log.info('Configuring PFC on interface %s to priority: %s' % (self.iface, priority))
        exe.block_run(self.set_tlv('PFC') + ' enabled=%s' % priority)

    def config_app(self, priority, header_type='L2', ether_type='RoCE'):
        header = '3' if header_type == 'L3' else '1'
        if ether_type == 'RoCE':
            ether = '4791'
            header = '3'

        else:
            ether = '12896'
        log.info('Configuring APP TLV on interface %s to priority: %s, header: %s, ether: %s'
                 % (self.iface, priority, header, ether))
        exe.block_run(self.set_tlv('APP') + ' app=%s,%s,%s' % (priority, header, ether))

    def config_tsa(self, tsa_map):
        """
        :param tsa_map(dict): Must give this with queues as keys and tsa algorithm as values
        :return:
        ex:- tsa_map = {'1':'ets', '2':'strict'...}
        """
        if not tsa_map:
            raise exception.ConfigException('TSA dictionary empty! Must provide TSA details to configure TSA')
        log.info('Configuring TSA on interface %s to %s' % (self.iface, tsa_map))
        tsa_values = []
        for key in sorted(tsa_map):
            tsa_values.append('%s:%s' % (key, tsa_map[key]))
        exe.block_run(self.set_tlv('ETS-CFG') + ' tsa=%s' % (','.join(tsa_values)))

    def config_tcPrioMap(self, prio_map):
        """
        :param prio_map(dict): Key is Queue number and Value is TC number
        :return:
        ex:- prio_map = {'0':'1', '1':'0'...}
        """
        if not prio_map:
            raise exception.ConfigException('TC Priority Map Dictionary empty! Must provide TC Map details to configure '
                                            'TC Map')
        log.info('Configuring TC Priority on interface %s to %s' % (self.iface, prio_map))
        prio_values = []
        for key in sorted(prio_map):
            prio_values.append('%s:%s' % (key, prio_map[key]))
        exe.block_run(self.set_tlv('ETS-CFG') + ' up2tc=%s' % (','.join(prio_values)))

    def config_tcBandwidth(self, tc_bw_map):
        """
        :param tc_bw_map(dict): Key is TC and value is BW for that TC
        :return:
        ex:- tc_bw_map = {'0':'80', '1':'20'}
        """
        if not tc_bw_map:
            raise exception.ConfigException('TC Bandwidth Map Dictionary empty! Must provide TC Bandwidth details.')
        log.info('Configuring Bandwidth per TC on interface %s to %s' % (self.iface, tc_bw_map))
        tc_bw_values = []
        for key in sorted(tc_bw_map):
            tc_bw_values.append(tc_bw_map[key])
        exe.block_run(self.set_tlv('ETS-CFG') + ' tcbw=%s' % ','.join(tc_bw_values))

    def configure_sysDesc(self, enable=True):
        log.info('%s System Descsription via lldp on interface %s' % ('Enabling' if enable else 'Disabling', self.iface))
        exe.block_run(self.set_tlv('sysDesc') + ' enableTx=%s' % ('yes' if enable else 'no'))

    def configure_appEnableTx(self, enable=True):
        exe.block_run(self.set_tlv('APP') + ' enableTx=%s' % ('yes' if enable else 'no'))
