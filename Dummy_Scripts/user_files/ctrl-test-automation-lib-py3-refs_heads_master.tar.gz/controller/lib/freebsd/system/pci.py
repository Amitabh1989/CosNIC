"""
:mod:`pci` -- pci module
===========================================

.. module:: controller.lib.freebsd.system.pci
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import re
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class LsPci(object):
    def __init__(self, bus_info=None, lspci_path=None):
        """
        Args:
             bus_info (str): bus_info of the device.
        """
        self._bus_info = bus_info
        self.__exe = exe

        if lspci_path is None:
            self._prg_path = find_executable('lspci')
        else:
            self._prg_path = lspci_path

        if self._prg_path is None:
            raise exception.ConfigException('lspci is not available')

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the lspci command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the lspci command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running lspci command over SSH.
            When None, the SSH mode is exited.
        """
        from controller.lib.freebsd.system import ssh

        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def run(self, **kwargs):
        option_list = []
        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + ' ' + value)

        output = self.__exe.block_run(' '.join([self._prg_path] + option_list))
        return output

    def get_speed(self):
        """
        Returns LnkSta and LnkCap speeds for the pci bus.
        """
        cmd = '%s -s %s -vvv | grep Lnk' % (self._prg_path, self._bus_info)
        output = self.__exe.block_run(cmd, shell=True)

        pci_speed = {'LnkSta': None, 'LnkCap': None}
        if re.search(r'LnkSta:\s+Speed\s+(.+?),', output):
            pci_speed['LnkSta'] = re.search(r'LnkSta:\s+Speed\s+(.+?)\s', output).group(1)

        if re.search(r'LnkCap:\s+Port\s+#\d+,\s+Speed\s+(.+?),', output):
            pci_speed['LnkCap'] = re.search(r'LnkCap:\s+Port\s+#\d+,\s+Speed\s+(.+?),', output).group(1)

        return pci_speed
