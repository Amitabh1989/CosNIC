"""
:mod:`roce_nfs` -- NFS over RDMA Configuration
===============================================

.. module:: controller.lib.freebsd.system.roce_nfs
.. moduleauthor:: manikanta.ambadipudi@broadcom.com

CTRL-48082: This module is deprecated please use controller.lib.freebsd.io.nfs_rdma
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

# RDMA not yet supported on FreeBSD.
# Only use this module for porting linux scripts to freebsd; use io.nfs_rdma for new scripts
# from controller.lib.freebsd.io.nfs_rdma import (NFSServer, NFSClient)
# __all__ = ['NFSServer', 'NFSClient']

import os
import time

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe

log = log_handler.get_logger(__name__)


class Server(object):
    def __init__(self, mount_points=1, dir_path=None, rdma_port=20049):
        self.mount_points = mount_points
        self.dir_path = dir_path
        self.rdma_port = rdma_port
        self.__mtp_list = []

        raise NotImplementedError("RDMA (roce_nfs) not yet supported for FreeBSD")

    def __verify_mounts(self):
        mnts = exe.block_run('mount')

        for mnt in mnts.splitlines():
            # CTRL-45195: roce/roce_nfs_various_mtu.py script fails with error
            # "ConfigException: cgroup on /sys/fs/cgroup/rdma type cgroup
            # (rw,nosuid,nodev,noexec,relatime,rdma) Please unmount all the rdma mount points
            # prior to running the script"
            # Correctly identify the devices using RDMA protocol by looking for 'proto=rdma'.
            if mnt.find('proto=rdma') != -1:
                raise exception.ConfigException(
                '%s \n Please unmount all the rdma mount points prior to running the script' % mnt)

    def __setup_nfs_server(self):
        """
            Load the RDMA Server Transport module and restart the NFS Server service
            Enter the rdma port number
        """
        log.info('Loading the RDMA transport module svcrdma')
        exe.block_run('modprobe svcrdma')
        log.info('Restarting NFS Server service.')
        exe.block_run('service nfs-server restart')
        time.sleep(5)
        exe.block_run('service nfs-server status')
        self.__add_rdma_port()

    def __add_rdma_port(self):
        """
            Check if the RDMA port is present in /proc/fs/nfsd/portlist,
            if not make a new entry
        """
        fo = open('/proc/fs/nfsd/portlist', 'r')
        ports = fo.read()
        fo.close()
        rdma_port = False
        for port in ports.splitlines():
            if port == 'rdma 20049':
                rdma_port = True
                break
        if not rdma_port:
            fo = open('/proc/fs/nfsd/portlist', 'a')
            fo.write('rdma 20049')
            fo.close()

    def create_mounts(self, mtps=None):
        if mtps:
            self.mount_points = mtps

        self.__verify_mounts()
        log.info('Creating %s mount points' % self.mount_points)

        for mt in range(1, (self.mount_points + 1)):
            # CTRL-46607: ESXi: SRIOV linux RoCE: "roce_nfs_tcp_io" inconsistently aborts while
            # running in batch with "mount directory" error.
            # Do not use /tmp filesystem for creating mount points as they may get cleaned up
            # in the middle of the test. Use /home instead.
            dir_name = '/home/nfs-dir-%s' % mt
            exe.block_run('mkdir -p %s' % dir_name)
            self.__mtp_list.append(dir_name)
            log.info('Created mount point mtp%s.' % mt)
            time.sleep(1)

        fo = open('/etc/exports', 'w')

        for num, mtp in enumerate(self.__mtp_list):
            st = os.stat(mtp)
            """ 0o111 for Executable permissions
                0o222 for Writable permissions
                0o444 for Readable permission
            """
            os.chmod(mtp, st.st_mode | 0o111 | 0o222 | 0o444)
            # CTRL-45769: [Automation]:Roce-NFS: Script for QA-Controller-37126 fails.
            # Use non-zero fsid.
            fo.write('%s *(fsid=%d,rw,async,insecure,no_root_squash)\n' % (mtp, int(num) + 1))

        fo.close()
        self.__setup_nfs_server()

    def remove_mounts(self):
        """
            Do not call this method without unmounting on the Client Side
        """
        if not self.__mtp_list:
            raise exception.ConfigException('No mount points available.'
            'Call create_mount_points method before calling this')
        import shutil
        mt = 0
        while self.__mtp_list:
            mt = len(self.__mtp_list) - 1
            log.info('Removing mount point %s' % self.__mtp_list[mt])
            shutil.rmtree(self.__mtp_list[mt])
            self.__mtp_list.pop(mt)
            mt += 1
            time.sleep(1)

    def mounts(self):
        return self.__mtp_list


class Client(object):
    def __init__(self, mount_points=1, dir_path=None):
        self.mount_points = mount_points
        self.dir_path = dir_path
        self.__mtp_list = []
        self.__mount_status = False

        raise NotImplementedError("RDMA (roce_nfs) not yet supported for FreeBSD")

    def __verify_mounts(self):
        """
            Verify if the mounts are already present,
            if yes raise an exception to remove them before creating new ones.
            Need to revisit this.
        """
        mnts = exe.block_run('mount')
        for mnt in mnts.splitlines():
            # CTRL-45195: roce/roce_nfs_various_mtu.py script fails with error
            # "ConfigException: cgroup on /sys/fs/cgroup/rdma type cgroup
            # (rw,nosuid,nodev,noexec,relatime,rdma) Please unmount all the rdma mount points
            # prior to running the script"
            # Correctly identify the devices using RDMA protocol by looking for 'proto=rdma'.
            if mnt.find('proto=rdma') != -1:
                raise exception.ConfigException(
                '%s \n Please unmount all the rdma mount points prior to running the script' % mnt)

    def __setup_nfs_client(self):
        """
            Load the Client RDMA Transport Module
        """
        log.info('Loading the RDMA transport module xprtrdma')
        exe.block_run('modprobe xprtrdma')

    def create_mounts(self, mtps=None):
        if mtps:
            self.mount_points = mtps

        self.__verify_mounts()
        log.info('Creating %s mount points' % self.mount_points)

        for mt in range(1, (self.mount_points + 1)):
            # CTRL-46607: ESXi: SRIOV linux RoCE: "roce_nfs_tcp_io" inconsistently aborts while
            # running in batch with "mount directory" error.
            # Do not use /tmp filesystem for creating mount points as they may get cleaned up
            # in the middle of the test. Use /home instead.
            dir_name = '/home/nfs-dir-%s' % mt
            exe.block_run('mkdir -p %s' % dir_name)
            self.__mtp_list.append(dir_name)
            log.info('Created mount point mtp: %s.' % mt)
            time.sleep(1)

        for mtp in self.__mtp_list:
            st = os.stat(mtp)
            """ 0o111 for Executable permissions
                0o222 for Writable permissions
                0o444 for Readable permission
            """
            os.chmod(mtp, st.st_mode | 0o111 | 0o222 | 0o444)

        self.__setup_nfs_client()

    def mount(self, srv_ip, srv_mtps, client_mtps=None):
        """
            Should mount all the points mentioned in the Mount Point List
        """
        if client_mtps:
            mounts_list = client_mtps
        else:
            mounts_list = self.__mtp_list
        if len(srv_mtps) != len(mounts_list):
            raise exception.ConfigException('The number of Mount Points on'
            'Server and Client should match to mount!')
        ip_idx = 0
        for srv_mtp,clt_mtp in zip(srv_mtps, mounts_list):
            log.info('Mounting %s to %s' % (clt_mtp, srv_mtp))
            exe.block_run('mount -o rdma,port=20049  %s:%s %s' % (srv_ip[ip_idx], srv_mtp, clt_mtp))
            ip_idx += 1
            time.sleep(1)
        log.info('Mounted all the Mount Points successfully')
        self.__mount_status = True

    def unmount(self, client_mtps=None):
        if not self.__mount_status:
            raise exception.ConfigException('No mount points found to unmount!')
        if client_mtps:
            mounts_list = client_mtps
        else:
            mounts_list = self.__mtp_list
        for clt_mtp in mounts_list:
            log.info('Unmounting %s' % clt_mtp)
            exe.block_run('umount %s' % clt_mtp)
            time.sleep(1)
        log.info('Unmounted all the Mount Points successfully')
        self.__mount_status = False

    def remove_mounts(self):
        if not self.__mtp_list:
            raise exception.ConfigException('No mount points available.'
            'Call create_mount_points method before calling this')
        import shutil
        mt = 0
        while self.__mtp_list:
            mt = len(self.__mtp_list) - 1
            log.info('Removing mount point %s' % self.__mtp_list[mt])
            shutil.rmtree(self.__mtp_list[mt])
            self.__mtp_list.pop(mt)
            mt += 1
            time.sleep(1)

    def mounts(self):
        return self.__mtp_list

    def mount_status(self):
        return self.__mount_status
