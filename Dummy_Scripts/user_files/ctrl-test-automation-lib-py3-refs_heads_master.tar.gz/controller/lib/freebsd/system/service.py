"""
:mod:`service` -- Wrapper for service
================================================================================

.. module:: controller.lib.linux.system.service
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

"""
from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)

class Service(object):
    def __init__(self, service_name):
        self.__service = service_name

    @property
    def status(self):
        try:
            log.info('Checking if %s service is running.' % self.__service)
            output = exe.block_run('service %s status' % self.__service)
            log.info(output)
            status = True
        except exception.ExeExitcodeException as err:
            if err.output.find('service could not be found') != -1:
                raise

            log.info('Service %s is not running.' % self.__service)
            log.info(err.output)
            return False

        log.info('Service %s is running.' % self.__service)
        return True

    def start(self):
        log.info('Starting %s service' % self.__service)
        output = exe.block_run('service %s start' % self.__service)
        log.info(output)

    def stop(self):
        log.info('Stopping %s service.' % self.__service)
        output = exe.block_run('service %s stop' % self.__service)
        log.info(output)

    def restart(self):
        log.info('Restarting %s service.' % self.__service)
        output = exe.block_run('service %s restart' % self.__service)
        log.info(output)
