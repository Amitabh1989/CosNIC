"""
:mod:`ssh` -- SSH wrapper library
=================================
.. module:: controller.lib.freebsd.system.ssh
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for SSH.
"""
from controller.lib.linux.system.ssh import (SSH, SSHSession)
__all__ = ['SSH', 'SSHSession']
