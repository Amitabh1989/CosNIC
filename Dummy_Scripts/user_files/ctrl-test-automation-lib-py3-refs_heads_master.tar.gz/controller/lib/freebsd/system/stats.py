"""
:mod:`stats` -- System statistics library
=========================================

.. module:: controller.lib.freebsd.system.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library is to access system statistics related information such as
CPU usage, interrupt.

.. note::

   Ethernet related statistics module is available at
   controller.lib.freebsd.eth.stats

Common functions might be get_nic_interrupt() and get_cpu_util(). Both of them
have similar ways to use.

Get Interrupt Counters
----------------------

get_nic_interrupts() requires one argument and few optional ones. To use the
function, you have to provide a name of Ethernet interface as below.

>>> from controller.lib.freebsd.system import stats
>>> stats.get_nic_interrupt(iface='p1p1')
{59: {'dev': 'p1p1-0', 'int': [0, 0, 0, 10772400], 'type': 'IR-PCI-MSI-edge'},
 60: {'dev': 'p1p1-1', 'int': [15854, 7601, 2435417, 0], 'type': 'IR-PCI-MSI-edge'},
 61: {'dev': 'p1p1-2', 'int': [2177, 3954957, 3160, 13224], 'type': 'IR-PCI-MSI-edge'},
 62: {'dev': 'p1p1-3', 'int': [0, 0, 9868013, 305135], 'type': 'IR-PCI-MSI-edge'}}

Which returns a dictionary that has interrupt ID as keys and additional
information as values. The interesting values are 'int'.

As you can guess, 'int' is a number of interrupts for each CPU. Those numbers
match with what you can see from /proc/interrupts.

If you specify "interval" argument, it returns differences for the given
interval time instead.

>>> stats.get_nic_interrupt(iface='p1p1', interval=1)
{59: {'dev': 'p1p1-0', 'int': [0, 0, 0, 1], 'type': 'IR-PCI-MSI-edge'},
 60: {'dev': 'p1p1-1', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 61: {'dev': 'p1p1-2', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 62: {'dev': 'p1p1-3', 'int': [0, 0, 0, 1], 'type': 'IR-PCI-MSI-edge'}}

It's important to note that the function becomes blocking once you specify the
interval argument.

If you need to calculate interrupt differences as non-blocking or at specific
times, you can call get_interrupt_diff() as below:


>>> old_stats = stats.get_nic_interrupt(iface='p1p1')
>>> time.sleep(1)
>>> new_stats = stats.get_nic_interrupt(iface='p1p1')
>>> stats.get_interrupt_diff(old_stats, new_stats)
{59: {'dev': 'p1p1-0', 'int': [0, 0, 0, 7], 'type': 'IR-PCI-MSI-edge'},
 60: {'dev': 'p1p1-1', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 61: {'dev': 'p1p1-2', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 62: {'dev': 'p1p1-3', 'int': [0, 0, 0, 7], 'type': 'IR-PCI-MSI-edge'}}

Get CPU Utilization
-------------------

get_cpu_util() takes less arguments and works simpler. Without any arguments,
it will return CPU utilization % in 0.1 sec

>>> stats.get_cpu_util()
32.43

Of course you can call the function as blocking with the interval argument.

>>> stats.get_cpu_util(interval=5)
31.03

Unlike interrupt counters, CPU utilization is not a cumulative number, you
cannot calculate it as a non-blocking.

"""

import collections
import json
import multiprocessing
import time
from typing import Dict, List, TypedDict, Union

import regex as re

from controller.lib.core import exception
from controller.lib.common.system.stats import BaseStats
from controller.lib.common.shell import exe
from controller.lib.freebsd.eth import stats as nic_stats

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"


InterruptInfo = TypedDict('InterruptInfo', {
    'dev': str,        # device name
    'type': str,       # rxq# | txq#
    'int': List[int],  # List of interrupt counts per CPU (freebsd only shows the sum, so this is a single entry)
    'sum': int,        # Sum of 'int' list entries
})
IntId = int            # IRQ#
InterruptData = Dict[IntId, InterruptInfo]

CpuInfo = TypedDict('CpuInfo', {
    'user': float, 'nice': float, 'system': float, 'idle': float, 'iowait': float, 'irq': float,
    'softirq': float, 'steal': float, 'guest': float, 'guest_nice': float
})
CpuId = Union[int, str]  # CPU# or 'all'
CpuData = Dict[CpuId, CpuInfo]


class FreeBsdStats(BaseStats):
    def __init__(self, iface):
        super().__init__(iface)

    @classmethod
    def get_interrupt(cls) -> InterruptData:
        """Return interrupt information

        Any interrupt information that does not have ID (i.e. NMI) will not be
        included.

        key = interrupt ID
        value = dict where 'dev' = devname, 'int' = interrupt count per CPU in a list,
        'sum' = sum of the interrupt counts of all CPUs, 'type' = rxq# or txq# value

        """
        ret_dict = {}
        # TODO: Only have aggregate interrupt count for all CPUs (for a given interrupt)!
        output = exe.block_run('vmstat -i | grep bnxt')

        regexp = r'irq(\d+):\s+(bnxt\d+):(rxq\d+)\s+(\d+)\s+(\d+)'
        for int_info in re.findall(regexp, output):
            int_id, int_dev, int_type, int_count, _rate = int_info

            ret_dict[int(int_id)] = {
                'dev': int_dev,
                'type': int_type,
                'int': [int(int_count)],
                'sum': int(int_count),
            }

        return ret_dict

    def get_nic_interrupt(self) -> List[int]:
        """Return sum of per-cpu interrupt counters belonging to the iface.

        Return:
            List of the per-cpu interrupt counts across all queues/irqs for the iface

        """
        int_dict = get_nic_interrupt(iface=self.iface)
        ret_list = [0] * multiprocessing.cpu_count()

        for int_info in int_dict.values():
            ret_list = [x + y for x, y in zip(ret_list, int_info['int'])]

        return ret_list

    def get_rx_offload_counter(self, **kwargs) -> int:
        iface_stats = nic_stats.get_stats(self.iface)

        if not hasattr(iface_stats, 'tpa'):
            raise exception.ConfigException('No TPA statistics available')

        return iface_stats.tpa.packets

    def get_tx_offload_counter(self, **kwargs):
        raise NotImplementedError

    def get_tcp_retransmitted(self, **kwargs) -> int:
        nstat_output = exe.block_run("netstat -s -p tcp | grep -i 'segment rexmit'")

        rexmits_re = re.search(r'\s*(\d+)\s+segment rexmit[s]?', nstat_output)
        if rexmits_re:
            return int(rexmits_re.group(1))

        return None


def get_interrupt() -> InterruptData:
    return FreeBsdStats.get_interrupt()


def get_interrupt_diff(old_int_counter, new_int_counter) -> InterruptData:
    """Return difference of two interrupt counters.

    This function is useful when calculating interrupt numbers for certain
    interval as non-blocking.

    Args:
        old_int_counter (dict): Return value of get_interrupt(). Must have
            all keys that new_int_counter has
        new_int_counter (dict): return value of get_interrupt(), but keys of
            the dictionary can be subset of get_interrupt()

    Return:
        dict: dictionary which has different counters between old and new

    """
    if not set(old_int_counter.keys()).issuperset(set(new_int_counter)):
        raise exception.ValueException(
            'old_int_counter does not have all keys in new_int_counter')

    return {
        key: {
            'dev': new_int_counter[key]['dev'],
            'type': new_int_counter[key]['type'],
            'int': [new - old for new, old in zip(new_int_counter[key]['int'],
                                                  old_int_counter[key]['int'])],
            'sum': new_int_counter[key]['sum'] - old_int_counter[key]['sum'],
        } for key in list(new_int_counter.keys())
    }


def get_nic_interrupt(iface, interval=None) -> InterruptData:
    """Return the interrupt info belonging to the given iface.

    Args:
        iface (str): ethX name
        interval (None, int): If None, return interrupt counters. Non-blocking.
            If integer, sleep for given seconds and return a difference of
            interrupt counters during that sleep time

    Return:
        InterruptData: dictionary per IRQ containing the difference or absolute number of interrupts depending on
            the interval parameter, along with type and dev

    """
    ret_dict = {}
    old_int = get_interrupt()

    time.sleep(interval or 0)

    for int_id, int_info in list(get_interrupt().items()):
        if re.match(iface + r'(\-.*)?$', int_info['dev']):
            ret_dict[int_id] = int_info

    return ret_dict if interval is None else get_interrupt_diff(old_int, ret_dict)


def get_cpu_time() -> CpuData:
    """
    Return CPU time using /proc/stat (vmstat).

    Return:
        dict: user, nice, system, idle, iowait, irq, softirq, steal, guest,
            guest_nice will be returned

    """
    ret_dict = {}
    output_json = json.loads(exe.block_run('vmstat -P --libxo json'))
    for cpu_data in output_json['cpu']:
        cpu_id = int(cpu_data['name'])
        user = float(cpu_data['user'])
        system = float(cpu_data['system'])
        idle = float(cpu_data['idle'])

        ret_dict[cpu_id] = {
            'user': user, 'nice': 0.0, 'system': system, 'idle': idle,
            'iowait': 0.0, 'irq': 0.0, 'softirq': 0.0, 'steal': 0.0, 'guest': 0.0, 'guest_nice': 0.0
        }
    output_json = json.loads(exe.block_run('vmstat --libxo json'))
    for cpu_data in output_json['cpu-statistics']:
        cpu_id = 'all'
        user = float(cpu_data['user'])
        system = float(cpu_data['system'])
        idle = float(cpu_data['idle'])

        ret_dict[cpu_id] = {
            'user': user, 'nice': 0.0, 'system': system, 'idle': idle,
            'iowait': 0.0, 'irq': 0.0, 'softirq': 0.0, 'steal': 0.0, 'guest': 0.0, 'guest_nice': 0.0
        }

    return ret_dict


def get_cpu_util(interval=None, cpu: Union[int, List[int]] = None) -> Union[float, List[float]]:
    """
    Return CPU utilization.

    If interval is None, it will measure for 0.1 sec.
    If cpu is None, it will return total utilization of all CPUs.
    If cpu is 'all' or a list of cpu ids, it will return a list of the utilization for each of the requested cpus

    Args:
        interval (None, int): interval time to measure CPU utilization
        cpu (None, int, list): CPU ID number which CPU utilization will be
            returned. If None, return avg CPU utilization of all CPUs. If
            int, return CPU utilization of the given CPU ID. If list, return
            a list of CPU utilization of the given CPU IDs. If 'all', return
            a list with each CPU's utilization

    Returns:
        float: CPU utilization
        list: A list of CPU utilization if cpu is list

    """
    def get_sum_cpu_time(cpu_time_dict, time_list):
        sum_list = []
        for time_name, value in list(cpu_time_dict.items()):
            if time_name in time_list:
                sum_list.append(value)

        return sum(sum_list)

    ret_dict = {}

    old_cpu_time = get_cpu_time()
    time.sleep(0.1 if interval is None else interval)
    new_cpu_time = get_cpu_time()

    for cpu_id in new_cpu_time:  # pylint: disable=C0206
        old_idle = get_sum_cpu_time(old_cpu_time[cpu_id], ['idle', 'iowait'])
        new_idle = get_sum_cpu_time(new_cpu_time[cpu_id], ['idle', 'iowait'])
        old_non_idle = get_sum_cpu_time(old_cpu_time[cpu_id], ['user', 'nice', 'system', 'irq', 'softirq', 'steal'])
        new_non_idle = get_sum_cpu_time(new_cpu_time[cpu_id], ['user', 'nice', 'system', 'irq', 'softirq', 'steal'])
        old_total = old_idle + old_non_idle
        new_total = new_idle + new_non_idle

        ret_dict[cpu_id] = round(((new_total - old_total) - (new_idle - old_idle)) * 100 / (new_total - old_total), 2)

    if cpu is None:
        return ret_dict['all']

    if cpu == 'all':
        sorted_dict = collections.OrderedDict(sorted(ret_dict.items()))
        sorted_dict.pop('all')
        return list(sorted_dict.values())

    if isinstance(cpu, int):
        return ret_dict[cpu]

    if isinstance(cpu, list):
        ret_list = []
        for cpu_id in cpu:
            if cpu_id not in ret_dict:
                raise ValueError(f'CPU ID {cpu_id} does not exist')
            ret_list.append(ret_dict[cpu_id])

        return ret_list
