"""
:mod:`stats` -- System statistics library
=========================================

.. module:: controller.lib.freebsd.system.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library is to access system statistics related information such as
CPU usage, interrupt.

.. note::

   Ethernet related statistics module is available at
   controller.lib.freebsd.eth.stats

Common functions might be get_nic_interrupt() and get_cpu_util(). Both of them
have similar ways to use.

Get Interrupt Counters
----------------------

get_nic_interrupts() requires one argument and few optional ones. To use the
function, you have to provide a name of Ethernet interface as below.

CTRL-48082: This module will be deprecated and lower kennels will be handled by controller.lib.freebsd.system.stats

>>> from controller.lib.freebsd.system import stats
>>> stats.get_nic_interrupt(iface='p1p1')
{59: {'dev': 'p1p1-0', 'int': [0, 0, 0, 10772400], 'type': 'IR-PCI-MSI-edge'},
 60: {'dev': 'p1p1-1', 'int': [15854, 7601, 2435417, 0], 'type': 'IR-PCI-MSI-edge'},
 61: {'dev': 'p1p1-2', 'int': [2177, 3954957, 3160, 13224], 'type': 'IR-PCI-MSI-edge'},
 62: {'dev': 'p1p1-3', 'int': [0, 0, 9868013, 305135], 'type': 'IR-PCI-MSI-edge'}}

Which returns a dictionary that has interrupt ID as keys and additional
information as values. The interesting values are 'int'.

As you can guess, 'int' is a number of interrupts for each CPU. Those numbers
match with what you can see from /proc/interrupts.

If you specify "interval" argument, it returns differences for the given
interval time instead.

>>> stats.get_nic_interrupt(iface='p1p1', interval=1)
{59: {'dev': 'p1p1-0', 'int': [0, 0, 0, 1], 'type': 'IR-PCI-MSI-edge'},
 60: {'dev': 'p1p1-1', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 61: {'dev': 'p1p1-2', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 62: {'dev': 'p1p1-3', 'int': [0, 0, 0, 1], 'type': 'IR-PCI-MSI-edge'}}

It's important to note that the function becomes blocking once you specify the
interval argument.

If you need to calculate interrupt differences as non-blocking or at specific
times, you can call get_interrupt_diff() as below:


>>> old_stats = stats.get_nic_interrupt(iface='p1p1')
>>> time.sleep(1)
>>> new_stats = stats.get_nic_interrupt(iface='p1p1')
>>> stats.get_interrupt_diff(old_stats, new_stats)
{59: {'dev': 'p1p1-0', 'int': [0, 0, 0, 7], 'type': 'IR-PCI-MSI-edge'},
 60: {'dev': 'p1p1-1', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 61: {'dev': 'p1p1-2', 'int': [0, 0, 0, 0], 'type': 'IR-PCI-MSI-edge'},
 62: {'dev': 'p1p1-3', 'int': [0, 0, 0, 7], 'type': 'IR-PCI-MSI-edge'}}

Get CPU Utilization
-------------------

get_cpu_util() takes less arguments and works simpler. Without any arguments,
it will return CPU utilization % in 0.1 sec

>>> stats.get_cpu_util()
32.43

Of course you can call the function as blocking with the interval argument.

>>> stats.get_cpu_util(interval=5)
31.03

Unlike interrupt counters, CPU utilization is not a cumulative number, you
cannot calculate it as a non-blocking.

"""

from controller.lib.freebsd.system.stats import (FreeBsdStats, get_interrupt, get_interrupt_diff, get_nic_interrupt,
                                                 get_cpu_util, get_cpu_time)
__all__ = ['FreeBsdStats', 'get_interrupt', 'get_interrupt_diff', 'get_nic_interrupt', 'get_cpu_util', 'get_cpu_time']
