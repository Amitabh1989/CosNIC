"""
:mod:`sysinfo` -- Collect system information
============================================

.. module:: controller.lib.freebsd.system.sysinfo
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import logging
import re

from controller.lib.core import exception
from controller.lib.common.system import sysinfo
from controller.lib.freebsd import eth
from controller.lib.freebsd.eth import ethtool
from controller.lib.common.shell import exe

log = logging.getLogger(__name__)


class SysInfo(sysinfo.BaseSysInfo):
    platform = 'FreeBSD'

    @classmethod
    def get_memory(cls):
        """ Return total memory in KB (/proc/meminfo, MemTotal default) """
        return int(exe.block_run('sysctl -n hw.realmem').strip()) / 1024

    @classmethod
    def get_driver_info(cls, driver_list):

        ret_dict = {}

        for driver_name in driver_list:
            iface_list = eth.get_interfaces_by_driver(driver_name)
            if len(iface_list) == 0:
                log.warning('No iface found that uses %s', driver_name)
                continue

            iface = iface_list[0]
            try:
                drv_info = ethtool.get_drvinfo(iface.name)
            except exception.ExeExitcodeException:
                continue

            ret_dict[drv_info['name']] = (f"{drv_info['hwrm_version']}-{drv_info['version']} "
                                          f"firmware ({drv_info['firmware']})")

        return ret_dict

    @classmethod
    def get_bnxt_en_info(cls):
        """Return bnxt_en driver information including firmware versions
        """

        drv_info = cls.get_driver_info(['bnxt_en'])
        drv, bc, rm, ph = re.findall(r'(\d+\.\d+\.\d+)', drv_info['bnxt_en'])

        return {'bnxt_en': drv, 'bc': bc, 'rm': rm, 'ph': ph}

    @classmethod
    def get_kernel_version(cls):
        return exe.block_run('uname -r', shell=True).strip()
