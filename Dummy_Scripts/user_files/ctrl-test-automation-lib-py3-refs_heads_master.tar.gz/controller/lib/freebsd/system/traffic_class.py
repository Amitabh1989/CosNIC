"""
:mod:`traffic_class` -- Wrapper for tc qdisc
================================================================================

.. module:: controller.lib.freebsd.system.traffic_class
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

"""
from distutils.spawn import find_executable
import json
from re import findall, search
import time
from typing import Union

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class TrafficClass(object):
    def __init__(self, tc_type, iface):
        raise NotImplementedError('TrafficClass (tc) is not yet migrated to dnctl/ipfw for FreeBSD')
        # self.iface = iface
        # self.tc = find_executable('tc')
        # self.tc_type = tc_type

    def config_traffic_classes(self, tc_num=None, tc_prio_map=None, method='add'):
        """tc qdisc add dev <p6p1> root mqprio num_tc 2 map 1 1 0 0 0 0 0 0  hw 1"""
        if method == 'add':
            if None in [tc_num, tc_prio_map]:
                raise exception.ConfigException('Traffic Class details must be provided to create traffic classes')

            log.info('Creating %s traffic classes on interface %s' % (tc_num, self.iface))
            exe.block_run('%s %s add dev %s root mqprio num_tc %s map %s hw 1'
                          % (self.tc, self.tc_type, self.iface, tc_num, (' '.join(tc_prio_map))))
        else:
            log.info('Deleting traffic classes.')
            try:
                exe.block_run('%s %s del dev %s root mqprio' % (self.tc, self.tc_type, self.iface))
            except Exception as e:
                if 'No such file or directory' in str(e):
                    pass

        time.sleep(1)

    def show_traffic_class(self):
        output = exe.block_run('%s %s show dev %s' % (self.tc, self.tc_type, self.iface))
        log.info(output)
        return output

    def add_qdisc(self, interface, name: str, block_id=None):
        """Add a queuing discipline to the interface.

        :param interface: The interface to add the qdisc to.
        :param name: The name of the qdisc to add.
        :param block_id: The block number to qdisc is tagged to.
        """
        if block_id is None:
            log.info(f'Adding qdisc {name} on interface {interface} with ingress.')
            return exe.block_run(f'{self.tc} {self.tc_type} add dev {interface} {name}')
        else:
            log.info(f'Adding qdisc {name} on block {block_id} with ingress.')
            return exe.block_run(f'{self.tc} {self.tc_type} add dev {interface} ingress_block {block_id} {name}')

    def delete_qdisc(self, interface: str, name: str, block_id=None):
        """Delete a queuing discipline from the interface.

        :param interface: The interface to delete the qdisc from.
        :param name: The name of the qdisc to delete.
        :param block_id: The block number to qdisc is tagged to.

        """
        if block_id is None:
            log.info(f'Deleting qdisc {name} on interface {interface}.')
            return exe.block_run(f'{self.tc} {self.tc_type} delete dev {interface} {name}')
        else:
            log.info(f'Deleting qdisc {name} on block {block_id}.')
            return exe.block_run(f'{self.tc} {self.tc_type} delete dev {interface} ingress_block {block_id} {name}')

    def show_qdisc(self, interface: str, name: str, flags: list) -> str:
        """Return the details of the qdisc in the below format.

        .. code-block: python
            qdisc mq 0: root
             Sent 17430617 bytes 103604 pkt (dropped 0, overlimits 0 requeues 2)
             backlog 0b 0p requeues 2
        :param interface: The interface to get the qdisc details of.
        :param name: The name of the qdisc to get the details of.
        :param flags: The extra flags to use when getting the details. e.g: ['-s', '-d']
        :return: The details of the qdisc in raw string format.
        """
        log.debug(f'Getting details of qdisc {name} on interface {interface}.')
        str_flags = ' '.join(flags)
        command_output = exe.block_run(f'{self.tc} {str_flags} {self.tc_type} show dev {interface}')
        qdisc_data = []
        extract = False

        for line in command_output.splitlines():
            if f'qdisc {name}' in line:
                qdisc_data.append(line)
                extract = True
            elif extract:
                if 'qdisc' not in line:
                    qdisc_data.append(line)
                else:
                    extract = False

        qdisc_data = '\n'.join(qdisc_data).strip()
        log.debug(f'Details of qdisc {name} on interface {interface}: {qdisc_data}.')
        return qdisc_data

    def get_qdisc_stats(self, interface: str, name: str) -> dict:
        """Return the statistics of the qdisc in the below format.

        .. code-block: python
            {
                'sent_bytes': 17430617,
                'sent_packets': 103604,
                'dropped_packets': 0
            }

        :param interface: The interface to get the qdisc details of.
        :param name: The name of the qdisc to get the details of.
        :return: The statistics of the qdisc.
        """
        qdisc_stats = {}
        log.debug(f'Getting statistics of qdisc {name} on interface {interface}.')
        qdisc_data = self.show_qdisc(interface=interface, name=name, flags=['-s'])
        qdisc_stats['sent_bytes'] = sum([int(b) for b in findall(r'(\d+) bytes', qdisc_data)])
        qdisc_stats['sent_packets'] = sum([int(b) for b in findall(r'(\d+) pkt', qdisc_data)])
        qdisc_stats['dropped_packets'] = sum([int(b) for b in findall(r'dropped (\d+)', qdisc_data)])
        log.debug(f'Statistics of qdisc {name} on interface {interface}: {qdisc_stats}.')
        return qdisc_stats

    def add_filter(self, interface: str, name: str, options: Union[list, str]):
        """Create a filter with the options specified.

        :param interface: The interface to add the filter to.
        :param name: The name of the filter.
        :param options: The options to use in the filter.

        """
        str_options = ' '.join(options) if isinstance(options, list) else options
        log.info(f'Adding filter {name} to interface {interface} with options: {str_options}.')
        return exe.block_run(f'{self.tc} filter add dev {interface} {name} {str_options}')

    def add_block_filter(self, block_id: str, name: str, options: Union[list, str]):
        """Create a filter with the options specified.

        :param block_id: The block id to add the filter to.
        :param name: The name of the filter.
        :param options: The options to use in the filter.

        """
        str_options = ' '.join(options) if isinstance(options, list) else options
        log.info(f'Adding filter {name} to block {block_id} with options: {str_options}.')
        return exe.block_run(f'{self.tc} filter add block {block_id} {name} {str_options}')

    def delete_filter(self, interface: str, options: Union[list, str]):
        """Delete the specified filter.

        To delete all the filters on the interface (aka flush), use (example):

        .. code-block:: python
            delete_filter(interface='eth0', options='ingress')

        :param interface: The interface to delete the filter from.
        :param options: The options part of the filter.

        """
        str_options = ' '.join(options) if isinstance(options, list) else options
        log.info(f'Deleting filter from interface {interface} with options: {str_options}.')
        return exe.block_run(f'{self.tc} filter delete dev {interface} {str_options}')

    def delete_block_filter(self, block_id: str, options: Union[list, str]):
        """Delete the specified filter.

        To delete all the filters on the interface (aka flush), use (example):

        .. code-block:: python
            delete_filter(block=200)

        :param block_id: The block id to delete the filter from.
        :param options: The options part of the filter.

        """
        str_options = ' '.join(options) if isinstance(options, list) else options
        log.info(f'Deleting filter from block {block_id} with options: {str_options}.')
        return exe.block_run(f'{self.tc} filter delete block {block_id} {str_options}')

    def show_filter(self, interface: str, name: str, flags: list) -> str:
        """Return the details of the filter in the below format.

        ..code-block: python
            filter protocol ip pref 10 flower chain 0
            filter protocol ip pref 10 flower chain 0 handle 0x1
              eth_type ipv4
              dst_ip 100.1.1.196
              skip_sw
              in_hw in_hw_count 1
                    action order 1: tunnel_key  set
                    src_ip 10.10.1.51
                    dst_ip 10.10.1.50
                    key_id 22
                    dst_port 4789
                    csum pipe
                     index 2 ref 1 bind 1 installed 407 sec used 407 sec
                    Action statistics:
                    Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0)
                    backlog 0b 0p requeues 0

                    action order 2: mirred (Egress Redirect to device vxlan0) stolen
                    index 2 ref 1 bind 1 installed 407 sec used 0 sec
                    Action statistics:
                    Sent 842300938 bytes 799147 pkt (dropped 0, overlimits 0 requeues 0)
                    Sent software 0 bytes 0 pkt
                    Sent hardware 842300938 bytes 799147 pkt
                    backlog 0b 0p requeues 0

        :param interface: The interface to get the filter details of.
        :param name: The filter to get the details of.
        :param flags: The extra flags to use when getting the details. e.g: ['-s']

        :return: The details of the specified filter in raw string format.
        """
        log.debug(f'Getting details of filter {name} on interface {interface}.')
        str_flags = ' '.join(flags)
        return exe.block_run(f'{self.tc} {str_flags} filter show dev {interface} {name}')

    def show_block_filter(self, block_id: str, name: str, flags: list) -> str:
        """Return the details of the filter in the below format.

        ..code-block: python
            filter protocol ip pref 10 flower chain 0
            filter protocol ip pref 10 flower chain 0 handle 0x1
              eth_type ipv4
              dst_ip 100.1.1.196
              skip_sw
              in_hw in_hw_count 1
                    action order 1: tunnel_key  set
                    src_ip 10.10.1.51
                    dst_ip 10.10.1.50
                    key_id 22
                    dst_port 4789
                    csum pipe
                     index 2 ref 1 bind 1 installed 407 sec used 407 sec
                    Action statistics:
                    Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0)
                    backlog 0b 0p requeues 0

                    action order 2: mirred (Egress Redirect to device vxlan0) stolen
                    index 2 ref 1 bind 1 installed 407 sec used 0 sec
                    Action statistics:
                    Sent 842300938 bytes 799147 pkt (dropped 0, overlimits 0 requeues 0)
                    Sent software 0 bytes 0 pkt
                    Sent hardware 842300938 bytes 799147 pkt
                    backlog 0b 0p requeues 0

        :param block_id: The block to get the filter details of.
        :param name: The filter to get the details of.
        :param flags: The extra flags to use when getting the details. e.g: ['-s']

        :return: The details of the specified filter in raw string format.
        """
        log.debug(f'Getting details of filter {name} on block {block_id}.')
        str_flags = ' '.join(flags)
        return exe.block_run(f'{self.tc} {str_flags} filter show block {block_id} {name}')

    def get_filter_stats(self, interface: str, name: str, handle: Union[list, int] = 1, block_id=None) -> dict:
        """Get the statistics of the filter for the specified handle ID in the below format.

        .. code-block: python

            {1: {'action order 1': {'dropped_packets': 0,
                            'id': 'tunnel_key  set',
                            'sent_bytes': 0,
                            'sent_packets': 0},
                 'action order 2': {'dropped_packets': 0,
                            'hardware': {'sent_bytes': 15400, 'sent_packets': 100},
                            'id': 'mirred (Egress Redirect to device vxlan0) '
                                  'stolen',
                            'sent_bytes': 15400,
                            'sent_packets': 100,
                            'software': {'sent_bytes': 0, 'sent_packets': 0}}},
            2: {'action order 1': {'dropped_packets': 0,
                            'id': 'tunnel_key  set',
                            'sent_bytes': 0,
                            'sent_packets': 0},
                'action order 2': {'dropped_packets': 0,
                            'hardware': {'sent_bytes': 15400, 'sent_packets': 100},
                            'id': 'mirred (Egress Redirect to device vxlan0) '
                                  'stolen',
                            'sent_bytes': 15400,
                            'sent_packets': 100,
                            'software': {'sent_bytes': 0, 'sent_packets': 0}}},
            }
        :param interface: The interface to get the filter statistics of.
        :param name: The filter to get the statistics of.
        :param handle: The handle ID list associated with the filter rules.
        :param block_id: The block_id is the ID associated with the filter rules.

        :return: The statistics of the filter.
        """
        handle_list = handle if isinstance(handle, list) else [handle]
        handle_filter_stats = {}
        log.debug(f'Getting statistics of filter {name} on interface {interface}.')
        if block_id is None:
            filter_data = self.show_filter(interface=interface, name=name, flags=['-s'])
        else:
            filter_data = self.show_block_filter(block_id=block_id, name=name, flags=['-s'])
        for handle in handle_list:
            filter_stats = {}
            filter_data_by_handle = self.get_filter_data_by_handle(filter_data=filter_data, handle=handle)
            key_title = findall(r'(action order \d+): (.*)', filter_data_by_handle)

            for key, title in key_title:
                filter_stats[key] = {'id': title.strip()}

            key = None

            for line in filter_data_by_handle.splitlines():
                if 'action order' in line:
                    key = line.split(':')[0].strip()
                elif key:
                    if 'Sent' in line:
                        what_ware = None

                        if 'software' in line:
                            what_ware = 'software'
                        elif 'hardware' in line:
                            what_ware = 'hardware'

                        if what_ware:
                            filter_stats[key][what_ware] = {}
                            b, p = search(r'(\d+) bytes (\d+) pkt', line).groups()
                            filter_stats[key][what_ware]['sent_bytes'] = int(b)
                            filter_stats[key][what_ware]['sent_packets'] = int(p)
                        else:
                            b, p, d = search(r'(\d+) bytes (\d+) pkt \(dropped (\d+),', line).groups()
                            filter_stats[key]['sent_bytes'] = int(b)
                            filter_stats[key]['sent_packets'] = int(p)
                            filter_stats[key]['dropped_packets'] = int(d)
                    elif 'backlog' in line:
                        key = None
            handle_filter_stats[handle] = filter_stats
        log.debug(f'\n\nStatistics of filter {name} on interface {interface}: {handle_filter_stats}.')
        return handle_filter_stats

    def get_filter_data_by_handle(self, filter_data: str, handle: int = 1):
        filter_data_by_handle = ''

        for line in filter_data.splitlines():
            if f'handle 0x{handle:x}' in line:
                filter_data_by_handle = line
            elif filter_data_by_handle:
                line += '\n'

                if 'handle ' in line:
                    break
                else:
                    filter_data_by_handle += line

        log.debug(f'Filter data for handle {handle}: {filter_data_by_handle}.')
        return filter_data_by_handle

    def get_detailed_filter_stats(self, interface: str, name: str = 'ingress',
                                  pref: Union[list, int] = None, block_id=None) -> list:
        """Get the statistics of the filter for the specified handle ID in the below format.

        .. code-block: python

        [{'protocol': 'ip', 'pref': 100, 'kind': 'flower', 'chain': 0, 'options': {'handle': 1, 'keys':
        {'eth_type': 'ipv4', 'dst_ip': '20.20.39.85'}, 'skip_sw': True, 'in_hw': True, 'in_hw_count': 1, 'actions':
        [{'order': 1, 'kind': 'tunnel_key', 'mode': 'set', 'src_ip': '200.10.142.1', 'dst_ip': '200.10.142.2',
         'key_id': 22, 'dst_port': 4789, 'flag': 'csum', 'control_action': {'type': 'pipe'}, 'index': 7501, 'ref': 1,
         'bind': 1, 'installed': 225, 'last_used': 225, 'first_used': 18806639, 'stats': {'bytes': 0, 'packets': 0,
         'drops': 0, 'overlimits': 0, 'requeues': 0, 'backlog': 0, 'qlen': 0}}, {'order': 2, 'kind': 'mirred',
         'mirred_action': 'redirect', 'direction': 'egress', 'to_dev': 'vxlan0', 'control_action': {'type': 'stolen'},
         'index': 7501, 'ref': 1, 'bind': 1, 'installed': 225, 'last_used': 225, 'first_used': 18806639, 'stats':
        {'bytes': 0, 'packets': 0, 'drops': 0, 'overlimits': 0, 'requeues': 0, 'backlog': 0, 'qlen': 0}}]}}]


        :param interface: The interface to get the filter statistics of.
        :param name: The filter to get the statistics of.
        :param pref: The handle ID list associated with the filter rules.
        :param block_id: The block_id is the ID associated with the filter rules.

        :return: The statistics of the filter.
        """
        if block_id is None:
            log.debug(f'Getting statistics of filter {name} on interface {interface}.')
            filter_data = self.show_filter(interface=interface, name=name, flags=['-s -j'])
        else:
            log.debug(f'Getting statistics of filter {name} on block id {block_id}.')
            filter_data = self.show_block_filter(block_id=block_id, name=name, flags=['-s -j'])

        if isinstance(filter_data, str) is False:
            raise TypeError('String is expected.')

        if not filter_data.strip():
            # tc filter returned empty output.
            return []

        try:
            filter_stats = json.loads(filter_data)
        except json.JSONDecodeError as err:
            raise UserWarning(f'Can`t decode lsblk json output: \n{filter_data}\n{repr(err)}')

        stats = [el for el in filter_stats if 'options' in el]

        if pref:
            pref = pref if isinstance(pref, list) else [pref]
            stats = [el for el in stats if el['pref'] in pref]

        return stats
