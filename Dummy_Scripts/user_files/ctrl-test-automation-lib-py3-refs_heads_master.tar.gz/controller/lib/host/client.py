"""
:mod:`client` -- RPyC client wrapper
====================================

.. module:: controller.lib.host.client
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

.. note::
   This module is to connect to remote hosts using RPyC. Due to no service is
   supported by STAT (as 3/30/2015), no service level host handling is
   implemented here, which means all developers who directly access this module
   should handle host object such as disconnecting from hosts at the end of the
   script.

Pre-requisite
-------------
To use client module, you have to run "server" on remote hosts. The way to run
it is quite simple if you already installed controller package using pip or
setuptools::

   $ stat_server.py

If you have not installed controller package, please refer README.rst.

Start using client module
-------------------------
If your remote host has IP address "192.168.1.1" and is running stat_server.py,
you can connect to it as below:

>>> from controller.lib.host import client
>>> rc = client.connect('192.168.1.1')

Now you can interact with remote hosts, such as checking connection status

>>> rc.connected
True

Or import Python module on the remote host

>>> r_exe = rc.import_module('controller.lib.common.shell.exe')

Note that import_module returns a proxy to access the remote host object -
r_exe for example. Now whenever you interact with r_exe, it should be running
on the remote host side. For example:

>>> r_exe.block_run('cat /etc/hostname')
'echo-devel-linux-2\\n'

Which is a hostname of the remote host. Now you can disconnect the connection
by calling "disconnect"

>>> rc.disconnect()


"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

from distutils.version import LooseVersion
from functools import wraps
import socket
import time
import threading
from typing import TYPE_CHECKING, Union

import rpyc

import controller
from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.host import remote_logging

if TYPE_CHECKING:
    from rpyc import SlaveService, Connection

DEFAULT_RPYC_PORT = 2726
log = log_handler.get_logger(__name__)


class HostHandler:
    """A class that provides methods to interact with a remote host.

    Args:
        hostname (str): hostname or IP address
        port (int): port number to communicate with RPyC server. If None,
            use the default value 2726
    """
    host_list = []

    def __init__(self, hostname, port=None, **kwargs):
        """
        Args:
            hostname (str): Hostname where the client is connected to
            port (int, optional): port number that RPyC will connect to
            **kwargs: keyword arguments
        """
        self.client: Union['SlaveService', 'Connection'] = None  # Not set, yet
        self._connected = False
        self._hostname = hostname
        self._remote_logger = None  # Not set yet
        self._remote_logger_thread = None  # Not set yet
        self.port = port or DEFAULT_RPYC_PORT
        self.modules = None

    def check_version(self):
        min_version = controller.__min_compatible_version__
        max_version = controller.__max_compatible_version__
        remote_version = self.client.modules.controller.get_version()

        if LooseVersion(min_version) > LooseVersion(remote_version):
            self.disconnect()
            raise exception.ConfigException(
                'Remote host "controller" package version %s is older than '
                'required version %s' % (remote_version, min_version))

        if LooseVersion(max_version) < LooseVersion(remote_version):
            self.disconnect()
            raise exception.ConfigException(
                'Remote host "controller" package version %s is newer than '
                'supported version %s' % (remote_version, max_version))

        return True

    def connected_only(func, *args, **kwargs):
        @wraps(func)
        def conn_check(self, *args, **kwargs):
            if not self.connected:
                raise exception.HostException('The host(%s) is not connected yet' % self.hostname)

            return func(self, *args, **kwargs)

        return conn_check

    @property
    def hostname(self):
        """
        Return hostname. Read-only property.

        """
        return self._hostname

    @property
    def connected(self):
        """
        Return whether a remote host is really connected or not. To reflect
        the most recent status, it tries to ping the remote host and then
        returns the result.

        Return:
            bool: True if connected else False

        """
        if self._connected:  # connected is True
            # Possibly huge overhead, but this is the most accurate way to
            # reflect the current connection status. If this introduces too
            # much delay, will be updated with simpler logic
            try:
                ping_retry = 3
                while True:
                    try:
                        self.client.ping()
                        break
                    except Exception:
                        time.sleep(1)
                        ping_retry -= 1
                        if ping_retry == 0:
                            raise
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # Don't use rpyc.core.async since it's removed in Python-3.X.
            except (EOFError, socket.error, rpyc.core.AsyncResultTimeout) as err:
                # adding prints to root cause CTRL-48175
                if 'expire' in str(err):
                    try:
                        log.error("Connection is lost for %s" % self._hostname)
                    except Exception:
                        pass
                log.error('Connection is closed for %s with Error: %s' % (self._hostname, str(err)))
                # Clean up and set connected to False
                self.disconnect()

        return self._connected

    def connect(self, logging_remote=True, max_retry=3, rpyc_kwargs=None, **kwargs):
        """
        Connect to a remote host using RPyC

        Args:
            max_retry (int): Maximum number of retries
            kwargs: Keyword arguments that are passed to rpyc.classic.connect

        """
        log.info(f'Connecting to {self.hostname} on port {self.port}')

        def connect_with_retry():
            for retry_num in range(1, max_retry + 1):
                time.sleep(1)
                self.disconnect()

                try:
                    self.client = rpyc.classic.connect(host=self.hostname, port=self.port, **(rpyc_kwargs or {}))
                except socket.timeout:
                    log.debug('Timeout. Retry up to %s times (Retry #%s)' % (max_retry, retry_num))
                    continue
                except socket.error as err:
                    if err.errno == 111:
                        log.debug('Connection refused. Retry up to %s times (Retry #%s)' % (max_retry, retry_num))
                        continue
                    if err.errno == 113:
                        log.debug('No route to host. (Retry #%s)' % retry_num)
                        continue
                    if err.errno == 10061:
                        log.debug('The server actively refuses the connection (Retry {})'.format(retry_num))
                        continue
                    log.debug('Unknown socket errors. Error: {}'.format(err))
                    continue
                except Exception as err:
                    log.debug('Unknown errors. Error: {}'.format(err))
                    continue
                else:
                    self._connected = True
                    # CTRL-45362: Automation: Fix the syntax errors identified during Py2.7 to Py3.X
                    # porting.
                    # When running on Python 3.X, it's observed that the default timeout of
                    # 30 seconds is not enough. So, make it 10 minutes.
                    self.client._config['sync_request_timeout'] = 10 * 60
                    log.info('sync_request_timeout is: %s' % self.client._config['sync_request_timeout'])
                    return True
            # Failed to connect to the remote host. Raise Exception.
            raise exception.HostException('Cannot connect to the remote host %s:%s' % (self.hostname, self.port))

        if self.connected:
            log.debug('Connection is still alive. Return')

        connect_with_retry()

        if logging_remote:
            log.debug('Remote logging is disabled')

        self.modules = self.client.modules
        self.check_version()
        HostHandler.host_list.append(self)
        return True

    def _add_remote_handler(self):
        self._remote_logger = remote_logging.SocketLogger()
        self._remote_logger.daemon_threads = True
        self._remote_logger.addhandler(client=self.client)

        if self._remote_logger_thread is None:  # No server is running
            self._remote_logger_thread = threading.Thread(target=self._remote_logger.serve_forever)
            self._remote_logger_thread.daemon = True
            self._remote_logger_thread.start()
        else:
            log.debug('The remote logging server is already running')

    def disconnect(self):
        """
        Disconnect from the remote host. Also shut down any remote logging
        server

        Returns:
            bool: True if successful

        """
        # Stop the any remote logging server
        if self._remote_logger_thread:
            # Shutdown only if there is a thread. Otherwise deadlock happens.
            self._remote_logger.shutdown()
            self._remote_logger.server_close()

        self._remote_logger = None
        self._remote_logger_thread = None

        if self.client:
            self.client.close()

        self._connected = False
        return True

    @connected_only
    def import_module(self, module):
        """
        Import module on the remote host and return the remote proxy object.
        If the platform name is "common", this follows below steps:

        1. Check whether the given module exists
        2. If not, check the remote system platform type, and try to import
            the module after replacing "common" to platform name.
        3. If not, raise errors no such module exists

        Args:
            module (str): A fully qualified module name e.g.) a.b.c

        Returns:
            object: Any imported remote object

        """
        try:
            remote_module = self.client.root.getmodule(module)
        except ImportError:
            r_system = self.client.modules.platform.system().lower()
            module = module.replace('controller.lib.common', 'controller.lib.{}'.format(r_system))
            remote_module = self.client.root.getmodule(module)

        return remote_module

    @connected_only
    def import_modules(self, module_list):
        """
        Import multiple modules.

        Args:
            module (list): A lost of fully qualified module names

        Returns:
            list: A list of imported remote objects

        """
        return [self.client.root.getmodule(module) for module in module_list]


class HostManager(object):
    """
    A class that manages multiple host objects.

    """
    def __init__(self):
        self.host_list = []

    def add_host(self, hosts, port=None):
        """
        Add HostHandler objects to the manager and connect to it, and return
        a list of HostHandler objects

        Args:
            hosts (list): A list of IP addresses of remote hosts
            port (int): Port number of the RPyC server
        Returns:
            list: A list of HostHandler objects

        """
        for host in hosts:
            client = connect(hostname=host, port=port)
            self.host_list.append(client)

        return self.host_list

    def import_module(self, module_name):
        """
        Import module on all hosts

        """
        ret_list = []

        for host in self.host_list:
            ret_list.append(host.import_module(module_name))

        return ret_list

    def close(self):
        """
        Close all host sockets.

        """
        for host in self.host_list:
            host.disconnect()


def connect(hostname, port=None, **kwargs):
    """
    Connect to a remote host and return the created RPyC object. If fails,
    raise exceptions as RPyC does.

    Args:
        hostname (str): hostname where the client is connected to

    Returns:
        host_obj (obj): HostHandler object
    """
    log.info(f'Connecting to {hostname} over RPYC port {port or DEFAULT_RPYC_PORT}')
    for host in HostHandler.host_list:
        if host.hostname == hostname and (port is None or host.port == port):
            if not host.connected:
                host.connect(**kwargs)
            return host

    client = HostHandler(hostname=hostname, port=port)
    client.connect(**kwargs)
    return client
