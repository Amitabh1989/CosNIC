"""
:mod:`remote_logging` -- Remote logging module
==============================================

.. module:: controller.lib.host.remote_logging
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This module handles remote logging to pass handler from remote servers to a
local host, since redirecting stdout/stderr is ideal.

"""

import sys
import traceback
import socketserver
import struct
import logging
import logging.handlers
import pickle

from controller.lib.core import exception
from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = log_handler.get_logger(__name__)


class SocketLoggerHandler(socketserver.BaseRequestHandler):
    def handle(self):
        while 1:
            # Get the data length
            data_header = self.request.recv(4)
            if len(data_header) < 4:
                break

            data_length = struct.unpack('>L', data_header)[0]
            data_buffer = self.request.recv(data_length)

            while len(data_buffer) < data_length:
                data_buffer += self.request.recv(data_length - len(data_buffer))

            # Create a logging record
            record = logging.makeLogRecord(pickle.loads(data_buffer))

            # Handle the record
            logger = logging.getLogger(record.name)
            if record.levelno >= logger.getEffectiveLevel():
                logger.handle(record)


class SocketLogger(socketserver.ThreadingTCPServer):
    """
    Use the logging.SocketHandler. Has better compatibility but requires
    running a separate server to listen to the logging messages from the
    remote hosts.

    Need to use the kernel assigned port to avoid print the log from the
    different BEAST process (i.e. running multiple harness on the same machine)

    """
    allow_reuse_address = True

    def __init__(self, host='0.0.0.0', port=0, handler=SocketLoggerHandler):
        socketserver.TCPServer.__init__(self, (host, port), handler)
        self.host, self.port = self.server_address
        log.info(
            'Starting remote logging server %s:%s ... '
            % (self.host, self.port))

    def addhandler(self, client):
        try:
            client.root.addhandler(port=self.port)

        except TypeError:
            log.warning(
                'Controller version is possibly old. Disable remote logging')
            return False

        except Exception:
            # Clean up
            ex_type, ex_value, ex_traceback = sys.exc_info()
            raise exception.RemoteLoggingException(
                'Failed to access the remote logger. Error: %s' % str(ex_value)
            )

        return True
