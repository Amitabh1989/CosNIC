"""
:mod:`server` -- RPyC based custom server
=========================================

.. module:: controller.lib.host.server
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Customized RPyC classic based server.

"""
import socket
import rpyc
import logging
import logging.handlers

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

log = logging.getLogger(__name__)

class Server(rpyc.classic.SlaveService):
    socket_handlers = {}

    def on_connect(self, conn=None):
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # Use the extra connection object in case of Python-3.X.
        if conn:
            super(Server, self).on_connect(conn)
        else:
            super(Server, self).on_connect()

    def on_disconnect(self, conn=None):
        # Clean up all shell processes
        from controller.lib.common.shell import exe
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # Use the extra connection object in case of Python-3.X.
        conn = conn or self._conn
        exe._terminate()
        host, dst_port = conn._config['endpoints'][1]
        logger = logging.getLogger()
        log.info('Removing handlers')

        if (host, dst_port) not in Server.socket_handlers:
            return

        socket_handler = Server.socket_handlers[(host, dst_port)]
        logger.removeHandler(socket_handler)
        del Server.socket_handlers[(host, dst_port)]
        del socket_handler

    def exposed_addhandler(self, port, **kwargs):
        log.debug('Adding the remote handler')
        logger = logging.getLogger()
        host, dst_port = self._conn._config['endpoints'][1]
        socket_handler = logging.handlers.SocketHandler(host=host, port=port)
        socket_handler.addFilter(ContextFilter(ip_addr=self._conn._config['endpoints'][0][0]))
        Server.socket_handlers[(host, dst_port)] = socket_handler
        logger.addHandler(socket_handler)

class ContextFilter(logging.Filter):
    def __init__(self, name='', ip_addr=None):
        self.ip_addr = ip_addr or socket.gethostname()
        super(ContextFilter, self).__init__(name=name)

    def filter(self, record):
        if not hasattr(record, 'ip_addr'):
            record.ip_addr = self.ip_addr
        return True
