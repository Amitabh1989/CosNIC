from typing import Callable
import functools
from controller.lib.common.shell.exe import run


def set_default_cli(func: Callable):
    """This decorator sets 'cli' keyword argument to a default value.
    This is convenient when we need to call a function using RPyC or locally.

    The func() supposed to expect 'cli' keyword argument. It is recommended to put cli
    as the last argument in a callee function signature to avoid
    TypeError: func() got multiple values for argument 'cli'
    Or call all arguments after the `cli` as keyword argument.

    Example::

    >>> from controller.lib.linux import set_default_cli
    >>>
    >>> @set_default_cli
    >>> def ping(addr, cli=None):
    >>>     return cli(f'ping {addr}')
    >>>
    >>> ping('localhost')

    The ping will be executed using default cli which is process_handler.run for now.

    :param func: callable object which expect cli argument in kwargs.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if 'cli' not in kwargs.keys():
            kwargs['cli'] = run
        return func(*args, **kwargs)

    return wrapper

