"""
:mod:`compiler` -- wrapper for make utility
===============================================

.. module:: controller.lib.linux.app_build
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import datetime
import logging
import os
import shutil
import tempfile
import urllib.error
import urllib.request
import pathlib
import requests
from bs4 import BeautifulSoup

from controller.lib.common.shell import exe
from controller.lib.core import exception

log = logging.getLogger(__name__)


class Make(object):
    def __init__(self, src_path):
        """
        Folder structure,
            parent_dir/
                        src_file.tar.gz
                        untar_dir/src_dir
        src_dir is output of untar and is actual source directory.
        """
        self.src_path = src_path
        if not os.path.exists(self.src_path):
            raise exception.LogHandlerException(f'{self.src_path} does not exist')
        self.parent_dir = os.path.dirname(self.src_path)
        self._src_dir = None if os.path.isfile(self.src_path) else self.src_path
        self.untar_dir = None
        self.untar_dir_prefix = 'untar'

    @property
    def src_dir(self):
        if self._src_dir is None:
            self.untar()
        return self._src_dir

    def untar(self, dst_dir=None):
        unpack_formats = []
        for uf in shutil.get_unpack_formats():
            unpack_formats.extend(uf[1])
        if not any(self.src_path.endswith(uf) for uf in unpack_formats):
            raise exception.ValueException(f'{self.src_path} is not a supported compressed format file.'
                                           f'The supported compressed file formats are {unpack_formats}')

        self.untar_dir = dst_dir or tempfile.mkdtemp(
            prefix=f"{self.untar_dir_prefix}_{datetime.datetime.now().strftime('%H_%M_%S_%d_%m_%Y')}",
            dir=self.parent_dir)
        log.info('Unpack the src file..')
        shutil.unpack_archive(filename=self.src_path, extract_dir=self.untar_dir)
        # fd = tarfile.open(self.src_path, 'r')
        # fd.extractall(self.untar_dir)
        self._src_dir = os.path.join(self.untar_dir, os.listdir(self.untar_dir)[0])
        return self._src_dir

    def make(self, opts=None):
        """
        run make with make opts
        """
        log.info(f'Compiling the source code')
        opts = opts or ''
        opts = opts if isinstance(opts, list) else [opts]
        opts = ' '.join(opts)
        command = f'make {opts}'
        return exe.block_run(command, cwd=self.src_dir, shell=True)

    def install(self, opts=None, jobs=None):
        """
        run make install
        """
        log.info(f'Installing the build')
        opts = opts or ''
        opts = opts if isinstance(opts, list) else [opts]
        opts = ' '.join(opts)
        jobs = f'-j{jobs}' if jobs else ''
        command = f'make {jobs} {opts} install'
        return exe.block_run(command, cwd=self.src_dir)

    def clean(self):
        """
        run make clean
        """
        log.info(f'clean the build')
        command = f'make clean'
        return exe.block_run(command, cwd=self.src_dir)


def url_download(download_url):
    temp_dir = tempfile.mkdtemp()
    filename = pathlib.Path(download_url).name
    downloaded_filename = os.path.join(temp_dir, filename)
    urllib.request.urlretrieve(download_url, downloaded_filename)
    if os.path.exists(downloaded_filename):
        file_size = os.path.getsize(downloaded_filename)
        if file_size == 0:
            raise exception.TestCaseFailure(f"Saved file {downloaded_filename}, from URL {download_url} is 0 bytes."
                                            f" please re-check the URL {download_url}")
        if file_size < 300:  # (bytes) No URL Found download page size 288
            with open(downloaded_filename, 'r') as file_read:
                resp = file_read.read()
                if f'URL was not found' in resp:
                    raise exception.TestCaseFailure(f"Incorrect URL {download_url} provided")
    else:
        raise exception.TestCaseFailure(f"Incorrect URL {download_url} provided")
    return downloaded_filename


def files_from_url(url):
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        links = soup.find_all('a')
        for link in links:
            href = link.get('href')
        return href
