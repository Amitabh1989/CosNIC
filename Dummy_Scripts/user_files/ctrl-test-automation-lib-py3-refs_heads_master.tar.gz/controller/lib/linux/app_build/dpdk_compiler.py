import datetime
import logging
import re
import time
import os
import shutil
import traceback

from controller.lib.core import exception
from distutils.spawn import find_executable
from controller.lib.common.shell import exe
from pathlib import Path

log = logging.getLogger(__name__)


def compile_dpdk(src_file, app_id, rings=None, dmax_ethport=None):
    """
    This method is used to compile DPDK application with given app ID on specified host
    :param src_file: DPDK driver file path, tar file
    :param app_id: APP_ID with which DPDK needs to be compiled
    :param rings: Number of rings with which DPDK needs to be compiled
    :param: dmax_ethport: dmax ethports with witch DPDK needs to be compiled
    :return: RTE_SDK and RTE_TARGET path where DPDK is compiled
    """
    tar_path = find_executable('tar')
    meson_path = find_executable('meson')
    ninja_path = find_executable('ninja')
    if not tar_path:
        raise exception.ConfigException(f"tar not found... Please check if tar is installed")
    if not meson_path:
        raise exception.ConfigException(f"meson not found... Please check if meson is installed")
    if not ninja_path:
        raise exception.ConfigException(f"ninja not found... Please check if ninja is installed")
    timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d-%H-%M-%S-%f')
    dpdk_dir = '/tmp/dpdk-%s' % timestamp
    os.mkdir(dpdk_dir)
    exe.block_run(f'{tar_path} -xvzf ' + src_file, cwd=dpdk_dir)
    dpdk_path = dpdk_dir + '/' + src_file.split('/')[-1].replace('.tar.gz', '')
    dpdk_version = src_file.split('-')[1]
    path = Path(src_file)
    shutil.rmtree(path.parent.absolute())
    if rings:
        if not (dpdk_version.startswith('17') or dpdk_version.startswith('19')):
            filename = dpdk_path + '/config/rte_config.h'
            file = open(filename, 'r')
            data = file.readlines()
            file.close()

            for idx, line in enumerate(data):
                if 'RTE_ETHDEV_QUEUE_STAT_CNTRS' in line:
                    data[idx] = re.sub('#define RTE_ETHDEV_QUEUE_STAT_CNTRS(.*)',
                                       '#define RTE_ETHDEV_QUEUE_STAT_CNTRS %s' % rings, line)
        else:
            filename = dpdk_path + '/config/common_base'
            file = open(filename, 'r')
            data = file.readlines()
            file.close()

            for idx, line in enumerate(data):
                if 'CONFIG_RTE_ETHDEV_QUEUE_STAT_CNTRS' in line:
                    data[idx] = re.sub('CONFIG_RTE_ETHDEV_QUEUE_STAT_CNTRS=(\d+)',
                                       'CONFIG_RTE_ETHDEV_QUEUE_STAT_CNTRS=%s' % rings, line)

        file = open(filename, 'w')
        file.writelines(data)
        file.close()
    try:
        if dpdk_version.startswith('17') or dpdk_version.startswith('19'):
            install_dir = 'x86_64-native-linuxapp-gcc'
            cmd = f'make -j 10 install RTE_SDK={dpdk_path} T={install_dir} ' \
                  f'DESTDIR={dpdk_path}/installdir-{install_dir} ' \
                  f'EXTRA_CFLAGS="-Dbnxt_tf_template={app_id}" CONFIG_RTE_LIBRTE_BNXT_TF_TEMPLATE={app_id}'
            exe.block_run(cmd, cwd=dpdk_path, shell=True)
            rte_sdk = dpdk_path + '/'
            rte_target = rte_sdk + f'{install_dir}/'
        else:
            rte_sdk = dpdk_path + '/'
            rte_target = dpdk_path + '/dpdk-build/'
            param_list = f"-Dbnxt_tf_template={app_id} "
            if dmax_ethport:
                param_list = param_list + f"-Dmax_ethports={dmax_ethport} "
            exe.block_run(f'{meson_path} {param_list} dpdk-build', cwd=dpdk_path)
            exe.block_run(f'{ninja_path} -C dpdk-build', cwd=dpdk_path)
            # check and verify compiled dpdk app_id
            output = exe.block_run(f"cat {dpdk_path}/dpdk-build/meson-logs/meson-log.txt", silent=True)
            compiled_version = re.findall('bnxt_tf_template=([\w]+)', output)
            if compiled_version[0] == app_id:
                log.info(f"DPDK compilation succeeded")
            else:
                raise exception.TestCaseFailure(
                    f"DPDK compiled with {compiled_version} app id while expected was {app_id}")
    except Exception:
        log.error(traceback.format_exc())
        raise exception.TestCaseFailure(f"DPDK compilation failed")
    return rte_sdk, rte_target
