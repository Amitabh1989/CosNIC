"""
:mod:`compiler` -- For HP Linpack utility
===============================================

.. module:: controller.lib.linux.app_build.hp_linpack
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import fileinput
import logging
import os
import pathlib
import platform
import re
import shutil
import sys

from controller.lib.core import exception
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


class HPLinPack(app_build.Make):

    def __init__(self, src_file):
        super().__init__(src_file)
        self.prefix = None
        self.hpl_bin = None
        self.hpl_dat = None

    @property
    def platform_arch(self):
        return platform.machine()

    def create_makefile(self, mpi_install_path, blas_install_path, rocm_path='/opt/rocm'):
        dst = pathlib.Path(self.src_dir, f'Make.{self.platform_arch}')
        shutil.copyfile(pathlib.Path(self.src_dir, 'setup/Make.Linux_PII_CBLAS'), dst)
        # mpi_install_path =
        for line in fileinput.input(dst, inplace=True):
            if re.match(r'ARCH\s+=', line):
                sys.stdout.write(f'ARCH  =  {self.platform_arch}')

            if re.match(r'TOPdir\s+=', line):
                sys.stdout.write(f'TOPdir  =  {self.src_dir}')

            if re.match(r'MPdir\s+=', line):
                sys.stdout.write(f'MPdir  =  {mpi_install_path}')

            if re.match(r'MPinc\s+=', line):
                sys.stdout.write(f'MPinc  =  ')

            if re.match(r'MPlib\s+=', line):
                if pathlib.Path(mpi_install_path, '/lib/libmpich.a').exists():
                    sys.stdout.write(f'MPlib  =  ')
                else:
                    libmpi_path = f'{mpi_install_path}/lib/libmpi.so'
                    os.environ['LD_LIBRARY_PATH'] = f'{libmpi_path}/$LD_LIBRARY_PATH'
                    sys.stdout.write(f'MPlib  =  {libmpi_path}')

            if re.match(r'LAdir\s+=', line):
                sys.stdout.write(f'LAdir  =  {blas_install_path}')

            if re.match(r'LAinc\s+=', line):
                sys.stdout.write(f'LAinc  =  ')

            if re.match(r'LAlib\s+=', line):
                sys.stdout.write(f'LAlib  =  {blas_install_path}/lib/libopenblas.a')

            if re.match(r'CC\s+=', line):
                sys.stdout.write(f'CC  =  {mpi_install_path}/bin/mpicc')

            if re.match(r'LINKER\s+=', line):
                sys.stdout.write(f'LINKER  =  {mpi_install_path}/bin/mpicc')

            if re.match(r'ROCM_PATH\s+=', line):
                sys.stdout.write(f'ROCM_PATH  =  {rocm_path}')

            if re.match(r'ROCM_INC\s+=', line):
                sys.stdout.write(f'ROCM_INC  =  {rocm_path}/include')

            if re.match(r'ROCM_LIB\s+=', line):
                sys.stdout.write(f'ROCM_LIB  =  {rocm_path}/lib')

            if re.match(r'HPL_DEFS\s+=', line):
                sys.stdout.write(f'HPL_DEFS  =  $(F2CDEFS) $(HPL_OPTS) $(HPL_INCLUDES) -DHPL_USE_ROCM')

    def verify_installation(self):
        self.hpl_bin = pathlib.Path(self.src_dir, f'bin/{self.platform_arch}/xhpl')
        self.hpl_dat = pathlib.Path(self.src_dir, f'bin/{self.platform_arch}/HPL.dat')

        if self.hpl_bin.exists():
            log.info(f'HP Linpack compilation is completed successfully and the path is {self.hpl_bin.as_posix()}')
        else:
            log.error(f'HP Linpack compilation is NOT successful')

        if self.hpl_dat.exists():
            log.info(f'HPL.dat is created and and the path is {self.hpl_dat.as_posix()}')
        else:
            log.error(f'HPL.dat is NOT created')

        if not (self.hpl_bin.exists() and self.hpl_dat.exists()):
            raise exception.NotFoundException(
                f'HP Linpack compliation is failed and xphl and HPL.dat file are NOT created')


def download(ver, url='https://www.netlib.org/benchmark/hpl/'):
    filename = f'hpl-{ver}.tar.gz'
    hpl_url = f'{url}{filename}'
    hpl_src_file = app_build.url_download(hpl_url)
    return hpl_src_file


def install(src_file, mpi_install_path, blas_install_path, rocm_path='/opt/rocm', verify_installation=True):
    hplinpack_ = HPLinPack(src_file)
    hplinpack_.create_makefile(mpi_install_path, blas_install_path, rocm_path=rocm_path)
    opts = f'arch={hplinpack_.platform_arch}'
    hplinpack_.make(opts=opts)
    if verify_installation:
        hplinpack_.verify_installation()

    return hplinpack_
