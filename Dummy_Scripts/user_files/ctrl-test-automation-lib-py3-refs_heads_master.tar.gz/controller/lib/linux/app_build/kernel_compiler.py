"""
:mod:`compiler` -- wrapper for make utility
===============================================

.. module:: controller.lib.common.system.compiler
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import logging
import os
import platform

from controller.lib.common.shell import exe
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


class BuildKernel(app_build.Make):
    def __init__(self, src_file):
        super().__init__(src_file)
        self.untar_dir_prefix = 'Kernel'
        self.signing_key_path = 'certs/signing_key.pem'
        self.genkey_config_path = 'certs/default_x509.genkey'

    def make_defconfig(self):
        return self.make('defconfig')

    def generate_pem(self, genkey_config_path=None, signing_key_path=None):
        """
        openssl req -new -nodes -utf8 -sha512 -days 36500 -batch -x509
        -config certs/x509.genkey -outform PEM -out certs/signing_key.pem -keyout certs/signing_key.pem
        """
        log.info('Generating signing key pem file')
        self.signing_key_path = signing_key_path or self.signing_key_path
        self.genkey_config_path = genkey_config_path or self.genkey_config_path
        command = f'openssl req -new -nodes -utf8 -sha512 -days 36500 -batch -x509 ' \
                  f'-config {self.genkey_config_path} -outform PEM -out {self.signing_key_path} ' \
                  f'-keyout {self.signing_key_path}'
        log.info(command)
        return exe.block_run(command, cwd=self.src_dir)

    def configure(self, **cfgs):
        if 'CONFIG_MODULE_SIG_KEY' not in cfgs:
            self.generate_pem()
            cfgs['CONFIG_MODULE_SIG_KEY'] = f"\'{self.signing_key_path}\'"

        config_exe = os.path.join(self.src_dir, 'scripts/config')
        config_file = os.path.join(self.src_dir, '.config')
        if os.path.isfile(config_exe):
            for var, val in cfgs.items():
                command = f'{config_exe} --set-val {var} {val}'
                exe.block_run(command, cwd=self.src_dir)
        elif os.path.isfile(config_file):
            with open(config_file, 'a') as fd:
                for var, val in cfgs.items():
                    fd.write(f'{var}={val}\n')
        else:
            log.warning(f'Make configuration is not updated')

    def compile(self, opts=None):
        if opts is None:
            opts = ['-j16', '-j16 modules', 'modules_install']
        opts = opts if isinstance(opts, list) else [opts]
        for opt in opts:
            self.make(opt)

    def update_grub(self):
        """
        Updates grub config
        """
        log.info(f'Update grub configuration')
        kernel_ver = platform.release()
        command = f'grubby --update-kernel=/boot/vmlinuz-{kernel_ver} --args="kmemleak=on"'
        return exe.block_run(command)
