"""
:mod:`compiler` -- For nccl supported utility
===============================================

.. module:: controller.lib.linux.app_build.nccl_support
.. moduleauthor:: Charan Kumar A M <charan.kumar-a-m@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import logging
import os

from controller.lib.common.shell import exe
from controller.lib.linux import app_build
from controller.lib.core import exception

log = logging.getLogger(__name__)


class NcclTests(app_build.Make):
    """
    This class defines method to compile and install Nccl Test suite
    """

    def __init__(self, src_file):
        super().__init__(src_file)
        self.prefix = None

    def get_prefix(self, with_mpi):
        """
        This method will build path to compile and returns the path
        @param  : with_mpi, string type
        """
        customer_dir = 'NVIDIA/'
        mpi_dir = 'mpi/' if with_mpi else ''
        nccl_test_dir = 'nccl'
        nccl_test_compile_path = f'/home/{customer_dir}{mpi_dir}{nccl_test_dir}'
        return nccl_test_compile_path

    def compile(self, with_cuda=None, nccl_test_compile_path=None, with_mpi=None, **kwargs):
        """
        methods defines compilation for nccl test suite
        @with_cude : string type , passes cuda installed path
        @with_mpi : string type , passes mpi installed path
        Example to compile :
        make CUDA_HOME=/usr/local/cuda NCCL_HOME=/home/MPI/install/nccl MPI=1 MPI_HOME=/home/MPI/install/mpi/
        """
        self.prefix = nccl_test_compile_path or self.get_prefix(with_mpi)
        opts = [f'CUDA_HOME={with_cuda}' if with_cuda else '',
                f'NCCL_HOME={self.prefix}' if self.prefix else '',
                f'MPI=1'
                f'MPI_HOME={with_mpi}' if with_mpi else '']

        kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
        opts_str = ' '.join(opts + kwargs_opts)
        exe.block_run(f'make {opts_str}', cwd=self.src_dir)
        return self.prefix


def download_nccl_tests(ver, url='https://github.com/NVIDIA/nccl-tests/archive/refs/tags/'):
    """
    methods defines download for nccl-test based on version provide by user
    @ver : string type , nccl-test version
    @url : string type , GitHub url for nccl-tests
    """
    filename = f'v{ver}.tar.gz'
    nccl_tests_url = f'{url}/{filename}'
    nccl_tests_file = app_build.url_download(nccl_tests_url)
    return nccl_tests_file


def rpm_deb_install(file_type, file_dir):
    if file_type.endswith('.rpm'):
        exe.block_run(f'yum install {file_type} -y', cwd=file_dir)
    elif file_type.endswith('.deb'):
        exe.block_run(f'dpkg -i {file_type}', cwd=file_dir)
    else:
        raise exception.ConfigException(
            f'currently supporting nccl library installation for Rhel and ubuntu OS only')


def nccl_lib_install(src_dir):
    """
    defines method to Install NCCL Repository
    @src_dir : string type, user passed directory where rpm / deb files for nccl library is downloaded
    """
    # Install NCCL Repository RPMs
    # fetching nccl files from user directory eg:nccl-local-repo-rhel9-2.21.5-cuda12.4-1.0-1.x86_64.rpm
    nccl_repo = os.listdir(src_dir)
    for repo in nccl_repo:
        if repo.startswith('nccl-local-repo'):
            rpm_deb_install(repo, src_dir)

    # fetching libnccl files from /var/'nccl-repo'/ eg:libnccl-2.21.5-1+cuda12.4.x86_64.rpm
    var_files = os.listdir('/var/')
    for items in var_files:
        if items.startswith('nccl-local-repo'):
            nccl_files = os.listdir(f'/var/{items}/')
            for files in nccl_files:
                if files.startswith('libnccl'):
                    rpm_deb_install(files, f'/var/{items}/')

