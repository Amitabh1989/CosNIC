"""
:mod:`compiler` -- For openBLAS utility
===============================================

.. module:: controller.lib.linux.app_build.open_blas
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import logging

from controller.lib.common.shell import exe
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


class OpenBLAS(app_build.Make):

    def __init__(self, src_file):
        super().__init__(src_file)
        self.prefix = self.get_prefix()

    def get_prefix(self):
        open_blas_dir = 'OpenBLAS/'
        version = exe.block_run(r"grep -E '^\s*VERSION\s*=\s*' Makefile.rule", cwd=self.src_dir).split('=')[-1].strip()
        version_dir = f'{version}/' if version else ''
        prefix = f'/home/{open_blas_dir}{version_dir}'
        return prefix

    def make(self, fc='gfortran', opts=None):
        opts = opts if isinstance(opts, list) else ([opts] if opts is not None else [])
        if fc is not None:
            opts = opts.append(f'FC={fc}')
        super().make(opts=opts)

    def install(self, prefix=None, opts=None, jobs=None):
        opts = opts if isinstance(opts, list) else ([opts] if opts else [])
        opts.append(f'PREFIX={prefix or self.prefix}')
        super().install(opts=opts, jobs=jobs)


def download(ver, url='https://github.com/OpenMathLib/OpenBLAS/releases/download/'):
    rel_dir = f'v{ver}/'
    filename = f'OpenBLAS-{ver}.tar.gz'
    open_blas_url = f'{url}{rel_dir}{filename}'
    open_blas_src_file = app_build.url_download(open_blas_url)
    return open_blas_src_file


def install(src_file, prefix=None, fc='gfortran'):
    open_blas_ = OpenBLAS(src_file)
    open_blas_.make(fc=fc)
    open_blas_.install(prefix)
    return open_blas_.prefix
