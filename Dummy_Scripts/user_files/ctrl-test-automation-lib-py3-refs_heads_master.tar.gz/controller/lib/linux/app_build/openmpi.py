"""
:mod:`compiler` -- For openMPI utility
===============================================

.. module:: controller.lib.linux.app_build.openmpi
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import logging
import tempfile

from controller.lib.common.shell import exe
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


class BuildOpenMpi(app_build.Make):

    def __init__(self, src_file):
        super().__init__(src_file)
        self.prefix = None

    def get_prefix(self, with_ucx, with_cuda, enable_mca_no_build):
        customer_dir = 'NVIDIA/' if with_cuda else ('AMD/' if enable_mca_no_build else '')
        ucx_dir = 'ucx/' if with_ucx else ''
        version = exe.block_run(f'grep repo_rev= VERSION', cwd=self.src_dir).split('=')[-1].strip()
        version_dir = f'{version}/' if version else ''
        prefix = f'/home/{customer_dir}{ucx_dir}{version_dir}'
        return prefix

    def configure(self, prefix=None, with_ucx=None, with_cuda=None, enable_static=True, enable_openib_udcm='disabled',
                  enable_openib_rdmacm='enabled', enable_orterun_prefix_by_default=True, enable_mca_no_build=None,
                  **kwargs):
        """
        Example to compile with ucx:
        ./configure --prefix=/opt/Rahul/install/mpi --with-ucx=/opt/Rahul/install/ucx/
        --enable-static --enable-openib-udcm=disabled --enable-openib-rdmacm=enabled --enable-orterun-prefix-by-default
        """
        self.prefix = prefix or self.get_prefix(with_ucx, with_cuda, enable_mca_no_build)
        opts = [f'--prefix={self.prefix}' if self.prefix else '',
                f'--with-ucx={with_ucx}' if with_ucx else '',
                f'--with-cuda={with_cuda}' if with_cuda else '',
                f'--enable-static' if enable_static else '',
                f'--enable_openib_udcm={enable_openib_udcm}' if enable_openib_udcm else '',
                f'--enable_openib_rdmacm={enable_openib_rdmacm}' if enable_openib_rdmacm else '',
                f'--enable_orterun_prefix_by_default' if enable_orterun_prefix_by_default else '',
                f'--enable-mca-no-build={enable_mca_no_build}' if enable_mca_no_build else '']
        kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
        opts_str = ' '.join(opts + kwargs_opts)
        exe.block_run(f'./configure {opts_str}', cwd=self.src_dir)
        return self.prefix

    def ldconfig(self):
        exe.block_run('ldconfig -v', cwd=self.src_dir)


def download(ver, url='https://download.open-mpi.org/release/open-mpi/'):
    temp_dir = tempfile.mkdtemp()
    series = '.'.join(ver.split('.')[:2])
    filename = f'openmpi-{ver}.tar.gz'
    openmpi_url = f'{url}v{series}/{filename}'
    openmpi_src_file = app_build.url_download(openmpi_url)
    return openmpi_src_file


def install(src_file, prefix=None, with_ucx=None, with_cuda=None, enable_static=True,
            enable_openib_udcm='disabled', enable_openib_rdmacm='enabled',
            enable_orterun_prefix_by_default=True, enable_mca_no_build=None, **kwargs):
    openmpi_ = BuildOpenMpi(src_file)
    prefix = openmpi_.configure(prefix=prefix, with_ucx=with_ucx, with_cuda=with_cuda, enable_static=enable_static,
                                enable_openib_udcm=enable_openib_udcm, enable_openib_rdmacm=enable_openib_rdmacm,
                                enable_orterun_prefix_by_default=enable_orterun_prefix_by_default,
                                enable_mca_no_build=enable_mca_no_build, **kwargs)
    openmpi_.make()
    openmpi_.install(jobs=16)
    openmpi_.ldconfig()
    return prefix
