"""
:mod:`compiler` -- For OSUBenchmark and Gdrcopy utility
===============================================

.. module:: controller.lib.linux.app_build.osubenchmarks
.. moduleauthor:: Charan Kumar A M <charan.kumar-a-m@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import logging

from controller.lib.common.shell import exe
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


class BuildOsuBenchmark(app_build.Make):

    def __init__(self, src_file):
        super().__init__(src_file)

    def configure(self, with_cuda=False, with_rocm=None, with_openmpi=None, enable_rocm=True, enable_cuda=True,
                  LD_FLAGS=None, CPPFLAGS=None, **kwargs):
        """
        Example to compile with rocm:
        ./configure CC=/home/dell/ompi/ompi_install/bin/mpicc CXX=/home/dell/ompi/ompi_install/bin/mpicxx
        --enable-rocm  --with-rocm=/opt/rocm LD_FLAGS=-D__HIP_PLATFORM_AMD__ CPPFLAGS=-D__HIP_PLATFORM_AMD__

        Example to compile with cuda:
        ./configure CC=/opt/MPI/install/mpi/bin/mpicc CXX=/opt/MPI/install/mpi/bin/mpicxx
        --enable-cuda --with-cuda-include=/usr/local/cuda/include/ --with-cuda-libpath=/usr/local/cuda/lib64
        """

        if with_rocm:  # AMD
            opts = [f'CC={with_openmpi}/bin/mpicc' if with_openmpi else '',
                    f'CXX={with_openmpi}/bin/mpicxx' if with_openmpi else '',
                    f'--enable-rocm' if enable_rocm else '',
                    f'--with-rocm={with_rocm}' if with_rocm else '',
                    f'LD_FLAGS={LD_FLAGS}' if LD_FLAGS else '',
                    f'CPPFLAGS={CPPFLAGS}' if CPPFLAGS else '']
            kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
            opts_str = ' '.join(opts + kwargs_opts)
            log.debug(f'opts_str : {opts_str}')

            exe.block_run(f'export PATH=$PATH:{with_rocm}/bin', shell=True)
            exe.block_run(f'./configure {opts_str}', cwd=self.src_dir)

        else:  # NVIDIA
            opts = [f'CC={with_openmpi}' if with_openmpi else '',
                    f'CXX={with_openmpi}' if with_openmpi else '',
                    f'--enable-cuda' if enable_cuda else '',
                    f'--with-cuda-include={with_cuda}/include/' if with_cuda else '',
                    f'--with-cuda-libpath={with_cuda}/lib64' if with_cuda else '']
            kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
            opts_str = ' '.join(opts + kwargs_opts)
            log.info(f'opts_str : {opts_str}')

            exe.block_run(f'export PATH=$PATH:{with_cuda}/bin/', shell=True)
            exe.block_run(f'./configure {opts_str}', cwd=self.src_dir)


def download_osu(ver, base_url='ftp://10.123.28.75/EC/Controller_Automation_GA/tools/'):
    filename = f'osu-micro-benchmarks-{ver}.tar.gz'
    osu_url = f'{base_url}/{filename}'
    osu_file = app_build.url_download(osu_url)
    return osu_file


def osu_install(src_file, with_cuda=False, with_rocm=None, with_openmpi=None, enable_rocm=True, enable_cuda=True,
                LD_FLAGS=None, CPPFLAGS=None, **kwargs):
    osu_ = BuildOsuBenchmark(src_file)
    osu_.configure(with_cuda=with_cuda, with_rocm=with_rocm, with_openmpi=with_openmpi, enable_rocm=enable_rocm,
                   enable_cuda=enable_cuda, LD_FLAGS=LD_FLAGS, CPPFLAGS=CPPFLAGS, **kwargs)
    osu_.install(jobs=16)


class BuildGdrcopy(app_build.Make):

    def __init__(self, src_file):
        super().__init__(src_file)
        self.prefix = None

    def get_prefix(self, with_mpi):
        customer_dir = 'NVIDIA/'
        mpi_dir = 'mpi/' if with_mpi else ''
        gdr_dir = 'gdrcopy/'
        prefix = f'/home/{customer_dir}{mpi_dir}{gdr_dir}'
        return prefix

    def compile(self, prefix=None, with_mpi=None, with_cuda=None, **kwargs):
        """
        Example to compile :
        make PREFIX=/opt/MPI/install/gdrcopy/ CUDA=/usr/local/cuda/ all install
        """
        self.prefix = prefix or self.get_prefix(with_mpi)
        opts = [f'PREFIX={self.prefix}' if self.prefix else '',
                f'CUDA={with_cuda}' if with_cuda else '']

        kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
        opts_str = ' '.join(opts + kwargs_opts)
        exe.block_run(f'make {opts_str} all install', cwd=self.src_dir)
        return self.prefix

    def insmod(self):
        exe.block_run('./insmod.sh', cwd=self.src_dir, shell=True)


def gdrcopy_install(src_file, prefix=None, with_mpi=None, with_cuda=None, **kwargs):
    gdrcopy_ = BuildGdrcopy(src_file)
    gdrcopy_.compile(prefix=prefix, with_mpi=with_mpi, with_cuda=with_cuda, **kwargs)
    gdrcopy_.insmod()
    return gdrcopy_.prefix


def download_gdrcopy(ver, url='https://github.com/NVIDIA/gdrcopy/archive/refs/tags/'):
    filename = f'v{ver}.tar.gz'
    gdrcopy_url = f'{url}/{filename}'
    gdrcopy_file = app_build.url_download(gdrcopy_url)
    return gdrcopy_file
