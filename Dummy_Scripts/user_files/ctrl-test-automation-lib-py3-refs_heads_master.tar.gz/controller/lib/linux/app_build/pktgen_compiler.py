import os
import pathlib
from distutils.spawn import find_executable

from controller.lib.linux import app_build
from controller.lib.common.shell import exe

class dpdk_pktgen_complier(object):

    def __init__(self, src_file, pkg_config_path=None):
        self.tar_file_path = src_file
        self.__untarred_dir_path = None
        self.pkg_config_path = pkg_config_path or '/usr/local/lib64/pkgconfig/'

    @property
    def untarred_dir_path(self):
        if self.__untarred_dir_path is None:
            maker = app_build.Make(self.tar_file_path)
            self.__untarred_dir_path = maker.untar()
        return self.__untarred_dir_path

    def compile_dpdk_pktgen(self):
        meson_path = find_executable('meson')
        ninja_path = find_executable('ninja')
        env = os.environ.copy()
        env['PKG_CONFIG_PATH'] = self.pkg_config_path
        exe.block_run(f'{meson_path} build', cwd=self.untarred_dir_path, env=env)
        exe.block_run(f'{ninja_path} -C build', cwd=self.untarred_dir_path, env=env)

    @property
    def dpdk_pktgen_bin_path(self):
        return str(pathlib.Path(self.untarred_dir_path).joinpath('build/app/pktgen'))


class bnxt_netmap_compiler(object):
    def __init__(self, src_file, pktgen_relative_path=None, bridge_relative_path=None):
        self.tar_file_path = src_file
        self.__untarred_dir_path = None
        self.pktgen_relative_path = pktgen_relative_path or 'build-apps/pkt-gen/'
        self.bridge_relative_path = bridge_relative_path or 'build-apps/bridge/'

    @property
    def untarred_dir_path(self):
        if self.__untarred_dir_path is None:
            maker = app_build.Make(self.tar_file_path)
            self.__untarred_dir_path = maker.untar()
        return self.__untarred_dir_path

    @property
    def pktgen_dir_path(self):
        return str(pathlib.Path(self.untarred_dir_path).joinpath(self.pktgen_relative_path))

    def compile_bnxt_netmap(self, drivers=None, no_drivers=None):
        drivers = ','.join(drivers) if isinstance(drivers, list) else (drivers or 'bnxt')
        no_drivers = ','.join(no_drivers) if isinstance(no_drivers, list) \
            else (no_drivers or 'virtio_net.c,i40e,ice,ixgbevf,ixgbe,igb,e1000e,e1000,vmxnet3,veth.c,mlx5')

        exe.block_run(f'./configure --drivers={drivers} --no-drivers={no_drivers}',
                                cwd=self.untarred_dir_path)
        maker = app_build.Make(self.untarred_dir_path)
        maker.make()

    def compile_pktgen(self):
        maker = app_build.Make(self.pktgen_dir_path)
        maker.make()

    def install_bnxt_netmap(self):
        self.compile_bnxt_netmap()
        maker = app_build.Make(self.untarred_dir_path)
        maker.install()

    def install_pktgen(self):
        self.compile_pktgen()
        maker = app_build.Make(self.pktgen_dir_path)
        maker.install()

    @property
    def pktgen_bin_path(self):
        return str(pathlib.Path(self.untarred_dir_path).joinpath('build/pkt-gen'))

    @property
    def bridge_dir_path(self):
        return str(pathlib.Path(self.untarred_dir_path).joinpath(self.bridge_relative_path))

    def compile_bridge(self):
        maker = app_build.Make(self.bridge_dir_path)
        maker.make()

    def install_bridge(self):
        self.compile_bridge()
        maker = app_build.Make(self.bridge_dir_path)
        maker.install()

    @property
    def bridge_bin_path(self):
        return str(pathlib.Path(self.untarred_dir_path).joinpath('build/bridge'))
