"""
:mod:`compiler` -- wrapper for rocm installation
===============================================

.. module:: controller.lib.linux.app_build.rocm_compiler
.. moduleauthor:: Charan Kumar A M <charan.kumar-a-m@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import logging
import os
import distro

from controller.lib.core import exception
from controller.lib.common.shell import exe
from distutils.spawn import find_executable
from controller.lib.linux.driver import install as src_install
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


def rocm_download(base_url='https://repo.radeon.com/amdgpu-install', ver=None):
    os_name = distro.id()
    version_id = distro.version()
    if 'rhel' in os_name:
        url = f'{base_url}/{ver}/rhel/{version_id}/'
    elif 'sles' in os_name:
        url = f'{base_url}/{ver}/sle/{version_id}/'
    elif 'ubuntu' in os_name:
        url = f'{base_url}/{ver}/ubuntu/jammy/'

    file_pattern = app_build.files_from_url(url)
    rocm_pkg_path = os.path.join(url, file_pattern)

    # download
    rocm_path = app_build.url_download(rocm_pkg_path)
    return rocm_path


def verify_rocm_installation():
    rocm_smi_patch = find_executable('rocm-smi')
    if rocm_smi_patch is None:
        raise exception.ConfigException('rocm-smi is not available')

    exe.block_run(f'modprobe amdgpu')

    output = exe.block_run(f'{rocm_smi_patch} --showhw')
    if "ROCm System Management Interface" in output:
        log.info(f'rocm is installed succesfully')
    else:
        raise exception.ConfigException(f'rocm is not installed properly {output}')


def rocm_installer(src_file):
    """
    defines rocm installation module used for gpu test environment
    @src_file : string, provide rpm/deb file directory
    """

    """Note: rocm-llvm installation is time consuming, 
    suggestion is to install dependency and later start installation 
    i.e  yum install rocm-llvm*  """

    # unbind rpm or deb file
    installObj = src_install.get_object(src_file)
    installObj.install()

    # install via amdgpg-install
    amdgpu_path = find_executable('amdgpu-install')
    if amdgpu_path is None:
        raise exception.ConfigException('amdgpu-install is not available')

    exe.block_run(f'{amdgpu_path} --usecase=rocm,hip,dkms -y')
