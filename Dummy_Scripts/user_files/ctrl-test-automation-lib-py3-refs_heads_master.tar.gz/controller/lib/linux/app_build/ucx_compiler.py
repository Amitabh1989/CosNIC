"""
:mod:`compiler` -- wrapper for UCX installation
===============================================

.. module:: controller.lib.linux.app_build.ucx_compiler
.. moduleauthor:: Subrahmanya Bhat <subrahmanya.bhat@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import logging
import os

from controller.lib.core import exception
from controller.lib.common.shell import exe
from controller.lib.linux import app_build

log = logging.getLogger(__name__)


class ucx_complier(app_build.Make):
    def __init__(self, src_file):
        super().__init__(src_file)
        self.tar_file_path = src_file
        self.ucx_dir = self.src_dir  # self.src_dir will call app_build->__init__.py
        self.prefix = None

    def get_prefix(self, with_cuda, with_rcom):
        customer_dir = 'NVIDIA/' if with_cuda else ('AMD/' if with_rcom else '')
        version = self.version
        version_dir = f'{version}/' if version else ''
        prefix = f'/home/ucx/{customer_dir}{version_dir}'
        return prefix

    @property
    def version(self):
        """
        This method is used to find ucx version
        :return: ucx_version
        """
        ver = exe.block_run('git describe --tags --always', cwd=self.ucx_dir, shell=True)
        return ver

    def configure(self, prefix=None, with_cuda=None, with_rcom=None, with_gdrcopy=None, with_rc=True, with_ud=True,
                  with_dc=True, with_dm=True, with_ib_hw_tm=True, disable_log=True,
                  disable_debug=True, disable_assertions=True, disable_params_check=True, **kwargs):
        """
        This method is used to configure UCX application.
        :return: install path for the ucx
        """
        self.prefix = prefix or self.get_prefix(with_cuda, with_rcom)
        if not os.path.exists(self.ucx_dir + '/config'):
            raise exception.TestCaseFailure("error")
        if with_rcom:  # AMD
            opts = (f'--prefix={self.prefix}' if self.prefix else '',
                    f'--disable-debug' if disable_debug else '',
                    f'--disable-assertions' if disable_assertions else '',
                    f'--disable-params-check' if disable_params_check else '',
                    f'--with-rocm={with_rcom}' if with_rcom else '',
                    f'--with-rc' if with_rc else '',
                    f'--with-ud' if with_ud else '',
                    f'--with-dc' if with_dc else '',
                    f'--with-dm' if with_dm else '',
                    f'--with-ib-hw-tm' if with_ib_hw_tm else '',
                    f'--disable-log' if disable_log else '')
            kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
            opts_str = ' '.join(opts + kwargs_opts)

            exe.block_run('sh autogen.sh', cwd=self.ucx_dir, shell=True)
            exe.block_run(f'./configure-release {opts_str}', cwd=self.ucx_dir+'/contrib/')
        else:  # NVIDIA
            opts = (f'--prefix={self.prefix}' if self.prefix else '',
                    f'--with-cuda={with_cuda}' if with_cuda else '',
                    f'--with-gdrcopy={with_gdrcopy}' if with_gdrcopy else '')
            kwargs_opts = [f'--{k}={v}' if v else f'--{k}' for k, v in kwargs]
            opts_str = ' '.join(opts + kwargs_opts)

            exe.block_run('sh autogen.sh', cwd=self.ucx_dir, shell=True)
            exe.block_run(f'./configure {opts_str}', cwd=self.ucx_dir)

        return self.prefix

    def install(src_file, prefix=None, with_cuda=None, with_rcom=None, with_gdrcopy=None, with_rc=True, with_ud=True,
                  with_dc=True, with_dm=True, with_ib_hw_tm=True, disable_log=True,
                  disable_debug=True, disable_assertions=True, disable_params_check=True, **kwargs):
        """
        This method is used to compile ucx
        :return: installed path of the ucx
        """
        ucx_ = ucx_complier(src_file)
        ucx_install_path = ucx_.configure(prefix=prefix, with_cuda=with_cuda, with_rcom=with_rcom, with_rc=with_rc,
                                          with_gdrcopy=with_gdrcopy, with_ud=with_ud, with_dc=with_dc, with_dm=with_dm,
                                          with_ib_hw_tm=with_ib_hw_tm, disable_log=disable_log,
                                          disable_debug=disable_debug, disable_assertions=disable_assertions,
                                          disable_params_check=disable_params_check, **kwargs)
        return ucx_install_path
