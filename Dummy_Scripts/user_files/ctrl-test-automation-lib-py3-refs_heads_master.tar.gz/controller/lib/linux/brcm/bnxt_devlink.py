"""
:mod:`bnxt_devlink` -- bnxt_devlink wrapper library.
====================================================
.. module:: controller.lib.linux.brcm.bnxt_devlink
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for devlink.
"""
import re
import logging

from controller.lib.common.shell import exe
from controller.lib.linux.system import ssh

log = logging.getLogger(__name__)

class BnxtDevlink():
    """
    The class that implements the bnxt_devlink command.
    """
    def __init__(self, **kwargs):
        """
        The BnxtDevlink constructor.
        """
        self.__exe = exe

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the bnxt_devlink command. If
        ssh_ip_address is specified, an SSH connection to that IP adress is established and that
        connection is used to run the bnxt_devlink command. Otherwise, the usual shell exe module is
        used.

        Args:
            ssh_ip_addr (str): The IP address to use for running bnxt_devlink command over SSH.
            When None, the SSH mode is exited.
        """
        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def inject_error(self, **kwargs):
        """
        The method that injects error into the firmware.
        """
        time = kwargs.get('time', 5)
        iteration = kwargs.get('iteration', 1)
        error_injector = kwargs.get('error_injector', 2)
        command = 'bnxt_devlink -d %s -i %s -e %s' % (time, iteration, error_injector)
        self.__exe.block_run(command)

    def generate_dump(self, **kwargs):
        """
        The method that generates core dump. Optionally, a backup location can be specified
        (in the SSH compliant format: host:path/). It is assumed that the specified host is
        accessible without a password prompt and that the path specified exists on the host.
        Example: 192.168.1.1:/root/nitro_dumps/

        Return:
            dump_file: The path to the dump file created.
        """
        time = kwargs.get('time', 5)
        dump_file = kwargs.get('dump_file', '/tmp/nitro_dump.core')
        iteration = kwargs.get('iteration', 1)
        error_injector = kwargs.get('error_injector', 2)
        backup_location = kwargs.get('backup_location', None)
        command = 'bnxt_devlink -d %s -o %s -i %s -e %s' % \
            (time, dump_file, iteration, error_injector)
        self.__exe.block_run(command)
        # If a backup location is specified, copy the core file to that location.
        if backup_location is not None:
            command = 'scp -o strictHostKeyChecking=no %s root@%s' % (dump_file, backup_location)
            self.__exe.block_run(command)

        return dump_file

    def cleanup_dump(self, dump_file):
        """
        The method that removes the dump file from the disk.

        Args:
            dump_file: The path to the dump file to remove.
        """
        command = 'rm -f %s' % dump_file
        self.__exe.block_run(command)

