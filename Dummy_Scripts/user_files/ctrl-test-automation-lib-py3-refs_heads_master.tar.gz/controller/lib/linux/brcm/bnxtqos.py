"""
:mod:`bnxtqos` -- Library for bnxtqos, the qos configuration utility
==================================================

.. module:: controller.lib.linux.eth.bnxtqos
.. moduleauthor:: Sreeman Ambati <sreeman.ambati@broadcom.com>

"""
import logging
import re
from controller.lib.common.shell import exe
from controller.lib.core import exception

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

log = logging.getLogger(__name__)


class bnxtqos:
    def __init__(self):
        pass

    def set_ets(self, iface,  tsa_map, prio_map, tc_bw_map):
        """
        Set the ets with tsa, prio and bw mapping

        # todo: Enable all queues in tsa_map before setting ets

        Args:
            iface: The interface to set ratelimit.
            tsa_map: TSA configuration details
            prio_map: Prio map setting details
            tc_bw_map: Traffic Class bandwith limits
        """
        if not tsa_map:
            raise exception.ConfigException(
                'Must provide TSA details to configure TSA')
        output = self.get_qos(iface)
        tsa_mapping = re.search(r'TSA_MAP:\s+(.*)', output).group(1)
        new_list = len(re.findall(r'(\d+:)', tsa_mapping))
        if new_list > len(tsa_map):
            for x in range(len(tsa_map), new_list):
                tsa_map[str(x)] = 'strict'
        log.info('Configuring TSA on interface %s to %s' % (iface, tsa_map))

        if not prio_map:
            raise exception.ConfigException(
                'Must provide priority-to-tc mapping details.')

        log.info('Configuring Bandwidth per TC on interface %s to %s' % (iface, prio_map))

        if not tc_bw_map:
            raise exception.ConfigException(
                'Must provide TC Bandwidth details.')

        log.info('Configuring Bandwidth per TC on interface %s to %s' % (iface, tc_bw_map))
        tc_bw_values = []

        for key in sorted(tc_bw_map):
            tc_bw_values.append(tc_bw_map[key])

        tsa_values = []

        for key in sorted(tsa_map):
            tsa_values.append('%s:%s' % (key, tsa_map[key]))

        prio_values = []

        for key in sorted(prio_map):
            prio_values.append('%s:%s' % (key, prio_map[key]))

        exe.block_run('bnxtqos -dev=%s set_ets tsa=%s priority2tc=%s tcbw=%s' % (
            iface,
            ','.join(tsa_values),
            ','.join(prio_values),
            ','.join(tc_bw_values)))

    def set_apptlv(self, iface, priority, header_type='L2', ether_type='RoCE', ether_value=None):
        header = '3' if header_type == 'L3' else '1'

        if ether_type == 'RoCE':
            ether = '4791'
            header = '3'

        elif ether_type == 'dscp':
            ether = ether_value
            header = '5'
        else:
            ether = '12896'

        log.info('Configuring APP TLV on interface %s to priority: %s, header: %s, ether: %s'
                 % (iface, priority, header, ether))
        exe.block_run('bnxtqos -dev=%s set_apptlv app=%s,%s,%s' %
                      (iface, priority, header, ether))

    def set_pfc(self, iface, prios):
        """
        Set the PFC value to interface.

        Args:
            iface: The interface to set PFC value.
            prios: PFC Value to set
        """
        exe.block_run('bnxtqos -dev=%s set_pfc enabled=%s' % (iface, prios))

    def set_ratelimit(self, iface, value):
        """
        Set the TC rate limit of interface.

        Args:
            iface: The interface to set ratelimit.
        """
        return exe.block_run('bnxtqos -dev=%s ratelimit %s' % (iface, value))

    def get_ratelimit(self, iface):
        """
        Get the TC rate limit of interface and return those values.

        Args:
            iface: The interface to get ratelimit info.
        """
        output = exe.block_run('bnxtqos -dev=%s get_qos' % iface)
        rate_limit = re.search(r'TC Rate Limit: (.*)', output).group(1).replace('%', '').split()
        return rate_limit

    def get_qos(self, iface):
        """
        Get the get_qos data of interface.

        Args:
            iface: The interface to get qos.
        """
        return exe.block_run('bnxtqos -dev=%s get_qos' % iface)

    def get_qos(self, iface):
        """
        Get the get_qos data of interface.

        Args:
            iface: The interface to get qos.
        """
        return exe.block_run('bnxtqos -dev=%s get_qos' % iface)

    def dump_pri2cos(self, iface):
        """
        Dump priority to TC to queue mapping on the specified interface.

        Args:
            iface: The interface to get the priority-tc-queue mapping of.
        """
        pri2cos = {}
        command = 'bnxtqos -dev=%s dump pri2cos' % iface
        command_output = exe.block_run(command, shell=True).strip()
        command_output = re.findall(r'(\d+)\s+(\d+)\s+(\d+)', command_output)
        # Build a map of priority to TC, queue.
        for (priority, tc, queue) in command_output:
            pri2cos[priority] = (tc, queue)

        return pri2cos

    def set_map(self, iface, pri2tc_map):
        """
        Set the priority to TC mapping on the specified interface.

        Args:
            iface:
                The interface to set the priority to TC mapping on.
            pri2tc_map:
                The dictionary of priority to TC mapping.
        """
        pri2tc = ''

        for key in sorted(pri2tc_map):
            pri2tc += ',%s:%s' % (key, pri2tc_map[key])

        command = 'bnxtqos -dev=%s set_map priority2tc=%s' % (
            iface, pri2tc[1:])
        exe.block_run(command, shell=True)

    def clear_pfc_config(self, iface):
        """Clear the existing PFC configuration on the specified interface.

        Args:
            iface: The interface to clear the PFC configuration on.
        """
        command = 'bnxtqos -dev=%s get_qos' % iface
        command_output = exe.block_run(command, shell=True)
        pfc_config = re.findall(r'(Priority|Sel|DSCP|UDP or DCCP|Ethertype):\s+(\w+)', command_output)
        tlv = ''
        for key, value in pfc_config:
            value = int(value, 16) if value.lower().startswith('0x') else int(value)
            if key == 'Priority':
                tlv = str(value)
            elif key == 'Sel':
                tlv += ',' + str(value)
            else:
                tlv += ',' + str(value)
                command = 'bnxtqos -dev=%s set_apptlv -d app=%s' % (iface, tlv)
                exe.block_run(command, shell=True)

    def set_bufferpool(self, iface, buffer_mode, option, direc=None, permanent=False):
        """
        Args:
            buffer_mode: buffer_pool
            direc: rx/tx
            option: shared | independent | ecn
            iface: The interface to set buffer pool mode configuration on
            permanent: For permanent configuration
        """
        if permanent:
            command = 'bnxtqos -dev=%s %s %s permanent' % (iface, buffer_mode,  option)
        elif direc != None:
            command = 'bnxtqos -dev=%s %s %s %s' % (iface, buffer_mode, direc, option)
        else:
            command = 'bnxtqos -dev=%s %s %s' % (iface, buffer_mode, option)
        command_output = exe.block_run(command, shell=True)
        return command_output

    def get_bufferpool(self, iface, buffer_mode):
        """
        Args:
            buffer_mode: buffer_pool
            iface: The interface to get buffer pool mode configuration on
        """
        command = 'bnxtqos -dev=%s %s' % (iface, buffer_mode)
        command_output = exe.block_run(command, shell=True)
        return command_output

    def set_tx_ep_limit(self, iface, port_idx=0, ep=None, max_limit=None, permanent=False):
        """
        Set the endpoint  port control on the specified interface.
        Args:
            iface:  The interface name to set endpoint port control
            port_idx: The port index to set the p endpoint  port control on.
            ep: Endpoints list.
            max_limit:  The max limits to set on ep
            permanent: To configure EP permanently or not
               """
        ep_list = ep if isinstance(ep, list) else [ep or 'ep0']
        max_limit_list = max_limit if isinstance(max_limit, list) else [max_limit]
        command = 'bnxtqos -dev=%s tx_endpoint_ratelimit port_idx=%s' % (iface, port_idx)
        command1 = ''
        for endpoint, limit in zip(ep_list, max_limit_list):
            command1 += ' %s max=%s' % (endpoint, limit)

        command += command1
        if permanent:
            command += ' permanent'
        exe.block_run(command, shell=True)

    def set_rx_ep_limit(self, iface, ep=None, max_limit=None, permanent=False):
        """
        Set the endpoint  port control on the specified interface.
        Args:
            iface:  The interface name to set endpoint port control
            ep: Endpoints list.
            max_limit:  The max limits to set on ep
            permanent: To configure EP permanently or not
               """
        ep_list = ep if isinstance(ep, list) else [ep or 'ep0']
        max_limit_list = max_limit if isinstance(max_limit, list) else [max_limit]
        command = 'bnxtqos -dev=%s rx_endpoint_ratelimit' % iface
        command1 = ''
        for endpoint, limit in zip(ep_list, max_limit_list):
            command1 += ' %s max=%s' % (endpoint, limit)
        command += command1
        if permanent:
            command += ' permanent'
        exe.block_run(command, shell=True)

    def get_tx_ep_limit(self, iface, port_idx=0, permanent=False):
        """
        Get the tx ep limit of interface and return those values.

        Args:
            iface: The interface to get  tx ep limit info.
            port_idx: Interface index
            permanent: Configured limit type
        """
        command = 'bnxtqos -dev=%s get_tx_endpoint_ratelimits port_idx=%s' % (iface, port_idx)
        if permanent:
            command += ' permanent'
        output = exe.block_run(command)
        return output

    def set_rx_port_limit(self, iface, max_limit=50, permanent=False):
        """
        Set the port control on the specified interface for rx.
        Args:
            iface:  The interface name to set endpoint port control
            max_limit:  The max  limit to set on port
            permanent: To configure port limit permanently
               """
        command = 'bnxtqos -dev=%s rx_port_ratelimit  max=%s' % (iface, max_limit)
        if permanent:
            command += ' permanent'
        exe.block_run(command, shell=True)

    def get_rx_port_limit(self, iface, permanent=False):
        """
        Get the rx port  limit of interface and return those values.

        Args:
            iface: The interface to get  rx port rate info.
            permanent: Configured limit type
        """
        command = 'bnxtqos -dev=%s get_rx_ratelimits' % iface
        if permanent:
            command += ' permanent'
        output = exe.block_run(command)
        get_value = re.findall(r'\d+', output)
        return get_value

    def set_tx_partition_limit(self, iface, max_limit=50, permanent=False):
        """
        Set the tx partition control on the specified interface for tx.
        Args:
            iface:  The interface name to set endpoint port control
            max_limit:  The max  limit to set on port
            permanent: To configure port limit permanently
               """
        command = 'bnxtqos -dev=%s partition_tx_ratelimit  max=%s' % (iface, max_limit)
        if permanent:
            command += ' permanent'
        exe.block_run(command, shell=True)

    def get_dscp2prio(self, iface):
        """
           Get the dscp2prio of interface and return those values.
           Args:
               iface: The interface to get dscp2prio info.

        """
        command = 'bnxtqos -dev=%s get_dscp2prio' % iface
        output = exe.block_run(command, shell=True)
        dscp2prio_dict = {k: v for k, v in re.findall(r'priority:(\d+)\s+dscp:(\d+)', output)}
        return dscp2prio_dict