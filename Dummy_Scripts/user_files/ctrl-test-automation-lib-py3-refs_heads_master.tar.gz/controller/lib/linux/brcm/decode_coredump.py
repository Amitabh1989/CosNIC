"""
:mod:`decode_coredump` -- Decode the coredump.
==============================================

.. module:: controller.lib.linux.brcm.decode_coredump
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2020 Broadcom Inc"

import logging
import re
import os
import collections
import tempfile

from controller.lib.core import exception
import controller.lib.common.shell.exe as exe

log = logging.getLogger(__name__)


class DecodeCoredump(object):
    def __init__(self, core_path, app_path='/usr/bin/decode_coredump', *args, **kwargs):
        if os.path.exists(core_path) is False:
            raise exception.ConfigException('%s does not exists' % core_path)

        if os.path.exists(app_path) is False:
            raise exception.ConfigException('%s does not exists' % app_path)

        self.__app_path = app_path
        self.__core_path = core_path
        self.__ctxm_summary = {}

    def __get_ctxm_summary(self):
        log.info('Decoding ctxm summary of coredump file: %s' % self.__core_path)
        command = '%s %s ctxm summary' % (self.__app_path, self.__core_path)
        command_output = exe.block_run(command, shell=True, silent=True)

        for line in command_output.split('\n'):
            if '*' in line:
                block_name = re.search(r'\*+(\w+)\*+', line).group(1)
                self.__ctxm_summary[block_name] = None
            elif self.__ctxm_summary[block_name] is None:
                self.__ctxm_summary[block_name] = collections.OrderedDict()
                items = re.findall(r'\s*([a-z]+)\s*', line)

                for item in items:
                    self.__ctxm_summary[block_name][item] = []
            else:
                values = re.findall(r'\s*([a-f0-9]+)[:\s]*', line)

                for item in range(len(values)):
                    self.__ctxm_summary[block_name][items[item]].append(values[item])

        log.debug('ctxm summary: %s' % self.__ctxm_summary)

    def get_block_names(self):
        self.__get_ctxm_summary()
        return list(self.__ctxm_summary.keys())

    def get_item_names(self, block_name):
        self.__get_ctxm_summary()
        return list(self.__ctxm_summary[block_name].keys())

    def get_item_values(self, block_name, item_name):
        self.__get_ctxm_summary()
        return self.__ctxm_summary[block_name][item_name]

    def validate_dump(self):
        command = '%s %s validate' % (self.__app_path, self.__core_path)
        command_output = exe.block_run(command)
        return 'PASSED' in command_output

    def get_nvram_data(self):
        command = '%s %s extract nvram' % (self.__app_path, self.__core_path)
        command_output = exe.block_run(command, shell=True, silent=True)
        return command_output

    def get_grc_all(self):
        grc_file = tempfile.mkstemp(suffix='.txt')[1]
        command = '%s %s grc all > %s' % (self.__app_path, self.__core_path, grc_file)
        exe.block_run(command, shell=True, silent=True)
        return grc_file
