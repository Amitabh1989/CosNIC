"""
This class implements a wrapper over the docker module. Each docker container created by this container manager
is maintained in a dict and can be managed using the API's throughout its lifetime.

Sample usage:
=============
>>> from controller.lib.linux.container.docker_manager import DockerContainerManager
>>> dcm = DockerContainerManager()
>>> dcm.list_containers()
[]
>>> dcm.create_container(image='debian:ssh', name='container0', ports={22: 50022})
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'created')]
>>> dcm.start_container(name='container0')
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'running')]
>>> dcm.stop_container(name='container0')
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'exited')]
>>> dcm.remove_container(name='container0')
>>> dcm.list_containers()
[]
>>> dcm.create_container(image='debian:ssh', name='container0', ports={22: 50022})
>>> dcm.start_container(name='container0')
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'running')]
>>> dcm.remove_container(name='container0')
>>> dcm.list_containers()
[]
>>> dcm.create_container(image='debian:ssh', name='container0', ports={22: 50022})
>>> dcm.start_container(name='container0')
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'running')]
>>> dcm.kill_container(name='container0')
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'exited')]
>>> dcm.remove_container(name='container0')
>>> dcm.list_containers()
[]
>>> dcm.create_container(image='debian:ssh', name='container0', ports={22: 50022})
>>> dcm.start_container(name='container0')
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'running')]
>>> dcm.exec_command_on_container(name='container0', command='ip addr show')
'1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000\n    link/loopback...'
>>> dcm.add_interface_to_container(name='container0', host_iface='enp4s0f0np0', ip_address='33.3.3.3/24')
>>> dcm.exec_command_on_container(name='container0', command='ip addr show')
'1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000\n    link/loopback...'
>>> dcm.exec_command_on_container(name='container0', command='ping -c 3 33.3.3.4')
'PING 33.3.3.4 (33.3.3.4) 56(84) bytes of data.\n64 bytes from 33.3.3.4: icmp_seq=1 ttl=64 time=0.182 ms\n64 bytes...'
>>> dcm.list_containers()
[('container0', 'debian:ssh', 'running')]
>>> dcm.exec_command_on_container(name='container0', command='service ssh start')
'Starting OpenBSD Secure Shell server: sshd.\n'
>>> dcm.exec_command_on_container(name='container0', command='service ssh status')
'sshd is running.\n'
>>> dcm.exec_command_on_container(name='container0', command='who')
''
>>> dcm.exec_command_on_container(name='container0', command='who')
'root     pts/0        Dec 12 11:01 (10.123.64.152)\n'
>>> dcm.exec_command_on_container(name='container0', command='who')
''
>>> dcm.remove_container(name='container0')
>>> dcm.list_containers()
[]
>>>
"""

import logging
from functools import wraps
from sys import platform
import time

import docker

from controller.lib.common.helpers.threaded import call_in_threads
from controller.lib.core import exception
from controller.lib.linux.system.ssh import SSHSession

logger = logging.getLogger(__name__)
CTRL_CONTAINER_LABEL = 'CTRL_MANAGED'

if platform == 'linux':
    PLATFORM = 'Linux'
elif platform == 'win32':
    PLATFORM = 'Windows'


class DockerContainerManager:
    class SanityChecker:

        @staticmethod
        def state_check(states):
            """Check and bail out when the container is in an unexpected state."""

            def inner_state_check(func):
                @wraps(func)
                def inner(self, name, *args, **kwargs):
                    self._containers[name].reload()

                    if type(states) is not list:
                        # This should never happen; just for sanity.
                        raise TypeError(f'Invalid type for states: "{states}". Should be list.')

                    if self._containers[name].attrs['State']['Status'] not in states:
                        raise exception.DockerException(f'Container {name} is not in states {states}.')

                    return func(self, name, *args, **kwargs)

                return inner

            return inner_state_check

    def __init__(self):
        """The container manager constructor. It maintains a collection of containers that it created, which can
        then be managed using the rest of its API's. It also loads any containers that were created by a
        previous instance of container manager by using labels.
        """
        self._containers = {}
        self.__docker_client = docker.from_env()
        container_list = self.__docker_client.containers.list(all=True, filters={'label': CTRL_CONTAINER_LABEL})

        for container in container_list:
            container.reload()
            self._containers[container.name] = container

    def create_container(self,
                         image: str,
                         name: str = None,
                         cap_add: list = None,
                         stdin_open: bool = True,
                         detach: bool = True,
                         ports: dict = None):
        """Create a container using the specified image.

        :param image: The image to use for creating.
        :param name: The name to use for the container. When not specified, docker chooses a name.
        :param stdin_open: Indicates if to keep the container active (True) when started or not.
        :param detach: Indicates if to run in background (True) or not.
        :param cap_add: A list of additional capabilities to add to the container. When not specified "NET_ADMIN"
                        capability is added to the container by default.
        :param ports: A dict containing the container port to host port mapping. e.g: passing {22: 50022} maps
                      the SSH port (22) on the container to the host port 50022.
        """
        if cap_add is None:
            cap_add = ['NET_ADMIN']

        logger.info(f'Creating container using image {image} and caps {cap_add}.')
        container = self.__docker_client.containers.create(image, name=name, cap_add=cap_add,
                                                           stdin_open=stdin_open, detach=detach,
                                                           ports=ports, labels=[CTRL_CONTAINER_LABEL])
        container.reload()
        self._containers[container.name] = container
        logger.debug(f'Total number of containers: {len(self._containers)}.')

    def create_containers(self,
                          image: str,
                          containers_name: list,
                          cap_add: list = None,
                          stdin_open: bool = True,
                          detach: bool = True,
                          ports: list = None) -> list:
        """Create multiple containers in parallel.

        :param image: The image to use for creating.
        :param containers_name: names to use for new containers. Used to detect number of containers to create.
        :param stdin_open: Indicates if to keep the container active (True) when started or not.
        :param detach: Indicates if to run in background (True) or not.
        :param cap_add: A list of additional capabilities to add to the container. When not specified "NET_ADMIN"
                        capability is added to the container by default.
        :param ports: A list of dict, each dict contains the container port to host port mapping.
                      e.g: passing {22: 50022} maps the SSH port (22) on the container to the host port 50022.
        """
        return call_in_threads(self.create_container,
                               image,
                               containers_name,
                               cap_add=cap_add,
                               stdin_open=stdin_open,
                               detach=detach,
                               ports=ports,
                               workers=25,
                               raise_err='complete')

    def remove_container(self, name: str, timeout: int = None):
        """Remove the container instance created by this instance of container manager.

        :param name: The name of the container to remove.
        :param timeout: Timeout in seconds to wait for the container to
                stop before sending a `SIGKILL`.
        :raises DockerException on failure to remove the container.
        """
        logger.info(f'Removing the container {name}.')

        try:
            self._containers[name].stop(timeout=timeout)
        except Exception as e:
            logger.debug(f'Failed to stop the container: {str(e)}.')

        try:
            self._containers[name].remove()
        except Exception as e:
            raise exception.DockerException(f'Failed to remove the container: {str(e)}.')

        logger.debug('Flushing the container from the collection.')
        self._containers.pop(name)
        logger.debug(f'Total number of containers: {len(self._containers)}.')

    def remove_containers(self,
                          containers_name: list = None,
                          timeout: int = None,
                          managed: bool = True,
                          check: bool = True) -> list:
        """Stop and delete multiple containers.

        :param containers_name: list of containers names to stop.
                                If empty, all or all ctrl-lib managed containers will be stopped.
        :param timeout: Timeout in seconds to wait for the container to
                        stop before sending a `SIGKILL`.
        :param managed: defines containers to stop if containers_name is not provided.
                        True - stop only containers managed by Au-common.
        :param check: defines should function re-raise an existed exception or not.
                        True - raise the exception happened on deleting container.
        """
        if not containers_name:
            container_list = self.list_containers(managed=managed)

            if not container_list:
                return []

            containers_name = [c[0] for c in container_list]

        if check:
            raise_err = 'complete'
        else:
            raise_err = ''

        return call_in_threads(self.remove_container, containers_name, timeout, workers=25, raise_err=raise_err)

    def list_containers(self, managed: bool = True) -> list:
        """List the docker containers on the system.

        :param managed: If True, return only the containers managed by this container manager. If False, return
                        all the containers on the system (even the ones that are not managed by this container
                        manager).
        :return: The list of containers on the system.
        """
        if managed:
            container_list = self.__docker_client.containers.list(all=True, filters={'label': CTRL_CONTAINER_LABEL})
        else:
            container_list = self.__docker_client.containers.list(all=True)

        for container in container_list:
            container.reload()

        return [(container.name, container.attrs['Config']['Image'], container.attrs['State']['Status'])
                for container in container_list]

    def pull_container_image(self, repository: str, tag: str = None):
        """Pull container image(s) from the specified repository.

        :param repository: The repository to pull the image from.
        :param tag: The tag to use when pulling the image.
        """
        logger.info(f'Pulling images from repository: {repository}.')
        self.__docker_client.images.pull(repository=repository, tag=tag)

    @SanityChecker.state_check(['exited', 'paused', 'created'])
    def start_container(self, name: str):
        """Start the container that is created by this instance of container manager.

        :param name: The name of the container to start.
        """
        logger.info(f'Starting the container {name}.')
        self._containers[name].start()

    def start_containers(self, containers_name: list = None):
        """Start the container that is created by this instance of container manager.

        :param containers_name: list of containers names to start.
                                If empty, all ctrl-lib managed containers will be started.
        """

        def _start_container(name):
            self._containers[name].start()

        if not containers_name:
            container_list = self.list_containers(managed=True)
            containers_name = [c[0] for c in container_list]

        logger.info(f'Starting the container {containers_name}.')
        call_in_threads(_start_container, containers_name, workers=25, raise_err='complete')

    @SanityChecker.state_check(['running', 'paused'])
    def stop_container(self, name: str, timeout: int = None):
        """Stop the container that is created by this instance of container manager.

        :param name: The name of the container to stop.
        :param timeout: Timeout in seconds to wait for the container to
                stop before sending a `SIGKILL`.
        """
        logger.info(f'Stopping the container {name}.')
        self._containers[name].stop(timeout=timeout)

    def stop_containers(self, containers_name: list = None, timeout: int = None, managed: bool = True) -> list:
        """Stop multiple containers in parallel.

        :param containers_name: list of containers names to stop.
                                If empty, all or all ctrl-lib managed containers will be stopped.
        :param timeout: Timeout in seconds to wait for the container to
                        stop before sending a `SIGKILL`.
        :param managed: defines containers to stop if containers_name is not provided.
                        True - stop only containers managed by Au-common.
        """

        def _stop_container(name):
            self._containers[name].stop(timeout=timeout)

        if not containers_name:
            container_list = self.list_containers(managed=managed)
            containers_name = [c[0] for c in container_list]

        return call_in_threads(_stop_container, containers_name, workers=40)

    @SanityChecker.state_check(['running', 'paused'])
    def kill_container(self, name: str):
        """Kill the container that is created by this instance of container manager.

        :param name: The name of the container to kill.
        """
        logger.info(f'Killing the container {name}.')
        self._containers[name].kill()

    def kill_containers(self, containers_name: list = None, managed: bool = True) -> list:
        """Kill multiple containers in parallel.

        :param containers_name: list of containers names to kill.
                               If empty, all or all ctrl-lib managed containers will be killed.
        :param managed: defines containers to kill if containers_name is not provided.
                       True - kill only containers managed by Au-common.
        """

        def _kill_container(name):
            self._containers[name].kill()

        if not containers_name:
            container_list = self.list_containers(managed=managed)
            containers_name = [c[0] for c in container_list]

        return call_in_threads(_kill_container, containers_name, workers=40)

    @SanityChecker.state_check(['running'])
    def get_container_logs(self, name: str, **kwargs) -> str:
        """Get the console logs of the container.

        :param name: The name of the container.
        :return: The console logs from the container.
        """
        logger.info(f'Getting logs from the container {name}.')
        return self._containers[name].logs(**kwargs).decode('utf-8')

    @SanityChecker.state_check(['running'])
    def exec_command_on_container(self, name: str, command: str) -> str:
        """Execute the specified command on the container that is created by this instance of container
        manager.

        :param name: The name of the container to run command on.
        :param command: The command to run on the container.
        :return: The output of the command.
        :raises ExeExitcodeException if the command execution failed.
        """
        logger.info(f'Executing {command} on container {name}.')
        result = self._containers[name].exec_run(command)

        if result.exit_code != 0:
            raise exception.ExeExitcodeException(command=command, exitcode=result.exit_code, output=result.output)

        return result.output.decode('utf-8')

    def exec_command_on_containers(self, command: str, containers_name: list = None, managed: bool = True) -> list:
        """Execute command in multiple containers in threads.

        :param command: Command to execute in all containers.
        :param containers_name: list of containers names to stop.
                                If empty, all or all ctrl-lib managed containers will be stopped.
        :param managed: defines containers to stop if containers_name is not provided.
                        True - stop only containers managed by Au-common.
        :returns: List with results of execution the command in appropriate container.
        """

        def _exec_command_on_container(name, cmd):
            self._containers[name].exec_run(cmd)

        if not containers_name:
            container_list = self.list_containers(managed=managed)
            containers_name = [c[0] for c in container_list]

        logger.info(f'Executing {command} on container {containers_name}.')
        return call_in_threads(_exec_command_on_container,
                               containers_name,
                               command,
                               workers=40,
                               raise_err='complete')

    @SanityChecker.state_check(['running'])
    def add_interface_to_container(self, name: str, host_iface: str, ip_address: str = None):
        """Add a network interface to the container.

        :param name: The name of the container.
        :param host_iface: The host interface to add to the container. e.g: p2p1.
        :param ip_address: The IPv4 address to assign to the interface on the container. e.g: '33.3.3.3/24'.
        """
        if PLATFORM == 'Linux':
            # It is assumed that the container is running a Linux based image for now. When we need to
            # support a non-Linux image for the containers, this needs necessary updates.
            from controller.lib.linux.eth.ip import attach_iface_to_pid_namespace
            self._containers[name].reload()
            container_pid = self._containers[name].attrs['State']['Pid']
            attach_iface_to_pid_namespace(iface=host_iface, pid=container_pid)
            time.sleep(2)
            if ip_address:
                command = f'ip addr add {ip_address} dev {host_iface}'
                self.exec_command_on_container(name=name, command=command)
            command = f'ip link set {host_iface} up'
            self.exec_command_on_container(name=name, command=command)
        else:
            raise exception.DockerException(f'Adding host interface is not supported on platform {PLATFORM}.')

    def add_interfaces_to_containers(self, containers_name: list, host_ifaces: list, ip_addresses: list = None):
        """Add a network interfaces to multiple containers in parallel.

        :param containers_name: list of containers names.
                           e.g. ['debian_0', 'debian_1']
        :param host_ifaces: list of lists The host interfaces to add to the containers. i-th to i-th
                           e.g. [['p2p1_0', 'p2p1_1'],
                                 ['p2p1_2', 'p2p1_3']]
        :param ip_addresses: list of listsThe addresses to assign to the interface on the container. i-th to i-th
                           e.g: [['33.3.3.3/24', '33.3.4.3/24'],
                                 ['33.3.4.3/24', '33.3.4.4/24']]
        """
        if len(containers_name) != len(host_ifaces):
            raise ValueError('Number of containers should match the number of interfaces.')

        if ip_addresses:
            if len(ip_addresses) != len(host_ifaces):
                raise ValueError('Number of ip addresses should match the number of interfaces.')
        else:
            ip_addresses = [None for _ in range(len(host_ifaces))]

        logger.info(f'Assign interfaces to containers {containers_name}.\n'
                    f'Interfaces {host_ifaces}\nips {ip_addresses}.')

        def _assign_interface_to_container(cont_name, per_cont_vf_names, container_ips):
            if container_ips:
                if len(per_cont_vf_names) != len(container_ips):
                    raise ValueError('Number of ip addresses does not match the match the number of '
                                     f'interfaces for {cont_name}.')
            else:
                container_ips = [None for _ in range(len(per_cont_vf_names))]

            for vf_name, ip_addr in zip(per_cont_vf_names, container_ips):
                if ip_addr:
                    ip_addr = f'{ip_addr}/24'

                self.add_interface_to_container(name=cont_name,
                                                host_iface=vf_name,
                                                ip_address=ip_addr)

        call_in_threads(_assign_interface_to_container,
                        containers_name,
                        host_ifaces,
                        ip_addresses,
                        workers=25,
                        raise_err='complete')

    @staticmethod
    def start_rpyc_in_containers(containers_conf: dict,
                                 cont_params: dict,
                                 log_id: str):
        """Start rpyc server in containers using ssh.

        The ctrl-lib supposed to be installed in the default location and SSH server started.
        Current implementation assume that all container are Linux and uses the same port to
        start rpyc inside container.

        This a temporary solution until start via docker API or image with started rpyc will be
        added.

        :param containers_conf: dict
                                 {'container1_name': {
                                'ssh_port': 5020,
                                'rpyc_port': 6020,
                                },
                                }
        :param cont_params: dict with management data shared among containers.
        :param log_id: an ID do calculate unique folder location.
        """

        def _start_rpyc_container(cont_cfg):

            ssh = SSHSession(address=cont_params['mgmt_ip'],
                             port=cont_cfg['ssh_port'],
                             username=cont_params['user'],
                             password=cont_params['password'])
            try:
                pass
                # TODO will modify if required
                DockerContainerManager.start_rpyc_server(ssh.exec_command, port=cont_cfg['rpyc_port'])
            finally:
                ssh.close()

        call_in_threads(_start_rpyc_container,
                        list(containers_conf.values()),
                        workers=40,
                        raise_err='complete')

    @staticmethod
    def start_rpyc_server(exec_command,
                          ip: str = '0.0.0.0',
                          port: int = 2726):
        """Start RPyC server on remote host.
        RPyC server`s logs, pid and outputs will be written in /tmp/au-common/run-{log_id}/ folder.

        Unique but meaningful log id could be generated using datetime module.
        >>> from datetime import datetime
        >>> datetime.now().strftime("%m%d%H%M")

        :param exec_command: callable command executor with 'check' parameter. e.g. ssh.exec_command()
        :param log_id: unique id to create a folder for logs and rpyc log file.
        :param lib_folder: folder where au-common folder with venv should be located.
        :param ip: ip address of remote interface where rpyc server should listen.
        :param port: port where rpyc server should listen.
        """
        logger.info(f'Start RPyC server on {ip}:{port}.')

        cmd = f'python3 /usr/local/bin/stat_server.py'
        rpyc_cmd = f'{cmd}'

        start_cmd = f'nohup {rpyc_cmd}'
        try:
            exec_command(start_cmd, check=True)
        except exception.ExeExitcodeException:
            err_msg = f'Failed to start RPYC on the remote host using {ip}:{port}.'
            raise Exception(err_msg)
        logger.info(f'RPyC server on {ip}:{port} has been started.')
