"""
:mod:`driver` -- Linux driver library
=====================================

.. module:: controller.lib.linux.driver
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import re
import time
from controller.lib.common.shell import exe
from typing import Union


def load(driver_name, param=None, method='modprobe'):
    """Load driver using modprobe or insmod

    Args:
        driver_name (str): driver name to be loaded. If method is 'insmod',
            driver_name should include absolute path to the driver
        param (dict): parameters that will be passed to drivers as key=value.
        method (str): [modprobe|insmod] use different command to load driver
    """

    param_str = ' '.join(
        ['%s=%s' % (key, value) for key, value in list(param.items())]) \
        if param else ''

    exe.block_run('%s %s %s' % (method, driver_name, param_str))
    time.sleep(1)
    if method == 'modprobe' and (str(driver_name) == 'bnxt_en'):
        output = exe.block_run('lsmod', silent=True)
        if output.find('bnxt_re') != -1:
            exe.block_run('rmmod bnxt_re')
            time.sleep(1)
            exe.block_run('modprobe bnxt_re')


def unload(driver_name, method='rmmod'):
    """Unload driver using modprobe or rmmod

    Args:
        driver_name (str): driver name to be unloaded.
        method (str): [modprobe|rmmod] use different command to unload driver
    """

    output = exe.block_run('lsmod', silent=True)
    if (str(driver_name) == 'bnxt_en') and output.find('bnxt_re') != -1:
        if method == 'modprobe':
            exe.block_run('modprobe -r bnxt_re')
        elif method == 'rmmod':
            exe.block_run('rmmod bnxt_re')

    if output.find(driver_name) != -1:
        if method == 'modprobe':
            exe.block_run('modprobe -r %s' % driver_name)
        elif method == 'rmmod':
            exe.block_run('rmmod %s' % driver_name)


def get_params(driver_name):
    """Return a list of supported parameters

    Args:
        driver_name (str): driver name
    """

    output = exe.block_run('modinfo %s' % driver_name)
    ret_list = []
    for param in re.findall(r'parm:\s+(.*)', output):
        ret_list.append(param.split(':')[0])

    return ret_list


def is_loaded(driver_name: str) -> bool:
    """Return True if <driver_name> is loaded

    :param driver_name: Driver name
    :returns:           True if driver is loaded, else False
    """
    return get_memory_usage(driver_name) is not None

# CTRL-48082: This method is deprecated.

def get_modinfo(driver_name):
    """Return driver information that is returned by modinfo

    Args:
        driver_name (str): driver name
    """
    ret_dict = {}  # 'parm': get_params(driver_name)}
    output = exe.block_run('modinfo %s' % driver_name)
    for line in output.splitlines():
        if re.match(r'(.*):[\s\t]+(.*)', line):
            param, value = re.match(r'(.*):[\s\t]+(.*)', line).groups()
            value = value.strip()
            if param.startswith('parm:'):
                continue  # Already collected
            if param in ret_dict:  # Already exists. Make it as a list
                if isinstance(ret_dict[param], list):
                    ret_dict[param].append(value)
                else:
                    ret_dict[param] = [ret_dict[param], value]
            else:
                ret_dict[param] = value

    return ret_dict


def get_memory_usage(driver_name: str) -> Union[str, None]:
    """Return the memory usage of the driver. If driver is not loaded, return None.

    Args:
        driver_name (str): driver name
    """
    with open('/proc/modules', 'r') as fileobj:
        output = fileobj.read()

    if re.search(r'%s\s+(\d+) (\d+)' % driver_name, output):
        return int(re.search(r'%s\s+(\d+) (\d+)' % driver_name, output).group(1))

    return None
