"""
:mod:`install` -- Linux driver install/uninstall API
====================================================

.. module:: controller.lib.linux.driver.install
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import os
import re
import time
import traceback
import distro

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.linux import driver
from controller.lib.linux import eth
from controller.lib.linux.eth import ethtool

log = log_handler.get_logger(__name__)


class InstallBase(object):
    def __init__(self, filename):
        self.filename = filename

    def install(self):
        raise NotImplemented

    def uninstall(self):
        raise NotImplemented

    def upgrade(self, force=False):
        raise NotImplemented

    def is_installed(self):
        raise NotImplemented

    def get_version(self, **kwargs):
        raise NotImplemented

    def get_package_info(self, pkg_name=None):
        raise NotImplemented

    @staticmethod
    def get_install(filename):
        """Return a instantiated class depending on the given filename

                Currently only support the source file type.

                Args:
                        filename (str): A filename with absolute path

                """

        if filename.endswith('tar.gz'):
            return SrcBase(filename)

        if filename.endswith('.rpm'):
            return RPMBase(filename)

        raise exception.ConfigException(
            'Not supported file type. Currently only support a source tar.gz')

    @staticmethod
    def get_latest_dir(dir_name):
        """Return the latest files that are in the given directory.

                No logic to validate filenames, but simply sort by versions

                Args:
                        dir_name (str): a directory name where files are located

                """
        filename_list = [filename for filename in os.listdir(dir_name)]
        filename_list.sort(key=lambda v: list(map(int, v.split('.'))))

        return filename_list[-1]


class RPMBase(InstallBase):
    def __init__(self, filename, drv_name=None):
        super(RPMBase, self).__init__(filename)
        self.pkg_name = self.get_package_info()['name']
        self.drv_name = drv_name
        self.drv_version = None
        self.drv_filepath = None

    def install(self):
        log.info('Install %s ... ' % self.filename)
        exe.block_run('rpm -ivh %s' % self.filename)

    def uninstall(self):
        log.info('Uninstall %s ... ' % self.pkg_name)
        exe.block_run('rpm -e %s' % self.pkg_name)

    def upgrade(self, force=False):
        log.info('Upgrading %s ... ' % self.filename)
        exe.block_run('rpm -Uvh %s %s' % (
            '--force' if force else '', self.filename))

    def is_installed(self, method=None, drv_name=None):
        log.info("The method = %s" % method)
        if method == 'modinfo':
            drv_info = driver.get_modinfo(self.drv_name \
                                              if self.drv_name is not None else drv_name)
            if 'version' not in drv_info:
                raise exception.ValueException(
                    'Cannot find "version" information from modinfo output')
            self.drv_version = drv_info['version']
            self.drv_filepath = drv_info['filename']
            return True
        elif method == 'ethtool':
            iface_list = eth.get_interfaces_by_driver(self.drv_name \
                                                          if self.drv_name is not None else drv_name)
            if len(iface_list) == 0:
                raise exception.ConfigException(
                    'No interfaces are found that use driver %s' % self.drv_name
                )
            iface = iface_list[0]
            drv_info = ethtool.get_drvinfo(iface)
            self.drv_version = drv_info['version']
            return True
        else:
            try:
                exe.block_run('rpm -V %s' % self.pkg_name)
            except exception.ExeExitcodeException as err:
                if 'not installed' in err.output:
                    return False
                raise
            else:
                return True

    def get_package_info(self, pkg_name=None):
        ret_dict = {}
        if pkg_name:
            output = exe.block_run('rpm -qi %s' % pkg_name)
        else:
            output = exe.block_run('rpm -qip %s' % self.filename)

        for param, value in re.findall('(.*)[\s\t]+:\s(.*)', output):
            if param is 'Description':
                continue
            ret_dict[param.lower().strip()] = value

        return ret_dict

    def get_version(self, pkg_name=None):
        pkg_info = self.get_package_info(pkg_name=pkg_name)
        return pkg_info['version']

    def get_release(self, pkg_name=None):
        pkg_info = self.get_package_info(pkg_name=pkg_name)
        return pkg_info['release']

    def get_drv_path(self, pkg_name=None):
        drv_path = ''
        output = exe.block_run('rpm -qpil %s' % self.filename)
        value = re.findall('(.*ko)', output)
        if value:
            return value
        return None


class DebBase(InstallBase):
    def __init__(self, filename, drv_name=None):
        super(DebBase, self).__init__(filename)
        self.pkg_name = self.get_package_info()['package']
        self.drv_name = drv_name
        self.drv_version = None
        self.drv_filepath = None

    def install(self, force=False):
        log.info('Install %s ... ' % self.filename)
        # apt install xyz.deb --- is another command used to install deb files
        force_all = '--force-all' if force else ''
        exe.block_run(f'dpkg {force_all} -i {self.filename}')

    def uninstall(self):
        log.info('Uninstall %s ... ' % self.pkg_name)
        exe.block_run('dpkg -r %s' % self.pkg_name)

    def upgrade(self, force=False):
        log.info('Upgrading %s ... ' % self.filename)
        self.install(force=force)

    def is_installed(self, method=None, drv_name=None):
        log.info("The method = %s" % method or 'dpkg-query')
        if method == 'modinfo':
            drv_info = driver.get_modinfo(self.drv_name if self.drv_name is not None else drv_name)
            if 'version' not in drv_info:
                raise exception.ValueException(
                    'Cannot find "version" information from modinfo output')
            self.drv_version = drv_info['version']
            self.drv_filepath = drv_info['filename']
            return True
        elif method == 'ethtool':
            iface_list = eth.get_interfaces_by_driver(self.drv_name if self.drv_name is not None else drv_name)
            if len(iface_list) == 0:
                raise exception.ConfigException(
                    'No interfaces are found that use driver %s' % self.drv_name
                )
            iface = iface_list[0]
            drv_info = ethtool.get_drvinfo(iface.name)
            self.drv_version = drv_info['version']
            return True
        else:
            try:
                exe.block_run("dpkg-query --showformat='${Version}' --show %s" % self.pkg_name)
            except exception.ExeExitcodeException as err:
                if 'no packages found' in err.output:
                    return False
                raise
            else:
                return True

    def get_package_info(self, pkg_name=None):
        ret_dict = {}
        if pkg_name:
            output = exe.block_run(f'dpkg -s {pkg_name}')
        else:
            output = exe.block_run(f'dpkg -f {self.filename}')

        for param, value in re.findall(r'(.*):(.*)', output):
            ret_dict[param.lower().strip()] = value.strip()

        return ret_dict

    def get_version(self, pkg_name=None):
        pkg_info = self.get_package_info(pkg_name=pkg_name)
        return pkg_info['version']
    
    def get_drv_path(self):
        output = exe.block_run('dpkg -c %s' % self.filename)
        value = re.findall('(.*ko)', output)
        if value:
            value = value[0].split()[-1][1:]
            return [value]
        return None


class SrcBase(InstallBase):
    """A class for driver installation using tar.gz.

        Accept two arguments; filename and regular expression. Each child class
        can pass regular expression which would be used to extract driver name
        and version. If regexp is None, some methods will not work due to missing
        driver and version information

        Args:
                filename (str): An absolute path to the file.
                        i.e. /tmp/driver-1.0.tar.gz
                regexp (str): regular express to get a driver name and version.

        """

    def __init__(self, filename, regexp=None):
        super(SrcBase, self).__init__(filename=filename)
        self.drv_name = None
        self.drv_version = None

        regexp = regexp or '.*/(\w+)-([0-9a-zA-Z\.]+).tar.gz'

        if not re.match(regexp, self.filename):
            log.warning(
                'Cannot recognize the filename. (Used regexp %s). Some methods '
                'will not be functional.' % regexp)
        else:
            self.drv_name, self.drv_version = re.match(
                regexp, self.filename).groups()

    def install(self):
        exe.block_run('tar -xvzf ' + self.filename, cwd='/tmp')
        config_found = False
        bnxtre = False
        path_found = False
        drv_path = '/tmp/' + self.filename.split('/')[-1].replace('.tar.gz', '')
        os_distro = distro.id()
        os_major_ver = int(distro.version_parts()[0])
        for fl in os.listdir(drv_path):
            if fl == 'config':
                config_found = True
                break
        if config_found:
            pwd = os.getcwd()
            exe.block_run('rm -f /etc/libibverbs.d/bnxt*', cwd='/tmp/')
            if os_distro == 'sles' and os_major_ver >= 15:
                exe.block_run('rm -f /usr/local/lib64/libbnxt*', cwd='/tmp/')
            else:
                exe.block_run('rm -f /usr/local/lib/libbnxt*', cwd='/tmp/')
            exe.block_run('sh autogen.sh', cwd=drv_path, shell=True)
            exe.block_run('./configure --sysconfdir=/etc',
                          cwd='/tmp/' + self.filename.split('/')[-1].replace('.tar.gz', ''))
            exe.block_run('make', cwd=drv_path)
            exe.block_run('make install all', cwd=drv_path)
            log.info('Module %s is successfully installed' % self.filename.split('/')[-1].replace('.tar.gz', ''))

            if os_distro == 'sles' and os_major_ver >= 15:
                lib_install_path = '/usr/local/lib64'
            else:
                lib_install_path = '/usr/local/lib'
            fo = open('/etc/ld.so.conf', 'r')
            output = fo.read()
            fo.close()
            for line in output.splitlines():
                if line == lib_install_path:
                    path_found = True
            if not path_found:
                fo = open('/etc/ld.so.conf', 'a')
                fo.write(lib_install_path)
                fo.close()
            exe.block_run('ldconfig -v')

        if not config_found:
            roce_version = l2_version = l2_prefix = None
            for root, subFolders, files in os.walk(drv_path):
                for file in files:
                    filePath = os.path.join(root, file)
                    if filePath.find('bnxt_re.h') != -1:
                        with open(filePath, 'r') as fileobj:
                            for line in fileobj.readlines():
                                if line.find('ROCE_DRV_MODULE_VERSION') != -1:
                                    roce_version = re.findall('ROCE_DRV_MODULE_VERSION\s+"(.*)"', line)[0]

                    if filePath.find('bnxt_extra_ver.h') != -1:
                        with open(filePath, 'r') as fileobj:
                            for line in fileobj.readlines():
                                if line.find('#define DRV_MODULE_EXTRA_VER') != -1:
                                    try:
                                        l2_version = re.findall('DRV_MODULE_EXTRA_VER\s+"(.*)"', line)[0]
                                    except:
                                        log.warning("l2_version - not found")

                    if filePath.find('bnxt.h') != -1:
                        with open(filePath, 'r') as fileobj:
                            for line in fileobj.readlines():
                                if line.find('DRV_MODULE_EXTRA_VER') != -1:
                                    l2_prefix = re.findall('DRV_MODULE_VERSION\s+"(.*)"', line)[0]

            try:
                exe.block_run('make', cwd=drv_path)
                exe.block_run('make install', cwd=drv_path)
            except:
                log.error(traceback.format_exc())
                raise exception.TestCaseFailure('Driver compilation failed, please check host log file')

            driver.unload('bnxt_en', method='rmmod')
            time.sleep(2)
            if roce_version is not None:
                self.drv_version = roce_version
                self.drv_name = 'bnxt_re'
                driver.load(self.drv_name)
                time.sleep(1)
                if not self.is_installed():
                    raise exception.TestCaseFailure(
                        '%s driver with version:%s is not installed' % (self.drv_name, self.drv_version))
                else:
                    log.info('%s driver with version:%s is installed' % (self.drv_name, self.drv_version))

            if l2_version is not None and l2_prefix is not None:
                self.drv_version = l2_prefix + l2_version
                self.drv_name = 'bnxt_en'
                driver.load(self.drv_name)
                time.sleep(1)
                if not self.is_installed():
                    raise exception.TestCaseFailure(
                        '%s driver with version:%s is not installed' % (self.drv_name, self.drv_version))
                else:
                    log.info('%s driver with version:%s is installed' % (self.drv_name, self.drv_version))
            return True

    def is_installed(self, method='modinfo', lcomp=None):
        """Return True/False whether driver is installed.

        Args:
        method (str): choices=[modinfo|ethtool] ethtool is obviously only
                                usable for network drivers
        """
        if not self.drv_version or not self.drv_name:
            log.warning(
                'Cannot check driver installation due to missing driver name '
                'and/or driver version information. Return True.')
            return True

        if method == 'modinfo':
            drv_info = driver.get_modinfo(self.drv_name)
            if 'version' not in drv_info:
                raise exception.ValueException(
                    'Cannot find "version" information from modinfo output')

        elif method == 'ethtool':
            iface_list = eth.get_interfaces_by_driver(self.drv_name)
            if len(iface_list) == 0:
                raise exception.ConfigException(
                    'No interfaces are found that use driver %s' % self.drv_name
                )
            iface = iface_list[0]
            drv_info = ethtool.get_drvinfo(iface)
        else:
            raise exception.ValueException(
                'method argument %s is invalid (choices=[modinfo|ethtool])')

        drv_version = drv_info['version']
        return self.drv_version == drv_version


class SuSE(RPMBase):
    def __init__(self, filename):
        super(SuSE, self).__init__(filename)


class RedHat(RPMBase):
    def __init__(self, filename):
        super(RedHat, self).__init__(filename)


class Ubuntu(DebBase):
    def __init__(self, filename):
        super(Ubuntu, self).__init__(filename)


class Debian(DebBase):
    def __init__(self, filename):
        super(Debian, self).__init__(filename)


def get_object(filename):

    with open('/etc/os-release', 'r') as fd:
        os = fd.read()
        if 'rhel' in os or 'centos' in os or 'Rocky' in os:
            return RedHat(filename)
        elif 'sles' in os:
            return SuSE(filename)
        elif 'debian' in os:
            return Debian(filename)
        elif 'ubuntu' in os:
            return Ubuntu(filename)
        else:
            log.warning('This OS is not supported')
            return None
