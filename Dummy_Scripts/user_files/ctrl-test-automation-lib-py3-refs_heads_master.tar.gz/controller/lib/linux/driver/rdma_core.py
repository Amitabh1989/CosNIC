"""
:mod:`rdma_core` -- Linux RDMA core install
====================================================

"""

import shutil
import distro
import os
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class InstallBase(object):
    def __init__(self, filename):
        self.filename = filename
        self._file_path = None
        self.tar_exe = find_executable('tar')
        if self.tar_exe is None:
            raise exception.ConfigException('tar is not available; have it installed before reattempting')

    @property
    def file_path(self):
        """
        :return: Returns path of extracted folder if not already extracted
        """
        if self._file_path is None:
            exe.block_run(f'{self.tar_exe} -xzf ' + self.filename, cwd='/tmp')
            self._file_path = '/tmp/' + self.filename.split('/')[-1].replace('.tar.gz', '')
        return self._file_path

    def install_rdma_core(self):
        """
        This method will compile and replace existing rdma-core with new one
        :return:
        """
        build_path = self.file_path + '/build'
        if os.path.exists(build_path):
            os.remove(build_path)
        os.mkdir(build_path)
        exe.block_run('export EXTRA_CMAKE_FLAGS="-DCMAKE_BUILD_TYPE=Debug -DENABLE_WERROR=1"', cwd=self.file_path,
                      shell=True)
        exe.block_run('cmake -G Ninja CFLAGS="-O0 -g" -DCMAKE_INSTALL_PREFIX=/usr ..', cwd=self.file_path + '/build',
                      shell=True)
        exe.block_run('ninja', cwd=self.file_path + '/build')
        exe.block_run('ninja install', cwd=self.file_path + '/build')


class RepoSubscription(object):
    def __init__(self):
        pass

    @staticmethod
    def clean_repolist():
        exe.block_run("yum clean all")

    @staticmethod
    def subscribe_to_repo(username=None, password=None):
        """
        :return:
        """
        username = username or 'siddharth.moghe'
        password = password or 'BCLPassword1'
        exe.block_run(f"subscription-manager register --username {username} --password {password} "
                      f"--auto-attach --force")

    @staticmethod
    def unsubscribe_to_repo():
        """
        :return:
        """
        exe.block_run(f"subscription-manager unregister")

    @staticmethod
    def configure_crb():
        """
        This method will enable or disable code ready builder repo
        :return:
        """
        os_distro = distro.id()
        os_major_ver = distro.version_parts()[0]
        if os_distro == 'rhel':
            exe.block_run(f"subscription-manager repos --enable codeready-builder-for-rhel-{os_major_ver}-$(arch)-rpms",
                          shell=True)
            exe.block_run(
                f"dnf -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-{os_major_ver}.noarch.rpm")
        elif os_distro == 'centos':
            exe.block_run(f"dnf config-manager --set-enabled crb", shell=True)
            exe.block_run("dnf -y install epel-release epel-next-release")
        else:
            raise exception.ConfigException(f"{os_distro}.... Unsupported distribution ")


class Rhel(InstallBase):
    def __init__(self, filename=None, username=None, password=None):
        super(Rhel, self).__init__(filename)
        self.username = username
        self.password = password

    @staticmethod
    def check_required_packages():
        raise NotImplemented

    @staticmethod
    def query_existing_installed_pkg():
        raise NotImplemented

    def compile_rdma_core(self):
        repo_obj = RepoSubscription()
        repo_obj.clean_repolist()
        repo_obj.subscribe_to_repo(self.username, self.password)
        repo_obj.clean_repolist()
        repo_obj.configure_crb()
        exe.block_run('dnf -y builddep redhat/rdma-core.spec', cwd=self.file_path)
        self.install_rdma_core()
        # rename Inbox lib so that OOB lib can take effect
        shutil.move("/usr/lib64/libibverbs/libbnxt_re-rdmav34.so", "/usr/lib64/libibverbs/libbnxt_re-rdmav34.so_old")

    @staticmethod
    def get_rdma_core_version():
        """
        :return: returns libibverbs version (equivalent to rdma-core) in int format
        """
        output = exe.block_run("ls -l /lib64/libibverbs.so.1", shell=True)
        return int(output.splitlines()[0].split('>')[-1].strip().split('.')[-2])


class Suse(InstallBase):
    def __init__(self, filename=None):
        super(Suse, self).__init__(filename)

    @staticmethod
    def query_existing_installed_pkg():
        raise NotImplemented

    @staticmethod
    def check_required_packages():
        pkg_list = ['cmake', 'gcc', 'libnl3-devel', 'ninja', 'pkg-config', 'valgrind-devel',
                    'python3-devel', 'python3-Cython', 'python3-docutils', 'pandoc']
        not_installed_pkgs = []
        for pkg in pkg_list:
            try:
                exe.block_run(f"zypper search -si {pkg}")
                log.debug(f"installation of {pkg} is present")
            except Exception:
                not_installed_pkgs.append(pkg)
        if not_installed_pkgs:
            raise exception.ConfigException(f"Cannnot proceed with installation as packages {not_installed_pkgs} not "
                                            f"found. Have them installed using zypper before reattempting ")

    def compile_rdma_core(self):
        self.check_required_packages()
        self.install_rdma_core()
        # rename Inbox lib so that OOB lib can take effect
        shutil.move("/usr/lib64/libibverbs/libbnxt_re-rdmav34.so", "/usr/lib64/libibverbs/libbnxt_re-rdmav34.so_old")

    @staticmethod
    def get_rdma_core_version():
        """
        :return: returns libibverbs version (equivalent to rdma-core) in int format
        """
        output = exe.block_run("ls -l /usr/lib64/libibverbs.so.1", shell=True)
        return int(output.splitlines()[0].split('>')[-1].strip().split('.')[-2])


class Debian(InstallBase):
    def __init__(self, filename=None):
        super(Debian, self).__init__(filename)

    @staticmethod
    def query_existing_installed_pkg():
        output = exe.block_run("dpkg -l").strip().split('\n')
        header = output[3]
        ret_dict = {}
        name = header.find('Name')
        version = header.find('Version')
        architecture = header.find('Architecture')
        description = header.find('Description')
        for info in output[5:]:
            temp_dict = dict()
            temp_dict['name'] = info[name: version - 2].strip()
            temp_dict['version'] = info[version:architecture - 2].strip()
            temp_dict['architecture'] = info[architecture:description - 2].strip()
            temp_dict['description'] = info[description:]
            ret_dict[temp_dict['name']] = temp_dict['version']

        return ret_dict

    def check_required_packages(self):
        pkg_list = ['build-essential', 'cmake', 'gcc', 'libudev-dev', 'libnl-3-dev', 'libnl-route-3-dev',
                    'ninja-build', 'pkg-config', 'valgrind', 'python3-dev', 'cython3', 'python3-docutils', 'pandoc']
        not_installed_pkgs = []
        existing_pkg = self.query_existing_installed_pkg().keys()
        for pkg in pkg_list:
            if not any(pkg in x for x in existing_pkg):
                not_installed_pkgs.append(pkg)
        if not_installed_pkgs:
            raise exception.ConfigException(f"Cannnot proceed with installation as packages {not_installed_pkgs} not "
                                            f"found. Have them installed using 'apt' before reattempting ")

    def compile_rdma_core(self):
        self.check_required_packages()
        self.install_rdma_core()
        # rename Inbox lib so that OOB lib can take effect
        shutil.move("/usr/lib/x86_64-linux-gnu/libibverbs/libbnxt_re-rdmav34.so",
                    "/usr/lib/x86_64-linux-gnu/libibverbs/libbnxt_re-rdmav34.so_old")

    @staticmethod
    def get_rdma_core_version():
        """
        :return: returns libibverbs version (equivalent to rdma-core) in int format
        """
        output = exe.block_run("ls -l /usr/lib/x86_64-linux-gnu/libibverbs.so.1", shell=True)
        return int(output.splitlines()[0].split('>')[-1].strip().split('.')[-2])


def install_rdma_core(filename, username=None, password=None):
    """
    Method to install RDMA core from given source file
    :param filename: local file path in tar.gz format
    :param username: username to subscribe to RHEL repo (required only when OS is RHEL)
    :param password: password to subscribe to RHEL repo (required only when OS is RHEL)
    :return:
    """
    distro_id = distro.id()
    if distro_id in ['rhel', 'centos']:
        obj = Rhel(filename, username, password)
    elif distro_id in ['ubuntu', 'debian']:
        obj = Debian(filename)
    elif distro_id == 'sles':
        obj = Suse(filename)
    else:
        raise exception.ConfigException(f"{distro_id}.... Unsupported OS distribution ")
    obj.compile_rdma_core()
    rdma_core_file_ver = int(obj.file_path.split('.')[-2].split('-')[-1])
    rdma_core_install_ver = obj.get_rdma_core_version()
    log.info(f"Installed rdma core version is {rdma_core_install_ver}")
    log.info(f"RDMA core version of {obj.file_path} is {rdma_core_file_ver}")
    shutil.rmtree(obj.file_path)
    return True if rdma_core_file_ver == rdma_core_install_ver else False
