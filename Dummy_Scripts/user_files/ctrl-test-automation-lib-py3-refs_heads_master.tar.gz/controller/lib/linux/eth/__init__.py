"""
:mod:`eth` -- Ethernet interface API
====================================

.. module:: controller.lib.linux.eth
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This module provides two layers to access Ethernet devices:

   * Application layer
   * IOCTL (currently disabled)

Application layer interacts with devices using applications - such as
"ip", "ethtool" and others. Namely each method/function calls will execute
shell commands, parse output and return values as necessary.

IOCTL layer interacts with devices using IOCTL, which is suitable for high
performance required test cases since it by-passes application layers and
access devices directly.

Both layers have the same method/function names so developers can abstract
layers how to communicate with devices by getting an object from the factory
method - "get_interface". It will return an object depending on what method
you want to use - and virtually the same code should work with either mode.

Most attributes of the object are properties; namely you can get and set
attributes through objects and directly update the Ethernet interface
attributes.

Following is an example how to get IP address from 'eth1' and change it

>>> from controller.lib.linux import eth
>>> eth1 = eth.get_interface('eth1')
>>> eth1.ip_addr
'70.168.2.10'
>>> eth1.ip_addr = '70.168.2.100/23'

Note that you must define the prefix when you set a new IP address, which is
"/23" above.

>>> eth1.ip_addr
'70.168.2.100'

Though note that there are som attributes that cannot not be set directly such
as ip6_addr and features due to they require more than one argument. Instead,
they have separate methods that can be called. (Typically,
set_<funcition_name>) For example:

>>> eth1.set_features('tx-checksum-ipv4', 'off')

"""

import os
import re
import ipaddress
from controller.lib.linux.eth import ip


def get_interface(iface, method='app'):
    """Factory function to return the Interface object

    Return Interface object depending on the given "method" argument.

    Args:
        method (str): [app|ioctl]. For application layer testing, should
            use "app" so this object runs tools depending on methods such
            as ethtool, ip, ifconnfig, etc.
            For high performance, should use 'ioctl' which doesn't execute
            shell command

    Returns:
        Interface: Interface object that has methods to interact with
            the Ethernet interface.
    """
    from .interface.app_interface import AppInterface
    iface = iface[-15:]
    if method == 'app':
        return AppInterface(iface=iface)
    elif method == 'ioctl':
        raise NotImplementedError('IOCTL is currently disabled')
    else:
        raise ValueError('Unknown method type')


def get_interface_by_mac_addr(
        mac_addr, vlan_id=None, virtual=False, alias_id=None, method='app'):
    """
    A factory function.

    Return Interface object that has the given MAC address depending on
    the method argument.

    .. note:

       This function cannot detect VLAN interface that has not the
       expected name format - i.e. ethX.<VLAN_ID>

    Args:
        mac_addr (str): MAC address in xx:xx:xx:xx:xx:xx format
        vlan_id (None, int): If None, return a physical interface. Otherwise
            return interface that is bound to the given VLAN ID
        alias_id (None, int): Placeholder. Will be supported later.
        method (str): [app|ioctl] For application layer testing, should
            use "app" so this object runs tools depending on methods such
            as ethtool, ip, ifconnfig, etc.
            For high performance, should use 'ioctl' which doesn't execute
            shell command

    Returns:
        Interface: If interface is detected, return AppInterface or
           IoctlInterface depending on the method argument otherwise return None

    """
    from .interface.app_interface import AppInterface

    eths = [
        eth for eth in os.listdir('/sys/class/net')
        if os.path.isdir('/sys/class/net/%s' % eth)
    ]

    for ethx in eths:
        ethx_mac_addr = open(
            '/sys/class/net/%s/address' % ethx, 'r').read().strip()

        # Check virtual
        if 'virtual' in os.path.realpath(
                '/sys/class/net/%s' % ethx) and not virtual:
            continue

        if ethx_mac_addr == mac_addr.lower():
            # Check VLAN
            if re.match('.*\.\d+$', ethx):  # VLAN interface
                if vlan_id and ethx.endswith('.%s' % vlan_id):
                    return AppInterface(iface=ethx)
            elif vlan_id is None:
                return AppInterface(iface=ethx)

    return None


# CTRL-48082: This method is deprecated

def get_interfaces_by_driver(driver, **kwargs):
    from .interface.app_interface import AppInterface
    ret_list = []
    for eth in os.listdir('/sys/class/net'):
        if driver == os.path.realpath(
                '/sys/class/net/%s/device/driver' % eth).split('/')[-1]:
            ret_list.append(AppInterface(eth))

    return ret_list


# CTRL-48082: This method is deprecated

def get_interfaces(**kwargs):
    return os.listdir('/sys/class/net')


# CTRL-48082: This method is deprecated

def get_interfaces_by_ip_addr(ip_addr, **kwargs):
    ret_list = []
    netmask = True if '/' in ip_addr else False
    ipv = ipaddress.ip_interface(ip_addr).version
    for eth in get_interfaces():
        _iface = get_interface(eth)
        iface_ipaddrs = [_ip_addr if netmask else ipaddress.ip_interface(_ip_addr).ip.compressed for _ip_addr in
                         ip.get_ip_addr(iface=_iface.name, ipv6=ipv == 6)]
        if ip_addr in iface_ipaddrs:
            ret_list.append(_iface)
    return ret_list
