"""
:mod:`arp` -- Linux tool 'arp' wrapper
======================================

.. module:: controller.lib.linux.eth.arp
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This module is a simple wrapper around 'arp' tool which can be used for
managing arp cache entries.
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2019 Broadcom Inc"


import re

from controller.lib.core import log_handler
from controller.lib.common.shell import exe


log =  log_handler.get_logger(__name__)


def add_entry(iface, ip_addr, mac_addr):
    """
    Add a static entry into the ARP cache.

    Args:
        iface: The interface to associate with the ARP entry.
        ip_addr: The IP address of the ARP entry.
        mac_addr: The MAC address of the ARP entry.
    """
    exe.block_run('arp -i %s -s %s %s' % (iface, ip_addr, mac_addr))

def remove_entry(iface, ip_addr):
    """
    Remove a static entry from the ARP cache.

    Args:
        iface: The interface to associate with the ARP entry.
        ip_addr: The IP address of the ARP entry.
    """
    exe.block_run('arp -i %s -d %s' % (iface, ip_addr))

def list_entries():
    """
    Retrieve the list of all existing ARP entries.
    """
    command_output = exe.block_run('arp -a')
    return re.findall('\(([\d\.]+)\) at ([\w:]+).*on ([\w]+)', command_output)
