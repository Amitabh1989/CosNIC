"""
:mod:`bridge` -- Interact with a bridge interfaces
==================================================

.. module:: controller.lib.linux.vm.create_vswitch
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import os

from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.linux import eth
from controller.lib.core import log_handler
from controller.lib.core import exception

log = log_handler.get_logger(__name__)


class BaseVswitch(object):
    def __init__(self, br_iface, **kwargs):
        self._br_iface = br_iface

    @property
    def br_iface(self):
        return self._br_iface

    def add_br(self):
        raise NotImplementedError

    def del_br(self):
        raise NotImplementedError

    def add_if(self, iface):
        raise NotImplementedError

    def del_if(self, iface):
        raise NotImplementedError

    @classmethod
    def get_bridges(cls):
        raise NotImplementedError

    def get_bridge(self):
        raise NotImplementedError


class Bridge(BaseVswitch):
    mode = 'bridge'

    def add_br(self):
        exe.block_run('ip link add %s type bridge' % self.br_iface)

    def del_br(self):
        log.info('Bring down the bridge interface %s ... ' % self.br_iface)
        exe.block_run('ip link set dev %s down' % self.br_iface)
        log.info('Removing the bridge interface %s ... ' % self.br_iface)
        exe.block_run('ip link delete %s type bridge' % self.br_iface)

    def add_if(self, iface):
        exe.block_run('ip link set dev %s up' % iface)
        exe.block_run('ip link set %s master %s' % (iface, self.br_iface))

    def del_if(self, iface):
        exe.block_run('ip link set %s nomaster' % iface)

    @classmethod
    def get_bridges(cls):
        ret_list = []

        for iface in os.listdir('/sys/class/net'):
            if os.access('/sys/class/net/%s/bridge/' % iface, 0):
                ret_list.append(iface)

        return ret_list

    def get_bridge(self):
        ret_dict = {
            'iface_list': os.listdir('/sys/class/net/%s/brif' % self.br_iface)}
        return ret_dict


class OVS(BaseVswitch):
    mode = 'ovs'

    def __init__(self, br_iface, **kwargs):
        self.ovs_vsctl = find_executable('ovs-vsctl')
        if self.ovs_vsctl is None:
            raise exception.ConfigException('ovs-vsctl is not available')
        super(OVS, self).__init__(br_iface=br_iface, **kwargs)

    def add_br(self):
        exe.block_run([self.ovs_vsctl, 'add-br', self.br_iface])

    def del_br(self):
        exe.block_run([self.ovs_vsctl, 'del-br', self.br_iface])

    @classmethod
    def get_bridges(cls):
        return exe.block_run(['ovs-vsctl', 'list-br']).splitlines()

    def add_if(self, iface):
        exe.block_run(([self.ovs_vsctl, 'add-port', self.br_iface, iface]))

    def del_if(self, iface):
        exe.block_run(([self.ovs_vsctl, 'del-port', self.br_iface, iface]))


def get_bridge(br_iface, mode=None):
    if br_iface in eth.get_interfaces():
        _iface = eth.get_interface(br_iface)
        if _iface.drvinfo['name'] == 'bridge':
            if mode is None or mode == 'bridge':
                return Bridge(br_iface=br_iface)
        elif _iface.drvinfo['name'] == 'openvswitch':
            if mode is None or mode == 'ovs':
                return OVS(br_iface=br_iface)

        raise exception.ConfigException(
            'Bridge %s already exist (mode: %s)'
            % (br_iface, _iface.drvinfo['name']))

    if not mode:
        raise exception.ValueException('"mode" is missing')

    for subclass in BaseVswitch.__subclasses__():
        if subclass.mode == mode:
            return subclass(br_iface=br_iface)

    raise exception.ValueException('Invalid mode %s' % mode)


def get_bridges():
    ret_list = []
    for br_iface in eth.get_interfaces():
        _iface = eth.get_interface(br_iface)
        try:
            if _iface.drvinfo['name'] == 'bridge':
                ret_list.append(br_iface)
            elif _iface.drvinfo['name'] == 'openvswitch':
                ret_list.append(br_iface)
        except exception.ExeExitcodeException:
            continue

    return ret_list
