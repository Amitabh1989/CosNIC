"""
:mod:`ethtool` -- Linux tool 'ethtool' wrapper
===============================================

.. module:: controller.lib.linux.eth.ethtool
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a wrapper module of ethtool.

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

import re
import tempfile
import os

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)
the_exe = exe


def use_ssh(ssh_ip_addr=None):
    """
    The function that selects the method to use to run the ethtool commands. If ssh_ip_address is
    specified, an SSH connection to that IP adress is established and that connection is used to
    run the ethtool commands. Otherwise, the usual shell exe module is used.

    Args:
        ssh_ip_addr (str): The IP address to use for running ethtool commands over SSH. When None,
        the SSH mode is exited.

    Caution:
        It is the responsibility of the caller to reset the SSH mode by calling this function
        with ssh_ip_addr=None.
    """
    from controller.lib.linux.system import ssh
    global the_exe

    if ssh_ip_addr is not None:
        the_exe = ssh.SSH(ssh_ip_addr)
    else:
        if isinstance(the_exe, ssh.SSH):
            the_exe.disconnect()

        the_exe = exe


def exec_ethtool(iface, opt, order=None, **kwargs):
    """Execute ethtool command.

    Args:
        iface (str): ethX name
        opt (str): option to be passed to ethtool. i.e.) '-s'
        order (list): List of keys in kwargs so the parameters are provided
            in order as defined here
        kwargs (kwargs): keyword argument which has key=parameter name and
            value=value. i.e. set_duplex('p1p1', 'full', speed=40000) will
            run "ethtool -s p1p1 duplex full speed 40000".

    """
    order = order or list(kwargs.keys())
    params = ' '.join('%s %s' % (key, kwargs[key]) for key in order)
    output = the_exe.block_run('ethtool %s %s %s' % (opt, iface, params))
    return output


def reset(iface):
    """
    Reset the specified interface.

    Args:
        iface (str): ethX name of the interface to reset.
    """
    the_exe.block_run('ethtool --reset %s all' % iface)


def get_msglvl(iface):
    """Return msglvl

    Args:
        iface (eth): ethX name

    Return:
        int: msglvl in integer

    """
    output = the_exe.block_run('ethtool %s' % iface)
    return int(re.search(r'Current message level: 0x[0-9a-f]+ \((\d+)\)', output).group(1))


def set_msglvl(iface, msglvl):
    """Set msglvl

    Args:
        iface (eth): ethX name
        msglvl (hex, int): message level
    """
    the_exe.block_run('ethtool -s %s msglvl %s' % (iface, msglvl))


def get_advertised_autonegotiation(iface):
    """ Verify if Advertised Auto Negotiation
        is enabled or disabled

    Args:
        iface (eth): ethX name
    """
    key_value = ''

    try:
        output = the_exe.block_run('ethtool %s' % iface)
    except exception.ExeExitcodeException as err:
        log.error('Failed to read interface settings')
        return None

    lines = output.split('\n\t')

    for each_line in lines:
        if 'Advertised auto-negotiation: ' in each_line:
            key_value = each_line.split(': ')[1].strip()

    return key_value


# Link Status function will return the Link state as 'yes' or 'no'
def link_status(iface):
    output = the_exe.block_run('ethtool %s' % iface)

    try:
        return re.search(r'Link detected:\s+(\w+)', output).group(1)
    except:
        raise exception.EthtoolException('Cannot find Link State information from ethtool')


def get_speed(iface):
    """
    Return link speed of the interface

    Args:
        iface (eth): ethX name

    Returns:
        int: link speed in Mb. -1 for unknown.

    """
    output = the_exe.block_run('ethtool %s' % iface)
    speed = re.search(r'Speed:\s+(\w+)', output).group(1)

    if 'Unknown' in speed:
        return -1

    speed = re.match(r'(\d+)', speed).group(1)

    try:
        return int(speed)
    except:
        raise exception.EthtoolException('Cannot find speed information from ethtool')


def get_supported_speeds(iface):
    """
    Return the list of supported speeds on the network interface.
    :return:  List of tuples with each element containing speed and duplex mode as values.
    """
    output = the_exe.block_run('ethtool %s' % iface)
    if 'Supported link modes' in output:  # To get only supported link speed with current nvm config
        speeds = []
        start = False
        for line in output.splitlines():
            if 'Supported link modes' in line:
                start = True
                speed, duplex = line.split(':')[1].split('/')
                duplex = duplex.strip()
            elif start:
                if ':' in line:
                    break
                speed, duplex = line.split('/')
                duplex = duplex.strip()
            if start:
                speed = re.search(r'(\d+)', speed).group(1)
                speeds.append((speed, duplex))
    else:
        speeds = re.findall(r'(\d+).*\/(Full|Half)', output)

    if len(speeds) > 0:
        return list(set(speeds))

    return None


def set_speed(iface, speed, **kwargs):
    """
    Set speed of the interface.

    Args:
        iface (eth): ethX name
        speed (int): New speed in Mb
    """
    exec_ethtool(iface, '-s', speed=speed, autoneg='off', **kwargs)


def get_duplex(iface):
    """
    Return duplex mode of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: duplex mode in lower case (which ethtool accepts as values for
           duplex mode setting)
    """
    output = the_exe.block_run('ethtool %s' % iface)

    try:
        return re.search(r'Duplex:\s+(\w+)', output).group(1).lower()
    except:
        raise exception.EthtoolException('Cannot find duplex information from ethtool')


def set_duplex(iface, duplex, **kwargs):
    """
    Set duplex mode of the interface.

    If showing 'cannot advertise duplex X' error, try to set speed and
    duplex at the same time by using the "set_speed_and_duplex" function

    Args:
        iface (str): ethX name
        duplex (str): duplex mode. choices=[full|half]
    """
    exec_ethtool(iface, '-s', duplex=duplex, **kwargs)


def get_stats(iface):
    """
    Return statistics of the interface, as ethtool -S returns since
    output format is different per NIC type

    Args:
        iface (str): ethX name

    Returns:
        dict: key=statistics name, value=value
    """
    return the_exe.block_run('ethtool -S %s' % iface)


def get_drvinfo(iface):
    """Return driver name, version and firmware versions

    Args:
        iface (str): ethX name

    Return:
        dict: key=name, version, firmware. value = values
    """
    output = the_exe.block_run('ethtool -i %s' % iface)

    if not re.search('.*driver: (.*)\n.*version: (.*)\n.*firmware-version: (.*)', output, re.MULTILINE):
        raise exception.EthtoolException('Cannot find driver information. Output: %s' % output)

    drv_name, drv_version, firm_version = \
        re.search('.*driver: (.*)\n.*version: (.*)\n.*firmware-version: (.*)', output, re.MULTILINE).groups()
    pkg_version = ''
    fw_version = ''

    if not firm_version or firm_version == 'N/A':
        log.info('Firmware version is empty')
    else:
        fw_arr = firm_version.split('/')
        fw_version = fw_arr[0].strip()

        if len(fw_arr) == 2:
            if len(fw_arr[1]) > 1:
                pkg_version = fw_arr[1].split()[1]
            else:
                pkg_version = fw_arr[1].strip()
        else:
            pkg_version = None

    return {'name': drv_name, 'version': drv_version, 'firmware': fw_version, 'pkg_version': pkg_version}


def get_features(iface):
    """
    Return ethtool features output. Return value is a dictionary which has a
    tuple as values (<status>, <fixed>)

    <status> is etierh 'on' or 'off'
    <fixed> is True or False depending on it's a fixed value or not.

    Args:
        iface (str): ethX name

    Returns:
        dict: key=feature name, value=(<status=on|off>, <fixed=bool>)
    """
    ret_dict = {}
    output = the_exe.block_run('ethtool -k %s' % iface)

    for param, value, fixed in re.findall(r'(.*):\s+(on|off)\s+(\[fixed\])?', output):
        ret_dict[param.strip()] = (value, True if fixed else False)

    return ret_dict


def set_features(iface, feature, value):
    """
    Set offload feature settings. No error checking about changing settings
    for "fixed" features, but raise exe exception as it is.

    Args:
        iface (str): ethX name
        feature (str): Feature name. e.g.) tx-checksumming
        value (str): choices=[on|off] as ethtool -k returns

    """
    the_exe.block_run('ethtool -K %s %s %s' % (iface, feature, value))


def get_coalesce(iface):
    """
    Return coalesce parameters as a dictionary.

    Args:
        iface (str): ethX name

    Return:
        dict: key=param, value=value

    """
    ret_dict = {}
    output = the_exe.block_run('ethtool -c %s' % iface)

    for param, value in re.findall(r'(.*):\s+(.*)', output):
        if re.match(r'\d+', value):  # param, values
            ret_dict[param] = int(value)
        elif value.startswith('Adaptive'):
            rx, tx = re.search(r'Adaptive\s+RX:\s+(.*)\s+TX:\s+(.*)', value).groups()
            ret_dict['adapt_rx'] = rx.strip()
            ret_dict['adapt_tx'] = tx.strip()

    return ret_dict


def set_coalesce(iface, param, value):
    """Set coalesce parameter.

    Args:
        iface (str): ethX name
        param (str): parameter name i.e.) rx-frames
        value (str, int): str for adapt_rx and adapt_tx and int for all other
            parameters.
    """
    the_exe.block_run('ethtool -C %s %s %s' % (iface, param, value))


def get_pause(iface):
    """Return pause options

    Args:
        iface (str): ethX name

    Return:
        dict: auto_neg, rx, tx, rx_neg, tx_neg keys and values
    """
    ret_dict = {}
    key_mapping = {
        'Autonegotiate': 'autoneg',
        'RX': 'rx',
        'TX': 'tx',
        'RX negotiated': 'rx_neg',
        'TX negotiated': 'tx_neg',
    }

    output = the_exe.block_run('ethtool -a %s' % iface)

    for pause_info in re.findall(r'(.*):[\s\t]+(o(n|ff))', output):
        param, value = pause_info[:2]

        if param in key_mapping:
            ret_dict[key_mapping[param]] = value

    return ret_dict


def set_pause(iface, **kwargs):
    """Set pause options

    Args:
        iface (str): ethX name
        **kwargs (kwargs): key=parameter, value=value

    """
    curr_cfg = {}
    curr_cfg = get_pause(iface)

    for key in list(kwargs.keys()):
        print(('flow_control:%s, curr_cfg:%s, req_cfg:%s' % (key, curr_cfg[key], kwargs[key])))

        if curr_cfg[key] == kwargs[key]:
            print(('%s flow control already %s' % (key, curr_cfg[key])))
            kwargs.pop(key)

    if len(kwargs) != 0:
        try:
            exec_ethtool(iface=iface, opt='-A', **kwargs)
        except exception.ExeExitcodeException as err:
            if err.exitcode == 78:
                raise exception.EthtoolNoChanges(err.output)
            elif 'no pause parameters changed' in err.output:
                raise exception.EthtoolNoChanges(err.output)

            raise
    else:
        print('Nothing to configure')

    return


def get_channels(iface):
    """Return channel information

    Args:
        iface (str): ethX name

    Return:
        dict: key=queue_type, value=preset, curset. If querying channels is
            not supported, return None

    """
    ret_dict = {'preset': {}, 'curset': {}}

    try:
        output = the_exe.block_run('ethtool -l %s' % iface)
    except exception.ExeExitcodeException as err:
        if 'not supported' in err.output:
            log.warning('Not supported')
            return None
        raise

    for queue_type in ['RX', 'TX', 'Other', 'Combined']:
        preset, curset = [int(queue) if len(queue) > 0 else 0
                          for queue in re.findall(r'%s:[\s\t]+(\d+)?' % queue_type, output)]
        ret_dict['preset'][queue_type.lower()] = preset
        ret_dict['curset'][queue_type.lower()] = curset

    return ret_dict


def set_channels(iface, channel_settings):
    """Configure the channel using the given parameter.

    Args:
        iface: interface name
        channel_settings (dict): new channel settings. The format of the
            expected channel_settings is same as the return value of
            get_channels()
    """
    settings_str = ' '.join(['%s %s' % (param, value) for param, value in list(channel_settings.items())])

    try:
        the_exe.block_run('ethtool -L %s %s' % (iface, settings_str))
    except exception.ExeExitcodeException as err:
        if 'no channel parameters changed, aborting' in err.output:
            pass
        else:
            raise


def get_rxfh_indir_table(iface):
    """
    Retrieves the receive flow hash indirection table and/or RSS hash key.
    :param iface: iface name
    :return:
    """
    ret_dict = {}
    output = the_exe.block_run('ethtool -x %s' % iface)

    table = {}
    for start, rings in re.findall(r'(\d+):\s\s+(.*)', output):
        for index, ring in zip(list(range(int(start), int(start) + len(rings.split()))), rings.split()):
            table[index] = ring
    ret_dict['table'] = table

    output = [str(tk.strip()) for tk in output.split('\n')]
    key = output[output.index('RSS hash key:') + 1]
    ret_dict['key'] = key

    return ret_dict


def set_rxfh_indir_table(iface, hkey=None, start=None, equal=None, weight=None,
                         hfunc=None, context=None, delete=None, default=False):
    """
    Configures the received flow hash indirection table and/or
              RSS hash key.

        ethtool -X|--set-rxfh-indir|--rxfh devname
              [hkey xx:yy:zz:aa:bb:cc:...]  [start N] [ equal N |
              weight W0 W1 ... | default ] [hfunc FUNC] [context CTX
              | new] [delete]
    :param iface: iface name
    :param hkey: RSS hash key of the specified network device
    :param start: For the equal and weight options, sets the starting
                  receive queue for spreading flows to N
    :param equal: Sets the received flow hash indirection table to spread
                  flows evenly between the first N receive queues.
    :param weight: Sets the received flow hash indirection table to spread
                  flows between receive queues according to the given
                  weights.  The sum of the weights must be non-zero and
                  must not exceed the size of the indirection table.
    :param hfunc: RSS hash function of the specified network
                  device
    :param context: RSS context to act on; either new to
                  allocate a new RSS context
    :param delete: Delete the specified RSS context
    :param default: Sets the received flow hash indirection table to default
    :return:
    """

    options = list()
    if hkey:
        options.append(f'hkey {hkey}')

    ethtool_version = list(map(int, get_ethtool_version().split(".")))
    if ethtool_version >= [5, 6]:  # Adding start options only if ethtool version is >= 5.6
        if start and (equal or weight):
            options.append(f'start {start}')

    if equal:
        options.append(f'equal {equal}')
    elif weight:
        options.append(f'weight {weight}')
    elif default:
        options.append(f'default')

    if hfunc:
        options.append(f'hfunc {hfunc}')

    if context:
        if delete:
            options.append(f'context {context} delete')
        else:
            options.append(f'context {context}')

    command = f'ethtool -X {iface} {" ".join(options)}'
    the_exe.block_run(command)


def get_ring(iface):
    """Return ring information

    Args:
        iface (str): ethX name

    Return:
        dict: key=queue type, value=preset, curset. If querying ring is not
            supported, return None
    """
    ret_dict = {'preset': {}, 'curset': {}}

    try:
        output = the_exe.block_run('ethtool -g %s' % iface)
    except exception.ExeExitcodeException as err:
        if 'not supported' in err.output:
            log.warning('Not supported')
            return None
        raise

    for queue_type in ['RX', 'RX Mini', 'RX Jumbo', 'TX']:
        preset, curset = [int(ring) for ring in re.findall(r'%s:[\s\t]+(\d+)' % queue_type, output)] or [0, 0]
        ret_dict['preset'][queue_type.lower()] = preset
        ret_dict['curset'][queue_type.lower()] = curset

    return ret_dict


def set_ring(iface, ring_settings):
    """Configure the ring parameters using the given parameter.

    Args:
        iface: "Interface name"
        ring_settings (dict): new channel settings. The rx and tx dictionary items of "curset"
    """
    settings = ' '.join(['%s %s' % (param, value) for param, value in list(ring_settings.items())])

    try:
        the_exe.block_run('ethtool -G %s %s' % (iface, settings))
    except exception.ExeExitcodeException as err:
        if 'no ring parameters changed, aborting' in err.output:
            pass
        else:
            raise


def get_nvram_dump(iface):
    """Dump NVRAM

    Args:
        iface (str): ethX name
    """
    return the_exe.block_run('ethtool -e %s' % iface)


def get_core_dump(iface, core_path):
    """
    Generate coredump using the specified interface.

    Args:
        iface (str)    : The interface to use to generate coredump.
        core_path (str): The path to the resulting coredump file.
    """
    temp_path = core_path or tempfile.mktemp(suffix='.core')
    command = 'ethtool -w %s data %s' % (iface, temp_path)
    the_exe.block_run(command, shell=True)
    return os.path.abspath(temp_path)


def get_iface_medium(iface):
    """ Get the medium details

    Args:
        iface (str): eth name

    Return:
        Interface medium [FIBRE/TP]
    """
    output = the_exe.block_run('ethtool %s' % iface)

    if re.search(r'\s*Supported ports:(\s*.*)', output):
        raw_medium = re.search(r'\s*Supported ports:(\s*.*)', output).group(1)
        medium = raw_medium.strip(' []')
        return medium
    else:
        log.error('Could not find the medium')

    return None


def add_mac_filter(iface, **kwargs):
    """
    Add a MAC filter rule with the specified L2 parameters.

    Args:
        iface (str): ethX name
        flow_type (str): Type of flow to filter; Default = 'ether'
        src_mac (str): Destination MAC address to use for filtering.
        dst_mac (str): Destination MAC address to use for filtering.
        vlan_id (int): vLAN ID to use for filtering.
        protocol (str): Ethertype to use for filtering.
        action (str): Action to take on rule hit; Default = -1 (drop).
    Return:
        test_status: True on success; False on failure.
        rule_id: The ID of the filter rule created on success; -1 on failure.
    """
    test_status = False
    rule_id = 0
    flow_type = kwargs.get('flow_type', 'ether')
    src_mac = kwargs.get('src_mac', None)
    dst_mac = kwargs.get('dst_mac', None)
    vlan_id = kwargs.get('vlan_id', None)
    vlan_id_mask = 0xf000
    protocol = kwargs.get('protocol', None)
    action = kwargs.get('action', -1)
    # If no parameter is specified, no filter can be created.
    if src_mac is None and dst_mac is None and protocol is None:
        raise exception.ConfigException('No parameter specified for filtering.')
    # If specified, build and execute the command.
    command = 'ethtool -U %s flow-type %s' % (iface, flow_type)
    command += '' if src_mac is None else (' src %s' % src_mac)
    command += '' if dst_mac is None else (' dst %s' % dst_mac)
    command += '' if vlan_id is None else (' vlan %s vlan-mask %s' % (vlan_id, vlan_id_mask))
    command += '' if protocol is None else (' src %s' % protocol)
    command += ' action %s' % action
    command_output = the_exe.block_run(command, shell=True)
    re_obj = re.search(r'Added rule with ID (\d+)', command_output)
    if 'Input/output error' in command_output:
        rule_id = -1
        re_obj = None
    else:
        re_obj = re.search(r'Added rule with ID (\d+)', command_output)
    # If the rule is successfully created, get the rule ID.
    if re_obj is not None:
        test_status = True
        rule_id = re_obj.group(1)

    return test_status, rule_id


def delete_mac_filter(iface, rule_id):
    """
    Delete the specified filter rule on the specified interface.

    Args:
        iface: The name of the interface to delete the filter rule on.
        rule_id: The ID of the rule to delete.
    """
    command = 'ethtool -U %s delete %s' % (iface, str(rule_id))
    the_exe.block_run(command, shell=True)
    return True


def list_mac_filters(iface, ntuple=False):
    """
    Get the list of MAC filter rules of the specified interface.

    Args:
        iface (str): ethX name
        ntuple:
    Return:
        rules_count: Number of rules available.
        mac_addresses: The list of destination MAC addresses used in the rules.
    """
    mac_addresses, filter_queue, rule_type = ([] for _ in range(3))
    rules_count = 0
    command = 'ethtool -u %s' % iface
    command_output = the_exe.block_run(command, shell=True).strip()
    rules_count = int(re.search(r'Total (\d+) rules', command_output).group(1))
    # If there are any rules, list them.
    if ntuple is True:
        if rules_count > 0:
            # expr = "Action: Direct to queue (.*)"
            filter_queue = re.findall(r"Action: Direct to queue (.*)", command_output)
            # expr = "Rule Type: (.*) over (.*)"
            rule_type = re.findall(r"Rule Type: (.*) over (.*)", command_output)
        return filter_queue, rule_type
    else:
        if rules_count > 0:
            mac_addresses = re.findall(r'Dest MAC addr:\s+([0-9a-zA-Z:]+)', command_output)
        return rules_count, mac_addresses


def set_rx_flow_hash(iface, flow_type, tuple_type):
    """
    Configures receive network flow classification options.
    Args:
        iface (str): ethX name
        flow_type (str): flow type. Ex: tcp4, udp4 etc
        tuple_type (str): tuple type. Ex: sd, sdfn etc
    """
    command = f'ethtool -U {iface} rx-flow-hash {flow_type} {tuple_type}'
    the_exe.block_run(command)


def get_rx_flow_hash(iface, flow_type):
    """
    Retrieves receive network flow classification options.
    Args:
        iface (str): ethX name
        flow_type (str): flow type. Ex: tcp4, udp4 etc
    """
    flow_hash = {}
    command = f'ethtool -u {iface} rx-flow-hash {flow_type}'
    output = the_exe.block_run(command)
    protocol_ipv = re.search(r'.*(TCP|UDP).*(IPV4|IPV6).*', output)
    if protocol_ipv:
        flow_hash['protocol'], flow_hash['ipv'] = protocol_ipv.groups()
        flow_hash['tuple'] = re.findall(r'.*(SA|DA|src\s+port|dst\s+port).*', output)
    return flow_hash


def add_tuple_filter(iface, **kwargs):
    """
    Add a tuple filter rule with the specified L2 parameters.

    Args:
        iface (str): ethX name
        protocol (str): Protocol to use for filtering, default(TCP).
        src_port (str): Source port number.
        dst_port (str): Destination port number.
        src_port_mask (int/hex): Source port number mask.
        dst_port_mask (int/hex): Destination port number mask.
        src_ip (str): Source ipv4/v6 address.
        dst_ip (str): Destination ipv4/v6 address.
        src_ip_mask (str): Source ipv4/v6 address mask.
        dst_ip_mask (str): Destination ipv4/v6 address mask.
        l4_proto (str): ICMP port number
        action(str): Action queue

    Return:
        test_status: True on success; False on failure.
        rule_id: The ID of the filter rule created on success; -1 on failure.
    """
    test_status = False
    rule_id = -1
    flow_type = kwargs.get('protocol', None)
    src_port = kwargs.get('src_port', None)
    src_port_mask = kwargs.get('src_port_mask', None)
    dst_port = kwargs.get('dst_port', None)
    dst_port_mask = kwargs.get('dst_port_mask', None)
    src_ip = kwargs.get('src_ip', None)
    src_ip_mask = kwargs.get('src_ip_mask', None)
    dst_ip = kwargs.get('dst_ip', None)
    dst_ip_mask = kwargs.get('dst_ip_mask', None)
    l4_proto = kwargs.get('l4_proto', None)
    action = kwargs.get('rx_que', None)
    # If no parameter is specified, no filter can be created.
    if action is None and flow_type is None:
        raise exception.ConfigException('No  action ring or/and flow_type specified for filtering.')
    # If specified, build and execute the command.
    command = 'ethtool -N %s flow-type %s' % (iface, flow_type)
    command += '' if src_ip is None else (' src-ip %s' % src_ip)
    command += '' if src_ip_mask is None else (' src-ip-mask %s' % src_ip_mask)
    command += '' if dst_ip is None else (' dst-ip %s' % dst_ip)
    command += '' if dst_ip_mask is None else (' dst-ip-mask %s' % dst_ip_mask)
    command += '' if src_port is None else (' src-port %s' % src_port)
    command += '' if src_port_mask is None else (' src-port-mask %s' % src_port_mask)
    command += '' if dst_port is None else (' dst-port %s' % dst_port)
    command += '' if dst_port_mask is None else (' dst-port-mask %s' % dst_port_mask)
    command += '' if l4_proto is None else (' l4proto %s' % l4_proto)
    command += ' action %s' % action

    try:
        command_output = the_exe.block_run(command, shell=True)
    except Exception as e:
        return test_status, e

    re_obj = re.search(r'Added rule with ID (\d+)', command_output)
    # If the rule is successfully created, get the rule ID.
    if re_obj is not None:
        test_status = True
        rule_id = re_obj.group(1)
    else:
        rule_id = command_output

    return test_status, rule_id


def get_tuple_list(iface):
    """
       Return the n tuple info.
       Args:
           iface (str): ethX name.
       """
    cmd = f"ethtool -n {iface}"
    return the_exe.block_run(cmd, shell=True, silent=True).rstrip()


def get_bus_info(iface):
    """
    Return the PCI BDF of the specified interface.

    Args:
        iface (str): ethX name.
    Return:
        The PCI BDF of the interface specified.
    """
    command = 'ethtool -i %s' % iface
    command_output = the_exe.block_run(command)
    command_output = re.findall(r'bus-info: ([\w:\.]+)', command_output)
    return command_output[0] if len(command_output) == 1 else None


def get_module_info(iface):
    """
    Return the cable info
    Args:
        iface (str): ethX name.
    Return:
        cable info in dict format
    """
    output = the_exe.block_run('ethtool -m %s' % iface)
    module_info = {param.strip(): value.strip() for param, value in re.findall(r'(.*)\s+:\s+(.*)', output)}
    return module_info


def get_ethtool_version():
    """
    Return:
        ethtool version info in str format
    """
    output = the_exe.block_run('ethtool --version')
    version = re.search(r'\d+.?(\d+)?', output).group(0)
    return version


def set_private_flags(iface):
    """
       Enable the numa direct on interface in MR.
       Args:
           iface (str): ethX name
       """
    command = f"ethtool --set-priv-flags {iface} numa_direct on"
    the_exe.block_run(command)


def get_private_flags(iface):
    """
      Get the numa direct status of interface in MR.
       Args:
           iface (str): ethX name
       """
    command = f"ethtool --show-priv-flags {iface}"
    output = the_exe.block_run(command)
    return re.search(r'numa_direct(\s+)?:\s+(\w+)', output).group(2)

def generate_coredump_ethtool(iface, file_name, flag=1):
    """
      Get the coredump output
       Args:
           iface (str): ethX name
           file_name (str): core file name
           flag : accepted values are 0 or 1
       """
    dump_output = None
    dump_level = None
    try:
        command = "ethtool -W {} {}".format(iface.name, flag)
        dump_level = the_exe.block_run(command)
    except Exception as e:
        dump_level = str(e)
    command = f"ethtool -w {iface.name} data {file_name}"
    log.info("executing the command %s" % command)
    try:
        dump_output = the_exe.block_run(command)
    except Exception as e:
        dump_output = str(e)
    return dump_output, dump_level


def get_wake_on_status(iface):
    """
    Get wake-on support detail and wake-on status of interface
    :param iface: (str) iface name
    :return :    (dict) support value and status value
    """
    output = the_exe.block_run(f'ethtool {iface}')
    wol_info = {}
    try:
        wol_info['support'] = re.search(r'Supports Wake-on:(.*)', output).group(1).strip()
        wol_info['status'] = re.search(r'Wake-on:(.*)', output).group(1).strip()
        return wol_info
    except Exception:
        raise exception.EthtoolException('Cannot find Wake-on information from ethtool')


def set_wake_on_status(iface, option):
    """
    Set wake-on on interface

    :param iface: (str) ethX name
    :param option: (str) wake-on mode, ex: p|u|m|b|a|g|s|f|d
    :return: None
    """
    the_exe.block_run(f'ethtool -s {iface} wol {option}')


def self_test(iface):
    """
    runs ethtool self test

    Args:
        iface (str): ethX name
    """
    the_exe.block_run('ethtool -t %s' % iface.name)