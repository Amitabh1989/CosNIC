"""
:mod:`ifconfig` -- Linux tool 'ifconfig' wrapper
================================================

.. module:: controller.lib.linux.eth.ifconfig
.. moduleauthor:: Albert To <albertt@broadcom.com>

This module is a simple wrapper around 'ifconfig' tool which can be used for
configuring IP address, MTU, MAC address, etc.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import re
import socket
import struct
import fcntl
import os

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe


log =  log_handler.get_logger(__name__)


def set_ip_addr(iface, ip_addr, netmask=None, method='change', is_ipv6=False):
    """
    Set IP address to the given iface. Not using IOCTL to test the application
    layer, namely "ifconfig"

    Args:
        iface (str): ethX name
        ip_addr (str): IP address in the X.X.X.X format
        netmask (int, str): Netmask in X.X.X.X or /XX format. If ipv6 is True,
           should be prefixlength. If None, not passing netmask parameter.
        method (str): [add|change|replace|del] as "ifconfig" command accepts to
           assign a new IP address.
        is_ipv6 (bool): Configure IPv6 address if True else IPv4

    Returns:
        str: Output of ifconfig command

    """

    if isinstance(netmask, str) and re.match('\d+\.\d+\.\d+\.\d+', netmask):
        netmask = sum([bin(int(x)).count('1') for x in netmask.split('.')])

    # Do not check parameter values further. Let "ifconfig" tool raise exceptions if any parameters are incorrect.
    if is_ipv6 and re.match('add|del', method):
        return exe.block_run(
            'ifconfig %s %s %s %s%s' % (
                iface, 'inet6', method, ip_addr,
                '/' + str(netmask) if netmask else ''
            )
        )
    elif not is_ipv6 and re.match('change|replace', method):
        return exe.block_run(
            'ifconfig %s %s%s' % (
                iface, ip_addr,
                '/' + str(netmask) if netmask else ''
            )
        )

    raise exception.IPException(
        '%s method is NOT supported for %s address family' % (
            method, 'IPv6' if is_ipv6 else 'IPv4'
        )
    )


def get_ip_addr(iface, is_ipv6=False, is_netmask=False):
    """
    Return a list of IP addresses.

    Args:
        iface (str): ethX name
        is_ipv6 (bool): Get IPv6 address if True else IPv4
        netmask (bool): Return netmask along with its IP address

    Returns:
        list: IP addresses
        list: tuple of (IP address, netmask) if netmask is True

    """

    output = exe.block_run('ifconfig %s' % iface)
    re_match_ip = 'inet6 [addr: ]*([a-fA-F0-9:]+)' if is_ipv6 \
        else 'inet\D+(\d+\.\d+\.\d+\.\d+)'
    re_match_mask = 'inet6 [addr: ]*[a-fA-F0-9:]+\D+(\d+)' if is_ipv6 \
        else '[Mm]ask\D+(\d+\.\d+\.\d+\.\d+)'

    output = exe.block_run(('ifconfig %s' % iface))
    ip_addr_list = []
    ip_addr_list.append(re.search(re_match_ip, output).group(1))
    ip_addr_list.append(re.search(re_match_mask, output).group(1))

    return ip_addr_list if is_netmask else ip_addr_list[0]


def get_mac_addr(iface):
    """
    Get MAC address of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: MAC address in XX:XX:XX:XX:XX:XX format

    """
    output = exe.block_run(('ifconfig %s' % iface))

    try:
        # CTRL-40596: MAC Address is returned as None when using api get_mac_addr.
        # Use the correct regex to fetch the MAC address.
        return re.search('(ether|HWaddr)\s+([a-fA-F0-9:]+)', output).group(2)
    except:
        raise exception.IPException('Cannot find MAC address')


def set_mac_addr(iface, mac_addr):
    """
    Set MAC address of the interface

    Args:
        iface (str): ethX name
        mac_addr (str): New MAC address in XX:XX:XX:XX:XX:XX format

    """

    if not re.match(
        '[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}',
        mac_addr
    ):
        raise ValueError(
            'MAC address must be in XX:XX:XX:XX:XX:XX format (input: %s)'
            % mac_addr
        )

    exe.block_run('ifconfig %s hw ether %s' % (iface, mac_addr))


def get_flags(iface):
    """
    Get flag values of the interface.

    Args:
        iface (str): ethX name

    """

    output = exe.block_run('ifconfig %s' % iface)
    flags = re.search('(.*)[Mm][Tt][Uu]', output).group(1)
    flags = flags.strip()
    if re.search('([A-Z]+,.*[A-Z])', flags):
        return re.search('([A-Z]+,.*[A-Z])', flags).group(1).split(',')
    elif re.search('([A-Z].*[A-Z])', flags):
        return re.search('([A-Z ].*[A-Z])', flags).group(1).split(' ')

    raise exception.IPException('Cannot get flags')


def get_state(iface):
    """
    Return "State" of the interface

    Args:
        iface (str): ethX name

    Returns:
        str: State

    """

    flags = get_flags(iface)
    state = 'UP'
    if state in flags:
        return 'up'
    else:
        return 'down'


def get_mtu(iface):
    """
    Return MTU of the interface

    Args:
        iface (str): ethX name

    Returns:
        int: MTU size

    """

    output = exe.block_run('ifconfig %s' % iface)
    if re.search('mtu\s+(\d+)\s+', output):
        return int(re.search('mtu\s+(\d+)\s+', output).group(1))
    elif re.search('MTU:(\d+)\s+', output):
        return int(re.search('MTU:(\d+)\s+', output).group(1))

    raise exception.IPException('Cannot find MTU information')


def set_mtu(iface, mtu):
    """
    Set MTU of the interface

    Args:
        iface (str): ethX name
        mtu (int): MTU size

    """

    exe.block_run('ifconfig %s mtu %s' % (iface, mtu))


def set_state(iface, state):
    """
    Set "State" of the interface

    Args:
        iface (str): ethX name
        state (str): State to set ('up' or 'down').

    """

    exe.block_run('ifconfig %s %s' % (iface, state))
