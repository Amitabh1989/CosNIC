"""
:mod:`app_interface` --
===========================================

.. module:: controller.lib.linux.eth.app_interface
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""
import regex as re
import os
import multiprocessing
import socket
import struct
import json

from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.common.shell import exe
from controller.lib.common.eth.interface import BaseInterface
from controller.lib.linux.system import stats as sysstats
from controller.lib.linux.eth import ethtool

from .. import ip
from .. import stats as ethstats

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

log = log_handler.get_logger(__name__)

class AppInterface(BaseInterface):
    """
    Can control a single Ethernet interface using this object. Abstract
    backend and perform different interactions with a system depending on
    the method.

    This class uses ip, ifconfig and ethtool. To use specific application,
    should use the application wrapper instead of this.

    Args:
        iface (str): ethX name

    Returns:
        Interface: Interface object that has methods to interact with
            the Ethernet interface

    """

    def __init__(self, iface):
        super(AppInterface, self).__init__(iface)
        # CTRL-45522: [controller-0.3.9b.19] roce_driver_feature_stress.py fails as the offload
        # feature for tx-ipip-segmentation name changed in 216 driver.
        # Build a mapping between "extinct" and "existing" feature names.
        # Example: 'tx-ipip-segmentation' that is present till kernel 4.6 is renamed (split??) to
        # 'tx-ipxip4-segmentation' and 'tx-ipxip6-segmentation'. Also, 'tx-sit-segmentation' is
        # removed. So, ignore that.
        #
        # Notes:
        # [1] This map should be updated as and when the feature names change.
        # [2] Keep the mapped value in a list even though there's just one value.
        self.__feature_name_map = {
            'tx-ipip-segmentation': ['tx-ipxip4-segmentation'],
            'tx-sit-segmentation': []
            }

    def up(self):
        """
        Bring up the interface.

        """

        exe.block_run('ip link set %s up' % self.iface)

    def down(self):
        """
        Bring down the interface

        """

        exe.block_run('ip link set %s down' % self.iface)

    @property
    def ip_addr(self):
        """
        Return IPv4 address of the interface. Use "ip" but returns the only
        first IP address if there are multiple as IP alias to match the
        behavior with ifconfig.

        Returns:
            str: IP address of the interface
            None: If No IP address is assigned

        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface)
        return ip_addr_list[0].split('/')[0] if len(ip_addr_list) > 0 else None

    @ip_addr.setter
    def ip_addr(self, new_ip_addr):
        """
        Set IP address of the interface. use "ip" but behaves as ifconfig -
        namely

           * If no IP address was assigned, the new IP address will be assigned
           * If IP address was already assigned, the new IP address will
             replace it
           * If 'new_ip_addr' is 0.0.0.0, will remove the IP address

        To interact with "ip" directly, should use "ip" wrapper instead.

        Args:
            new_ip_addr (str): New IP address of the interface with subnet.
                format shuold be x.x.x.x/x

        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface)

        if len(ip_addr_list) > 0:
            log.debug('Remove IP addresses before assigning ... ')
            for ip_addr in ip_addr_list:
                ip.set_ip_addr(
                    iface=self.iface, ip_addr=ip_addr, method='del',
                ),

        if new_ip_addr is None or new_ip_addr == '0.0.0.0':
            return

        ip.set_ip_addr(iface=self.iface, ip_addr=new_ip_addr)

    @property
    def ip6_addr(self):
        """
        Return IPv6 addresses of the interface.
        Note that IOCTL does not support IPv6 - therefore using proc instead

        Returns:
            list: List of IPv6 addresses

        """

        return [
            ip6.split('/')[0] for ip6 in ip.get_ip_addr(
                iface=self.iface, ipv6=True)
        ]

    @ip6_addr.setter
    def ip6_addr(self, new_ip6_addr):
        """Add a new IPv6 address to the interface

        Args:
            new_ip6_addr (str): IPv6 address with prefix
        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface, ipv6=True)
        if len(ip_addr_list) > 0:
            log.debug('Remove IP addresses before assigning ... ')
            for ip_addr in ip_addr_list:
                ip.set_ip_addr(
                    iface=self.iface, ip_addr=ip_addr, method='del', ipv6=True)
        ip.set_ip_addr(
            iface=self.iface, ip_addr=new_ip6_addr, method='add', ipv6=True)

    def set_ip6_addr(self, new_ip6_addr, method, **kwargs):
        """
        Set IPv6 address to the given iface.

        Args:
            new_ip_addr (str): New IP address of the interface
                with prefix preceded by '/' (e.g. <ipv6 addr>/<prefix>)
            method (str): [add|change|replace|del] as "ip" command accepts to
                assign IP address.

        """

        ip.set_ip_addr(
            iface=self.iface, ip_addr=new_ip6_addr, method=method, ipv6=True)

    @property
    def netmask(self):
        """Return netmask of the interface.

        Returns:
            str: netmask of the interface

        """
        if not self.prefix:
            return None

        return socket.inet_ntoa(
            struct.pack(">I", (0xffffffff << (32 - self.prefix)) & 0xffffffff))

    @property
    def prefix(self):
        """Return prefix of the interface

        """
        ip_addr_list = ip.get_ip_addr(iface=self.iface)
        if len(ip_addr_list) > 0:
            # Return the first IP address / Netmask
            ip_addr, prefix = ip_addr_list[0].split('/')
            return int(prefix)

        return None

    @property
    def ip6_prefix(self):
        """Return IPv6 prefix of the interface as a dictionary.

        key is a IP address and value is the prefix, since it's expected to see
        multiple addresses
        """
        ret_dict = {}

        for ip6_addr in ip.get_ip_addr(iface=self.iface, ipv6=True):
            addr, prefix = ip6_addr.split('/')
            ret_dict[addr] = prefix

        return ret_dict

    @property
    def mac_addr(self):
        """
        Return MAC addres of the interface

        Returns:
            str: MAC address of the interface
        """

        return ip.get_mac_addr(iface=self.iface)

    @mac_addr.setter
    def mac_addr(self, new_mac_addr):
        """
        Set MAC address of the interface

        Args:
            new_mac_addr (str): New MAC address of the interface
            in XX:XX:XX:XX:XX:XX format

        """

        new_mac_addr = new_mac_addr.lower()
        ip.set_mac_addr(iface=self.iface, mac_addr=new_mac_addr)

    @property
    def state(self):
        """
        Return link status. 'up', 'down' and 'unknown'

        Returns:
            str: link status
        """
        print((self.iface))
        if not os.access(
            '/sys/class/net/%s/operstate' % self.iface, 0):
            raise exception.IPException('Cannot find the status of the interface.')

        with open(
            '/sys/class/net/%s/operstate' % self.iface, 'r'
            ) as fileobj:
            state = fileobj.read().strip()

        if state not in ['up','down']:
            raise exception.IPException('Cannot find the status of the interface.')
        return state

    @property
    def link_status(self):
        """
        Return link status. 'yes' or 'no' as per ethtool 'Link detected' output

        Returns:
            str: link status
        """
        return ethtool.link_status(iface=self.iface)

    @property
    def mtu(self):
        """
        Return MTU of the interface

        Returns:
            int: MTU of the interface

        """

        return ip.get_mtu(iface=self.iface)

    @mtu.setter
    def mtu(self, new_mtu):
        """
        Set MTU size of the interface

        Args:
            new_mtu (int): New MTU of the interface
        """

        ip.set_mtu(iface=self.iface, mtu=new_mtu)

    def supported_speeds(self):
        """
        Return the list of supported speeds on the network interface.
        :return:  List of tuples with each element containinng speed and duplex mode as values.
        """
        return ethtool.get_supported_speeds(iface=self.iface)

    @property
    def speed(self):
        """
        Return link speed of the interface. Use ethtool.

        Returns:
            int: link speed in Mb. -1 = unknown

        """

        return ethtool.get_speed(iface=self.iface)

    @speed.setter
    def speed(self, new_speed):
        """
        Set speed of the interface using ethtool, but speed/duplex together as
        "ethtool -s <iface> speed <new_speed> duplex <original duplex>"

        Args:
            new_speed (int): New speed of the interface

        """

        ethtool.set_speed(iface=self.iface, speed=new_speed)

    @property
    def duplex(self):
        """
        Return duplex mode of the interface. Use ethtool.

        Returns:
            str: dupldx mode. 0 = half, 1 = full, 0xff = unknown.
        """

        return ethtool.get_duplex(iface=self.iface)

    @duplex.setter
    def duplex(self, new_duplex):
        """
        Set duplex mode of the interface using ethtool, but speed/duplex
        together as "ethtool -s <iface> speed <original speed> <new_duplex>"

        Args:
            new_duplex (str): full/half

        """

        ethtool.set_duplex(
            iface=self.iface, duplex=new_duplex, speed=self.speed)

    @property
    def stats(self):
        """
        Return statistics of the interface. Use ethtool. Only return the
        basic unicast/multicast/broadcast statistics since it's not possible
        to know the NIC type here.

        Should use controller.lib.linux.eth.stats if you need to access TPA
        related counters.

        Returns:
            dict: key=parameter, value=value
        """

        return ethstats.get_stats(self.iface)

    @property
    def drvinfo(self):
        """
        Return driver information of the interface. Use ethtool.

        Return value should have following keys:

        * name: driver name
        * version: driver version
        * firmware: Optional. firmware information including name and version

        Returns:
            dict: driver information
        """
        return ethtool.get_drvinfo(iface=self.iface)

    def dump(self, **kwargs):
        """
        Dump the NIC property in dict.

        Returns:
            dict: key=param, value=value
        """

        attr_list = [
            'ip_addr', 'ip6_addr', 'netmask', 'mac_addr', 'state',
            'mtu', 'speed', 'duplex', 'drvinfo'
        ]

        ret_dict = {}

        for attr in attr_list:
            ret_dict[attr] = getattr(self, attr)

        return ret_dict

    @property
    def features(self):
        """
        Return ethtool -k output in dictionary.
        key is a name of feature and value is a tuple, which has below:

        <status> is etierh 'on' or 'off'
        <fixed> is True or False depending on it's a fixed value or not.

        Returns:
            dict: features

        """
        return ethtool.get_features(iface=self.iface)

    def set_feature(self, **kwargs):
        """
        Set offload feature settings. No error checking about changing settings
        for "fixed" features, but raise exe exception as it is.

        For example::

        >>> from controller.lib.linux import eth
        >>> eth1 = eth.get_interface('eth1')
        >>> eth1.set_features(**{'tx-checksum-ipv4': 'off'})

        Args:
            **kwargs (kwargs): key=feature name, value=value. Because feature
                names have some unsupported letters in names, should pass
                this argument as a dictionary
        """
        # CTRL-45522: [controller-0.3.9b.19] roce_driver_feature_stress.py fails as the offload
        # feature for tx-ipip-segmentation name changed in 216 driver.
        # If setting a feature fails, retry with its mapped name(s).
        try:
            ethtool.exec_ethtool(iface=self.iface, opt='-K', **kwargs)
        except Exception as e:
            if 'bad command line' in str(e):
                for key, value in list(kwargs.items()):
                    # If there's no mapped name for the feature, bail out.
                    if key not in self.__feature_name_map:
                        raise e

                    for mapped_feature_name in self.__feature_name_map.get(key, []):
                        ethtool.exec_ethtool(iface=self.iface, opt='-K', \
                            **{mapped_feature_name: value})
            else:
                raise e

    def set_features(self, param=None, value=None, param_dict=None):
        """For backward compatibility - same as set_feature()

        Args:
            param (str): A name of a parameter
            value (str): A new value for the parameter
            param_dict (dict): A dictionary where key=param and value=value.
                Can be used when changing multiple parameters at the same time.
                If this is given, param and value are ignored
        """

        if param_dict:
            return self.set_feature(**param_dict)

        if not param or not value:
            raise exception.ValueException(
                'Both "param" and "value" should be given')

        self.set_feature(**{param: value})

    @property
    def coalesce(self):
        """Return ethtool -c output in dictionary

        key is a name of parameter and value is integer, except adaptive rx/tx
        which has 'on' and 'off' as possible values

        """
        return ethtool.get_coalesce(iface=self.iface)

    def set_coalesce(self, param, value):
        """Set value of the coalesce parameter

        Acceptable parameter / values are as what coalesce() returns

        Args:
            param (str): parametner name i.e.) rx-frames
            value (str, int): str for adaptive rx/tx and integer for all other
                parameters

        """
        ethtool.set_coalesce(iface=self.iface, param=param, value=value)

    @property
    def interrupt(self):
        """Return interrupt numbers that are parsed from /proc/interrupts

        Return:
            dict: key=interrupt id, value=interrupt info including counters
        """

        int_matrix = [
            int_info['int'] for int_info in list(sysstats.get_nic_interrupt(
                iface=self.iface).values())]

        ret_value = {
            cpu_num: sum(int_num) for cpu_num, int_num in
            enumerate(zip(*int_matrix))}
        log.info('Interrupts %s' % ret_value)
        if any(isinstance(el, list) for el in list(ret_value.values())):
            for idx in range(0, len(list(ret_value.values()))):
                ret_value['total'] = sum(list(ret_value.values())[idx])
        else:
            ret_value['total'] = sum(ret_value.values())
        return ret_value

    @property
    def smp_affinity(self):
        """Return CPU affinity list

        Return:
            dict: key=interrupt id, value=affinity in list of CPU index. i.e.)
                [0,6] means the affinity is set to CPU 0 and CPU 6
        """
        ret_dict = {}

        for int_id, info in list(sysstats.get_nic_interrupt(
                iface=self.iface).items()):
            with open('/proc/irq/%s/smp_affinity' % int_id, 'r') as \
                    fileobj:
                output = fileobj.read().strip().replace(',', '')
                smp_affinity = bin(int(output, 16))[:1:-1]
                smp_affinity_idx = [
                    idx for idx, bit in enumerate(smp_affinity) if int(bit) is 1
                ]
                smp_affinity_idx.sort()
                ret_dict[int_id] = smp_affinity_idx

        return ret_dict

    @smp_affinity.setter
    def smp_affinity(self, affinity_dict):
        """Set affinitiy list

        Args:
            affinity_dict: key=interrupt id, value=affinity in list of CPU
                index. i.e.) [0,6] will set affinity to CPU 0 and CPU 6
        """

        for int_id, affinity_list in list(affinity_dict.items()):
            with open('/proc/irq/%s/smp_affinity_list' % int_id, 'w') as fileobj:
                fileobj.write(','.join(map(str, affinity_list)))

            # bit_list = ['1' if bit in affinity_list else '0' for bit in range(
            #     multiprocessing.cpu_count())]
            # bit_list.reverse()
            # with open('/proc/irq/%s/smp_affinity' % int_id, 'w') as fileobj:
            #     fileobj.write(
            #         format(int(''.join(bit_list), 2), 'x')
            #     )

    @property
    def netstat(self):
        """Return /proc/net/netstat

        Return:
            dict: key=parameter, value=value
        """
        ret_dict = {}
        with open('/proc/net/netstat', 'r') as fileobj:
            netstat = fileobj.read()

        tcp_header, tcp_value, ip_header, ip_value = netstat.splitlines()

        for param, value in zip(tcp_header.split(), tcp_value.split()):
            ret_dict[param] = value

        for param, value in zip(ip_header.split(), ip_value.split()):
            ret_dict[param] = value

        return ret_dict

    @property
    def snmp(self):
        """Return /proc/net/snmp

        Return:
            dict: key=parameter, value=value
        """
        ret_dict = {}
        with open('/proc/net/snmp', 'r') as fileobj:
            snmp = fileobj.read()

        key_list = ['Ip', 'Icmp', 'IcmpMsg', 'Tcp', 'Udp', 'UdpLite']

        for key in key_list:
            output = re.findall('%s: (.*)' % key, snmp)
            if len(output) != 0:
                header, value = output
                ret_dict[key.lower()] = dict(list(zip(
                    header.split(),
                    [int(v) for v in value.split()]
                    )))

        return ret_dict

    @property
    def flow_control(self):
        """Return the flow control setting"""
        setting = ethtool.get_pause(self.iface)
        if setting['autoneg'] == 'on':
            return 'auto_neg'
        elif setting['rx'] == 'on' and setting['tx'] == 'off':
            return 'rx'
        elif setting['rx'] == 'on' and setting['tx'] == 'on':
            return 'rx_tx'
        elif setting['rx'] == 'off' and setting['tx'] == 'on':
            return 'tx'
        else:
            return 'disabled'

    @flow_control.setter
    def flow_control(self, new_mode):
        """Set the flow control to the new setting"""
        try:
            if new_mode == 'rx':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='on', tx='off')
            elif new_mode == 'tx':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='off', tx='on')
            elif new_mode == 'rx_tx':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='on', tx='on')
            elif new_mode == 'auto_neg':
                ethtool.exec_ethtool(
                    iface=self.iface, opt='-A', autoneg='on')
            elif new_mode == 'disabled':
                ethtool.exec_ethtool(
                    iface=self.iface,
                    opt='-A', autoneg='off', rx='off', tx='off')

        except exception.EthtoolNoChanges:
            pass

    @property
    def route(self):
        """Return route information of the current iface using
        /proc/net/route. No IPv6 support yet.

        Return:
            list: List of routing entries for iface

        """
        ret_dict = {}
        with open('/proc/net/route', 'r') as fileobj:
            route_output = fileobj.read().strip().splitlines()

        header_list = [header.lower() for header in route_output.pop(0).split()]

        for line in route_output:
            print(line)
            data = line.split()
            iface = data[0]

            if not iface in ret_dict:
                ret_dict[iface] = []
            data_dict = {}

            for idx, header in enumerate(header_list):
                if header in ['destination', 'gateway', 'mask']:
                    data_dict[header] = socket.inet_ntoa(
                        struct.pack('<L', int(data[idx], 16))
                    )
                else:
                    data_dict[header] = data[idx]

            ret_dict[iface].append(data_dict)
            print(ret_dict)

        if self.iface not in ret_dict:
            return None  # No routing table for the interface. Return None.

        return ret_dict[self.iface]

    def set_route(self, method, dst, gateway=None):
        ip.set_route(self.iface, method, dst, gateway)

    @property
    def sysclass_stats(self):
        """Statistics information from /sys/class/net/<eth_name>/statistics
        """
        dir_path = '/sys/class/net/%s/statistics' % self.iface
        ret_dict = {}

        for stats_name in os.listdir(dir_path):
            with open(dir_path + '/' + stats_name, 'r') as fileobj:
                ret_dict[stats_name] = int(fileobj.read().strip())

        return ret_dict

    @property
    def queue(self):
        """Return queue settings"""
        curset = ethtool.get_channels(self.iface)['curset']
        return {'rx': curset['rx'], 'tx': curset['tx']}

    @queue.setter
    def queue(self, queue_dict):
        """Configure the channel using the given parameter.

        Args:
            queue_dict (dict): {'rx': <rx_queue_num>, 'tx': <tx_queue_num>}
        """
        ethtool.set_channels(self.iface, queue_dict)

    @property
    def channel(self):
        """Return channel settings
        """
        return ethtool.get_channels(self.iface)

    @channel.setter
    def channel(self, channel_settings):
        """Configure the channel using the given parameter.

        Args:
            channel_settings (dict): new channel settings. The format of the
                expected channel_settings is same as the return value of
                get_channels()
        """
        ethtool.set_channels(self.iface, channel_settings)

    @property
    def ring(self):
        """ Return ring settings
        """
        return ethtool.get_ring(self.iface)

    @ring.setter
    def ring(self, ring_settings=None):
        """ Configure the ring parameters using the dictionary argument
        """
        ethtool.set_ring(self.iface, ring_settings)

    @property
    def medium(self):
        """Return the transmission medium type [FIBRE/TP]

        """
        return ethtool.get_iface_medium(iface=self.iface)

    def ring_sizes(self):
        """ Return ring sizes individually
        """
        curset = ethtool.get_ring(self.iface)
        return {'rx':curset['rx'], 'tx':curset['tx'], 'rx-jumbo':curset['rx jumbo']}

    def set_ethtool(self, opt, order=None, **kwargs):
        """Proxy to controller.lib.linux.eth.ethtool.exec_ethtool

        Args:
            opt (str): option that will be passed to ethtool. i.e.) '-s'
            order (list): List of keys in kwargs so the parameters are provided
                in order as defined here
            kwargs (kwargs): keyword arguments which key=parameter value=
                value. i.e.) set_ethtool('-s', speed=40000, duplex='half') will
                run ethtool -s <iface> speed 40000 duplex half. Note that no
                order of the options is guaranteed, so you need to pass "order"
                if you need to keep the order of parameters.

        """
        return ethtool.exec_ethtool(
            iface=self.iface, opt=opt, order=order, **kwargs)

    def ping(self, dst_ip, count=10, **kwargs):
        """Ping the remote host"""

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        try:
            exe.block_run('ping -c %s %s %s' % (
                count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def iface_ping(self, dst_ip, count=10, **kwargs):
        """ Ping to the remote host from a specific interface
        """

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        try:
            exe.block_run('ping -I %s -c %s %s %s' % (
                self.iface, count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def ping6(self, dst_ip, count=10, **kwargs):
        """Ping over IPv6 to remote host"""
        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())
        ]

        try:
            exe.block_run('ping6 -c %s %s %s' % (
                count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def iface_ping6(self, dst_ip, count=10, **kwargs):
        """Ping over IPv6 to remote host"""
        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())
        ]

        try:
            exe.block_run('ping6 -I %s -c %s %s %s' % (
                self.iface, count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        return True

    def add_vlan(self, vlan_id):
        """Add VLAN using the given VLAN ID"""
        return ip.add_vlan(iface=self.iface, vlan_id=vlan_id)


    def remove_vlan(self, vlan_id):
        """Delete VLAN using the given VLAN ID"""
        ip.remove_vlan(iface=self.iface, vlan_id=vlan_id)

    @property
    def vlan_iface_list(self):
        ret_list = []

        for iface in get_interfaces():
            if re.match(self.name + '\.(\d+)', iface):
                vlan_iface = self.__class__(iface=iface)
                ret_list.append(vlan_iface)

        return ret_list

    @property
    def vlan_id(self):
        """Return a VLAN ID using the iface name

        Namely this interface should have been created using add_vlan() - if
        this is manually created and does not have the expected VLAN interface
        name format (<parent>.<vlan_id), then this will not work.
        """
        vlan_iface = self.iface.split('.')

        if len(vlan_iface) == 1:
            return None

        return int('.'.join(vlan_iface[1:]))  # Return the last VLAN ID

    @property
    def sriov(self):
        """Return a number of VFs and total VFs.

        {
            'num': <sriov_numbfs>
            'total': <sriov_totalvfs>
        }

        If SR-IOV is not enabled, return None
        """

        if not os.access(
                '/sys/class/net/%s/device/sriov_totalvfs' % self.iface, 0):
            return None

        ret_dict = {}

        with open(
            '/sys/class/net/%s/device/sriov_numvfs' % self.iface, 'r'
        ) as fileobj:
            ret_dict['num'] = int(fileobj.read().strip())

        with open(
            '/sys/class/net/%s/device/sriov_totalvfs' % self.iface, 'r'
        ) as fileobj:
            ret_dict['total'] = int(fileobj.read().strip())

        return ret_dict

    @sriov.setter
    def sriov(self, new_num):
        """Set the number of VFs"""
        if not os.access(
                '/sys/class/net/%s/device/sriov_totalvfs' % self.iface, 0):
            raise exception.ConfigException('SR-IOV is disabled')

        with open(
            '/sys/class/net/%s/device/sriov_numvfs' % self.iface, 'w'
        ) as fileobj:
            fileobj.write(str(new_num))

    @property
    def pcidevice(self):
        """ Return PCI device name"""
        if not os.access(
                        '/sys/class/net/%s' % self.iface, 0):
            return None
        return os.path.realpath('/sys/class/net/%s' %(self.iface)).split("/")[-3]

    @property
    def local_cpulist(self):
        if not os.access(
                '/sys/class/net/%s/device/local_cpulist' % self.iface, 0):
            return None

        with open(
            '/sys/class/net/%s/device/local_cpulist' % self.iface, 'r'
        ) as fileobj:
            cpu_list = fileobj.read().strip().split(',')
            cpu_ranges = [cpu for cpu in cpu_list if '-' in cpu]
            cpu_list = [int(cpu) for cpu in cpu_list if '-' not in cpu]
            for cpu in cpu_ranges:
                start, end = cpu.split('-')
                cpu_list.extend(list(range(int(start), int(end)+1)))
        return sorted(cpu_list)

    @property
    def numa_node(self):
        if not os.access(
                '/sys/class/net/%s/device/numa_node' % self.iface, 0):
            return None

        with open(
            '/sys/class/net/%s/device/numa_node' % self.iface, 'r'
        ) as fileobj:
            numa_node = fileobj.read().strip()
        return int(numa_node)

    def devlink(self, mode='switchdev'):
        """Set iface to switchdev mode"""
        exe.block_run('devlink dev eswitch set pci/%s mode %s' % (self.pcidevice, mode))

    def vf_reps(self):
        """Return the names of VF representors along with the details returned by `get_vfs_info`.

        This function uses OS commands and should be called on the host, e.g. via rpyc.

        Output format is:
        .. code-block:
            {
                0: {
                    'businfo': '0000:98:00.0',
                    'name': 'p2p1_0',
                    'mac': '00:01:02:03:04:05',
                    'vfr_name': 'eth0'
                },
                1: {
                    'businfo': '0000:98:00.1',
                    'name': 'p2p1_1',
                    'mac': '00:01:02:03:04:06',
                    'vfr_name': 'eth1'
                }
            }

        :param interface: The name of the interface to get the VF representor info of.
        :return: A dict containing the info of VF representors.
        """
        _sysfs_net = '/sys/class/net'
        vf_list = self.vf_list
        vf_rep_info = {}

        vf_id = 0
        for vf_name, vf_pci in vf_list.items():
            vf_rep_info[vf_id] = {}
            vf_rep_info[vf_id]['name'] = vf_name
            vf_rep_info[vf_id]['businfo'] = vf_pci
            vf_rep_info[vf_id]['vfr_name'] = 'unavailable'
            vf_id += 1

        with open(f'{_sysfs_net}/{self.iface}/phys_switch_id', 'r') as f:
            pf_switch_id = f.read().strip()

        with open(f'{_sysfs_net}/{self.iface}/phys_port_name', 'r') as f:
            pf_port_id = re.findall(r"pf?(\d+)", f.read().strip())[0]

        sysfs_net_entries = os.walk(_sysfs_net)

        for _, ifaces, _ in sysfs_net_entries:
            for iface in ifaces:
                if iface != self.iface:
                    try:
                        with open(f'{_sysfs_net}/{iface}/phys_switch_id', 'r') as f:
                            switch_id = f.read().strip()

                        if switch_id == pf_switch_id:
                            with open(f'{_sysfs_net}/{iface}/phys_port_name', 'r') as f:
                                port_name = f.read().strip()
                                func_ids = re.search(r'pf?(\d)vf?(\d+)', port_name)
                                if func_ids:
                                    pf_id = func_ids.group(1)
                                    vf_id = int(func_ids.group(2))
                                    if pf_id == pf_port_id:
                                        vf_rep_info[vf_id]['vfr_name'] = iface

                    except OSError:
                        pass

        log.debug(f'VF representor info of {self.iface}: {vf_rep_info}.')
        return vf_rep_info

    @property
    def vf_list(self):
        from collections import OrderedDict
        from controller.lib.linux import eth
        pci_dev_vfs_list = OrderedDict()
        vf_pci_devids = {}
        pf_pci_id = os.path.realpath('/sys/class/net/%s/device' % self.iface).split('/')[-1]
        for vf_iface in eth.get_interfaces_by_driver('bnxt_en'):
            vf_phy_pci_id = os.path.realpath('/sys/class/net/%s/device/physfn' % vf_iface.name).split('/')[-1]
            if pf_pci_id == vf_phy_pci_id:
                vf_pci_id = os.path.realpath('/sys/class/net/%s/device' % vf_iface.name).split('/')[-1]
                vf_pci_devids[vf_pci_id] = vf_iface.name
                vf_iface.up()

        for pci_id, vf_name in sorted(vf_pci_devids.items()):
            pci_dev_vfs_list[vf_name] = pci_id
        return pci_dev_vfs_list

    @property
    def phys_switch_id(self):
        """vib id information from /sys/class/net/<eth_name>/phys_switch_id
        """
        if not os.access('/sys/class/net/%s/phys_switch_id' % self.iface, 0):
            raise exception.IPException('Cannot find the vib id of the interface.')

        with open('/sys/class/net/%s/phys_switch_id' % self.iface, 'r') as fileobj:
            phys_switch_id = fileobj.read().strip()
        return phys_switch_id

    def set_roce_version(self, v2=True):
        from controller.lib.linux.eth.interface import app_interface
        if v2:
            log.info('Setting RoCE Version to V2...')
            version = 'RoCE v2'
        else:
            log.info('Setting RoCE Version to V1...')
            version = 'IB/RoCE v1'
        ctrl_iface = app_interface.AppInterface(self.iface)
        roce_iface = ctrl_iface.roce
        if not os.access('/sys/kernel/config/rdma_cm/', 0):
            raise exception.ConfigException('rdma_cm is not loaded! '
                                            'Please load the RoCE Driver, which calls the rdma_cm driver')
        if not os.access('/sys/kernel/config/rdma_cm/%s' % roce_iface, 0):
            os.makedirs('/sys/kernel/config/rdma_cm/%s' % roce_iface)
        port = os.listdir('/sys/class/net/%s/device/infiniband/%s/ports/' % (self.iface, roce_iface))[0]
        fo = open('/sys/kernel/config/rdma_cm/%s/ports/%s/default_roce_mode' % (roce_iface, port), 'w')
        fo.write(version)
        fo.close()

    @property
    def roce(self):
        """ Return the associated roce interface """
        if not os.access(
                '/sys/class/net/%s/device/infiniband/' % self.iface, 0):
            raise exception.ConfigException('Infiniband not found!'
                        'Please make sure RoCE Lib is installed or the interface is UP')
        cwd = os.getcwd()
        os.chdir('/sys/class/net/%s/device/infiniband/' % self.iface)
        roce_iface = os.listdir('.')[0]
        """ Revert back to the original directory """
        os.chdir(cwd)
        return roce_iface

    @property
    def roce_state(self):
        """ Return the state of the RoCE interface """
        from controller.lib.linux.eth.interface import app_interface
        ctrl_iface = app_interface.AppInterface(self.iface)
        if not os.access(
                '/sys/class/net/%s/device/infiniband/' % self.iface, 0):
            if ctrl_iface.state != 'down':
                raise exception.ConfigException('Cannot get State of the RoCE interface')
            else:
                log.warning('The physical interface is DOWN!'
                                'Hence the RoCE interface will also be DOWN')
                return 'down'
        roce_iface = ctrl_iface.roce
        port = os.listdir('/sys/class/net/%s/device/infiniband/%s/ports/' % (self.iface, roce_iface))[0]
        fo = open('/sys/class/net/%s/device/infiniband/%s/ports/%s/state' % (self.iface, roce_iface, port), 'r')
        state = fo.read().split(':')[1].strip()
        fo.close()
        return state.lower()

    def roce_gid(self, ip_addr):
        """ Return a list of GUID indices for the RoCE interface """
        from controller.lib.linux.eth.interface import app_interface
        ctrl_iface = app_interface.AppInterface(self.iface)
        if not os.access(
                '/sys/class/net/%s/device/infiniband/' % self.iface, 0):
            raise exception.ConfigException('Infiniband not found!'
                        'Please make sure RoCE Lib is installed or the interface is UP')
        cwd = os.getcwd()
        roce_iface = ctrl_iface.roce
        port = os.listdir('/sys/class/net/%s/device/infiniband/%s/ports/' % (self.iface, roce_iface))[0]
        gid_list = os.listdir('/sys/class/net/%s/device/infiniband/%s/ports/%s/gids/' % (self.iface, roce_iface, port))
        idx = 0
        gid_idx_list = []
        for gid in gid_list:
            fo = open('/sys/class/net/%s/device/infiniband/%s/ports/%s/gids/%s' % (self.iface, roce_iface, port, gid), 'r')
            f_gid = fo.read()
            fo.close()
            if int(''.join(f_gid.strip().split(':')), 16) != 0:
                # Map the gid to the ip_addr and return the gid index list
                gidx_list = f_gid.strip().split(':')
                if int(gidx_list[0], 16) != 0:
                    idx += 1
                    continue
                sub_net3 = str(int(gidx_list[-1][2:], 16))
                sub_net2 = str(int(gidx_list[-1][:2], 16))
                sub_net1 = str(int(gidx_list[-2][2:], 16))
                net = str(int(gidx_list[-2][:2], 16))
                gid_ip = '%s.%s.%s.%s' % (net, sub_net1, sub_net2, sub_net3)
                x_ip_addr = ip_addr[0] if type(ip_addr) is list else ip_addr
                if gid_ip in x_ip_addr:
                    log.debug(gidx_list)
                    log.debug(gid_ip)
                    log.debug(idx)
                    gid_idx_list.append(gid)
                idx += 1
                #id_idx.append(gid)
        return sorted(gid_idx_list)

    def roce_v1_gid(self, ip_addr=None):
        """ Return a list of RoCE V1 gids for the RoCE interface """
        from controller.lib.linux.eth.interface import app_interface
        ctrl_iface = app_interface.AppInterface(self.iface)
        gid_list = ctrl_iface.roce_gid(ctrl_iface.ip_addr if not ip_addr else ip_addr)
        if len(gid_list) == 1:
            raise exception.HostException('RoCE V1 support is deprecated. %s' %gid_list)

    def roce_v2_gid(self, ip_addr=None):
        """ Return a list of RoCE V2 gids for the RoCE interface """
        from controller.lib.linux.eth.interface import app_interface
        ctrl_iface = app_interface.AppInterface(self.iface)
        gid_list = ctrl_iface.roce_gid(ctrl_iface.ip_addr if not ip_addr else ip_addr)
        if gid_list:
            return gid_list[-1]
        else:
            raise exception.HostException('RoCE Gid not found. %s' % gid_list)

    @property
    def roce_stats(self):
        """ Return the stats of the RoCE interface """
        from controller.lib.linux.eth.interface import app_interface
        ctrl_iface = app_interface.AppInterface(self.iface)
        roce_iface = ctrl_iface.roce
        pDict = {}
        try:
            # CTRL-44212: Update roce and l2roce test script to adhere to changes went in
            # CTRL-40297.
            # Use the device specific stats file to collect the stats. IF this doesn't work,
            # fall back to the old style driver-level stats file for backwards compatibility.
            if not os.access('/sys/kernel/debug/bnxt_re/%s/info' % roce_iface, 0):
                if not os.access('/sys/kernel/debug/bnxt_re/info', 0):
                    raise exception.ConfigException('RoCE Stats not found! Is RoCE lib installed?')

                fo = open('/sys/kernel/debug/bnxt_re/info', 'r')
            else:
                fo = open('/sys/kernel/debug/bnxt_re/%s/info' % roce_iface, 'r')

            roce_info = fo.read()
            fo.close()
            device = False

            for line in roce_info.splitlines():
                if line.find('IBDEV %s' % roce_iface) != -1:
                    device = True
                    continue

                if device == True:
                    if len(line.split(':', 2)) > 1:
                        (key, val) = line.split(':', 2)
                        pDict[key.strip()] = val.strip()

                    if line.find('IBDEV') != -1:
                        device = False
                        break
        except:
            pass
            log.warning('Setups appears to be using inbox drivers.')
        try:
            if not pDict:
                pDict['Rx Pkts'] = str(exe.block_run('cat /sys/class/infiniband/' + roce_iface +
                                                     '/ports/1/hw_counters/rx_pkts'))
                pDict['Tx Pkts'] = str(exe.block_run('cat /sys/class/infiniband/' + roce_iface +
                                                     '/ports/1/hw_counters/tx_pkts'))
                pDict['Active QP'] = str(exe.block_run('cat /sys/class/infiniband/' + roce_iface +
                                                       '/ports/1/hw_counters/active_qps'))

                command_output = exe.block_run('ibv_devinfo -v -d %s' % roce_iface).strip()
                pDict['Max QP'] = str(re.search(r'max_qp:\s+(.*)', command_output).group(1))
        except:
            log.error('Setup doesn\'t appear to support statistics.')
        log.debug('roce stats %s' % pDict)
        return pDict

    @property
    def roce_stats_sys_device(self):
        """ Return the stats of the RoCE interface """
        roce_iface = self.roce
        pDict = {}
        try:
            sys_device_cmd_output = exe.block_run('rdma stat show link %s -j' %roce_iface)
            pDict = json.loads(sys_device_cmd_output)[0]
        except:
            raise exception.ConfigException('Setup doesn\'t appear to support statistics.')
        log.debug('roce stats %s' % pDict)
        return pDict

    @property
    def qPairs(self):
        """ Return the number of Active Queue Pairs of the RoCE interface """
        from controller.lib.linux.eth.interface import app_interface
        ctrl_iface = app_interface.AppInterface(self.iface)
        stats = ctrl_iface.roce_stats
        qp = {}
        if stats:
            qp['Active QP'] = str(stats['Active QP'])
            qp['Max QP'] = str(int(stats['Max QP'], 16))
        return qp

    def vf_stats(self, vf_id):
        """
        This method fetches stats of given VF using /sys/class/net command
        :param vf_id: vf number of which stats needs to be fetched
        :return: stats of VF in dict format
        """
        output = exe.block_run(f"cat /sys/class/net/{self.iface}/device/sriov/{vf_id}/stats")
        my_dict = {}
        arr = re.findall(r'(.*)\s:(.*)', output)
        if arr:
            for key, value in arr:
                key = key.strip()
                value = value.strip()
                key = re.sub(r'\s', "_", key)
                my_dict[key] = value
        return my_dict

    @property
    def get_udcc_sessions(self):
        """

        @return: list (list of udcc sessions for the iface)
        """
        from controller.lib.linux.eth.interface import app_interface

        ctrl_iface = app_interface.AppInterface(self.iface)
        event_path = f"/sys/kernel/debug/bnxt_re/{ctrl_iface.pcidevice}/udcc"
        if not os.access(event_path, 0):
            return None
        event_list = exe.block_run(f"ls {event_path}", shell=True).splitlines()
        return event_list

    def udcc_stats(self, event_no):
        """

        @param event_no: str (udcc event for which the event_details are required)
        @return: dict (event details in form of dict)
        """

        from controller.lib.linux.eth.interface import app_interface

        event_details = dict()
        ctrl_iface = app_interface.AppInterface(self.iface)
        event_session_path = f"/sys/kernel/debug/bnxt_re/{ctrl_iface.pcidevice}/udcc/{event_no}/session_query"
        if not os.access(event_session_path, 0):
            return None
        event_info = exe.block_run(f"cat {event_session_path}", shell=True)
        if event_info:
            for line in event_info.splitlines():
                if '=' in line:
                    event_name, event_value = line.split('=', 1)
                    event_details[event_name.strip()] = event_value.strip()
        return event_details


def get_interface_by_driver(driver):
    """Return a list of ethX that uses the given driver

    Args:
        driver (str): driver name

    Return:
        list: list of ethX names
    """

    from .interface.app_interface import AppInterface
    ret_list = []
    for iface in os.listdir('/sys/class/net'):
        iface_driver = os.path.realpath(
            '/sys/class/net/%s/device/driver' % iface).split('/')[-1]
        if driver == iface_driver:
            ret_list.append(AppInterface(iface=eth))

    return ret_list


def get_interfaces():
    """Simply return all ethX interface names
    """

    return os.listdir('/sys/class/net')
