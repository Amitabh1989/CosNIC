"""
:mod:`ip` -- Linux tool 'ip' wrapper
====================================

.. module:: controller.lib.linux.eth.ip
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This module is a simple wrapper around 'ip' tool which can be used for
configuring IP address, routing, etc.

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import re
import ipaddress
from typing import Callable
import json

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.linux import set_default_cli


log = log_handler.get_logger(__name__)
the_exe = exe


def trim_iface_name(function):
    """
    The decorator that trims the interface name if it's larger than 15 bytes as newer versions of
    "ip" tool expect interface names to be < 15 bytes.
    """
    # CTRL-45596: [controller-0.3.9b19] Many vlan scripts failing as STAT tried to create vlan
    # interfaces which exceeds MAX limit of 15 characters for interface name created via "ip link".
    # Use the trimmed interface name to work with newer "ip" command.
    def inner(iface, *args, **kwargs):
        iface = iface[-15:]
        return function(iface, *args, **kwargs)

    return inner


def use_ssh(ssh_ip_addr=None):
    """
    The function that selects the method to use to run the ip commands. If ssh_ip_address is
    specified, an SSH connection to that IP adress is established and that connection is used to
    run the ip commands. Otherwise, the usual shell exe module is used.

    Args:
        ssh_ip_addr (str): The IP address to use for running ip commands over SSH. When None, the
        SSH mode is exited.

    Caution:
        It is the responsibility of the caller to reset the SSH mode by calling this function
        with ssh_ip_addr=None.
    """
    from controller.lib.linux.system import ssh
    global the_exe

    if ssh_ip_addr is not None:
        the_exe = ssh.SSH(ssh_ip_addr)
    else:
        if isinstance(the_exe, ssh.SSH):
            the_exe.disconnect()

        the_exe = exe


@trim_iface_name
def up(iface):
    """ Bring up the interface

    Args:
        iface (str): ethX name

    """
    the_exe.block_run('ip link set dev %s up' % iface)


@trim_iface_name
def down(iface):
    """ Bring down the interface

    Args:
        iface (str): ethX name
    """
    the_exe.block_run('ip link set dev %s down' % iface)


@trim_iface_name
def set_ip_addr(iface, ip_addr, method='add', ipv6=False):
    """
    Set IP address to the given iface. Not using IOCTL to test the application
    layer, namely "ip"

    Args:
        iface (str): ethX name
        ip_addr (str): IP address in the X.X.X.X/X format which includes subnet
        method (str): [add|change|replace|del] as "ip" command accepts to
           assign a new IP address.
        ipv6 (bool): Configure IPv6 address if True else IPv4

    Returns:
        str: Output of ip command

    """
    # convert the ip_addr to ip_addr and netmask
    try:
        ip_addr, netmask = ip_addr.split('/')
    except ValueError as err:
        raise exception.ValueException(
            'Invalid IP address/netmask argument %s. Must be x.x.x.x/x format' % ip_addr)

    if isinstance(netmask, str) and re.match(r'\d+\.\d+\.\d+\.\d+', netmask):
        netmask = sum([bin(int(x)).count('1') for x in netmask.split('.')])

    ip_addr = '%s/%s' % (ip_addr, netmask)
    # Do not check parameter values further. Let "ip" tool raise exceptions
    # if any parameters are incorrect.
    try:
        return the_exe.block_run('ip %s addr %s %s dev %s' % ('-6' if ipv6 else '', method, ip_addr, iface))
    except exception.ExeExitcodeException as err:
        if 'File exists' in err.output:
            raise exception.IPFileExists('Same IP address is already assigned. Output: %s' % err.output)
        raise  # Raise all other exception types


@trim_iface_name
def get_ip_addr(iface, ipv6=False):
    """
    Return a list of IP addresses.

    Args:
        iface (str): ethX name
        ipv6 (bool): Get IPv6 address if True else IPv4

    Returns:
        list: IP addresses
        list: tuple of (IP address, netmask) if netmask is True

    """
    try:
        output = the_exe.block_run('ip addr show dev %s' % iface)
    except Exception:
        return []
    re_match = r'inet6\s+([a-f0-9:]+)/?(\d+)?' if ipv6 \
        else r'inet\s+(\d+\.\d+\.\d+\.\d+)/?(\d+)?'

    return [
        '%s%s' % (ip_addr, '/%s' % netmask if netmask else '') for ip_addr, netmask in
        re.findall(re_match, output)
    ]


@trim_iface_name
def get_mac_addr(iface):
    """
    Get MAC address of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: MAC address in XX:XX:XX:XX:XX:XX format

    """
    output = the_exe.block_run(('ip link show dev %s' % iface))

    try:
        return re.search('link/ether\s+([a-f0-9:]+)', output).group(1)
    except Exception:
        raise exception.IPException('Cannot find MAC address')


@trim_iface_name
def set_mac_addr(iface, mac_addr):
    """
    Set MAC address of the interface

    Args:
        iface (str): ethX name
        mac_addr (str): New MAC address in XX:XX:XX:XX:XX:XX format

    """
    if not re.match(
        '[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:'
        '[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}',
        mac_addr
    ):
        raise ValueError('MAC address must be in XX:XX:XX:XX:XX:XX format (input: %s)' % mac_addr)

    the_exe.block_run('ip link set dev %s address %s' % (iface, mac_addr))


@trim_iface_name
def get_flags(iface):
    """
    Get flag values of the interface.

    Args:
        iface (str): ethX name

    """
    output = the_exe.block_run('ip link show dev %s' % iface)

    if re.search('%s: <(.*)> mtu', output):
        return re.search('%s: <(.*)> mtu', output).group(1).split(',')

    raise exception.IPException('Cannot get flags')


@trim_iface_name
def get_state(iface):
    """
    Return "State" of the interface

    Args:
        iface (str): ethX name

    Returns:
        str: state ( up or down ).

    """
    output = the_exe.block_run('ip addr show dev %s' % iface)

    try:
        return re.search(r'state\s([A-Z]+)', str(output)).group(1).lower()
    except Exception:
        raise exception.IPException('Cannot find link state information')


@trim_iface_name
def get_mtu(iface):
    """
    Return MTU of the interface

    Args:
        iface (str): ethX name

    Returns:
        int: MTU size

    """
    output = the_exe.block_run('ip link show dev %s' % iface)

    try:
        return int(re.search(r'mtu\s+(\d+)\s+', output).group(1))
    except Exception:
        raise exception.IPException('Cannot find MTU information')


@trim_iface_name
def set_mtu(iface, mtu):
    """
    Set MTU of the interface

    Args:
        iface (str): ethX name
        mtu (int): MTU size

    """
    the_exe.block_run('ip link set mtu %s dev %s' % (mtu, iface))


@trim_iface_name
def add_veth_pair(endpoint1, endpoint2):
    """
    veth devices are created in interconnected pairs.

    Args:
        endpoint1 (str): veth endpoint1 name
        endpoint2 (str): veth endpoint2 name

    """
    the_exe.block_run('ip link add %s type veth peer name %s' % (endpoint1, endpoint2))


@trim_iface_name
def add_vlan(iface, vlan_id, lower_kernel=False, name=None, proto='802.1Q'):
    """
    Remove vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID
        lower_kernel (bool): set True for lower kernels
        name (str): Name for Vlan interface
        proto (str): Proto for Vlan interface
    """
    if not lower_kernel:
        if name:
            vlan_name = name
        else:
            vlan_name = iface + '.' + str(vlan_id)

        vlan_name = vlan_name[-15:]
        command = 'ip link add link %s name %s type vlan id %s proto %s' % \
            (iface, vlan_name, vlan_id, proto)
    else:
        command = 'vconfig add %s %s' % (iface, vlan_id)

    try:
        the_exe.block_run(command)
    except exception.ExeExitcodeException as e:
        if 'is unknown,' in e.output:
            # OS is RHEL5 where ip link delete command is not supported. Shall execute
            # vconfig command
            add_vlan(iface, vlan_id, lower_kernel=True)
        # CTRL-46702: [Automation-RoCE]: Script fails while trying to add already existing vlan
        # interface.
        # If vLAN interface already exists, ignore the error and reuse it.
        elif 'File exists' in e.output:
            log.info("VLAN ID %s already exists" % vlan_id)
        else:
            raise exception.IPException('Unable to add vlan. Output: %s' % e)
    except exception.IPFileExists:
        log.info("VLAN ID %s already exists" % vlan_id)

    return vlan_name


def remove_vlan(iface=None, vlan_id=None, vlan_name=None, lower_kernel=False):
    """
    Remove vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID
        vlan_name (str): vlan interface name
        lower_kernel (bool): set True if testing with lower kernel
    """
    if vlan_name:
        host_vlan = vlan_name
    else:
        host_vlan = iface + '.' + str(vlan_id)

    host_vlan = host_vlan[-15:]

    if not lower_kernel:
        command = 'ip link delete %s ' % host_vlan
    else:
        command = 'vconfig rem %s' % host_vlan

    try:
        the_exe.block_run(command)
    except exception.ExeExitcodeException as e:
        if 'is unknown,' in e.output:
            # OS is RHEL5 where ip link delete command is not supported. Shall execute
            # vconfig command
            remove_vlan(iface, vlan_id, lower_kernel=True)
        else:
            raise exception.IPException('Unable to remove vlan. Output: %s' % e)

    return


@trim_iface_name
def set_promiscuous_mode(iface, mode):
    """
    Set promiscuous for interface

    Args:
        iface (str): ethX name
        mode (str): on/off

    """
    the_exe.block_run('ip link set %s promisc %s ' % (iface, mode))


@trim_iface_name
def set_route(iface, method, dst, gateway=None):
    """Set route

    Note that you must provide one of optional arguments, gateway and iface.

    Args:
        iface (str): Name of iface
        method (str): [add|del] method to be passed to "ip" command.
        dst (str): Destination IP range with netmask i.e.) x.x.x.x/x
        gateway (None, str): route will be added using 'via' if this is given
            otherwise 'dev' will be used using iface

    """
    if gateway and iface:
        cmd = 'route %s -host %s gw %s' % (method, dst, gateway)
    elif not(gateway or iface):
        raise exception.ValueException('only and at least one of gateway and iface arguments should be passed')
    else:
        cmd = 'ip route %s %s %s %s' % (method, dst, 'via' if gateway else 'dev', gateway if gateway else iface)

    try:
        the_exe.block_run(cmd)
    except exception.ExeExitcodeException as err:
        if 'File exists' in err.output:
            raise exception.IPFileExists('The same route is already assigned')
        raise


@trim_iface_name
def set_macvlan(macvlan_iface_name, iface=None, method='add', mode='bridge'):
    """Set macvlan interface

    Args:
        iface (str): The interface name over which the macvlan interface is to be created
        method (str): [add/del] Add or Delete the macvlan interface
        macvlan_iface_name (str): Name of MacVlan iface
        mode (str): mode
    """
    macvlan_iface_name = macvlan_iface_name[-15:]

    if method == 'add':
        cmd = 'ip link add %s link %s type macvlan mode %s' % \
            (macvlan_iface_name, iface, mode)
    else:
        cmd = 'ip link delete %s' % macvlan_iface_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_vxlan(iface, method, vxlan_id, tun_name=None, group=None, remote=None, external=False, gpe=False, **kwargs):
    """Configure VXLAN

    Args:
        iface: ethX name
        method: [add|del] operation
        vxlan_id (int): VXLAN ID
        group (str): multicast group. Required for 'adding' VXLAN
        tun_name (str): Name of tunnel to be created
        remote (str): remote ip
        external (bool): External True or False
        gpe (bool): gpe True or False
    """
    tun_name = ('vxlan%s' % vxlan_id) if tun_name is None else tun_name

    if method == 'add':
        # Only 4789 dstport is supported for now so hardcoding
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        if group is not None:
            cmd = 'ip link add %s type vxlan id %s group %s dev %s dstport 4789 %s' % \
                (tun_name, vxlan_id, group, iface, params)
        elif external is True:
            cmd = 'ip link add name %s type vxlan external dev %s dstport 4789' % \
                  (tun_name, iface)
        elif gpe is True:
            cmd = 'ip link add %s type vxlan gpe remote %s dev %s dstport 4789 external' % \
                (tun_name, remote, iface)
        else:
            cmd = 'ip link add %s type vxlan id %s remote %s dev %s dstport 4789 %s' % \
                (tun_name, vxlan_id, remote, iface, params)
    else:
        cmd = 'ip link delete %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_geneve(iface, method, geneve_id, tun_name=None, remote=None, **kwargs):
    """Configure Geneve

    Args:
        iface: ethX name
        method: [add|del] operation
        geneve_id (int): GENEVE ID
        tun_name: Name of tunnel to be created
        remote: Remote IP
    """
    tun_name = ('geneve.%s' % geneve_id) if tun_name is None else tun_name

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        cmd = 'ip link add %s type geneve id %s remote %s %s' % \
            (tun_name, geneve_id, remote, params)
    else:
        cmd = 'ip link delete %s' % tun_name

    exe.block_run(cmd)


@trim_iface_name
def set_gre(iface, tun_name, method, local=None, remote=None, ttl=255, ipv6=False, **kwargs):
    """Configure GRE tunneling

    Args:
        iface (str): ethX name
        tun_name (str): gre interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
        ipv6 (bool): IPv6 or not
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        if ipv6:
            cmd = 'ip -6 tunnel add %s mode ip6gre local %s remote %s ttl %s dev %s %s' % \
                (tun_name, local, remote, ttl, iface, params)
        else:
            cmd = 'ip tunnel add %s mode gre local %s remote %s ttl %s dev %s %s' % \
                (tun_name, local, remote, ttl, iface, params)
    else:
        cmd = 'ip tunnel del %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_ipip(iface, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip tunnel add %s mode ipip local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = 'ip tunnel del %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_ipip6(iface, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip -6 tunnel add %s mode ipip6 local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = 'ip tunnel del %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_ip6ip(iface, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip tunnel add %s mode sit local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = 'ip tunnel del %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_ip6ip6(iface, tun_name, method, local=None, remote=None, ttl=255):
    """Configure ip-in-ip tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip-in-ip interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        ttl (int): ttl
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        cmd = 'ip -6 tunnel add %s mode ip6ip6 local %s remote %s ttl %s dev %s' % \
            (tun_name, local, remote, ttl, iface)
    else:
        cmd = 'ip tunnel del %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_sit(iface, tun_name, method, local=None, remote=None, mode='any', **kwargs):
    """Configure sit tunneling

    Args:
        iface (str): ethX name
        tun_name (str): sit interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        mode (str) : supported modes are ip6ip | ipip | mplsip | any
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        cmd = 'ip link add name %s type sit local %s remote %s mode %s dev %s %s' % \
              (tun_name, local, remote, mode, iface, params)
    else:
        cmd = 'ip link delete %s' % tun_name

    the_exe.block_run(cmd)


@trim_iface_name
def set_ip6tnl(iface, tun_name, method, local=None, remote=None, mode='any', **kwargs):
    """Configure ip6tnl tunneling

    Args:
        iface (str): ethX name
        tun_name (str): ip6tnl interface name
        method (str): [add|del] operation
        local (str): local IP address for tunneling. Required for 'add'
        remote (str): remote IP address for tunneling. Required for 'add'
        mode (str): tunnel mode
    """
    tun_name = tun_name[-15:]

    if method == 'add':
        params = ' '.join('%s %s' % (key, value) for key, value in list(kwargs.items()))
        cmd = 'ip link add name %s type ip6tnl local %s remote %s mode %s dev %s %s' % \
              (tun_name, local, remote, mode, params, iface)
    else:
        cmd = 'ip link delete %s' % tun_name

    the_exe.block_run(cmd)


def get_next_network_ip(ip_addr, v6=False):
    ip_addr, subnet = ip_addr.split("/") if '/' in ip_addr else (ip_addr, '')

    if v6:
        new_ip = ipaddress.ip_address('%s' % ip_addr) + 2 ** 96
    else:
        new_ip = ipaddress.ip_address('%s' % ip_addr) + 256

    if subnet:
        new_network_ip_addr = ipaddress.ip_network(str(new_ip)+'/'+subnet, strict=False)
    else:
        new_network_ip_addr = new_ip

    return new_network_ip_addr


def get_next_ip(ip_addr):
    # This ip address generated will try to match to the client tunnel ip in case of 'baremetal vxlan' config.
    #  So if client tunnel ip changes then the '+2' should be changed accordingly.
    new_ip = ipaddress.ip_address('%s' % ip_addr) + 2
    return new_ip


@trim_iface_name
def get_vf_state(iface, vf_id):
    """
    Get the configured link state of the VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (int): The ID of the VF.
    Return:
        str: The configured link state of the VF (auto | enable | disable | None).
    """
    vf_state = None
    command = 'ip link show %s' % iface
    command_output = the_exe.block_run(command)

    for each_line in command_output.split('\n'):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_state = re.search(r'link-state[\s]*([a-z]*)[,]*', each_line).group(1)
            break

    return vf_state


@trim_iface_name
def set_vf_state(iface, vf_id, vf_state):
    """
    Set the link state of the VF.

    Args:
        iface (str)   : The name of the PF interface.
        vf_id (int)   : The ID of the VF.
        vf_state (str): The link state to set.
    """
    command = 'ip link set %s vf %s state %s' % (iface, str(vf_id), vf_state)
    the_exe.block_run(command)


@trim_iface_name
def get_vf_rate(iface, vf_id):
    """
    Get the configured Max_TX_Rate of the VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (int): The ID of the VF.
    Return:
        str: The configured MAX_TX_RATE of the VF (Integer value only).
    """
    vf_rate = None
    command = 'ip link show %s' % iface
    command_output = the_exe.block_run(command)

    for each_line in command_output.split('\n'):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_rate = re.search(r'max_tx_rate[\s]*(\d+)[,]*', each_line).group(1)
            break

    return vf_rate


@trim_iface_name
def set_vf_rate(iface, vf_id, vf_rate):
    """
Set the TX rate of the VF.

Args:
    iface (str)   : The name of the PF interface.
    vf_id (int)   : The ID of the VF.
    vf_rate (int): Rate value to be set.
"""
    command = 'ip link set %s vf %s rate %s' % (iface, vf_id, vf_rate)
    the_exe.block_run(command)


@trim_iface_name
def get_vf_vlan(iface, vf_id):
    """
    Get the VLAN id of the specified VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (str): The ID of the VF.
    Return:
        VLAN ID of the specified VF or None.
    """
    vf_vlan = None
    command = 'ip -o link show %s' % iface
    command_output = the_exe.block_run(command, shell=True)

    for each_line in command_output.split('\\ '):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_vlan = re.search(r'vlan[\s]*(\d+)[,]*', each_line).group(1)
            break

    return vf_vlan


@trim_iface_name
def set_vf_vlan(iface, vf_id, vlan_id, qos=None, proto=None):
    """
    Set the vLAN ID on the VF.

    Args:
        iface (str)   : The name of the PF interface.
        vf_id (int)   : The ID of the VF.
        vlan_id (str): The vLAN ID to set.
        qos: VLAN QOS (priority) bits for the VLAN tag
        proto: VLAN PROTOCOL for the VLAN tag
    """
    command = 'ip link set %s vf %s vlan %s' % (iface, str(vf_id), vlan_id)
    if qos:
        command += ' qos %s' % str(qos)
    if proto:
        command += ' proto %s' % proto
    the_exe.block_run(command)


@trim_iface_name
def set_vf_mac(iface, vf_id, vf_mac):
    """
    Set the mac address for the specified  VF.

    Args:
        iface (str)   : The name of the PF interface.
        vf_id (int)   : The ID of the VF.
        vf_mac (str): mac_address value to be set.
    """
    command = 'ip link set %s vf %s mac %s' % (iface, vf_id, vf_mac)
    the_exe.block_run(command)


@trim_iface_name
def get_vf_mac(iface, vf_id):
    """
    Get the MAC address of the specified VF.

    Args:
        iface (str): The name of the PF interface.
        vf_id (str): The ID of the VF.
    Return:
        The MAC address of the specified VF or None.
    """
    vf_mac_address = None
    command = 'ip -o link show %s' % iface
    command_output = the_exe.block_run(command, shell=True)

    for each_line in command_output.split('\\ '):
        if 'vf ' + str(vf_id) + ' ' in each_line:
            vf_mac_address = re.search(r'(MAC|ether)[\s]+([a-zA-Z0-9:]+)', each_line).group(2)
            break

    return vf_mac_address


def get_iface_name(mac_address):
    """
    Get the name of the interface with the MAC address specified.

    Args:
        mac_address (str): The MAC address of the interface.
    Return:
        The name of the interface with the specified MAC address or None.
    """
    iface_name = None
    command = 'ip -o link show'
    command_output = the_exe.block_run(command, shell=True)
    re_obj = re.search(r'[0-9]+:[\s]+([\w]+).*link/ether[\s]+%s' % mac_address, command_output)

    if re_obj is not None:
        iface_name = re_obj.group(1)

    return iface_name


@trim_iface_name
def set_vf_trust(iface, vf_id, vf_trust_state=False):
    """
    Set the VF trust state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to configure the trust on.
        vf_trust_state: The trust state to configure (True=on; False=off).
    """
    trust_state = 'on' if vf_trust_state is True else 'off'
    command = 'ip link set dev %s vf %s trust %s' % (iface, vf_id, trust_state)
    # Configuring VF trust using ip command is not supported in all kernel versions.
    # So, expect failures and ignore it.
    try:
        the_exe.block_run(command, shell=True)
    except Exception:
        pass


@trim_iface_name
def get_vf_trust(iface, vf_id):
    """
    Get the VF trust state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to get the trust state of.
    Return:
        trust_state: True if trust is "on", False otherwise.
    """
    trust_state = False
    command = 'ip link show %s' % iface
    command_output = the_exe.block_run(command, shell=True)
    trust_states = re.findall('vf %s.*trust (on|off)' % str(vf_id), command_output.strip())

    if len(trust_states) > 0 and trust_states[0] == 'on':
        trust_state = True

    return trust_state


@trim_iface_name
def set_vf_mac(iface, vf_id, mac_address):
    """
    Set MAC address of the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to set MAC address of.
        mac_address: The MAC address to set.
    """
    command = 'ip link set dev %s vf %s mac %s' % (iface, vf_id, mac_address)
    the_exe.block_run(command, shell=True)


@trim_iface_name
def get_mcast_addr(iface):
    """
    Get the multicast addresses the specified interface is a part of.

    Args:
        iface: The name of the PF interface.
    Return:
        maddrs: A dictionary with multicast group ID as the key and a list of multicast
            addresses as the value.
    """
    maddrs = {}
    command = 'ip maddr show dev %s' % iface
    item_list = the_exe.block_run(command, shell=True).split('\n')

    for item in item_list:
        if ':\t' in item:
            group_id = item.split(':')[0]
            maddrs[group_id] = []
        elif item != '':
            maddrs[group_id].append(item.strip())

    return maddrs


@trim_iface_name
def configure_multicast(iface, multicast_type='multicast', action='on'):
    """
    Enable/Disable multicast on interface

    Args:
        iface (str): The name of the PF interface.
        multicast_type (str): this can be multicast/allmulticast.
        action (str): this can be either on or off
    """
    multicast_type = multicast_type.lower()
    action = action.lower()
    command = 'ip link set dev %s %s %s' % (iface, multicast_type, action)
    the_exe.block_run(command, shell=True)


@trim_iface_name
def configure_mcast_addr(iface, maddr, action='add'):
    """
    Add/delete a static multicast address to/from the specified interface.

    Args:
        iface: The name of the PF interface.
        maddr: The multicast address to add/delete.
        action: action to be performed. can be either on or off
    """
    command = 'ip maddr %s %s dev %s' % (action, maddr, iface)
    the_exe.block_run(command, shell=True)
    return True


@trim_iface_name
def set_vf_spoof(iface, vf_id, spoofchk=True):
    """
    Set the VF spoof state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to configure the spoof.
        spoofchk: spoof to configure (True=on; False=off).
    """
    spoofchk = 'on' if spoofchk is True else 'off'
    command = 'ip link set dev %s vf %s spoofchk %s' % (iface, vf_id, spoofchk)
    the_exe.block_run(command, shell=True)


@trim_iface_name
def get_vf_spoof(iface, vf_id):
    """
    Get the VF spoof state on the specified VF.

    Args:
        iface: The name of the PF interface.
        vf_id: The ID of the VF to get the spoof state.
    Return:
        spoof_state: True if spoof is "on", False otherwise.
    """
    spoof_state = False
    command = 'ip link show %s' % iface
    command_output = the_exe.block_run(command, shell=True)
    spoof_states = re.findall('vf %s.*spoof checking (on|off)' % str(vf_id), command_output.strip())

    if spoof_states[0] == 'on':
        spoof_state = True

    return spoof_state


@trim_iface_name
@set_default_cli
def attach_iface_to_pid_namespace(iface: str, pid: int, cli: Callable = None):
    """Attach the interface to the network namespace of the process specified.

    :param iface: The name of the interface.
    :param pid: The process ID to attach the interface to.
    :param cli: The command executor.
    """
    command = f'ip link set {iface} netns {pid}'
    return cli(command)


def get_vf_id_from_vf_mac(vf_mac):
    """

    :param vf_mac: mac address of the VF interface
    :return:
    """
    command = 'ip -j link show'
    command_output = the_exe.block_run(command)
    for iface_data in json.loads(command_output):
        if 'vfinfo_list' in iface_data:
            for vf_data in iface_data['vfinfo_list']:
                if vf_data['address'] == vf_mac:
                    return str(vf_data['vf'])


@trim_iface_name
def configure_neighbour(iface: str, peer_ip: str, peer_mac: str, action='add'):
    """
    :param iface: Name of Interface on which operation is being done
    :param peer_ip: IP address (either v4/v6) of peer interface for which neigh entry is being added
    :param peer_mac: Mac address (either v4/v6) of peer interface for which neigh entry is being added
    :param action: supported operations "ADD/DEL"
    :return:
    """
    peer_ip = peer_ip.split('/')[0]
    ip_ver = ipaddress.ip_address(u'%s' % peer_ip).version
    if action.lower() not in ['add', 'del']:
        raise exception.ConfigException(f"Supported actions are either 'add/del' and not {action}")
    command = f"ip {'-6' if ip_ver == 6 else ''} nei {action.lower()} {peer_ip} lladdr {peer_mac} dev {iface}"
    if action == 'add':
        command += 'nud perm'
    the_exe.block_run(command, shell=True)
