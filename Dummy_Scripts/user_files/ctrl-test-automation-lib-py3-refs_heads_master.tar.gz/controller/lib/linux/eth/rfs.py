"""
:mod:`rfs` -- Ethernet RFS library
===========================================

.. module:: controller.lib.linux.<DIR>.rfs
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import os

from controller.lib.core import exception
from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


def get_flow_entries():
    """Get RFS flow entry number

    Args:
        rfs_entry_num (int): A number of rfs entry number

    """

    with open('/proc/sys/net/core/rps_sock_flow_entries', 'r') as fileobj:
        return int(fileobj.read())


def set_flow_entries(rfs_entry_num):
    """Set RFS flow entry number

    Update /proc/sys/net/core/rps_sock_flow_entries

    Args:
        rfs_entry_num (int): A number of rfs entry number
    """

    with open('/proc/sys/net/core/rps_sock_flow_entries', 'w') as fileobj:
        fileobj.write(str(rfs_entry_num))


def set_flow_cnt(iface, queue_list=None):
    """Set flow counter

    Update /psys/class/net/device/queues/rx-queue/rps_flow_cnt

    Args:
        iface (str): ethX name
        queue_list (list): List that has a flow counter for each queue. The
            length of the list must match with the number of queues.
            If None, will use (RFS flow entry/queue length)

    """
    rx_queue_list = [
        rx_queue for rx_queue in os.listdir('/sys/class/net/%s/queues' % iface)
        if rx_queue.startswith('rx')
    ]

    flow_entry_num = get_flow_entries()
    queue_list = queue_list or [
        (0 if flow_entry_num is 0 else int(flow_entry_num / len(rx_queue_list)))
        for _ in range(len(rx_queue_list))
    ]

    if len(queue_list) != len(rx_queue_list):
        raise exception.ValueException(
            'A length of "queue_list" %s does not match with the queue '
            'number %s' % (len(queue_list), len(rx_queue_list))
        )

    for queue_dir, counter in zip(
            [x for x in os.listdir('/sys/class/net/%s/queues' % iface) \
                            if x.startswith('rx')], queue_list):
        log.info('Set %s rps_flow_cnt to %s ... ' % (queue_dir, counter))
        with open('/sys/class/net/%s/queues/%s/rps_flow_cnt' % (
                iface, queue_dir), 'w') as fileobj:
            fileobj.write(str(counter))
