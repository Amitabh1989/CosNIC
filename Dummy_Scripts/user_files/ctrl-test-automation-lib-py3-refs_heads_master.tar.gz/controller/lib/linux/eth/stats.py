"""
:mod:`stats` -- Ethernet interface statistics library
=====================================================

.. module:: controller.lib.linux.eth.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a library that converts ethtool statistics output information into
an object type.

"""

from typing import List

import regex as re

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.common.eth.stats import BaseNIC, CounterBase
from controller.lib.linux.eth import ethtool

log = log_handler.get_logger(__name__)


class Cumulus(BaseNIC):
    driver_name = 'bnxt_en'

    def __init__(self, xdir_counters: List[str] = None, port_counters: List[str] = None):
        counter_list = [
            'ucast_packets', 'ucast_bytes',
            'mcast_packets', 'mcast_bytes',
            'bcast_packets', 'bcast_bytes'
        ]
        if xdir_counters:
            counter_list += xdir_counters

        super().__init__(*counter_list)
        self.tpa = CounterBase(*['packets', 'bytes', 'events', 'aborts', 'errors', 'eligible_pkt', 'eligible_bytes',
                                 'hds_pkt'])
        port_counters = port_counters or []
        self.port = CounterBase(*port_counters)

    def get_diff(self, old_stats, new_stats=None, **kwargs):
        new_stats = new_stats or self
        diff_stats = super(Cumulus, self).get_diff(old_stats, new_stats)
        diff_stats.tpa = new_stats.tpa.get_diff(old_stats.tpa, new_stats.tpa)
        diff_stats.port = new_stats.port.get_diff(old_stats.port, new_stats.port)
        return diff_stats

    @staticmethod
    def get_stats(iface):
        """Update attributes to reflect the current statistics

        Args:
            iface (str): ethX name
        """
        output = exe.block_run('ethtool -S ' + iface, silent=True)
        xdir_counters = list(set([counter[1] for counter in re.findall('\s+([rt]x)_(.*):\s+(\d+)', output)]))
        port_counters = list(
            set([counter for counter in re.findall(r'^(?!\s+[rt]x|\s+[\[])\s+(.*):\s+\d+', output, re.MULTILINE)]))
        cumulus = Cumulus(xdir_counters=xdir_counters, port_counters=port_counters)

        # Handle rx/tx packets and bytes
        for counter in re.findall('\[(\d+)\]:\s([rt]x)_([umb]cast|push)_(packets|bytes|xmit|cmpl):\s+(\d+)', output):
            queue, xdir, cast_type, counter_type, value = counter

            cast_counter_type = cast_type + '_' + counter_type
            cumulus.set_stats_counter(xdir, queue, cast_counter_type, value)

            # Add cast value to packets / bytes
            cumulus.set_stats_counter(xdir, queue, counter_type, value)

        # Handle drop / error counters
        for drop_error_counter in re.findall(
                '\[(\d+)\]:\s([rt]x)_(drops|discards|buf_errors|errors|l4_csum_errors):\s+(\d+)', output):
            queue, xdir, counter_type, value = drop_error_counter
            cumulus.set_stats_counter(xdir, queue, counter_type, value)

        # Handle TPA counters
        # CTRL-40983: TPA scripts are aborting while checking for TPA counters, as counter name
        # has changed on Thor B0 with latest fw and driver.
        # Fix the regex and the logic to support both Cumulus and Thor supplied stats counters.
        for tpa_counter in re.findall('\[(\d+)\]:\s(rx_tpa|tpa)_(packets|.*bytes|events|aborts|.*pkt|errors):\s+(\d+)',
                                      output):
            queue, dummy, counter_type, value = tpa_counter
            """
            # In Thor, the name of 'packets' is changed to 'pkt'. Thankfully, the name of 'bytes'
            # is still 'bytes'. So, translate 'pkt' into 'packets'.
            #
            # The resulting counters data structure would look like below:
            #
            # +================+============+================+
            # | PROPERTY       | Cu/Wh+     | THOR           |
            # +================+============+================+
            # | packets        | packets    | pkt            |
            # +----------------+------------+----------------+
            # | bytes          | bytes      | bytes          |
            # +----------------+------------+----------------+
            # | events         | events     | N/A (None)     |
            # +----------------+------------+----------------+
            # | aborts         | aborts     | N/A (None)     |
            # +----------------+------------+----------------+
            # | errors         | N/A (None) | errors         |
            # +----------------+------------+----------------+
            # | eligible_pkt   | N/A (None) | eligible_pkt   |
            # +----------------+------------+----------------+
            # | eligible_bytes | N/A (None) | eligible_bytes |
            # +----------------+------------+----------------+
            """
            if counter_type == 'pkt':
                counter_type = 'packets'
            if counter_type in cumulus.tpa.counter_list:
                cumulus.set_stats_counter('tpa', queue, counter_type, value)

        for counter in re.findall(r'^\s+([rt]x)_(.*):\s+(\d+)', output, re.MULTILINE):
            xdir, counter_type, value = counter
            if counter_type in cumulus.counters:
                cumulus.set_stats_counter(xdir, 0, counter_type, value)

        for counter in re.findall(r'^(?!\s+[rt]x|\s+[\[])\s+(.*):\s+(\d+)', output, re.MULTILINE):
            counter_type, value = counter
            if counter_type in cumulus.port.counter_list:
                cumulus.set_stats_counter('port', 0, counter_type, value)

        return cumulus


class I40e(BaseNIC):
    """Intel i40e statistics handler.

    Note that

    * All cast type counters are parsed PF level - e.g. rx_<statistics>, not
      port.rx_<statistics>
    * Because i40e does not report cast type counters per queue, it will return
      as a list which has only one element, as defined in the API doc in
      controller.lib.common.eth.stats.CounterBase.set_queue_value

    """

    driver_name = 'i40e'

    def __init__(self):
        counter_list = ['ucast_packets', 'mcast_packets', 'bcast_packets']
        super().__init__(*counter_list)

    @staticmethod
    def get_stats(iface):
        cast_mapping = {
            'unicast': 'ucast_packets',
            'multicast': 'mcast_packets',
            'broadcast': 'bcast_packets'
        }

        output = exe.block_run('ethtool -S ' + iface)
        i40e = I40e()

        # Handle rx/tx packets and bytes
        for counter in re.findall(
                '([rt]x)-(\d+)\.[rt]x_(packets|bytes):\s+(\d+)', output):
            xdir, queue, counter_type, value = counter
            i40e.set_stats_counter(xdir, queue, counter_type, value)

        # Handle cast types
        for counter in re.findall(
                '\s+([rt]x)_(unicast|multicast|broadcast):\s+(\d+)', output):
            xdir, cast_type, value = counter
            i40e.set_stats_counter(xdir, 0, cast_mapping[cast_type], value)

        # Handle drops/errors
        for counter in re.findall(
                '([rt]x)_(dropped|errors):\s+(\d+)', output):
            xdir, counter_type, value = counter
            counter_type = 'drops' if counter_type == 'dropped' \
                else counter_type
            i40e.set_stats_counter(xdir, 0, counter_type, value)

        return i40e


class Bnx2x(BaseNIC):
    driver_name = 'bnx2x'

    def __init__(self):
        counter_list = ['ucast_packets', 'mcast_packets', 'bcast_packets']
        super().__init__(*counter_list)

    @staticmethod
    def get_stats(iface):
        output = exe.block_run('ethtool -S ' + iface)
        bnx2x = Bnx2x.factory()

        # Handle rx/tx packets
        for counter in re.findall(
                '\[(\d+)\]:\s([rt]x)_([umb]cast)_packets:\s+(\d+)',
                output
        ):
            queue, xdir, cast_type, value = counter
            bnx2x.set_stats_counter(xdir, queue, cast_type + '_packets', value)

            # Add cast value to packets
            bnx2x.set_stats_counter(xdir, queue, 'packets', value)

        # Handle the total bytes
        for counter in re.findall(
                '\[(\d+)\]:\s([rt]x)_bytes:\s+(\d+)', output):
            queue, xdir, value = counter
            bnx2x.set_stats_counter(xdir, queue, 'bytes', value)

        # Handle drop / error counters
        for drop_error_counter in re.findall(
                '\[(\d+)\]:\s([rt]x)_(discards|csum_offload_errors):\s+(\d+)',
                output):
            queue, xdir, counter_type, value = drop_error_counter
            counter_type = 'drops' if counter_type == 'discards' else 'errors'
            bnx2x.set_stats_counter(xdir, queue, counter_type, value)

        return bnx2x


class Mlx4En(BaseNIC):
    """Mellanox mlx4_en statistics handler.

    Note that

    * All cast type counters are parsed PF level - namely
      vport_<statistics> fields in ethtool output.
    * All other statistic types are collected from port level.
    * Because i40e does not report cast type counters per queue, it will return
      as a list which has only one element, as defined in the API doc in
      controller.lib.common.eth.stats.CounterBase.set_queue_value

    For details, please refer https://community.mellanox.com/docs/DOC-1481
    """
    driver_name = 'mlx4_en'

    def __init__(self):
        counter_list = ['ucast_packets', 'mcast_packets', 'bcast_packets']
        super().__init__(*counter_list)

    @staticmethod
    def get_stats(iface, output=None):
        cast_mapping = {
            'unicast': 'ucast_packets',
            'multicast': 'mcast_packets',
            'broadcast': 'bcast_packets'
        }

        mlx4_en = Mlx4En.factory()
        output = output or exe.block_run('ethtool -S ' + iface)

        # Handle rx/tx packets
        for counter in re.findall(
                '([rt]x)(\d+)_(packets|bytes):\s+(\d+)', output
        ):
            xdir, queue, counter_type, value = counter
            mlx4_en.set_stats_counter(xdir, queue, counter_type, value)

        # Handle cast types
        for counter in re.findall(
                'vport_([rt]x)_(unicast|multicast|broadcast)_packets:\s+(\d+)',
                output
        ):
            xdir, cast_type, value = counter
            mlx4_en.set_stats_counter(xdir, 0, cast_mapping[cast_type], value)

        # Handle drops/errors
        for counter in re.findall(
                '([rt]x)_(dropped|errors):\s+(\d+)', output
        ):
            xdir, counter_type, value = counter
            counter_type = 'drops' if counter_type == 'dropped' \
                else counter_type
            mlx4_en.set_stats_counter(xdir, 0, counter_type, value)

        return mlx4_en


class Mlx5Core(BaseNIC):
    """Mellanox mlx4_en statistics handler.

    .. warning::

       The code has not been tested on mlx5_en yet

    Note that

    * Due to no "[rt]x<queue>_bytes" available, it will return None
    * tx<queue>_0_packets will be treated as tx<queue>_packets
    * drops counter is not handled. This is due to no rx_dropped is
      reported anymore.
    * errors counter is not handled. This is due to no rx_errors or tx_errors
      are reported anymore.
    * Because i40e does not report cast type counters per queue, it will return
      as a list which has only one element, as defined in the API doc in
      controller.lib.common.eth.stats.CounterBase.set_queue_value

    """
    driver_name = 'mlx5_core'

    def __init__(self):
        counter_list = ['ucast_packets', 'mcast_packets', 'bcast_packets']
        super().__init__(*counter_list)

    @staticmethod
    def get_stats(iface, output=None):
        cast_mapping = {
            'unicast': 'ucast_packets',
            'multicast': 'mcast_packets',
            'broadcast': 'bcast_packets'
        }

        mlx5_core = Mlx5Core.factory()
        output = output or exe.block_run('ethtool -S ' + iface)

        # Handle rx packets
        for counter in re.findall('rx(\d+)_packets:\s+(\d+)', output):
            queue, value = counter
            mlx5_core.set_stats_counter('rx', queue, 'packets', value)

        # Handle tx packets
        # TODO: Should be updated
        for counter in re.findall('tx(\d+)_\d+_packets:\s+(\d+)', output):
            queue, value = counter
            mlx5_core.set_stats_counter('tx', queue, 'packets', value)

        # Handle cast types
        for counter in re.findall(
                '([rt]x)_(unicast|multicast|broadcast)_packets:\s+(\d+)',
                output
        ):
            xdir, cast_type, value = counter
            mlx5_core.set_stats_counter(xdir, 0, cast_mapping[cast_type], value)

        # Handle drops/errors
        # TODO: Should be updated

        return mlx5_core


def get_stats(iface):
    """Return statistics information of the given iface

    Args:
        iface (str): ethX name
    """
    drv_name = ethtool.get_drvinfo(iface)['name']

    for subclass in BaseNIC.__subclasses__():
        if drv_name == subclass.driver_name:
            return subclass.get_stats(iface)
    raise exception.ValueException(
        'Not supported driver %s' % drv_name
    )
