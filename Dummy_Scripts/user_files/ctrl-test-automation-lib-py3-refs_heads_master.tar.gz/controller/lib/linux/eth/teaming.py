"""
:mod:`teaming` -- The test script template
===========================================

.. module:: controller.lib.linux.<DIR>.teaming
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import os
import logging
import time

from controller.lib.common.shell import exe
from controller.lib.linux import eth
from controller.lib.common.eth import teaming


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


log = logging.getLogger(__name__)

#CTRL-48082: This class method is deprecated.

class LinuxTeaming(teaming.BaseTeam):
    def __init__(self, team_name):
        super(LinuxTeaming, self).__init__(team_name)

    def create_teaming(self, member_names, mode):
        exe.block_run('modprobe bonding')

        if not os.access('/sys/class/net/%s' % self.team_name, 0):
            with open('/sys/class/net/bonding_masters', 'w') as fileobj:
                fileobj.write('+%s' % self.team_name)

        # Bring down the bonding device before changing mode
        iface_ctrl = eth.get_interface(iface=self.team_name)
        iface_ctrl.down()

        with open(
            '/sys/class/net/%s/bonding/mode' % self.team_name, 'w'
        ) as fileobj:
            fileobj.write(str(mode))

        for iface in member_names:
            self.add_team_member(iface, self.team_name)

        iface_ctrl.up()

    def remove_teaming(self):
        log.info('Remove all slaves ... ')
        for iface in self.get_team_member_info():
            del_slave(iface, self.team_name)

        log.info('Remove bonding device ... ')

        if not os.access('/sys/class/net/%s' % self.team_name, 0):
            with open('/sys/class/net/bonding_masters', 'w') as fileobj:
                fileobj.write('-%s' % self.team_name)

        log.info('Unloading the driver ... ')
        exe.block_run('modprobe -r bonding')

    def add_team_member(self, member_names, method='+', **kwargs):
        for iface in member_names:
            # Remove all assigned IP addresses
            iface_ctrl = eth.get_interface(iface)
            iface_ctrl.ip_addr = None

            # bring down the interface before adding
            iface_ctrl.down()

            for ipv6, ipv6_prefix in list(iface_ctrl.ip6_prefix.items()):
                iface_ctrl.set_ip6_addr(ipv6 + '/' + ipv6_prefix, 'del')

            with open(
                '/sys/class/net/%s/bonding/slaves' % self.team_name, 'w'
            ) as fileobj:
                fileobj.write('%s%s' % (method, iface))

            iface_ctrl.up()

    def remove_team_member(self, member_names=None):
        self.add_team_member(member_names, method='-')

    def create_vlan(self, vlan_id=None):
        iface_ctrl = eth.get_interface(self.team_name)
        iface_ctrl.add_vlan(vlan_id)

    def remove_vlan(self, vlan_id=None):
        iface_ctrl = eth.get_interface(self.team_name)
        iface_ctrl.remove_vlan(vlan_id)

    def set_team(self, **kwargs):
        for key, value in list(kwargs.items()):
            with open(
                '/sys/class/net/%s/bonding/%s' % (self.team_name, key), 'w'
            ) as fileobj:
                fileobj.write(value)

    def get_team_info(self, **kwargs):
        pass


def get_bonding_dev():
    if not os.access('/sys/class/net/bonding_masters', 0):
        return []

    with open('/sys/class/net/bonding_masters', 'r') as fileobj:
        return fileobj.read().strip().split()


def add_bonding(slave_list, mode, bonding_devname='bond0'):
    """
    Set bonding device.

    Args:
        name (str): Name of the bonding device
        mode (str, int): bonding mode
    """
    exe.block_run('modprobe bonding')

    if not os.access('/sys/class/net/%s' % bonding_devname, 0):
        with open('/sys/class/net/bonding_masters', 'w') as fileobj:
            fileobj.write('+%s' % bonding_devname)

    # Bring down the bonding device before changing mode
    iface_ctrl = eth.get_interface(iface=bonding_devname)
    iface_ctrl.down()

    with open(
        '/sys/class/net/%s/bonding/mode' % bonding_devname, 'w'
    ) as fileobj:
        fileobj.write(str(mode))
    if str(mode) == '802.3ad' or str(mode) == str(4):
        with open(
                '/sys/class/net/%s/bonding/xmit_hash_policy' % bonding_devname, 'w'
        ) as fileobj:
            fileobj.write('layer3+4')

    for iface in slave_list:
        add_slave(iface, bonding_devname)

    exe.block_run('ip link set dev %s up' % bonding_devname)


def del_bonding(bonding_devname='bond0'):
    log.info('Remove all slaves ... ')
    for iface in get_slaves(bonding_devname):
        del_slave(iface, bonding_devname)

    log.info('Remove bonding device ... ')

    if not os.access('/sys/class/net/%s' % bonding_devname, 0):
        with open('/sys/class/net/bonding_masters', 'w') as fileobj:
            fileobj.write('-%s' % bonding_devname)

    log.info('Unloading the driver ... ')
    exe.block_run('modprobe -r bonding')


def get_slaves(bonding_devname='bond0'):
    """Return all slaves that are belong to the given bonding device
    """
    with open(
        '/sys/class/net/%s/bonding/slaves' % bonding_devname, 'r'
    ) as fileobj:
        return fileobj.read().strip().split()


def add_slave(iface, bonding_devname='bond0', method='+'):
    """Add iface as a slave to the bonding device

    Args:
        iface (str): ethX name which will becmoe a slave
        bonding_devname (str): bonding device name
        method (str): choices=[+|-]. Should not override
    """
    # Remove all assigned IP addresses
    iface_ctrl = eth.get_interface(iface)
    iface_ctrl.ip_addr = None

    iface_ctrl.down()
    time.sleep(1)

    for ipv6, ipv6_prefix in list(iface_ctrl.ip6_prefix.items()):
        iface_ctrl.set_ip6_addr(ipv6 + '/' + ipv6_prefix, 'del')

    with open(
        '/sys/class/net/%s/bonding/slaves' % bonding_devname, 'w'
    ) as fileobj:
        fileobj.write('%s%s' % (method, iface))

    iface_ctrl.up()


def del_slave(iface, bonding_devname='bond0'):
    """Remove slave iface from the bonding device

    Args:
        iface (str): ethX name which will becmoe a slave
        bonding_devname (str): bonding device name

    """
    add_slave(iface, bonding_devname, method='-')


def set_param(bonding_devname='bond0', **kwargs):
    """Set bonding related parameter

    key = param name, value = value
    Mode change is not allowed
    """
    for key, value in list(kwargs.items()):
        with open(
            '/sys/class/net/%s/bonding/%s' % (bonding_devname, key), 'w'
        ) as fileobj:
            fileobj.write(value)


def get_bond_info(bonding_devname):
    """Return information about bonding device

    Args:
        bonding_devname (str): name of bonding device
    """
    ret_dict = {}
    for attr in os.listdir('/sys/class/net/%s/bonding' % bonding_devname):
        with open(
            '/sys/class/net/%s/bonding/%s' % (bonding_devname, attr), 'r'
        ) as fileobj:
            ret_dict[attr] = fileobj.read().strip()

    return ret_dict


def get_available_mode():
    return [
        'balance-rr',
        'active-backup',
        'balance-xor',
        'broadcast',
        '802.3ad',
        'balance-tlb',
        'balance-alb',
    ]
