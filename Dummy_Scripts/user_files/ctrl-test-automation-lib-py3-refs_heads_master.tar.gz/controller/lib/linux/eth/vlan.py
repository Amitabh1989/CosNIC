"""
:mod:`tunnel` -- Linux tunneling library
========================================

.. module:: controller.lib.linux.eth.tunnel
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library provides some basic functions to interact with various tunnel
types, such as NVGRE, VXLAN and IP-to-IP.
"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2019 Broadcom Inc"

from controller.lib.core import log_handler
from controller.lib.linux import eth
from controller.lib.linux.eth import ip
from controller.lib.core import exception
log = log_handler.get_logger(__name__)


class Vlan(object):
    def __init__(self, iface, vlan_id, vlan_name=None, proto='802.1Q'):
        self.iface = iface
        self.vlan_id = int(str(vlan_id))
        self.vlan_name = (vlan_name or '%s.%s' % (iface, self.vlan_id))[-15:]
        self.proto = proto
        self._ctrl = None

    @property
    def ctrl(self):
        if not self._ctrl:
            self._ctrl = eth.get_interface(self.vlan_name)
        return self._ctrl

    @property
    def name(self):
        return self.ctrl.name

    def add(self, **kwargs):
        try:
            self.vlan_name = ip.add_vlan(iface=self.iface, vlan_id=self.vlan_id,
                                         name=self.vlan_name, proto=self.proto)
        except exception.IPFileExists:
            log.info('vlan id %s already exists' % self.vlan_id)
        except exception.IPException:
            raise exception.TestCaseFailure('Failed to Create VLAN Interface')
        else:
            ip.up(self.vlan_name)

    def delete(self):
        ip.remove_vlan(iface=self.iface, vlan_name=self.vlan_name)

    def set_ip_addr(self, ip_addr):
        ip.set_ip_addr(self.vlan_name, str(ip_addr))


def add_vlan(iface, vlan_id, ip_addr=None, vlan_name=None, proto='802.1Q', **kwargs):
    """
    Configure VLAN interface
    """
    vlan = Vlan(iface=iface, vlan_id=vlan_id, vlan_name=vlan_name, proto=proto)
    vlan.add(**kwargs)
    if ip_addr:
        vlan.set_ip_addr(ip_addr=ip_addr)
    return vlan
