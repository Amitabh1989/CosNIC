#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Author: N0dr4x (n0dr4x@protonmail.com)

'''
Simple Scapy TCP Session class that provide ability
to : 
   - execute the 3-way handshake (eg. connect)
   - properly close connection (->FIN/ACK, <-FIN/ACK, ->ACK )
   - send automatic acknowledgment of received tcp data packet
   - build a next packet to send with correct sequence number
   - directly send data through the session

HINT : Don't forget to block TCP/RST packet that was send
       by the linux kernel because no source port was bound.
       
         # iptables -A OUTPUT -p tcp --sport 1337 --tcp-flags RST RST -j DROP

Source port is, for now, fixed to 1337 to facilitate wireshark filtering.
The purpose of this class is to easily build a working tcp session and
have complete scapy control of the next tcp packet.

Usage & example :
   
   # Create the session object and connect to host 192.168.13.37 port 80
   >>> sess = TcpSession(('192.168.13.37',80))
   >>> sess.connect()

   # Build next packet and send it fragmented (layer 2)
   >>> p = sess.build('GET / HTTP/1.1\r\n\r\n')
   >>> send(fragment(p, fragsize=16))

   # Direct send data through the session and close
   >>> sess.send('GET /index.html HTTP/1.1\r\n\r\n')
   >>> sess.close()

   # Session object can be reusable
   >>> sess.connect()
   >>> sess.send('GET /robot.txt HTTP/1.1\r\n\r\n')
   >>> sess.close()

TODO :
   1/ Optionally dump received data to a file
   2/ Proper logging
'''

from scapy.all import *
from threading import Thread
log = logging.getLogger(__name__)


class TcpSession:

    def __init__(self, iface, target, timestamp=False):
        self.set_conf_iface(iface)
        self.iface = iface
        log.info('{} {} {}'.format(target[0], target[1], target[2]))
        self.seq = 0
        self.ack = 0
        self.ip = IP(dst=target[0])
        self.sport = target[1]
        self.dport = target[2]
        self.connected = False
        self._ackThread = None
        self._timeout = 3
        self.TSvalue = 0
        self.TSecr = 0
        self.timestamp = timestamp

    def set_conf_iface(self, iface):
        """
        Setting conf.iface of scapy with the iface to be used in route resolution config.route
        scapy uses conf.iface to resolve conf.route
        :param iface:
        :return:
        """
        log.info('Changing Scapy conf.iface from {} to {}'.format(conf.iface, iface))
        conf.iface = iface
        conf.route.resync()
        log.info('conf.route is {}'.format(conf.route))

    def _TSval(self):
        self.TSvalue = int(random.randint(1024, 65535))
        return self.TSvalue

    def _ack(self, p):
        self.ack = p[TCP].seq + len(p[Raw])

        TSoption = [opt for opt in p[TCP].options if 'Timestamp' in opt]
        if TSoption:
            self.TSecr = TSoption[0][1][0]

        if self.timestamp:
            ack = self.ip / TCP(sport=self.sport, dport=self.dport, flags='A', seq=self.seq, ack=self.ack, options=[('Timestamp', (self.TSvalue, self.TSecr))])
        else:
            ack = self.ip / TCP(sport=self.sport, dport=self.dport, flags='A', seq=self.seq, ack=self.ack)
        send(ack)

    def _ack_rclose(self):
        self.connected = False

        self.ack += 1
        if self.timestamp:
            fin_ack = self.ip / TCP(sport=self.sport, dport=self.dport, flags='FA', seq=self.seq, ack=self.ack, options=[('Timestamp', (self.TSvalue, self.TSecr))])
        else:
            fin_ack = self.ip / TCP(sport=self.sport, dport=self.dport, flags='FA', seq=self.seq, ack=self.ack)
        ack = sr1(fin_ack, timeout=self._timeout)
        self.seq += 1

        assert ack.haslayer(TCP), 'TCP layer missing'
        assert ack[TCP].flags & 0x10 == 0x10, 'No ACK flag'
        assert ack[TCP].ack == self.seq, 'Acknowledgment number error'

    def _sniff(self):
        s = L3RawSocket()
        while self.connected:
            p = s.recv(MTU)
            if p.haslayer(TCP) and p.haslayer(Raw) \
                    and p[TCP].dport == self.sport:
                self._ack(p)
            if p.haslayer(TCP) and p[TCP].dport == self.sport \
                    and p[TCP].flags & 0x01 == 0x01:  # FIN
                self._ack_rclose()

        s.close()
        self._ackThread = None
        log.info('Acknowledgment thread stopped')

    def _start_ackThread(self):
        self._ackThread = Thread(name='AckThread', target=self._sniff)
        self._ackThread.start()

    def connect(self):
        log.info('Connecting to server')
        self.seq = random.randrange(0, (2 ** 32) - 1)
        if self.timestamp:
            syn = self.ip / TCP(sport=self.sport, dport=self.dport, seq=self.seq, flags='S', options=[('Timestamp', (self._TSval(), 0))])
        else:
            syn = self.ip / TCP(sport=self.sport, dport=self.dport, seq=self.seq, flags='S')
        log.info('Sending sync')
        syn.show2()
        syn_ack = sr1(syn, timeout=self._timeout)
        self.seq += 1
        log.info('Got sync-ack')
        syn_ack and syn_ack.show2()

        assert syn_ack.haslayer(TCP), 'TCP layer missing'
        assert syn_ack[TCP].flags & 0x12 == 0x12, 'No SYN/ACK flags'
        assert syn_ack[TCP].ack == self.seq, 'Acknowledgment number error'

        self.ack = syn_ack[TCP].seq + 1
        TSoption = [opt for opt in syn_ack[TCP].options if 'Timestamp' in opt]
        if TSoption:
            self.TSecr = TSoption[0][1][0]
        self.TSvalue += 1
        if self.timestamp:
            ack = self.ip / TCP(sport=self.sport, dport=self.dport, seq=self.seq, flags='A', ack=self.ack, options=[('Timestamp', (self.TSvalue, self.TSecr))])
        else:
            ack = self.ip / TCP(sport=self.sport, dport=self.dport, seq=self.seq, flags='A', ack=self.ack)
        log.info('Sending ack')
        send(ack)
        ack.show2()

        self.connected = True
        self._start_ackThread()
        log.info('Connected')

    def close(self):
        self.connected = False

        if self.timestamp:
            fin = self.ip / TCP(sport=self.sport, dport=self.dport, flags='FA', seq=self.seq, ack=self.ack, options=[('Timestamp', (self.TSvalue + 1, self.TSecr))])
        else:
            fin = self.ip / TCP(sport=self.sport, dport=self.dport, flags='FA', seq=self.seq, ack=self.ack)
        fin_ack = sr1(fin, timeout=self._timeout)
        self.seq += 1

        assert fin_ack.haslayer(TCP), 'TCP layer missing'
        assert fin_ack[TCP].flags & 0x11 == 0x11, 'No FIN/ACK flags'
        assert fin_ack[TCP].ack == self.seq, 'Acknowledgment number error'

        self.ack = fin_ack[TCP].seq + 1
        if self.timestamp:
            ack = self.ip / TCP(sport=self.sport, dport=self.dport, flags='A', seq=self.seq, ack=self.ack, options=[('Timestamp', (self.TSvalue + 1, self.TSecr))])
        else:
            ack = self.ip / TCP(sport=self.sport, dport=self.dport, flags='A', seq=self.seq, ack=self.ack)

        send(ack)

        log.info('Disconnected')

    def build(self, payload):
        if self.timestamp:
            psh = self.ip / TCP(sport=self.sport, dport=self.dport, flags='PA', seq=self.seq, ack=self.ack, options=[('Timestamp', (self.TSvalue, self.TSecr))]) / payload
        else:
            psh = self.ip / TCP(sport=self.sport, dport=self.dport, flags='PA', seq=self.seq, ack=self.ack)/payload
        self.seq += len(psh[Raw])
        self.TSvalue += 1
        return psh

    def send(self, payload):
        psh = self.build(payload)
        log.info('Payload is ')
        log.info(psh.show2())
        ack = sr1(psh, timeout=self._timeout)

        assert ack.haslayer(TCP), 'TCP layer missing'
        assert ack[TCP].flags & 0x10 == 0x10, 'No ACK flag'
        assert ack[TCP].ack == self.seq, 'Acknowledgment number error'


class TCPServer(object):
    def __init__(self, port=5555, send_size=8096, recv_size=1024):
        self._port = port
        self._recv_size = recv_size
        self._send_size = send_size
        self.PKT = 'x' * self._send_size
        self.conn = None
        self.cl_addr = None
        self.connected = False
        self.sock = None
        self.closed = False

    def start(self):
        self.sock = socket.socket()
        log.info("Socket successfully created")
        self.sock.bind(('', self._port))
        self.sock.listen(1)
        log.info("socket is listening")
        # Establish connection with client.
        # self.conn, self.cl_addr = self.sock.accept()
        # self.connected = True
        # log.info('Got connection from {}'.format(self.cl_addr))
        # data = self.conn.recv(self._recv_size)
        # while True:
        #     log.info("sending data")
        #     self.conn.send(self.PKT)
        #     time.sleep(2)

        self._ackThread = Thread(name='DataSend', target=self._start_acceptThread, args=(5,))
        self._ackThread.start()

    def _start_acceptThread(self, pkt_count=5):
        # Establish connection with client.
        try:
            log.info('Ready to accept connections')
            self.conn, self.cl_addr = self.sock.accept()
            log.info('Got connection from {}'.format(self.cl_addr))
        except Exception as err:
            import traceback
            log.error(traceback.format_exc())
            log.info('********Exception is {}'.format(str(err)))
            self.close(msg='local')
            return
        self.connected = True
        log.info('Got connection from {}'.format(self.cl_addr))
        # self.accept()

        data = self.conn.recv(self._recv_size)
        while self.connected and pkt_count > 0:
            log.info("sending data")
            self.conn.send(self.PKT)
            time.sleep(2)
            pkt_count -= 1

        self.close(msg='local')

    def close(self, msg=''):
        # Close the connection with the client
        log.info('{}: close requested'.format(msg))
        if self.conn:
            self.conn.close()
            self.connected = False
        if self.sock:
            self.sock.shutdown(socket.SHUT_RDWR)
            # self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.close()
            self.closed = True
            self.connected = False
