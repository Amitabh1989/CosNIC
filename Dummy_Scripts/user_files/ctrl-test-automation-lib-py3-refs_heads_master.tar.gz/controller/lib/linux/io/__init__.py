"""
:mod:`dpdk` -- DPDK module
==========================

.. module:: controller.lib.linux.io
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a base module of DPDK library test scripts. The location of the module will be
updated (to higher level, not under IO) once standard module structure is
defined and accepted.

For now, this is only for Linux

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2016-2020 Broadcom Inc."

import os
import re
import time
import logging
from controller.lib.common.shell import exe
from controller.lib.linux.system import ssh
from controller.lib.core import exception

log = logging.getLogger(__name__)


class DPDKController(object):
    """
    Base class for all DPDK application test scripts.
    """
    def __init__(self, **kwargs):
        """
        The constructor.

        Args:
            kwargs : A dictionary of additional optional arguments.
              - 'RTE_SDK'='<path_to_dpdk_home>'
                The path where DPDK is installed on the system.
              - 'RTE_TARGET'='<path_to_dpdk_target>'
                The path to the DPDK target environment.
        """
        self.RTE_SDK = kwargs.get('RTE_SDK', None)
        self.RTE_TARGET = kwargs.get('RTE_TARGET', None)
        self._git_url_dpdk = kwargs.get('GIT_URL_DPDK', 'https://github.com/Broadcom/dpdk.git')
        self._git_branch_dpdk = kwargs.get('GIT_BRANCH_DPDK', 'dpdk-next-master')
        self.dpdk_driver = kwargs.get('dpdk_driver', 'igb_uio')
        self.__hugepage_size = kwargs.get('hugepage_size', 2048)
        self.__hugepage_count = kwargs.get('hugepage_count', 2048)
        self.__hugepage_mount = kwargs.get('hugepage_mount', '/mnt/hugepages')
        self.__numa_nodes_count = 0
        self._shell_prompt = kwargs.get('shell_prompt', '# ')
        self._ssh_ip_addr = kwargs.get('ssh_ip_addr', None)
        self._tencent_coexist = kwargs.get('tencent_coexist', False)
        self._hugepage_memory = kwargs.get('hugepage_memory', None)
        self._file_prefix = kwargs.get('file_prefix', None)

        if self._ssh_ip_addr is not None:
            self._exe = ssh.SSH(self._ssh_ip_addr, shell_prompt=self._shell_prompt)
        else:
            self._exe = exe

        if self.dpdk_driver == 'igb_uio' and (self.RTE_SDK is None or self.RTE_TARGET is None):
            raise exception.ConfigException('DPDK SDK/target environment path not specified')

    def configure_hugepages(self):
        """
        Configure hugepages for testpmd application.
        """
        # CTRL-45469: Automation: DPDK: DPDK scripts fail on non-NUMA setups.
        # Get the number of NUMA nodes on the setup.
        try:
            command = 'lscpu | grep "NUMA node(s)"'
            command_output = self._exe.block_run(command, shell=True)
            re_obj = re.search(r'NUMA node\(s\):\s+(\d+)', command_output)

            if re_obj is not None:
                self.__numa_nodes_count = int(re_obj.group(1))
        except Exception:
            pass
        # Create the mount point for hugepages, just in case none exists.
        command = 'mkdir -p %s' % self.__hugepage_mount
        self._exe.block_run(command, shell=True)
        # Unmount the hugepages mount point, just in case mounted.
        try:
            command = 'umount %s' % self.__hugepage_mount
            self._exe.block_run(command, shell=True)
        except Exception:
            pass
        # (Re)Mount the hugepages mount point.
        command = 'mount -t hugetlbfs nodev %s' % self.__hugepage_mount
        self._exe.block_run(command, shell=True)
        # Configure the hugepages.
        command = 'echo %s > /sys/kernel/mm/hugepages/hugepages-%skB/nr_hugepages' % \
            (self.__hugepage_count, self.__hugepage_size)
        self._exe.block_run(command, shell=True)
        # CTRL-45469: Automation: DPDK: DPDK scripts fail on non-NUMA setups.
        # Use only as many NUMA nodes as available.
        for numa_node in range(self.__numa_nodes_count):
            command = \
                'echo %s > /sys/devices/system/node/node%s/hugepages/hugepages-%skB/nr_hugepages' \
                % (self.__hugepage_count, numa_node, self.__hugepage_size)
            self._exe.block_run(command, shell=True)
        # Ensure that enough hugepages are free.
        command = 'cat /proc/meminfo | grep HugePages_Free'
        command_output = self._exe.block_run(command, shell=True)
        re_obj = re.search('HugePages_Free:[\s]+([\d]+)', command_output)
        # If not enough free hugepages are free, bail out.
        # On some machines (YES!) though we ask for hugepages, the free hugepages will be zero.
        # More surprisingly (!!), testpmd still works. So, do not bail out just because there
        # appear to be no hugepages and expect the unexpected!!
        """
        if re_obj is None or int(re_obj.group(1)) == 0:
            raise exception.TestPMDException('Not enough hugepages are available')
        """

    def cleanup_hugepages(self):
        """
        Clean-up the hugepages allocated.
        """
        # Release the hugepages.
        command = 'echo %s > /sys/kernel/mm/hugepages/hugepages-%skB/nr_hugepages' % \
            (0, self.__hugepage_size)
        self._exe.block_run(command, shell=True)
        # CTRL-45469: Automation: DPDK: DPDK scripts fail on non-NUMA setups.
        # Use only as many NUMA nodes as available.
        for numa_node in range(self.__numa_nodes_count):
            command = \
                'echo %s > /sys/devices/system/node/node%s/hugepages/hugepages-%skB/nr_hugepages' \
                % (0, numa_node, self.__hugepage_size)
            self._exe.block_run(command, shell=True)
        # Unmount the hugepages mount point.
        try:
            command = 'umount %s' % self.__hugepage_mount
            self._exe.block_run(command, shell=True)
        except Exception:
            pass
        # Remove the mount point used for hugepages.
        command = 'rm -rf %s' % self.__hugepage_mount
        self._exe.block_run(command, shell=True)

    def _is_inbox_driver(self):
        """
        Identify the PMD to use.
            Inbox -> driver name: vfio-pci and RTE_SDK: ''.
            Out-of-box -> driver name: vfio-pci or igb_uio and RTE_SDK: not ''.
        """
        # CTRL-42475: Need support for select the dpdk driver(vfio-pci/igb_uio) and also inbox/oob
        # separate.
        # Correctly identify inbox v/s out-of-box PMD.
        return self.dpdk_driver != 'igb_uio' and self.RTE_SDK == ''

    def configure_pmd(self):
        """
        The method that configures and launches the testpmd application. It will:
            - Configure the hugepages.
            - Loads the PMD.
            - Binds the requested interfaces to the PMD.
            - Finally, launches the testpmd application.
        """
        # Do the necessary initializations.
        test_status = True
        local_iface_list = []
        # CTRL-43100: DPDK : Check hugepages before going ahead with testpmd config.
        # Attempt to allocate hugepages.
        if not self._tencent_coexist:
            self.configure_hugepages()
        # CTRL-42475: Need support for select the dpdk driver(vfio-pci/igb_uio) and also inbox/oob
        # separate.
        if self.dpdk_driver == 'igb_uio':
            self._exe.block_run('modprobe uio')
            command = 'insmod %s/kmod/%s.ko' % (self.RTE_TARGET, self.dpdk_driver)
            try:
                self._exe.block_run(command)
            except Exception as e:
                if 'File exists' in str(e):
                    pass
                else:
                    raise
        else:
            command = 'modprobe %s' % self.dpdk_driver
            self._exe.block_run(command)
        # CTRL-40788: Add support in dpdk scripts for inbox OS.
        # Use the appropriate command to identify the interfaces to bind to the PMD.
        if self._is_inbox_driver() is False:
            command = r'%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
        else:
            command = r'dpdk-devbind --status'

        command_output = self._exe.block_run(command)
        dev_matches = re.findall(r"(\w+:\w+:\w+.\w+).*if=(\w+) drv", command_output)

        if len(dev_matches) == 0:
            test_status = False

        for port_bdf, iface in dev_matches:
            # In case of any failure, break out.
            if test_status is False:
                break

            if iface in self.ifaces:
                # CTRL-40788: Add support in dpdk scripts for inbox OS.
                # Use the appropriate command to identify the interfaces to bind to the PMD.
                if self._is_inbox_driver() is False:
                    command = '%s/usertools/dpdk-devbind.py --force --bind=%s %s' % \
                        (self.RTE_SDK, self.dpdk_driver, port_bdf)
                else:
                    command = 'dpdk-devbind --force --bind=%s %s' % (self.dpdk_driver, port_bdf)

                self._exe.block_run(command)
                self._port_bdfs.append(port_bdf)
                local_iface_list.append(iface)
        # CTRL-40284: DPDK Automation: Remove configuration of peer MAC addresses
        # from the config file.
        # Adjust the peer MAC addresses based on the order in which the interfaces
        # are bound to the DPDK driver.
        if test_status is True:
            if self.ifaces[0] != local_iface_list[0]:
                temp = self._peer1_mac
                self._peer1_mac = self._peer2_mac
                self._peer2_mac = temp
            # Then, make sure that the interfaces are bound to the DPDK driver.
            # CTRL-40788: Add support in dpdk scripts for inbox OS.
            # Use the appropriate command to verify the interfaces are bound to the PMD.
            if self._is_inbox_driver() is False:
                command = r'%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
            else:
                command = r'dpdk-devbind --status'

            command_output = self._exe.block_run(command)
            dpdk_dev_matches = re.findall(r"(\w+:\w+:\w+.\w).*drv=%s unused" % \
                self.dpdk_driver, command_output)

        for port_bdf in self._port_bdfs:
            if port_bdf not in dpdk_dev_matches:
                test_status = False
                break

        return test_status

    def kill(self):
        """
        The method kill/stop the Testpmd object on the host and returns
        """
        test_status = False
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        try:
            self._pexpect_object.close()
            test_status = True
        except Exception:
            pass
        # Wait a while to settle things down.
        time.sleep(3)
        return test_status

    def stop(self):
        """
        The method that cleans up the testpmd host. It will:
            - Close the pexepect session used for testpmd.
            - Unbinds the interfaces from the PMD and binds them back to the L2 driver.
            - Removes the PMD.
            - Cleans up the hugepages configured.
            If clean_up is false just kill the testpmd object and return status
        """
        # Do the necessary initializations.
        port_count = 0
        test_status = False
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Close the pexpect session only when not using SSH.
        if self._ssh_ip_addr is None:
            try:
                self._pexpect_object.close()
            except Exception:
                pass
            # Wait a while to settle things down.
            time.sleep(3)
        # In case of SSH session, reset the pexpect closure delay.
        else:
            try:
                self._pexpect_object.delayafterclose = None
                self._pexpect_object.ptyproc.delayafterclose = None
            except Exception:
                pass
        # Then, look for the BRCM interfaces used by DPDK driver.
        try:
            # CTRL-40788: Add support in dpdk scripts for inbox OS.
            # Use the appropriate command to identify the interfaces bound to the PMD.
            if self._is_inbox_driver() is False:
                command = self.RTE_SDK + '/usertools/dpdk-devbind.py --status'
            else:
                command = 'dpdk-devbind --status'

            command_output = self._exe.block_run(command)

            for each_line in command_output.split('\n'):
                if 'drv=' + self.dpdk_driver in each_line:
                    for index in range(len(self._port_bdfs)):
                        if self._port_bdfs[index] in each_line:
                            port_count += 1
                            break
                    # If all ports are found to be bound, break out.
                    if port_count == len(self._port_bdfs):
                        test_status = True
                        break
            # If there are such BRCM interfaces, bind them to the L2 driver.
            for port_bdf in self._port_bdfs:
                # CTRL-40788: Add support in dpdk scripts for inbox OS.
                # Use the appropriate command to bind the interfaces back to the default driver.
                if self._is_inbox_driver() is False:
                    command = self.RTE_SDK + '/usertools/dpdk-devbind.py --force --bind=bnxt_en' \
                        + ' ' + port_bdf
                else:
                    command = 'dpdk-devbind --force --bind=bnxt_en ' + port_bdf

                self._exe.block_run(command)
            # Then, make sure that the interfaces are bound to the default driver.
            if test_status is True:
                # CTRL-40788: Add support in dpdk scripts for inbox OS.
                # Use the appropriate command to verify the interfaces are bound to the default
                # driver.
                if self._is_inbox_driver() is False:
                    command = self.RTE_SDK + '/usertools/dpdk-devbind.py --status'
                else:
                    command = 'dpdk-devbind --status'

                command_output = self._exe.block_run(command)
                port_count = 0
                test_status = False
                # Then, extract the interface BDF of the BRCM interfaces.
                for each_line in command_output.split('\n'):
                    if 'bnxt_en' in each_line:
                        for index in range(len(self._port_bdfs)):
                            if self._port_bdfs[index] in each_line:
                                port_count += 1
                                break
                        # If all ports are found to be bound, break out.
                        if port_count == len(self._port_bdfs):
                            test_status = True
                            break
        except Exception:
            pass
        # CTRL-40340: DPDK scripts fail with error "igb_uio.ko: File exists" if the previous
        # testcase fails.
        # Attempt to remove the DPDK drivers whether they are loaded or not. This "stop()"
        # function is called by all the DPDK scripts in the clean up path. So, never miss
        # unloading the DPDK drivers.
        try:
            command = 'rmmod %s' % self.dpdk_driver
            self._exe.block_run(command)
        except Exception:
            pass

        try:
            self._exe.block_run('rmmod uio')
        except Exception:
            pass
        # Cleanup the hugepages.
        if not self._tencent_coexist:
            self.cleanup_hugepages()
        # Finally, return the test status.
        return test_status

    def build_dpdk(self, checkout=False):
        """
        """
        # If requested to checkout the sources, start afresh.
        if checkout is True:
            # First, remove the older DPDK sources, if any.
            command = 'rm -rf ' + self.RTE_SDK
            self._exe.block_run(command, shell=True)
            # Then, change into the parent directory of dpdk SDK.
            # Ex: If RTE_SDK is '/root/sandbox/dpdk', change into 'root/sandbox'.
            dir_name_list = self.RTE_SDK.split('/')
            dir_name_list.pop()
            parent_dir = '/'.join(dir_name_list)
            os.chdir(parent_dir)
            # Then, clone the remote DPDK repository.
            command = 'git clone ' + self._git_url_dpdk + ' -b ' + self._git_branch_dpdk
            self._exe.block_run(command, shell=True)
        # Then, change back into the DPDK SDK directory and build it.
        os.chdir(self.RTE_SDK)
        command = 'make install T=' + self.RTE_TARGET.split('/')[-1] + ' BNXT_SUPPORT=yes'
        command_output = self._exe.block_run(command, shell=True)
        # If there is any build error, the command above will throw an exception.
        # So, no need to look for errors here. If there's no problem, return success.
        return True
