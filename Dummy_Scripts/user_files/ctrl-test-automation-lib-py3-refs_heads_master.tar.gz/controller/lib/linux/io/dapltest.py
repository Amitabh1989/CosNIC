"""
:mod:`dapltest` -- dapltest Command Wrapper.
============================================
.. module:: controller.lib.linux.io.dapltest
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for dapltest command.
"""
import os

from controller.lib.common.shell import exe
from controller.lib.core import exception


class DAPLTestController(object):
    def __init__(self, **kwargs):
        """
        The Constructor.
        """
        self.__command = 'dapltest'
        self.__qp_count = kwargs.get('qp_count', '2048')
        self.__rdma_device = kwargs['rdma_interface_server']
        self.__rdma_port = kwargs.get('rdma_port_server', '1')
        conf_paths = ['/etc/rdma/dat.conf', '/etc/dat.conf']
        conf_path = None
        for path in conf_paths:
            if os.path.exists(path):
                conf_path = path
                break
        if not conf_path:
            raise exception.ConfigException(f'No dat.conf path found at {conf_paths}')
        exe.block_run(
            "sed -i '/%s/d' %s" % (self.__rdma_device, conf_path), shell=True)
        command = '%s-%s u2.0 nonthreadsafe default libdaploscm.so.2 dapl.2.0 "%s %s" ""' % \
            (self.__rdma_device, self.__rdma_port,
             self.__rdma_device, self.__rdma_port)
        exe.block_run('echo \'%s\' >> %s' % (command, conf_path), shell=True)

    def run(self, test_name):
        """
        Run the specified dapl test.

        Args:
            test_name: The name of the test to run.
        Return:
            test_output: The output of the test.
        """
        test_output = None

        if 'limit' in test_name:
            os.environ['DAPL_MAX_INLINE'] = '96'
            self.__command += ' -T L'
            self.__command += ' -D %s-%s' % (self.__rdma_device,
                                             self.__rdma_port)
            self.__command += ' -m %s' % self.__qp_count
            self.__command += ' %s' % test_name
            test_output = exe.block_run(self.__command, shell=True)
        else:
            raise exception.UnsupportedException(
                'Unsupported dapltest: %s.' % test_name)

        return test_output


class DAPLTestServer(DAPLTestController):
    def __init__(self, **kwargs):
        super(DAPLTestServer, self).__init__(**kwargs)


class DAPLTestClient(DAPLTestController):
    def __init__(self, **kwargs):
        super(DAPLTestClient, self).__init__(**kwargs)
