__doc__ = """
:mod:`fio` -- FIO wrapper
===========================

.. module:: controller.lib.linux.io.fio
.. moduleauthor:: Gaurav Sethi <gaurav.sethi@broadcom.com>

This is a wrapper Python module for FIO.
FIO needs to be installed on both client and server systems.
"""

__usage__ = """

from controller.lib.linux.io import fio
a = fio.Fio()
options = ["--name=temp-fio", "--bs=512k", "--ioengine=libaio", "--iodepth=8", "--size=16M", "--direct=1", 
            "--rw=write", "--numjobs=2", "--time_based"]
a.block_start("/dev/nvme0n1", 10, options=options, timeout=30)

For all error string for FIO refer: https://github.com/axboe/fio/issues/842 
"""

import re
import time
import json
from distutils.spawn import find_executable
from typing import List, Union, Any

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Corporation"

log = log_handler.get_logger(__name__)

__changeset__ = """
ID               WHO         WHEN(MM/DD/YY)   COMMENTS
==============================================================================
DCSG01658268     gs888750    24/07/24         Adding FIO.py

"""


class Fio():
    def __init__(self, prg_path=None):
        """
        :param prg_path: Path of FIO executable
        """
        self._prg_path = prg_path
        self.init_data()

    def init_data(self):
        self._proc = None
        self._command = None
        self.expected_exit_codes = [0, None]
        self.result = None

    @staticmethod
    def _get_options(target: str, runtime: int, options: List[str]) -> str:
        """ "Return command line options
        Args:
            target (str): Target
            runtime (int): runtime in secs
            options (list): a list of options to be passed to FIO
        """
        options = options or []

        final_target = ""
        for temp_target1 in target.split(','):
            temp_target2 = ""
            for idx, item in enumerate(temp_target1.split("/")):
                if item:
                    temp_char = "/" if idx == 1 else "\\\\"
                    temp_target2 += temp_char + item
            final_target += temp_target2 + ','
        final_target = final_target[:-1]
        options = [
            option
            for option in options
            if not (option.startswith("--filename") or option.startswith("--runtime"))
        ]

        options = [
            "--filename=%s" % final_target,
            "--runtime=%s" % runtime,
            "--group_reporting",
            "--time_based",
            "--output-format=json",
        ] + options

        return " ".join(options)

    @property
    def proc(self):
        """
        Return subprocess.Popen process object

        Return:
            Popen: subprocess.Popen object that runs FIO tools
        """
        return self._proc

    @property
    def command(self):
        """
        Return a shell command that is exactly passed to exe. if None, the
        process has not started yet.

        Returns:
            str: command
            None: if the process has not started yet

        """
        return self._command

    def get_option_value(self, param: str) -> Union[str, None]:
        """
        Return a value of the parameter that is passed to FIO

        Args:
            param (str): parameter i.e.) -b

        Returns:
            str: value for the given parameter
            None: If the given parameter is not passed to FIO
        """
        if self.command is None:
            return None

        options = self.command.split()
        for option in options:
            if re.match(param + "(.*)", option):
                return re.match(param + "(.*)", option).group(1)

        return None

    def start(self, target: str, runtime: int, options: List = None) -> "Popen":
        """Start FIO process

        Args:
            target (str): target where IO will rnn to (--filename)
            runtime (int): runtime (--runtime)
            options (list): A list of options that will be passed to the FIO process. i.e.)
        """
        self.init_data()
        prg_path = self._prg_path or find_executable("fio")

        if prg_path is None:
            raise exception.ConfigException("Cannot find FIO")

        options = self._get_options(target=target, runtime=runtime, options=options)
        cmd_line = prg_path + " " + options

        log.info("FIO command: %s" % cmd_line)
        self._command = cmd_line

        self._proc = exe.run(cmd_line)

    def block_start(
        self, target: str, runtime: int, options: List = None, timeout: int = None
    ) -> Any:
        """
        Start FIO process, but as blocking.

        Args:
            target (str): target where IO will rnn to (-f)
            runtime (int): runtime (-d)
            options (list): A list of options that will be passed to the FIO
                process. i.e.) ['-b64k', '-t8', '-#3']
            timeout (None, int): timeout value in secs. Will raise exception
                if FIO process still runs after this time

        """

        self.start(target, runtime, options)

        stop_time = timeout if timeout is None else (time.time() + timeout)

        while stop_time is None or time.time() < stop_time:
            exitcode = self.poll()
            if exitcode is None:
                time.sleep(1)
                continue

            if exitcode == 0:
                self.get_results()
                return True

            raise exception.FioExitCodeException(
                "FIO returned non-zero exitcode %s. Output: %s"
                % (exitcode, self._proc.get_output())
            )

        raise exception.FioTimeOut("FIO process is still running after timeout")

    def stop(self):
        """
        Stop the process using subprocess.Popen.kill()
        """
        self.proc.stop()
        self.expected_exit_codes.append(-15)

    def kill(self):
        """
        Kill the process using subprocess.Popen.kill()
        """
        self.proc.kill()
        self.expected_exit_codes.append(-9)

    def poll(self):
        """
        Return None if the process is still running otherwise exitcode of the process

        """

        poll_res = self.proc.poll()
        if poll_res not in self.expected_exit_codes:
            raise exception.ExeExitcodeException(
                self.command, poll_res, self.proc.get_error() + self.proc.get_output()
            )
        return poll_res

    def get_results(self):
        """
        Return console output

        Returns:
            str: String output of FIO in dict format
            dict: If FIO is not running yet
        """
        # return json.loads(output) if output else {}

        output = self._proc.get_output()
        return json.loads(output) if output else {}

    @property
    def results(self):
        """ """
        if not self.result or len(self.result) == 0:
            self.result = self.get_results()
        return self.result
