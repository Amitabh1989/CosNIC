"""
:mod:`rping` -- grfwork Wrapper.
=========================================

.. module:: controller.lib.linux.io.grfwork
.. moduleauthor:: Sudheer vegesna <sudheer.vegesna@broadcom.com>

This is a wrapper python module for grfwork command.

"""

from controller.lib.common.shell import exe
from controller.lib.core import exception
from virt.lib.core import log_handler

log = log_handler.get_logger(__name__)


class GrfWorkController(object):
    def __init__(self, mode, **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which grfwork runs.
                   - 'server' to run as grfwork server (default).
                   - 'client' to run as grfwork client
        """
        self._mode = mode
        self._server_name = kwargs.get('server_name', None)

        if mode == 'client' and self._server_name is None:
            raise exception.ConfigException('No server name specified')
        self._server_path = kwargs.get('grfwork_path', None)
        log.info(self._server_path)
        if self._server_path is None:
            raise exception.ConfigException('No server path specified')

        self._gw_command = self._server_path
        self._port = kwargs.get('port', '12001')
        self._mr_num = kwargs.get('mr_num', 1)
        self._buf_size = kwargs.get('message_size', '4096')
        self._memalign = kwargs.get('memalign', True)
        self._gid_index = kwargs.get('gid_index', '1')
        self._share_cq = kwargs.get('share_cq', True)
        self._tos = kwargs.get('tos', '236')
        self._qp_count = kwargs.get('qp_count', '60')
        self._qp_type = kwargs.get('rdma_qp_type', 'RC')
        self._sge_num = kwargs.get('sge_num', '1')
        self._batch_size = kwargs.get('batch_size', '1')
        self._request = kwargs.get('request', '128,128,128,128')
        self._wq_depth = kwargs.get('wq_depth', '1')
        self._cq_depth = kwargs.get('cq_depth', None)
        self._mtu_size = kwargs.get('mtu_size', '1024')
        self._print_thp = kwargs.get('print_thp', True)
        self._ib_command = kwargs.get('ib_command', 'ib_write_bw')
        if mode is 'server':
            self._roce_interface = kwargs.get('rdma_interface_server', None)
        else:
            self._roce_interface = kwargs.get('rdma_interface_client', None)

        self._result = None

    def start(self):
        """
        """
        # Run the IB command.
        log.info(self._gw_command)
        self._gw_proc = exe.run(self._gw_command, shell=True)

    def stop(self):
        """
        """
        # Kill the process.
        self._gw_proc.kill()

    def poll(self):
        """
        """
        # If the command failed, return failure.

        return self._gw_proc.poll()

    @property
    def result(self):
        """
        """
        output = self._gw_proc.get_output()
        output = output.split('\n')
        for line in output:
            if self._mode == 'server' and f'Endpoint {int(self._qp_count) -1}' in line:
                self._result = line
                break
            elif self._mode == 'client' and f'conn {int(self._qp_count) -1}' in line:
                self._result = line
                break
        else:
            self._result = output[-20:]
        log.info(self._result)
        return self._result


class GrfWorkCommandServer(GrfWorkController):
    def __init__(self, **kwargs):
        super(GrfWorkCommandServer, self).__init__(mode='server', **kwargs)

    def setup_grfwork(self, port_no='25000'):
        """
        """
        if self._mode != 'server':
            raise exception.ConfigException('Attempt to setup client on server node')

        qp_types = {'UD': 4, 'RC': 2}
        commands = {'ib_send_bw': 2, 'ib_read_bw': 4, 'ib_atomic_bw': 5, 'ib_write_bw': 0}
        mtu_sizes = {'256': 1, '512': 2, '1024': 3, '2048': 4, '4096': 5}

        # Build the server-side command.
        self._gw_command += \
            f' --server --dev={self._roce_interface} --gid={self._gid_index} --port={port_no} ' \
            f'--mr_num={self._mr_num} --buf_size={self._buf_size} --tos={self._tos} --qp_num={self._qp_count}' \
            f' --sge_num={self._sge_num} --batch_size={self._batch_size}' \
            f' --request={self._request} --wq_depth={self._wq_depth}'

        self._gw_command += f' --qp_type={qp_types.get(self._qp_type, 2)}'
        self._gw_command += f' --opcode={commands.get(self._ib_command, 0)}'
        self._gw_command += f' --mtu={mtu_sizes.get(self._mtu_size, 3)}'

        if self._cq_depth is not None:
            self._gw_command += f' --cq_depth={self._cq_depth}'
        if self._memalign is True:
            self._gw_command += ' --memalign'
        if self._share_cq is True:
            self._gw_command += ' --share_cq'

        if self._print_thp is True:
            self._gw_command += ' --print_thp'


class GrfWorkCommandClient(GrfWorkController):
    def __init__(self, **kwargs):
        super(GrfWorkCommandClient, self).__init__(mode='client', **kwargs)

    def setup_grfwork(self, port_no='25000'):
        """
        """
        if self._mode != 'client':
            raise exception.ConfigException('Attempt to setup server on client node')

        qp_types = {'UD': 4, 'RC': 2}
        commands = {'ib_send_bw': 2, 'ib_read_bw': 4, 'ib_atomic_bw': 5, 'ib_write_bw': 0}
        mtu_sizes = {'256': 1, '512': 2, '1024': 3, '2048': 4, '4096': 5}
        # Build the client-side command.
        self._gw_command += \
            f' --connect={self._server_name} --dev={self._roce_interface} --gid={self._gid_index} ' \
            f'--port={port_no} --mr_num={self._mr_num} --buf_size={self._buf_size} --tos={self._tos} ' \
            f'--qp_num={self._qp_count} --sge_num={self._sge_num} --batch_size={self._batch_size}' \
            f' --request={self._request} --wq_depth={self._wq_depth}'

        self._gw_command += f' --qp_type={qp_types.get(self._qp_type, 2)}'
        self._gw_command += f' --opcode={commands.get(self._ib_command, 0)}'
        self._gw_command += f' --mtu={mtu_sizes.get(self._mtu_size, 3)}'

        if self._cq_depth is not None:
            self._gw_command += f' --cq_depth={self._cq_depth}'
        if self._memalign is True:
            self._gw_command += ' --memalign'
        if self._share_cq is True:
            self._gw_command += ' --share_cq'
        if self._print_thp is True:
            self._gw_command += ' --print_thp'

