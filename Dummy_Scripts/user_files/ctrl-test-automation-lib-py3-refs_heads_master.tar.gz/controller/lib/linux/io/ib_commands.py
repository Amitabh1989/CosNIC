"""
:mod:`ib_commands` -- IB Commands Wrapper.
=========================================

.. module:: controller.lib.linux.io.ib_commands
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for IB IO commands. Listed below are the
functionalities provided by this module:

1. Run 'ib_send_bw' command.
2. Run 'ib_read_bw' command.
3. Run 'ib_write_bw' command.
4. Run 'ib_send_lat' command.
5. Run 'ib_read_lat' command.
6. Run 'ib_write_lat' command.
7. Run 'ib_atomic_bw' command.
"""
import json.decoder
import platform
import time
import re
import subprocess
from typing import List, Union

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class IBCommandController(object):
    def __init__(self, mode='server', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which IB Command runs.
                   - 'server' to run as IB command server (default).
                   - 'client' to run as IB command client.
            kwargs : A dictionary of additional optional arguments. Value types can be: str, int, None

               server_name (mandatory)                  The IP address of the IB command server node
               io_duration (default: 120)               The duration for which to run IO
               run_infinitely (default: no)             Run test forever, print results every <io_duration> seconds
               iterations (default: 500)                Number of exchanges
               ib_command (default: ib_send_bw)         The IB command to run for IO
               message_size (default: 65536)            The size in bytes of the message to use for IO
               mtu_size (default: 1500)                 The size in bytes of the MTU to use for IO
               recv_q_depth (default: 100)              The depth of the receive queue to use for IO
               enable_cq_moderation (default: yes)      Generate Cqe only after <cq_moderation> completion
               cq_moderation (default: 100)             Generate Cqe only after <cq_moderation> completion
               ip_ver_gid (default: ipv4)               IP version to use for GID
               ip_ver_conn (default: ip_ver_gid)        IP version to use for connection manager parameters negotiation.
               event_mode (default: no)                 Sleep on CQ events
               gid_index (default: 1)                   GID index to test
               atomic_operation (default: None)         Type of atomic operation (CMP_AND_SWAP or FETCH_AND_ADD)
               xmit_q_depth (default: 100)              Size of tx queue
               rdma_qp_type (default: RC)               Connection type (RC, XRC, DC), (and UC, UD, SRD for ib_send)
               qp_count (default: 1)                    The number of QP's to use for IO
               qp_timeout (default: 14)                 QP timeout, timeout value is 4 usec * 2 ^<qp_timeout>
               bi_directional_io (default: no)          Measure bidirectional bandwidth
               use_rdma_cm (default: no)                Connect QPs with rdma_cm and run test on those QPs
               format_gbps (default: no)                Report Max/Average BW of test in Gbit/sec (instead of MiB/sec)
               use_cuda (default: no)                   ...
               use_rocm (default: no)                   ...
               server_gpu_no (default: None)            ...
               client_gpu_no (default: None)            ...
               use_srq (default: no)                    ...
               mr_per_qp (default: no)                  Create memory region for each qp
               resize_cq (default: no)                  ...
               resize_cq_size (default: 128)            ...
               send_sge (default: no)                   ...
               send_sge_per_wqe (default: 2)            ...
               read_request (default: no)               num of outstanding read/atom
               read_request_queue (default: 1):         num of outstanding read/atom
               randomize_send_sge (default: no)         ...
               test_with_all_msg_size (default: no)     Run sizes from 2 till 2^23
               inline_size (default: None)              Max size of message to be sent in inline
               use_hugepages (default: no)              Use Hugepages instead of contig, memalign allocations
               json_output (default: False)             If True, also save output in json format
               json_output_dir (default: None)          The directory to save json output. If None, use '/tmp'.
               rdma_interface_server (default: None)    Server RoCE interface to use (default=<first interface found>)
               rdma_port_server (default: 1)            Server RoCE port to use (default='1')
               rdma_interface_client (default: None)    Client RoCE interface to use (default=<first interface found>)
               rdma_port_client (default: 1)            Client port to use (default='1')

        todo: Since server_name is mandatory, it should be an arg not a kwarg
        todo: server_name should be renamed to server_ip
        todo: All values that can be 'yes'/'no' should really be bools (True/False)
        todo: enable_cq_moderation is not needed. Can be derived from cq_moderation: bool(cq_moderation is not None)
        todo: read_request is not needed. Can be derived from read_request_queue: bool(read_request_queue is not None)
        """
        self._mode = mode

        self._server_name = kwargs.get('server_name', None)
        if self._server_name is None:
            raise exception.ConfigException('No server name specified')

        self._ib_proc = None
        self.output = ''
        self.error = ''

        self._io_duration = kwargs.get('io_duration', '120')
        self._run_infinitely = kwargs.get('run_infinitely', 'no')
        self._iterations = kwargs.get('iterations', '500')
        self._ib_command = kwargs.get('ib_command', 'ib_send_bw')
        self._message_size = kwargs.get('message_size', '65536')
        self._mtu_size = kwargs.get('mtu_size', '1024')
        self._recv_q_depth = kwargs.get('recv_q_depth', '100')
        self._enable_cq_moderation = kwargs.get('enable_cq_moderation', 'yes')
        self._cq_moderation = kwargs.get('cq_moderation', '100')
        self._ip_ver_gid = kwargs.get('ip_ver_gid', 'ipv4')
        self._ip_ver_conn = kwargs.get('ip_ver_conn', self._ip_ver_gid)
        self._event_mode = kwargs.get('event_mode', 'no')
        self._gid_index = kwargs.get('gid_index', '1')
        self._atomic_operation = kwargs.get('atomic_operation', None)
        self._xmit_q_depth = kwargs.get('xmit_q_depth', '100')
        self._qp_type = kwargs.get('rdma_qp_type', 'RC')
        self._qp_count = kwargs.get('qp_count', '1')
        self._qp_timeout = kwargs.get('qp_timeout', '14')
        self._bi_directional_io = kwargs.get('bi_directional_io', 'no')
        self._use_rdma_cm = kwargs.get('use_rdma_cm', 'no')
        self._format_gbps = kwargs.get('format_gbps', 'no')
        self._use_cuda = kwargs.get('use_cuda', 'no')
        self._use_rocm = kwargs.get('use_rocm', 'no')
        self._server_gpu_no = kwargs.get('server_gpu_no', None)
        self._client_gpu_no = kwargs.get('client_gpu_no', None)
        self._use_srq = kwargs.get('use_srq', 'no')
        self._mr_per_qp = kwargs.get('mr_per_qp', 'no')
        self._resize_cq = kwargs.get('resize_cq', 'no')
        self._resize_cq_size = kwargs.get('resize_cq_size', '128')
        self._send_sge = kwargs.get('send_sge', 'no')
        self._send_sge_per_wqe = kwargs.get('send_sge_per_wqe', '2')
        self._read_request = kwargs.get('read_request', 'no')
        self._read_request_queue = kwargs.get('read_request_queue', '1')
        self._randomize_send_sge = kwargs.get('randomize_send_sge', 'no')
        self._test_with_all_msg_size = kwargs.get('test_with_all_msg_size', 'no')
        self._inline_size = kwargs.get('inline_size', None)  # supported in Dev modified perftest
        self._result = {'THROUGHPUT': '', 'LATENCY': ''}
        self._hugepages = kwargs.get('use_hugepages', 'no')
        self._use_wr_api = kwargs.get('use_wr_api', 'no')  # supported in Dev modified perftest
        self._json_output = kwargs.get('json_output', False)
        self._json_output_dir = kwargs.get('json_output_dir', '/tmp')
        self._wait_destroy = kwargs.get('wait_destroy', None)

        self._cmd_str = self._ib_command
        self._json_file: str = None

        if int(self._mtu_size) > 4096:
            exception.ConfigException(f'The maximum supported MTU size for RoCE is 4096. But mtu used is {self._mtu_size}')

        if self._qp_type == 'UD':
            if 'ib_send' not in self._ib_command:
                raise exception.ConfigException('Incorrect QP type specified')
            # CTRL-49151: [Automation-RoCE]: Need a change in stats calculation when traffic type
            # is UD.
            # When UD QP's are requested, force bi-directional traffic.
            # TODO: This is just a work around; the real fix needs re-organizing all the RoCE
            # scripts (and perhaps even the non-RoCE scripts). So, it will be
            # done later.
            if self._bi_directional_io != "strict-no":
                self._bi_directional_io = 'yes'

        if self._bi_directional_io == "strict-no":
            self._bi_directional_io = 'no'

        if self._use_srq == 'yes' and 'ib_send' not in self._ib_command:
            raise exception.ConfigException('SRQ is supported only for ib_send_*')
        # CTRL-50097: [Automation :Roce-scaling]: Increase the qp time out value for all
        # ib_read_bw scaling test.
        # If the QP's to use is more than 32k, increase the qp_timeout as recommended in the
        # RoCE driver README.txt.
        #
        # - For use cases where the adapter QP limit is exercised or active qps are
        #  close to adapter limits, ack timeout needs to be increased to 24 to avoid
        # retransmissions and loss of performance.
        # For example:
        # For multiple instances of ib_send_bw/ib_read_bw/ib_write_bw, which creates
        # total of 64K QPs, specify higher ack timeout in each application instance
        # using -u 24.
        if int(self._qp_count) > 32000:
            self._qp_timeout = '24'

        # inline_size: Due to issue in yml.load() even if value is provided None in yml file it gets converted in
        # string type instead of None type; hence need to handle in below format
        if self._inline_size == 'None':
            self._inline_size = None
        # -I option i.e. inline size is supported by only write and send commands of perftest
        inline_supported_ib_commands_list = ['ib_send_bw', 'ib_write_bw', 'ib_send_lat', 'ib_write_lat']
        if self._inline_size and self._ib_command not in inline_supported_ib_commands_list:
            raise exception.ConfigException('Inline option is supported only for ib_write and ib_send commands')
        if mode == 'server':
            self._roce_interface = kwargs.get('rdma_interface_server', None)
            self._roce_port = kwargs.get('rdma_port_server', '1')
        else:
            self._roce_interface = kwargs.get('rdma_interface_client', None)
            self._roce_port = kwargs.get('rdma_port_client', '1')

    def bind_path(self, taskset_cpus: List[int] = None) -> str:
        bind_path = ''
        if taskset_cpus:
            os_type = platform.system().lower()
            taskset_cmd_prefix = 'cpuset -l' if os_type == 'freebsd' else 'taskset --cpu-list'
            taskset_cpus = taskset_cpus if isinstance(taskset_cpus, list) else [taskset_cpus]
            bind_path = f'{taskset_cmd_prefix} {",".join(map(str, taskset_cpus))} '
        return bind_path

    def setup_ib_command_server(self, port_no: Union[int, str] = 25000, taskset_cpus: List[int] = None,
                                gid_idx: int = None):
        """
        Sets self._cmd_str

        :param port_no:      Port to listen/connect to
        :param taskset_cpus: List of CPUs to bind to self._ib_command
        :param gid_idx:      Use this gid_idx instead of that passed in the constructor
        """
        if self._mode != 'server':
            raise exception.ConfigException('Attempt to setup server on client node')

        # Build the server-side command.
        if self._roce_interface is not None:
            self._cmd_str += f' -d {self._roce_interface}'

        self._cmd_str += ' -F'
        self._cmd_str += f' -i {self._roce_port}'
        if self._test_with_all_msg_size != 'yes' and 'ib_atomic' not in self._ib_command:
            self._cmd_str += f' -s {self._message_size}'
        self._cmd_str += f' -m {self._mtu_size}'
        self._cmd_str += f' -x {self._gid_index if gid_idx is None else gid_idx}'
        self._cmd_str += f' -p {port_no}'
        self._cmd_str += f' -t {self._xmit_q_depth}'
        self._cmd_str += f' -c {self._qp_type}'
        self._cmd_str += f' -u {self._qp_timeout}'
        # CTRL-50051: 218.0 : RoCE : ib_write_bw IO reports throughput as 0Gb/s for 2Gb
        # message size.
        # Consider the specified CQ moderation value.
        if self._enable_cq_moderation == 'yes':
            self._cmd_str += f' -Q {self._cq_moderation}'

        if self._event_mode == 'yes':
            self._cmd_str += ' -e'
            self._cmd_str += f' -n {self._iterations}'
        elif self._resize_cq == 'yes':
            self._cmd_str += f' --resize_cq {self._resize_cq_size}'
            self._cmd_str += f' -n {self._iterations}'
        elif self._test_with_all_msg_size == 'yes':
            self._cmd_str += ' -a'
        elif self._run_infinitely == 'yes':
            self._cmd_str += ' --run_infinitely'
        else:
            self._cmd_str += f' -D {self._io_duration}'

        if 'ib_read' in self._cmd_str and int(self._qp_timeout) < 24:
            self._qp_timeout = '24'
        if '_bw' in self._cmd_str:
            self._cmd_str += f' -q {self._qp_count}'

            if self._bi_directional_io == 'yes':
                self._cmd_str += ' -b'
            # CUDA support is available only for *_bw commands.
            if self._use_cuda == 'yes' and self._use_rocm == 'yes':
                raise exception.ConfigException('only one of parameter should set to yes in [use_cuda, use_rocm]')
            if self._use_cuda == 'yes':
                self._cmd_str += ' --use_cuda'

            if self._use_rocm == 'yes':
                self._cmd_str += ' --use_rocm'

            if self._server_gpu_no is not None and (self._use_cuda == 'yes' or self._use_rocm == 'yes'):
                self._cmd_str += f'={self._server_gpu_no}'

            if self._wait_destroy:
                self._cmd_str += f' --wait_destroy={self._wait_destroy}'

        if 'ib_send_bw' in self._cmd_str:
            self._cmd_str += f' -r {self._recv_q_depth}'
        elif 'ib_atomic_bw' in self._cmd_str:
            self._cmd_str += f' -A {self._atomic_operation}'

        if self._use_rdma_cm == 'yes':
            self._cmd_str += ' -R'

        if self._format_gbps == 'yes':
            self._cmd_str += ' --report_gbits'

        if self._use_srq == 'yes':
            self._cmd_str += ' --use-srq'

        if self._mr_per_qp == 'yes':
            self._cmd_str += ' --mr_per_qp'

        if self._send_sge == 'yes':
            self._cmd_str += f' --send_sge_per_wqe {self._send_sge_per_wqe}'

        if self._read_request == 'yes':
            self._cmd_str += f' -o {self._read_request_queue}'

        if self._hugepages == 'yes':
            self._cmd_str += ' --use_hugepages'

        if self._inline_size:
            self._cmd_str += f' -I {self._inline_size}'

        if self._ip_ver_gid == 'ipv6':
            self._cmd_str += ' --ipv6'

        if self._ip_ver_conn == 'ipv6':
            self._cmd_str += ' --ipv6-addr'

        if self._use_wr_api == 'yes':
            self._ib_command += ' --use_wr_api'

        if self._json_output:
            directory = self._json_output_dir.rstrip('/')
            self._json_file = f'{directory}/{self._roce_interface}_{self._ib_command}_{port_no}_server.json'
            self._cmd_str += f' --out_json --out_json_file={self._json_file}'

        self._cmd_str = self.bind_path(taskset_cpus) + self._cmd_str

    def setup_ib_command_client(self, port_no: Union[int, str] = 25000, taskset_cpus: List[int] = None,
                                gid_idx: int = None):
        """
        Sets self._cmd_str

        :param port_no:      Port to listen/connect to
        :param taskset_cpus: List of CPUs to bind to self._ib_command
        :param gid_idx:      Use this gid_idx instead of that passed in the constructor
        """
        if self._mode != 'client':
            raise exception.ConfigException('Attempt to setup client on server node')
        if self._randomize_send_sge == 'yes' and self._send_sge != 'yes':
            raise exception.ConfigException("randomize_send_sge works only when send_sge param set to Yes; "
                                            "please reconfigure and retry")

        # Build the client-side command
        if self._roce_interface is not None:
            self._cmd_str += f' -d {self._roce_interface}'

        self._cmd_str += ' -F'
        self._cmd_str += f' -i {self._roce_port}'
        if self._test_with_all_msg_size != 'yes' and 'ib_atomic' not in self._ib_command:
            self._cmd_str += f' -s {self._message_size}'
        self._cmd_str += f' -m {self._mtu_size}'
        self._cmd_str += f' -x {self._gid_index if gid_idx is None else gid_idx}'
        self._cmd_str += f' -p {port_no}'
        self._cmd_str += f' -t {self._xmit_q_depth}'
        self._cmd_str += f' -c {self._qp_type}'
        self._cmd_str += f' -u {self._qp_timeout}'
        # CTRL-50051: 218.0 : RoCE : ib_write_bw IO reports throughput as 0Gb/s for 2Gb
        # message size.
        # Consider the specified CQ moderation value.
        if self._enable_cq_moderation == 'yes':
            self._cmd_str += f' -Q {self._cq_moderation}'

        if self._event_mode == 'yes':
            self._cmd_str += ' -e'
            self._cmd_str += f' -n {self._iterations}'
        elif self._resize_cq == 'yes':
            self._cmd_str += f' --resize_cq {self._resize_cq_size}'
            self._cmd_str += f' -n {self._iterations}'
        elif self._test_with_all_msg_size == 'yes':
            self._cmd_str += ' -a'
        elif self._run_infinitely == 'yes':
            self._cmd_str += ' --run_infinitely'
        else:
            self._cmd_str += f' -D {self._io_duration}'

        if 'ib_read' in self._ib_command and int(self._qp_timeout) < 24:
            self._qp_timeout = '24'
        if '_bw' in self._ib_command:
            self._cmd_str += f' -q {self._qp_count}'

            if self._bi_directional_io == 'yes':
                self._cmd_str += ' -b'
            # CUDA support is available only for *_bw commands.
            if self._use_cuda == 'yes' and self._use_rocm == 'yes':
                raise exception.ConfigException('only one of parameter should set to yes in [use_cuda, use_rocm]')
            if self._use_cuda == 'yes':
                self._cmd_str += ' --use_cuda'

            if self._use_rocm == 'yes':
                self._cmd_str += ' --use_rocm'

            if self._client_gpu_no is not None and (self._use_cuda == 'yes' or self._use_rocm == 'yes'):
                self._cmd_str += f'={self._client_gpu_no}'

            if self._wait_destroy:
                self._cmd_str += f' --wait_destroy={self._wait_destroy}'

        if 'ib_send_bw' in self._ib_command:
            self._cmd_str += f' -r {self._recv_q_depth}'
        elif 'ib_atomic_bw' in self._ib_command:
            self._cmd_str += f' -A {self._atomic_operation}'

        if self._use_rdma_cm == 'yes':
            self._cmd_str += ' -R'

        if self._format_gbps == 'yes':
            self._cmd_str += ' --report_gbits'

        if self._use_srq == 'yes':
            self._cmd_str += ' --use-srq'

        if self._mr_per_qp == 'yes':
            self._cmd_str += ' --mr_per_qp'

        if self._send_sge == 'yes':
            self._cmd_str += f' --send_sge_per_wqe {self._send_sge_per_wqe}'
            if self._randomize_send_sge == 'yes':
                self._cmd_str += ' --randomize_send_sge'

        if self._read_request == 'yes':
            self._cmd_str += f' -o {self._read_request_queue}'

        if self._hugepages == 'yes':
            self._cmd_str += ' --use_hugepages'
        if self._inline_size:
            self._cmd_str += f' -I {self._inline_size}'

        if self._ip_ver_gid == 'ipv6':
            self._cmd_str += ' --ipv6'

        if self._ip_ver_conn == 'ipv6':
            self._cmd_str += ' --ipv6-addr'

        if self._json_output:
            directory = self._json_output_dir.rstrip('/')
            self._json_file = f'{directory}/{self._roce_interface}_{self._ib_command}_{port_no}_client.json'
            self._cmd_str += f' --out_json --out_json_file={self._json_file}'

        if self._use_wr_api == 'yes':
            self._ib_command += ' --use_wr_api'

        self._cmd_str += ' ' + self._server_name

        self._cmd_str = self.bind_path(taskset_cpus) + self._cmd_str

    def cleanup_ib_command_server(self):
        """
        """
        if self._mode != 'server':
            raise exception.ConfigException(
                'Attempt to cleanup server on client node')

        return True

    def cleanup_ib_command_client(self):
        """
        """
        if self._mode != 'client':
            raise exception.ConfigException(
                'Attempt to cleanup client on server node')

        return True

    def start(self, **kwargs):
        """Run the IB command"""

        self.output = ''
        self.error = ''
        self._ib_proc = exe.run(self._cmd_str, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)

    def stop(self, block=True):
        """Stop the process. If <block> is True, wait for the process to die."""

        # Kill the process.
        self._ib_proc.stop()
        # If requested, wait for the process to die.
        while self._ib_proc.poll() is None and block is True:
            time.sleep(0.1)

    def poll(self):
        """
        :returns: None if command is running,
                  0 if command exits with RC 0
        :raises: ExeExitcodeException of command exits with non-zero RC
        """
        # If the command failed, return failure.
        res = self._ib_proc.poll()
        if res is None:
            return None

        if res != 0:
            raise exception.ExeExitcodeException(self._cmd_str, res, self.get_error() + self.get_output())
        return res

    def get_output(self):
        if not self.output:
            self.output = self._ib_proc.get_output().strip()
        return self.output

    def get_error(self):
        if not self.error:
            self.error = self._ib_proc.get_error().strip()
        return self.error

    def get_json_results(self):
        if not self._json_output:
            raise Exception('IBCommandClient constructor arg json_output must be True to call get_json_results')

        output = self.get_output()
        log.debug(f'{self._cmd_str} output:\n{output}')

        out = exe.block_run(f'cat {self._json_file}')
        json_data = json.loads(out)
        return json_data

    def get_results(self, display_result_on_console=False):
        """
        Compose the results from the summary info line, just in case someone asks for them.
        Expected to be called once (via poll method), after command finishes running (poll() == 0)
        To get results again later after polling completed, use self.result

        Assumes IB cmd output ending like (BW test example, similar for latency):
         ....
         GID: 00:00:00:00:00:00:00:00:00:00:255:255:43:00:01:02
        ---------------------------------------------------------------------------------------
         #bytes     #iterations    BW peak[Gb/sec]    BW average[Gb/sec]   MsgRate[Mpps]
         2147483647    85               0.00               48.64                   0.000003      # output[-2]
        ---------------------------------------------------------------------------------------  # last line

        :param display_result_on_console: Flag to chose whether to display result on console or not.
            Default is False as printing on console exceeds log file size limit in most of cases

        :return:
        """
        output = self.get_output()
        if display_result_on_console:
            log.debug(output)
        else:
            log.debug('\n'.join(['IB result output:'] + output.splitlines()[-4:]))
        if output:
            attribute = 'THROUGHPUT' if 'bw' in self._ib_command else 'LATENCY'
            group_index = 4 if 'bw' in self._ib_command else 3

            if 'bw' in self._ib_command:
                unit = 'Gb/sec' if self._format_gbps else 'MB/sec'
            else:
                unit = 'usec'

            self._result[attribute] = re.search(r'\s*(\d*)\s*(\d*)\s*([\d\.]*)\s*([\d\.]*).*',
                                                output.splitlines()[-2]).group(group_index) + ' ' + unit

    def get_all_latancy_results(self):
        res_dict = {}
        output = self.get_output()
        log.debug(output)
        for line in output.splitlines():
            b = re.search(
                r'\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*)'
                r'\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*).*',
                line)
            if b.group(1):
                msg_dict = {'iterations': b.group(2),
                            't_min': b.group(3),
                            't_max': b.group(4),
                            't_typical': b.group(5),
                            't_avg': b.group(6),
                            't_stdev': b.group(7),
                            'percentile_99': b.group(8),
                            'percentile_99.9': b.group(9)}
                res_dict[b.group(1)] = msg_dict
        return res_dict

    def get_all_bw_results(self):
        res_dict = {}
        output = self.get_output()
        log.debug(output)
        for line in output.splitlines():
            b = re.search(r'\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*)\s*([0-9\.]*).*', line)
            if b.group(1):
                msg_dict = {'iterations': b.group(2),
                            'bw_peak': b.group(3),
                            'bw_average': b.group(4),
                            'msg_rate': b.group(5)}
                res_dict[b.group(1)] = msg_dict
        return res_dict

    @property
    def result(self):
        """
        """
        self.get_results()
        return self._result


class IBCommandServer(IBCommandController):
    def __init__(self, **kwargs):
        super(IBCommandServer, self).__init__(mode='server', **kwargs)


class IBCommandClient(IBCommandController):
    def __init__(self, **kwargs):
        super(IBCommandClient, self).__init__(mode='client', **kwargs)
