"""
:mod:`ibv_pingpong` -- ibv_*_pingpong command Wrapper.
=========================================
.. module:: controller.lib.linux.io.ibv_pingpong
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for IB IO commands. Listed below are the
functionalities provided by this module:

1. Run 'ibv_rc_pingpong' command.
2. Run 'ibv_ud_pingpong' command.
3. Run 'ibv_srq_pingpong' command.
"""
import logging
import re
import time
from typing import Dict
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from controller.lib.common.shell import exe
from controller.lib.core import exception

log = logging.getLogger(__name__)


class IBVPingpongController(object):
    def __init__(self, mode: Literal['server', 'client'] = 'server', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which IB Command runs.
                   - 'server' to run as IB command server (default).
                   - 'client' to run as IB command client.
            kwargs : A dictionary of additional optional arguments.
                   - 'server_name'='<server_name>'
                     The name or IP address of the IB command server node (Mandatory).

                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO (default='120').

                   - 'message_size'='<message_size>'
                     The size in bytes of the message to use for IO (default='64').

                   - 'mtu_size'='<mtu_size>'
                     The size in bytes of the MTU to use for IO (default='1500').

                   - 'recv_q_depth'='<recv_q_depth>'
                     The depth of the receive queue to use for IO (default='100').

                   - 'rdma_interface_server'='<rdma_interface_server>'
                     The RoCE interface to use on the server (default=<first interface found>).

                   - 'rdma_port_server'='<rdma_port_server>'
                     The RoCE port to use on the server (default='1').

                   - 'rdma_interface_client'='<rdma_interface_client>'
                     The RoCE interface to use on the client (default=<first interface found>).

                   - 'rdma_port_client'='<rdma_port_client>'
                     The RoCE port to use on the client (default='1').
        """
        self._mode = mode
        self._server_name = kwargs.get('server_name', None)

        if mode == 'client' and self._server_name is None:
            raise exception.ConfigException('No server name specified')

        self.data_line_number = 3   # Line number to be parsed in output
        use_gpu_ping_pong_tool = kwargs.get('gpu_ping_pong_tool', False)
        if use_gpu_ping_pong_tool:
            path = kwargs.get('gpu_pingpong_tool_path', None)
            if not path:
                raise exception.ConfigException("Please provide GPU Ping pong tool path in config file and re-run")
            if kwargs.get('rdma_qp_type', 'RC') == 'RC':
                tool_name = 'rc_pingpong'
            else:
                tool_name = 'ud_pingpong'
            self._ibv_pingpong_command = path + tool_name
            self.data_line_number = 5   # Line number to be parsed in output
        elif kwargs.get('use_srq', 'no') == 'yes':
            self._ibv_pingpong_command = 'ibv_srq_pingpong'
        elif kwargs.get('rdma_qp_type', 'RC') == 'UD':
            self._ibv_pingpong_command = 'ibv_ud_pingpong'
        else:
            self._ibv_pingpong_command = 'ibv_rc_pingpong'

        self._message_size = kwargs.get('message_size', '65536')

        if self._ibv_pingpong_command == 'ibv_rc_pingpong':
            self._mtu_size = kwargs.get('mtu_size', '1500')

        self._recv_q_depth = kwargs.get('recv_q_depth', '100')
        self._ip_version = kwargs.get('ip_version', None)
        self._gid_index = kwargs.get('gid_index', '1')
        self._qp_count = kwargs.get('qp_count', '16')
        self._iterations = kwargs.get('iterations', 1000)
        self._result = {'THROUGHPUT': ''}

        if mode == 'server':
            self._roce_interface = kwargs.get('rdma_interface_server', None)
            self._roce_port = kwargs.get('rdma_port_server', '1')
        else:
            self._roce_interface = kwargs.get('rdma_interface_client', None)
            self._roce_port = kwargs.get('rdma_port_client', '1')

        self._tcp_port = None
        self._ib_proc = None

    def start(self):
        """Run the IBV pingpong command"""
        self._ib_proc = exe.run(self._ibv_pingpong_command)
        return True

    def stop(self):
        """Kill, and wait for rping completion"""
        # Kill the process.
        self._ib_proc.kill()
        # Wait for the process to die.
        while self._ib_proc.poll() is None:
            time.sleep(1)

        return True

    def poll(self, get_result=True):
        """Return None if pingpong still running, else raise exception on error or save result and return exit code"""
        if self._ib_proc.poll() is None:
            return None

        # If the command failed, return failure.
        if self._ib_proc.poll() != 0:
            raise exception.ExeExitcodeException(self._ibv_pingpong_command,
                                                 self._ib_proc.poll(), '')
        if get_result:
            self.get_result()
        return self._ib_proc.poll()

    def wait(self, timeout, force=True) -> bool:
        """Wait for rping completion upto timeout seconds and optionally kill (default) if still running

        :return: True if command exited successfully (poll() == 0), False if still running, exception if cmd failed
        """
        # Wait for the process to complete.
        stop_time = time.time() + timeout
        while self._ib_proc.poll() is None and time.time() < stop_time:
            time.sleep(0.5 if timeout <= 10 else timeout/10.0)

        if self._ib_proc.poll() is None and force:
            self._ib_proc.stop()

        return self._ib_proc.poll() == 0

    def get_result(self):
        """Compose the results, just in case someone asks for them."""
        attribute = 'THROUGHPUT'
        output = self._ib_proc.get_output()
        log.debug(f"{str(self)} output: {output}")
        data = output.split('\n')[-self.data_line_number]
        self._result[attribute] = re.search(r'.*=[\s]*(.*)', data).group(1)

    @property
    def result(self) -> Dict[str, str]:
        """Return pingpong parsed output (currently throughput) if finished running successfully, else None"""
        return self._result

    @property
    def mode(self) -> Literal['server', 'client']:
        """Return mode of the IBV pingpong controller: server or client"""
        return self._mode

    @property
    def server_name(self) -> str:
        """Return the server name/ip"""
        return self._server_name

    @property
    def tcp_port(self) -> str:
        """Return TCP port number as string"""
        return self._tcp_port

    def __str__(self):
        return f"IBVPingpong{self.mode.capitalize()}[{self.server_name}/{self._roce_interface}:{self.tcp_port}]"


class IBVPingpongServer(IBVPingpongController):
    def __init__(self, **kwargs):
        super().__init__(mode='server', **kwargs)

    def setup_ibv_pingpong(self, port_no=None):
        """Build server command line string"""

        self._tcp_port = port_no if port_no is not None else '25000'

        # Build the server-side command.
        if self._roce_interface is not None:
            self._ibv_pingpong_command += ' -d ' + self._roce_interface

        self._ibv_pingpong_command += ' -i ' + self._roce_port
        self._ibv_pingpong_command += ' -s ' + self._message_size
        if self._iterations is not None:
            self._ibv_pingpong_command += ' -n ' + self._iterations
        self._ibv_pingpong_command += ' -g ' + self._gid_index
        self._ibv_pingpong_command += ' -p ' + self._tcp_port
        self._ibv_pingpong_command += ' -r ' + self._recv_q_depth

        if 'ibv_rc_pingpong' in self._ibv_pingpong_command:
            self._ibv_pingpong_command += ' -m ' + self._mtu_size
        elif 'ibv_srq_pingpong' in self._ibv_pingpong_command:
            self._ibv_pingpong_command += ' -q ' + self._qp_count

        return True

    def setup_ibv_pingpong_gpu(self, port_no=None, data_integrity=False, with_cuda=True):
        """Build server command line string with GPU support"""

        self._tcp_port = port_no if port_no is not None else '25000'

        # Build the server-side command.
        if self._roce_interface is not None:
            self._ibv_pingpong_command += ' -d ' + self._roce_interface

        self._ibv_pingpong_command += ' -i ' + self._roce_port
        self._ibv_pingpong_command += ' -s ' + self._message_size
        self._ibv_pingpong_command += ' -g ' + self._gid_index
        self._ibv_pingpong_command += ' -p ' + self._tcp_port
        if self._iterations is not None:
            self._ibv_pingpong_command += ' -n ' + self._iterations
        if with_cuda:
            self._ibv_pingpong_command += ' -C '
        if data_integrity:
            self._ibv_pingpong_command += ' -c '

        return True


class IBVPingpongClient(IBVPingpongController):
    def __init__(self, **kwargs):
        super().__init__(mode='client', **kwargs)

    def setup_ibv_pingpong(self, port_no=None):
        """Build client command line string"""

        self._tcp_port = port_no if port_no is not None else '25000'

        # Build the client-side command.
        if self._roce_interface is not None:
            self._ibv_pingpong_command += ' -d ' + self._roce_interface

        self._ibv_pingpong_command += ' -i ' + self._roce_port
        self._ibv_pingpong_command += ' -s ' + self._message_size
        if self._iterations is not None:
            self._ibv_pingpong_command += ' -n ' + self._iterations
        self._ibv_pingpong_command += ' -g ' + self._gid_index
        self._ibv_pingpong_command += ' -p ' + self._tcp_port
        self._ibv_pingpong_command += ' -r ' + self._recv_q_depth

        if 'ibv_rc_pingpong' in self._ibv_pingpong_command:
            self._ibv_pingpong_command += ' -m ' + self._mtu_size
        elif 'ibv_srq_pingpong' in self._ibv_pingpong_command:
            self._ibv_pingpong_command += ' -q ' + self._qp_count

        self._ibv_pingpong_command += ' ' + self._server_name
        return True

    def setup_ibv_pingpong_gpu(self, port_no=None, data_integrity=False, with_cuda=True):
        """Build client command line string with GPU support"""

        self._tcp_port = port_no if port_no is not None else '25000'

        # Build the client-side command.
        if self._roce_interface is not None:
            self._ibv_pingpong_command += ' -d ' + self._roce_interface

        self._ibv_pingpong_command += ' -i ' + self._roce_port
        self._ibv_pingpong_command += ' -s ' + self._message_size
        self._ibv_pingpong_command += ' -g ' + self._gid_index
        self._ibv_pingpong_command += ' -p ' + self._tcp_port
        if self._iterations is not None:
            self._ibv_pingpong_command += ' -n ' + self._iterations
        if with_cuda:
            self._ibv_pingpong_command += ' -C '
        if data_integrity:
            self._ibv_pingpong_command += ' -c '
        self._ibv_pingpong_command += ' ' + self._server_name

        return True
