"""
:mod:`iperf` -- iperf wrapper library.
======================================
.. module:: controller.lib.linux.io.iperf
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for iperf over SSH. It uses the iperf library in controller.lib.common.io
over the SSH channel.
"""
import logging

from controller.lib.common.shell import exe
from controller.lib.linux.system import ssh
from controller.lib.common.io import iperf

log = logging.getLogger(__name__)

class IperfServer(iperf.Server):
    """
    The class that wraps around controller.lib.common.io.iperf.Server class. By default, it uses
    the shell.exe module for execution. This behavior can be overridden using use_ssh() method to
    use ssh module for execution.
    """
    def __init__(self, *args, **kwargs):
        """
        The IperfServer constructor.
        """
        ssh_ip_addr = kwargs.pop('ssh_ip_addr', None)
        super(IperfServer, self).__init__(*args, **kwargs)

        if ssh_ip_addr is None:
            self._exe = exe
        else:
            self._exe = ssh.SSH(ssh_ip_addr)

class IperfClient(iperf.Client):
    """
    The class that wraps around controller.lib.common.io.iperf.Client class. By default, it uses
    the shell.exe module for execution. This behavior can be overridden using use_ssh() method to
    use ssh module for execution.
    """
    def __init__(self, *args, **kwargs):
        """
        The IperfClient constructor.
        """
        ssh_ip_addr = kwargs.pop('ssh_ip_addr', None)
        super(IperfClient, self).__init__(*args, **kwargs)

        if ssh_ip_addr is None:
            self._exe = exe
        else:
            self._exe = ssh.SSH(ssh_ip_addr)

