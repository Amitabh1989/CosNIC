"""
:mod:`iser` -- iSER IO Wrapper.
===============================

.. module:: controller.lib.linux.io.iser
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for iSER IO. Listed below are the
functionalities provided by this module:

1. Setup a linux node as iSER target.
2. Setup a linux node as iSER initiator.
3. Perform IO on an iSER mount point using MLTT.
4. Restore the states of the iSER target and initiator nodes.
"""

import time
import re
import glob
import os

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
import controller.lib.common.io.mltt as mltt
from controller.lib.linux.io import fio
import controller.lib.linux.eth.ip as ip


__changeset__ = """
ID               WHO         WHEN(MM/DD/YY)   COMMENTS
==============================================================================
DCSG_ALL_ERS     Team        11/07/24         All check-ins till date
DCSG01658268     gs888750    25/07/24         supporting FIO tool as alternate IO tool

"""
log = log_handler.get_logger(__name__)


class ISERController(object):
    def __init__(self, mode="target", **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which iSER controller runs.
                   - 'target' to run as iSER target.
                   - 'initiator' to run as iSER initiator.
            kwargs : A dictionary of additional optional arguments.
                   - 'target_name'='<target_name>'
                     The name or IP address of the iSER target node (Mandatory).

                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO using MLTT (default='120').
        """
        self._mode = mode
        self._target_name = kwargs.get("target_name", None)

        if self._target_name is None:
            raise exception.ConfigException("No iSER target name specified")

        self._io_tool = None
        self._nfs_dir = kwargs.get("nfs_dir", "/home/nfs-dir-0/")
        self._block_size = kwargs.get("block_size", "64K")
        self._thread_count = kwargs.get("thread_count", "8")
        self._queue_depth = kwargs.get("queue_depth", "8")
        self._io_duration = kwargs.get("io_duration", "120")
        self._ram_disk_size = kwargs.get("ram_disk_size", "1G")
        self._toggle_mtu = kwargs.get("toggle_mtu", "no")
        self._toggle_link = kwargs.get("toggle_link", "no")
        self._iface_name = kwargs.get("iface_name", None)
        self._mtu_size = kwargs.get("mtu_size", "2048")
        self._io_mode = kwargs.get("io_mode", "asynchronous")
        self._mount_point_count = kwargs.get("mount_point_count", "1")
        self._mout_point_index = kwargs.get("mount_point_index", "0")
        self._lun_count = int(kwargs.get("lun_count", "1"))
        self._tgt_name = "tgt" + self._mout_point_index
        self._device_name = "/dev/ram" + self._mout_point_index
        self._target_service_provider = kwargs.get("target_service_provider", "stgt")
        self._monitor_time = kwargs.get("monitor_time", "0")
        self._rdma_io_tool = kwargs.get("rdma_ulp_io_tool", "mltt")
        self._fio_op_type = kwargs.get("fio").get("operation_type", "write") if kwargs.get("fio") else "write"
        self._fio_engine = kwargs.get("fio").get("io_engine", "libaio") if kwargs.get("fio") else "libaio"
        # The set of information presented as test result.
        self._results = {"THROUGHPUT (MB/s)": "", "IOPS": "", "CPU": "", "ERRORS": ""}
        # We need not support all possible sizes for the RAM disks. So, if what is
        # requested is not in the list of supported, assume the max.
        if self._ram_disk_size not in ["64M", "128M", "256M", "512M", "1G"]:
            self._ram_disk_size = "1G"

        if (
            self._toggle_mtu == "yes" or self._toggle_link == "yes"
        ) and self._iface_name is None:
            raise exception.ConfigException("No interface name specified to toggle MTU")
        # initilize it to True by assuming host has valid MLTT license
        self.active_mltt_license = True if self._rdma_io_tool.lower() == "mltt" else False
        self.check_io_tool_to_use()

    def check_io_tool_to_use(self):
        """
        Use FIO tool if MLTT license is not available else use MLTT
        """
        if self._rdma_io_tool not in ['mltt', 'fio']:
            raise exception.ConfigException(
                f"Unsupported IO tool passed:{self._rdma_io_tool}; supported are mltt/fio"
            )

        if self._rdma_io_tool == "mltt":
            if self._io_mode == "synchronous":
                self._io_tool = mltt.Pain()
            else:
                self._io_tool = mltt.Maim()
            if not self._io_tool.check_license():
                log.info(
                    f"Host does not have Active MLTT License; hence switching to FIO as IO tool"
                )
                self.active_mltt_license = False
                self._rdma_io_tool = 'fio'  # switch to FIO when MLTT does not have active license

        if self._rdma_io_tool == "fio":
            self._io_tool = fio.Fio()

    def setup_multipath(self):
        """
        The method to configure "Device Mapper Multipathing".
        """
        linux_distro = None
        command_output = exe.block_run("cat /etc/os-release")
        for each_line in command_output.split("\n"):
            if "Debian" in each_line:
                linux_distro = "Debian"
        if linux_distro != "Debian":
            command1 = "mpathconf --enable"
            exe.block_run(command1, shell=True)
            time.sleep(1)

        command = "systemctl restart multipathd"
        exe.block_run(command, shell=True)

    def setup_iser_target(self, deep_init=True, multipath=False):
        """ """
        if self._mode is not "target":
            raise exception.ConfigException(
                "Attempt to setup iSER target on initiator node"
            )
        # If asked to setup targets using 'stgt', do so.
        if self._target_service_provider == "stgt":
            if deep_init is True:
                # Translate the RAM disk size as needed for 'brd' module.
                if self._ram_disk_size == "64M":
                    self._ram_disk_size = "67108"
                elif self._ram_disk_size == "128M":
                    self._ram_disk_size = "134217"
                elif self._ram_disk_size == "256M":
                    self._ram_disk_size = "268435"
                elif self._ram_disk_size == "512M":
                    self._ram_disk_size = "536871"
                else:
                    self._ram_disk_size = "1073742"
                # Load the 'brd' module to setup RAM disks.
                command = (
                    "modprobe brd rd_nr="
                    + self._mount_point_count
                    + " rd_size="
                    + self._ram_disk_size
                )
                exe.block_run(command)
                # (Re)start the tgtd service.
                command = "service tgtd restart"
                exe.block_run(command)
            # Setup an iSCSI target and LUN over iSER transport on the
            # RAM disk created.
            command = (
                "tgt-setup-lun -n "
                + self._tgt_name
                + " -d "
                + self._device_name
                + " -b rdwr -t iser"
            )
            exe.block_run(command)
            # Make sure that the target and LUN are created.
            command = "tgtadm -m target -o show"
            command_output = exe.block_run(command)
            return_status = False

            for each_line in command_output.split("\n"):
                if self._device_name in each_line:
                    return_status = True
                    break
        # If asked to setup targets using 'lio', do so.
        elif self._target_service_provider == "lio":
            return_status = True

            if deep_init is True:
                # Clear any previous target configuration forcibly.
                self._clear_iser_target_config()
            # List the current configuration to make sure old stuff is indeed
            # cleared.
            command = "targetcli ls"
            target_list = exe.block_run(command)
            # Get the name of the SUT for creating meaningful target iqn.
            command = "hostname"
            command_output = exe.block_run(command)
            host_name = command_output.lower().strip()
            # Create the RAM DISK for backstore. When doing multipath configuration, targets and
            # LUN's should be created only once and reused with multiple interfaces. So, don't
            # create them second time.
            if multipath is False:
                for lun_index in range(self._lun_count):
                    ramdisk_name = (
                        "ramdisk" + self._mout_point_index + "_" + str(lun_index)
                    )
                    if not ramdisk_name in target_list:
                        command = (
                            "targetcli backstores/ramdisk/ create name=%s"
                            % ramdisk_name
                            + " nullio=False size="
                            + self._ram_disk_size
                        )
                        exe.block_run(command)
                # Create one target.
                command = (
                    "targetcli iscsi/ create wwn=iqn.2001-04.com."
                    + host_name
                    + "-"
                    + self._tgt_name
                )
                command_output = exe.block_run(command)
                # Create the LUNs on the target with the preconfigured RAM
                # DISKS.
                for lun_index in range(self._lun_count):
                    command = (
                        "targetcli iscsi/iqn.2001-04.com."
                        + host_name
                        + "-"
                        + self._tgt_name
                        + "/tpg1/luns create /backstores/ramdisk/ramdisk"
                        + self._mout_point_index
                        + "_"
                        + str(lun_index)
                    )
                    command_output = exe.block_run(command)

                if deep_init is True:
                    # Delete the default target portal, without which a new one
                    # CAN'T be created!
                    command = (
                        "targetcli iscsi/iqn.2001-04.com."
                        + host_name
                        + "-"
                        + self._tgt_name
                        + "/tpg1/portals delete 0.0.0.0 ip_port=3260"
                    )
                    command_output = exe.block_run(command)
            # Create the target portal on the RoCE interface.
            command = (
                "targetcli iscsi/iqn.2001-04.com."
                + host_name
                + "-"
                + self._tgt_name
                + "/tpg1/portals create "
                + self._target_name
            )
            command_output = exe.block_run(command)
            # Enable iSER on the target portal.
            command = (
                "targetcli iscsi/iqn.2001-04.com."
                + host_name
                + "-"
                + self._tgt_name
                + "/tpg1/portals/"
                + self._target_name
                + ":3260 enable_iser boolean=True"
            )
            command_output = exe.block_run(command)
            # Do some recommended ACL configuration.
            command = (
                "targetcli iscsi/iqn.2001-04.com."
                + host_name
                + "-"
                + self._tgt_name
                + "/tpg1/ set attribute authentication=0"
                + " demo_mode_write_protect=0 generate_node_acls=1 cache_dynamic_acls=1"
            )
            command_output = exe.block_run(command)
            # Save the target configuration.
            command = "targetcli saveconfig"
            command_output = exe.block_run(command)
            # List the current configuration to make sure things are intact.
            command = "targetcli ls"
            command_output = exe.block_run(command)
        # Any other provider? Ahh no.
        else:
            raise exception.TestCaseFailure(
                "Unknown iSCSI target service provider - "
                + self._target_service_provider
            )

        return return_status

    def setup_iser_initiator(self, deep_init=True, multipath=False):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to setup iSER initiator on target node"
            )

        if deep_init is True:
            # Load the 'ib_iser' module.
            command = "modprobe ib_iser"
            exe.block_run(command)
        # Discover the iSCSI target over iSER transport.
        command = (
            "iscsiadm -m discovery -t st -p " + self._target_name + ":3260 -I iser"
        )
        command_output = exe.block_run(command)
        return_status = False

        for each_line in command_output.split("\n"):
            if self._tgt_name in each_line:
                self._tgt_name = re.search(".*(iqn.*)", each_line).group(1)
                return_status = True
                break

        if return_status is False:
            raise exception.TestCaseFailure(
                "Failed to discover the iSCSI target over iSER"
            )
        # Get the list of existing SCSI devices.
        old_scsi_devices = self._get_scsi_devices()
        # Log into the target discovered.
        self._do_iser_login()
        # Identify the SCSI device associated with the target.
        time.sleep(2)
        self._scsi_device_name = self._get_scsi_device_name(old_scsi_devices, multipath)
        return return_status

    def _do_iser_login(self):
        """ """
        # Log into the target discovered.
        command = (
            "iscsiadm -m node -T "
            + self._tgt_name
            + " -p "
            + self._target_name
            + ":3260 -l"
        )
        command_output = exe.block_run(command)
        return_status = False

        for each_line in command_output.split("\n"):
            if "successful" in each_line:
                return_status = True
                break

        if return_status is False:
            raise exception.TestCaseFailure(
                "Failed to log into the iSCSI target over iSER"
            )

        return return_status

    def _get_scsi_devices(self):
        """ """
        return glob.glob("/dev/sd*")

    def _get_scsi_device_name(self, old_scsi_devices, multipath):
        """ """
        if multipath is False:
            new_scsi_devices = self._get_scsi_devices()
            delta_scsi_device = list(set(new_scsi_devices) - set(old_scsi_devices))
        else:
            command = "multipath -l"
            command_output = exe.block_run(command, shell=True)
            delta_scsi_device = re.findall(r"(\w+) \(", command_output)

        return ",".join(delta_scsi_device)

    def _clear_iser_target_config(self):
        command = "targetcli clearconfig confirm=True"
        try:
            exe.block_run(command)
        except Exception as e:
            if "Errno 20" in str(e):
                pass
            else:
                raise exception.TestCaseFailure(
                    "Cannot clear ISER target configuration"
                )

    def cleanup_iser_target(self, deep_cleanup=True):
        """ """
        if self._mode is not "target":
            raise exception.ConfigException(
                "Attempt to cleanup iSER target on initiator node"
            )

        if deep_cleanup is True:
            # If asked to setup targets using 'stgt', do so.
            if self._target_service_provider == "stgt":
                # Stop the tgtd service.
                command = "service tgtd stop"
                exe.block_run(command)
                # Unload the 'brd' module to setup RAM disk.
                command = "rmmod brd"
                exe.block_run(command)
            # If asked to setup targets using 'lio', do so.
            elif self._target_service_provider == "lio":
                # Clear the target configuration forcibly.
                self._clear_iser_target_config()
            # Any other provider? Ahh no.
            else:
                raise exception.TestCaseFailure(
                    "Unknown iSCSI target service provider - "
                    + self._target_service_provider
                )

        return True

    def _clear_iser_initiator_config(self):
        command = "iscsiadm -m node -o delete"
        exe.block_run(command)

    def cleanup_iser_initiator(self, deep_cleanup=True):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to cleanup iSER initiator on target node"
            )

        # Remove the temporary folder created by MLTT.
        if self._io_tool is not None:
            command = "rm -rf " + self._io_tool.temp_dir
            exe.block_run(command)
        # Log out of the iSCSI target.
        command = (
            "iscsiadm -m node -T "
            + self._tgt_name
            + " -p "
            + self._target_name
            + ":3260 -u"
        )
        command_output = exe.block_run(command)
        return_status = False

        for each_line in command_output.split("\n"):
            if "successful" in each_line:
                return_status = True
                break

        if return_status is False:
            raise exception.TestCaseFailure(
                "Failed to log out of the iSCSI target over iSER"
            )
        # In the end, delete the iSCSI target record from the system.
        if deep_cleanup is True:
            self._clear_iser_initiator_config()

        return return_status

    def setup_iser_mount_point(self):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to setup mount point on target node"
            )

        # Create an ext3 file system on the SCSI device.
        command = "mkfs.ext3 -F -t ext3 " + self._scsi_device_name
        exe.block_run(command)
        if not os.path.isdir(self._nfs_dir):
            # Mount the file system.
            command = "mkdir -p " + self._nfs_dir
            exe.block_run(command)
        command = "mount " + self._scsi_device_name + " " + self._nfs_dir
        exe.block_run(command)
        return True

    def cleanup_iser_mount_point(self):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to cleanup mount point on target node"
            )

        # Unmount the file system.
        command = "umount " + self._nfs_dir
        exe.block_run(command)
        return True

    def do_iser_login_logout(self, login_logout_count):
        """ """
        return_status = True

        for count in range(login_logout_count):
            # Log out first.
            if return_status is True:
                return_status = self.cleanup_iser_initiator(deep_cleanup=False)
            else:
                break
            # Sleep for a while to settle things down.
            time.sleep(2)
            # If logout was successful, log back in.
            if return_status is True:
                return_status = self._do_iser_login()
            else:
                break
            # Sleep for a while to settle things down.
            time.sleep(2)

        return return_status

    def do_iser_driver_load_unload(self):
        """ """
        # Unload the RoCE driver first.
        command = "rmmod bnxt_re"
        exe.block_run(command)
        # Load the RoCE driver after.
        command = "modprobe bnxt_re"
        exe.block_run(command)
        return True

    def configure_mltt(self):
        # setup the MLTT command options.
        block_size_option = "-b" + self._block_size
        thread_count_option = "-t" + self._thread_count
        queue_depth_option = "-Q" + self._queue_depth
        monitor_time = "-M" + self._monitor_time
        mltt_options = [
            block_size_option,
            thread_count_option,
            queue_depth_option,
            "-C1",
            "-o",
            "-%f100",
            monitor_time,
        ]
        return mltt_options

    def configure_fio(self):
        # Setup the FIO command options.
        io_engine = "--ioengine=" + self._fio_engine
        block_size_option = "--bs=" + self._block_size
        queue_depth_option = "--iodepth=" + self._queue_depth
        operation_type = "--rw=" + self._fio_op_type
        numjobs = "--numjobs=" + self._thread_count
        fio_options = [
            io_engine,
            block_size_option,
            queue_depth_option,
            operation_type,
            numjobs,
            "--name=temp-fio",
            f"--size={self._block_size}"
        ]

        return fio_options

    def do_iser_mltt_io(self, dst_ip=None, block=True):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException("Attempt to perform IO on target node")

        tool_options = self.configure_mltt() if self.active_mltt_license else self.configure_fio()
        dst_ip = dst_ip or self._scsi_device_name
        self._io_tool.start(dst_ip, self._io_duration, tool_options)

        if block is True:
            # Sleep until the command is completed. If asked to toggle the
            # MTU during the IO, do so roughly in the middle.
            io_run_time = 0
            mid_io_duration = int(self._io_duration) / 2

            while self._io_tool.poll() is None:
                if self._toggle_mtu == "yes" and io_run_time == mid_io_duration:
                    print(
                        (
                            "Changing MTU on %s to %s"
                            % (self._iface_name, self._mtu_size)
                        )
                    )
                    ip.set_mtu(self._iface_name, int(self._mtu_size))
                    time.sleep(3)
                elif self._toggle_link == "yes" and io_run_time == mid_io_duration:
                    print(("Bringing down %s" % self._iface_name))
                    ip.down(self._iface_name)

                io_run_time = io_run_time + 1
                time.sleep(1)
            # If the command failed, return failure.
            if self._io_tool.poll() != 0:
                raise exception.ExeExitcodeException(
                    self._io_tool.command, self._io_tool.poll(), ""
                )

            self.get_results()

        return True

    def poll(self):
        """ """
        while self._io_tool.poll() is None:
            time.sleep(1)

        # If the command failed, return failure.
        if self._io_tool.poll() != 0:
            raise exception.ExeExitcodeException(
                self._io_tool.command, self._io_tool.poll(), ""
            )
        self.get_results()
        return self._io_tool.poll()

    def get_results(self):
        # Compose the results, just in case someone asks for them.
        if self._rdma_io_tool.lower() == "fio":
            self._results = self._io_tool.results()
        else:
            result = self._io_tool.get_data()
            temp_string = (
                re.sub(".*\s-\s", "", str(result.throughput))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["THROUGHPUT (MB/s)"] = temp_string
            temp_string = (
                re.sub(".*\s-\s", "", str(result.iops))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["IOPS"] = temp_string
            temp_string = (
                re.sub(".*\s-\s", "", str(result.cpu_util))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["CPU"] = temp_string
            temp_string = (
                re.sub(".*\s-\s", "", str(result.errors))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["ERRORS"] = temp_string
        return self._results

    @property
    def results(self):
        """ """
        return self._results


class ISERTarget(ISERController):
    def __init__(self, **kwargs):
        super(ISERTarget, self).__init__(mode="target", **kwargs)


class ISERInitiator(ISERController):
    def __init__(self, **kwargs):
        super(ISERInitiator, self).__init__(mode="initiator", **kwargs)
