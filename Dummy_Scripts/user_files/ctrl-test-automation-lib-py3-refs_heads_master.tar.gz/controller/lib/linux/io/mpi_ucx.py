"""
:mod:`mpi_ucx` -- OpenMPI UCX tool wrapper.
=========================================

.. module:: controller.lib.linux.io.mpi
.. moduleauthor:: Gaurav Sethi <gaurav.sethi@broadcom.com>

"""
import os
import time
import subprocess
import platform
from collections import OrderedDict
from typing import List, Union

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class MpiController:
    """
    Class methods to build and execute MPI command
    """
    def __init__(self):
        self.benchmark_command = None
        self.mpi_proc = None
        self.expected_exit_codes = [0, None]
        self.proc_name = None

    def build_mpi_command(self, **kwargs):
        """
        The Constructor.
        :param kwargs: A dictionary of arguments.
        Args:
            mpirun_path: path where MPI with UCX is compiled
            test_path: path of benchmark test
            ip_addr_list: list of IP addresses of hosts
            iface_list: list of RoCE interfaces of hosts
            gid_index_list: list of GID indexes
            transport: type of ROCE transport <RC/UD/ Default: None>
            map_by: <node/ppr/ Default:node>
            bind_to: <none/hw_thread : Default:none
            num_slots: number of processors to bind
            use_host_ppn: host_ppn <True/False/ Default:False>
            use_nccl: <True/False/ Default:False>
            nccl_options: list of NCCL environemnt variables
            session_id: Name of the process
        """
        # initiation
        mpirun_path = kwargs.get("mpirun_path", '')
        test_path = kwargs.get("test_path", None)
        ip_addr_list = kwargs.get("ip_addr_list", [])
        iface_list = kwargs.get("iface_list", [])
        gid_index_list = kwargs.get("gid_index_list", [])
        transport = kwargs.get("transport", '')
        map_by = kwargs.get("map_by", "node")
        bind_to = kwargs.get("bind_to", "none")
        num_slots = kwargs.get("num_slots", 2)
        use_host_ppn = kwargs.get("use_host_ppn", False)
        use_nccl = kwargs.get("use_nccl", False)
        nccl_options = kwargs.get("nccl_options", [])
        self.proc_name = kwargs.get("session_id", None)
        taskset_cpus = kwargs.get("taskset_cpus", None)
        gpu_only = kwargs.get("gpu_only", False)

        self.validate_args(**kwargs)
        if not gpu_only:
            ip_layer = ""
            for ip_addr in ip_addr_list:
                if use_host_ppn:
                    ip_layer += f"{ip_addr}:{num_slots // 2},"
                else:
                    ip_layer += f"{ip_addr},"
            iface_layer = ""
            for iface in iface_list:
                iface_layer += f"{iface}:1,"
            gid_layer = ""
            for gid in gid_index_list:
                gid_layer += f"{gid},"

        self.benchmark_command = mpirun_path + " --allow-run-as-root "
        self.benchmark_command += f"-np {num_slots} "
        if not use_nccl:
            if map_by.lower() == "node":
                self.benchmark_command += "--map-by node "
            else:
                self.benchmark_command += f"--map-by ppr:{num_slots // 2}:node "
        self.benchmark_command += f"--bind-to {bind_to} "
        if transport:
            self.benchmark_command += f"-x UCX_TLS=self,sm,{transport.lower()} "
        if not gpu_only:
            self.benchmark_command += f'-H "{ip_layer}" '
            if use_nccl:
                self.benchmark_command += (f" -x NCCL_IB_HCA={iface_layer} "
                                           f"-x NCCL_IB_GID_INDEX={gid_index_list[0]} ")
                for nccl_option in nccl_options:
                    self.benchmark_command += f"-x {nccl_option} "
            else:
                self.benchmark_command += (f" -x UCX_NET_DEVICES={iface_layer} "
                                           f"-x IB_GID_INDEX={gid_layer} ")
        else:
            if use_nccl:
                for nccl_option in nccl_options:
                    self.benchmark_command += f"-x {nccl_option} "

        self.benchmark_command += ("--mca pml ucx --mca osc ucx --mca spml ucx "
                                   "--mca btl ^vader,tcp,openib,uct ")
        self.benchmark_command += f"{test_path} "
        self.benchmark_command = self.bind_path(taskset_cpus) + self.benchmark_command

    @staticmethod
    def validate_args(**kwargs):
        """
        This method validates parameters required for the test are present and exit if not available
        """
        # validations
        gpu_only = kwargs.get("gpu_only", False)
        if not os.path.isabs(kwargs.get('mpirun_path')):
            raise exception.ConfigException("Provide valid MPIRUN path")
        if not gpu_only:
            if kwargs.get('ip_addr_list') is None:
                raise exception.ConfigException("IP address list is Empty")
            if kwargs.get('iface_list') is None:
                raise exception.ConfigException("Iface list is Empty")
            if kwargs.get('gid_index_list') is None:
                raise exception.ConfigException("GID list is Empty")
        if not os.path.isabs(kwargs.get('test_path')):
            raise exception.ConfigException("Provide valid test path")
        if kwargs.get('use_nccl') and not kwargs.get('nccl_options'):
            raise exception.ConfigException("Provide valid NCCL test options")

    def start(self):
        """
        Method to launch command with required argument
        :return:
        """
        # Run the command.
        self.expected_exit_codes = [0, None]  # reset the exit codes on each 'start' call
        self.mpi_proc = exe.run(
            self.benchmark_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            proc_name=self.proc_name,
            shell=True,
        )
        return True

    def stop(self, block=True):
        """

        :param block: Wait until poll() method is not None when set to True
        :return:
        """
        # Kill the process.
        self.mpi_proc.stop()
        self.expected_exit_codes.append(-15)
        # If requested, wait for the process to die.
        while self.mpi_proc.poll() is None and block is True:
            time.sleep(0.1)
        return self.mpi_proc.poll() is not None

    def poll(self):
        """
        Exit or continue based on exit code of process
        """
        # If the command failed, return failure.
        poll_res = self.mpi_proc.poll()
        if poll_res not in self.expected_exit_codes:
            raise exception.ExeExitcodeException(
                self.benchmark_command, poll_res, self.mpi_proc.get_error()
            )
        return poll_res

    def bind_path(self, taskset_cpus: List[int] = None) -> str:
        bind_path = ''
        if taskset_cpus:
            os_type = platform.system().lower()
            taskset_cmd_prefix = 'cpuset -l' if os_type == 'freebsd' else 'taskset --cpu-list'
            taskset_cpus = taskset_cpus if isinstance(taskset_cpus, list) else [taskset_cpus]
            bind_path = f'{taskset_cmd_prefix} {",".join(map(str, taskset_cpus))} '
        return bind_path


class Nccl(MpiController):
    """
    Class methods for RCCl/NCCL benchmark tests
    """
    def __init__(self, **kwargs):
        super().__init__()
        self.build_command(**kwargs)

    def build_command(self, **kwargs):
        """
        The Constructor.
        :param kwargs: A dictionary of arguments.
        Args:
            iterations: Number of iterations test needs to be ran
            message_size: message size to test with (Default is None)
            skip_iteration: skip x iterations before warmup
            mem_limit: Memory Limit (Max is 128)
            use_cuda: For GPU direct pt2pt scenario <True/False/Default:False>
            min_bytes: Minimum byte size to start with
            max_bytes: Maximum byte size to end with
            stepfactor: factor at which byte sizes to be skipped
            gpus_per_thread: number of GPU's to be utilized for test
            warmup_iters: warmup iteration count
            num_threads: Number of threads to be run
            operation_type: <sum/prod/min/max/avg/all>
            memory_type: <coarse/fine/host/managed>
            blocking: <0/1>
        """
        self.build_mpi_command(**kwargs)
        # initiation
        iterations = kwargs.get("iterations", None)  # iteration count
        message_size = kwargs.get("message_size", None)
        skip_iter = kwargs.get("skip_iteration", None)
        mem_limit = kwargs.get("mem_limit", None)
        min_bytes = kwargs.get("min_bytes", None)  # min size in bytes
        max_bytes = kwargs.get("max_bytes", None)  # max size in bytes
        stepfactor = kwargs.get("stepfactor", None)  # increment factor
        gpus_per_thread = kwargs.get("gpus_per_thread", None)  # gpus per thread
        threads = kwargs.get("num_threads", None)  # num threads
        operation_type = kwargs.get("operation_type", None)
        memory_type = kwargs.get("memory_type", None)
        blocking = kwargs.get("blocking", None)

        # below are test specific options
        nccl_command = ""
        if iterations:
            nccl_command += f"-n {iterations} "
        if message_size:
            nccl_command += f"-m {message_size} "
        if skip_iter:
            nccl_command += f"-x {skip_iter} "
        if mem_limit:
            nccl_command += f"-M {mem_limit} "
        if min_bytes:
            nccl_command += f"-b {min_bytes} "
        if max_bytes:
            nccl_command += f"-e {max_bytes} "
        if stepfactor:
            nccl_command += f"-f {stepfactor} "
        if threads:
            nccl_command += f"-t {threads} "
        if gpus_per_thread:
            nccl_command += f"-g {gpus_per_thread} "
        if operation_type:
            nccl_command += f"-o {operation_type} "
        if memory_type:
            nccl_command += f"-y {memory_type} "
        if blocking:
            nccl_command += f"-z {blocking} "

        self.benchmark_command += nccl_command

    def get_results(self):
        """
        Compose and return result
        :return: dict or string
        """
        res_dict = {}
        # Compose the results.
        output = self.mpi_proc.get_output().strip().split("\n")
        dict_keys = ['size', 'count', 'type', 'redop', 'root', 'oop_time', 'oop_algbw', 'oop_busbw', 'oop_wrong',
                     'ip_time', 'ip_algbw', 'ip_busbw', 'ip_wrong']
        for info in output:
            info = info.strip()
            if info and info[0].isdigit():
                line = info.split()
                temp_dict = OrderedDict(dict.fromkeys(dict_keys))
                for list_idx, item in enumerate(line):
                    for dict_idx, (k, v) in enumerate(temp_dict.items()):
                        if list_idx == dict_idx:
                            temp_dict[k] = item
                res_dict[temp_dict.pop("size")] = temp_dict
        # To reduce log file size print the whole command output
        # only if data is not available in expected format
        log.debug(f"Output for {self.proc_name} is {res_dict if res_dict else output}")
        return res_dict


class Comms(MpiController):
    """
    Class for comms benchmark
    """
    def __init__(self, **kwargs):
        """

        :param kwargs:
        """
        super().__init__()
        self.build_command(**kwargs)

    def build_command(self, **kwargs):
        """

        The Constructor.
        :param kwargs: A dictionary of arguments.
        Args:
            master_ip: Master IP to be used
            min_bytes: Minimum byte size to start with
            max_bytes: Maximum byte size to end with
            stepfactor: factor at which byte sizes to be skipped
            iterations: Number of iterations test needs to be ran
            test_name: Name of the test
            blocking: <0/1>
            backend: Backend to use <nccl/gloo/mpi/ucc/xla/fairring/Default:nccl>
            device: Device to use <cpu/cuda/rocm/tpu/Default:cuda>
            log: logging type <DEBUG/INFO/WARNING/ERROR/CRITICAL/Default:INFO>
            ibv_devices: # list of RoCE devices on which IO will be running
        """
        # initiation
        master_ip = kwargs.get("master_ip", None)
        min_bytes = kwargs.get("min_bytes", None)  # min size in bytes
        max_bytes = kwargs.get("max_bytes", None)  # max size in bytes
        stepfactor = kwargs.get("stepfactor", None)  # increment factor
        iterations = kwargs.get("iterations", None)  # iteration count
        test_name = kwargs.get("test_name", '')  # Name of binary
        test_type = kwargs.get("test_type", "collective")
        blocking = kwargs.get("blocking", None)
        backend = kwargs.get("backend", "nccl")  # backend to use
        device = kwargs.get("device", "cuda")  # Device to use
        log_type = kwargs.get("log", "INFO")  # logging type
        use_nccl = kwargs.get("use_nccl", False)
        ibv_devices = kwargs.get("ibv_devices", [])  # list of RoCE devices

        self.build_mpi_command(**kwargs)
        self.validate_param_args(**kwargs)

        # below are test specific options
        param_command = ""
        param_command += f"--master-ip {master_ip} "
        if min_bytes:
            param_command += f"--b {min_bytes} "
        if max_bytes:
            param_command += f"--e {max_bytes} "
        if stepfactor:
            param_command += f"--f {stepfactor} "
        if iterations:
            option = "n" if use_nccl else "i"
            param_command += f"--{option} {iterations} "
        param_command += f"--{test_type} {test_name} "
        if blocking:
            param_command += f"-z {blocking} "
        if ibv_devices:
            param_command += f"--ibv_devices {','.join(ibv_devices)}"
        param_command += f"--backend {backend} "
        param_command += f"--device {device} "
        param_command += f"--log {log_type} "
        self.benchmark_command += param_command

    @staticmethod
    def validate_param_args(**kwargs):
        """
        This method validates parameters required for the test are present and exit if not available
        """
        master_ip = kwargs.get("master_ip", None)
        backend = kwargs.get("backend", "nccl")
        device = kwargs.get("device", "cuda")
        log_type = kwargs.get("log_type", "INFO")
        test_name = kwargs.get("test_name", '')
        test_type = kwargs.get("test_type", "collective")
        supported_test_type = ["collective", "pt2pt"]
        # validations
        if master_ip is None:
            raise exception.ConfigException("Provide Valid master ip")
        if backend not in ["nccl", "gloo", "mpi", "ucc", "xla", "fairring"]:
            raise exception.ConfigException(f"Unsupported backend type {backend} provided")
        if device not in ["cpu", "cuda", "rocm", "tpu"]:
            raise exception.ConfigException(f"Unsupported device type {device} provided")
        if log_type not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            raise exception.ConfigException(f"Unsupported log type {log_type} provided")
        if not test_name:
            raise exception.ConfigException("Provide valid test_name (binary) to execute")
        if test_type not in supported_test_type:
            raise exception.ConfigException(f"Only {supported_test_type} test types are supported and not {test_type}")
        if test_type.lower() != 'pt2pt' and test_name.lower() in ['one2one', 'pairwise']:
            raise exception.ConfigException(f"Pt2Pt tests({test_name}) provided for non pt2pt type of test")

    def get_results(self):
        """
        Compose and return result
        :return: dict or string
        """
        res_dict = {}
        # Compose the results.
        output = self.mpi_proc.get_output().strip().split("\n")
        dict_keys = ['size', 'nelementsperrank', 'p50', 'p75', 'p90', 'min', 'max', 'algbw', 'busbw']
        for info in output:
            info = info.strip()
            if info.startswith("COMMS-RES-"):
                line = info.split()
                temp_dict = OrderedDict(dict.fromkeys(dict_keys))
                for list_idx, item in enumerate(line):
                    for dict_idx, (k, v) in enumerate(temp_dict.items()):
                        if list_idx == dict_idx:
                            temp_dict[k] = item
                res_dict[temp_dict.pop("size")] = temp_dict
        # To reduce log file size print the whole command output
        # only if data is not available in expected format
        log.debug(f"Output for {self.proc_name} is {res_dict if res_dict else output}")
        return res_dict


class Dlrm(MpiController):
    """
    Class for DLRM benchmark
    """
    def __init__(self, **kwargs):
        """

        :param kwargs:
        """
        super().__init__()
        self.build_command(**kwargs)

    def build_command(self, **kwargs):
        """

        The Constructor.
        :param kwargs: A dictionary of arguments.
        Args:
            master_ip: Master IP to be used
            backend: Backend to use <nccl/gloo/mpi/ucc/xla/fairring/Default:nccl>
            device: Device to use <cpu/cuda/rocm/tpu/Default:cuda>
            log: logging type <DEBUG/INFO/WARNING/ERROR/CRITICAL/Default:INFO>
            num_batches: Number of batches to be run (default: 10)
            mini_batch_size: mini_batch_size
            arch_mlp_bot: arch_mlp_bot
            arch_sparce_feature_size: arch_sparce_feature_size
            arch_embedding_size: arch_embedding_size
        """
        # initiation
        master_ip = kwargs.get("master_ip", None)
        backend = kwargs.get("backend", "nccl")  # backend to use
        device = kwargs.get("device", "cuda")  # Device to use
        log_type = kwargs.get("log", "INFO")  # logging type
        blocking = kwargs.get("blocking", None)
        mini_batch_size = kwargs.get("mini_batch_size", 32)
        num_batches = kwargs.get("num_batches", 10)
        arch_mlp_bot = kwargs.get("arch_mlp_bot", '1024-256')
        arch_sparce_feature_size = kwargs.get("arch_sparce_feature_size", '64')
        arch_embedding_size = kwargs.get("arch_embedding_size", '10000-10000-10000-10000-10000-10000-10000-10000-'
                                                                '10000-10000-10000-10000-10000-10000-10000-10000')

        self.build_mpi_command(**kwargs)
        self.validate_param_args(**kwargs)

        # below are test specific options
        param_command = ""
        param_command += f"--master-ip {master_ip} "
        param_command += f"--backend {backend} "
        param_command += f"--device {device} "
        param_command += f"--log {log_type} "
        param_command += f"--num-batches {num_batches} "
        param_command += f"--mini-batch-size {mini_batch_size} "
        param_command += f"--arch-mlp-bot {arch_mlp_bot} "
        param_command += f"--arch-sparse-feature-size {arch_sparce_feature_size} "
        param_command += f"--arch-embedding-size {arch_embedding_size} "
        if blocking:
            param_command += f"--z {blocking} "
        self.benchmark_command += param_command

    @staticmethod
    def validate_param_args(**kwargs):
        """
        This method validates parameters required for the test are present and exit if not available
        """
        master_ip = kwargs.get("master_ip", None)
        backend = kwargs.get("backend", "nccl")
        device = kwargs.get("device", "cuda")
        log_type = kwargs.get("log", "INFO")
        # validations
        if master_ip is None:
            raise exception.ConfigException("Provide Valid master ip")
        if backend not in ["nccl", "gloo", "mpi", "ucc", "xla", "fairring"]:
            raise exception.ConfigException(f"Unsupported backend type {backend} provided")
        if device not in ["cpu", "cuda", "rocm", "tpu"]:
            raise exception.ConfigException(f"Unsupported device type {device} provided")
        if log_type not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            raise exception.ConfigException(f"Unsupported log type {log_type} provided")

    def get_results(self):
        """
        Compose and return result
        :return: dict or string
        """
        # Compose the results.
        host_id = 1
        host_dict = {}
        output = self.mpi_proc.get_output().strip().split("\n")
        res_dict = {}
        dict_keys = ['iters', 'region', 'memory', 'lat_min', 'p50', 'p75', 'p95', 'sum']
        for info in output:
            info = info.strip()
            if info and info[0].isdigit():
                line = info.split()
                temp_dict = OrderedDict(dict.fromkeys(dict_keys))
                for list_idx, item in enumerate(line):
                    for dict_idx, (k, v) in enumerate(temp_dict.items()):
                        if list_idx == dict_idx:
                            temp_dict[k] = item
                res_dict[temp_dict.pop("region")] = temp_dict
                if line[1] == "total_time":
                    host_dict[f"GPU_{host_id}"] = res_dict
                    res_dict = {}
                    host_id += 1
        # To reduce log file size print the whole command output
        # only if data is not available in expected format
        log.debug(f"Output for {self.proc_name} is {host_dict if host_dict else output}")
        return host_dict


class CommsTraceReplay(MpiController):
    """
    Class for CommsTraceReplay benchmark
    """
    def __init__(self, **kwargs):
        """

        :param kwargs:
        """
        super().__init__()
        self.build_command(**kwargs)

    def build_command(self, **kwargs):
        """

        The Constructor.
        :param kwargs: A dictionary of arguments.
        Args:
            master_ip: Master IP to be used
            backend: Backend to use <nccl/gloo/mpi/ucc/xla/fairring/Default:nccl>
            device: Device to use <cpu/cuda/rocm/tpu/Default:cuda>
            trace_path: path of trace file to load
        """
        # initiation
        master_ip = kwargs.get("master_ip", None)
        backend = kwargs.get("backend", "nccl")  # backend to use
        device = kwargs.get("device", "cuda")  # Device to use
        trace_path = kwargs.get("trace_path", '')

        self.build_mpi_command(**kwargs)
        self.validate_param_args(**kwargs)

        # below are test specific options
        param_command = ""
        param_command += f"--master-ip {master_ip} "
        param_command += f"--backend {backend} "
        param_command += f"--device {device} "
        param_command += f"--trace-path {trace_path}"

        self.benchmark_command += param_command

    @staticmethod
    def validate_param_args(**kwargs):
        """
        This method validates parameters required for the test are present and exit if not available
        """
        master_ip = kwargs.get("master_ip", None)
        backend = kwargs.get("backend", "nccl")
        device = kwargs.get("device", "cuda")
        trace_path = kwargs.get("trace_path", '')
        # validations
        if master_ip is None:
            raise exception.ConfigException("Provide Valid master ip")
        if backend not in ["nccl", "gloo", "mpi", "ucc", "xla", "fairring"]:
            raise exception.ConfigException(f"Unsupported backend type {backend} provided")
        if device not in ["cpu", "cuda", "rocm", "tpu"]:
            raise exception.ConfigException(f"Unsupported device type {device} provided")
        if not os.path.isabs(trace_path):
            raise exception.ConfigException("Provide absolute trace path")

    def get_results(self):
        """
        Compose and return result
        :return: dict or string
        """
        # Compose the results.
        host_dict = {}
        # yet to get data to implement this API
        return host_dict


class Osu(MpiController):
    """
    Class methods for OSU benchmark tests
    """
    def __init__(self, **kwargs):
        super().__init__()
        self.build_command(**kwargs)
        self.unit_attribute = 'LATENCY' if 'lat' in kwargs.get('test_path') else 'THROUGHPUT'

    def build_command(self, **kwargs):
        """
        The Constructor.
        :param kwargs: A dictionary of arguments.
        Args:
            iterations: Number of iterations test needs to be ran
            message_size: message size to test with (Default is None)
            skip_iteration: skip x iterations before warmup
            use_cuda: For GPU direct pt2pt scenario <True/False/Default:False>
        """
        self.build_mpi_command(**kwargs)
        # initiation
        iterations = kwargs.get("iterations", None)  # iteration count
        message_size = kwargs.get("message_size", None)
        skip_iter = kwargs.get("skip_iteration", None)
        use_cuda = kwargs.get("use_cuda", True)

        # below are test specific options
        osu_command = ""
        if iterations:
            osu_command += f"-i {iterations} "
        if message_size:
            osu_command += f"-m {message_size} "
        if skip_iter:
            osu_command += f"-x {skip_iter} "
        if use_cuda:
            osu_command += "D D "

        self.benchmark_command += osu_command

    def get_results(self):
        """
        Compose and return result
        :return: dict or string
        """
        res_dict = {}
        # Compose the results.
        output = self.mpi_proc.get_output().strip().split("\n")
        for info in output:
            info = info.strip()
            if info and info[0].isdigit():
                line = info.split()
                temp_dict = {"size": line[0],
                             "%s" % self.unit_attribute: line[1]}
                res_dict[temp_dict.pop("size")] = temp_dict
        # To reduce log file size print the whole command output
        # only if data is not available in expected format
        log.debug(f"Output for {self.proc_name} is {res_dict if res_dict else output}")
        return res_dict
