"""
:mod:`netperf` -- netperf wrapper library
==================================================================================

.. module:: controller.lib.linux.io.netperf
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

This is a wrapper method for netperf 2.6

"""

import time
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class NetperfBase(object):
    if None in [find_executable('netperf'), find_executable('netserver')]:
        raise exception.ConfigException('netperf not found... Please check if netperf is installed!')

    def __init__(self, sock_type):
        self.__netperf_path = find_executable(sock_type)
        self.__sock_type = sock_type
        self.__netperf_pid = None
        self.__cmd = None

    def start(self, options, taskset_cpus=None):
        log.info('Starting %s with options (%s)' % (self.__sock_type, options))
        if taskset_cpus:
            taskset_cpus = taskset_cpus if isinstance(taskset_cpus, list) else [taskset_cpus]
        bind_path = f'taskset --cpu-list {",".join(map(str, taskset_cpus))} ' if taskset_cpus else ''
        self.__cmd = f'{bind_path}{self.__sock_type} {" ".join(options)}'
        self.__netperf_pid = exe.run(self.__cmd)

    def poll(self):
        if self.__netperf_pid:
            return self.__netperf_pid.poll()
        return False

    def get_data(self):
        if self.__sock_type == 'netserver':
            return None
        # If traffic is running return None
        if self.poll() is None:
            log.info('Traffic still running... No data available at this point...')
            return None
        if self.poll() is False:
            log.info('No data available... Was netperf run at all?')
            return False
        if not self.poll() in [0, None]:
            raise exception.NetperfDataException(
                'netperf terminated with errors... %s' % (self.__netperf_pid.get_output()))
        return self.__netperf_pid.get_output()

    def check_proc_status(self):
        output = exe.block_run('ps -Af')
        proc = self.__sock_type if not self.__cmd else self.__cmd
        for line in output.splitlines():
            if line.find(proc) != -1:
                return True
        return False

    def stop(self):
        """if self.__sock_type == 'netserver':
            log.warning('Killing all netserver processes...')
            exe.block_run('killall netserver')
            return True"""
        if not self.__netperf_pid:
            log.info('%s is not running...' % self.__sock_type)
            return True
        self.__netperf_pid.kill()
        timeout = time.time() + 5
        while time.time() < timeout:
            # Using "not None" as poll returns 0 on successful termination and if self.poll() will not work
            if self.poll() is not None:
                log.info('%s process successfully stopped' % self.__sock_type)
                return True
            time.sleep(0.25)
        else:
            raise exception.NetperfException('Failed to stop %s!' % self.__sock_type)


class Netperf(NetperfBase):
    """
        A class to represent the _STREAM kind of netperf tests
    """
    def __init__(self):
        super(Netperf, self).__init__('netperf')

    def start(self, srv_ip, proto='TCP_STREAM', port=12865, runtime=None, taskset_cpus=None,
              test_specific_options=None, *args, **kwargs):
        """
        :param srv_ip: ip address of server
        :param proto: kind of traffic to be run
        :param port: port number
        :param runtime: length of the test
        :param taskset_cpus: cpu cores for taskset
        :param test_specific_options: test specific args in dict format.
        :param args:
        :param kwargs: Generic params of netpef
        :return:
        """
        options = ['-H', srv_ip]  # Append the server ip to the list
        options.extend(['-p', str(port), '-t', proto])
        if runtime:
            options.extend(['-l', str(runtime)])
        for key in list(kwargs.keys()):
            options.extend(('-' + key, str(kwargs[key])))
        if args:
            options.extend(args)
        if test_specific_options:
            options.append('--')
            for key in list(test_specific_options.keys()):
                options.extend(('-' + key, str(test_specific_options[key])))
        super(Netperf, self).start(options, taskset_cpus=taskset_cpus)

    def __parse_output(self, output):
        """
        This is a data parser method to parse the output of netperf
        :param output(str): The output of netperf cmd
        :return perf_dict(dict): This is a dictionary of the perf stats obtained from netperf output

        Dictionary output example for TCP related tests:
        {'ElapsedTime': ['10.00', None], 'SendSocketSize': ['16384', None], 'SendMessageSize': ['16384', None],
        'Throughput': ['23459.93', None], 'RecvSocketSize': ['87380', None]}

        Dictionary output example for UDP related tests:
        {'MessagesOkay': ['282397', '176477'], 'ElapsedTime': ['10.00', '10.00'], 'SocketSize': ['212992', '212992'],
        'Errors': ['0', None], 'Throughput': ['14799.09', '9248.32'], 'MessageSize': ['65507', None]}

        Elapsed Time is in seconds
        Socket and Message Sizes ( both rx and tx ) are in bytes
        Throughput is in Mbps
        The dictionary values are lists of two elements. This is to accommodate the sceond set of values observed for
        the UDP tests.

        Note: The Request/Response tests will fail because of the hardcoding

        """
        from collections import OrderedDict
        perf_key_list = []
        perf_val_list = []
        value = False
        for line in output.splitlines():
            log.info(line)
            if line.find('MIGRATED') != -1:
                # Skip the first line
                continue
            if line.find('bytes') != -1:
                # Skip the units line and go to the next line with values
                value = True
                continue
            key_idx = 0
            if not value:
                for key in line.split(' '):
                    if key is not '':
                        if key_idx >= len(perf_key_list):
                            perf_key_list.append(key)
                        else:
                            perf_key_list[key_idx] += key
                        key_idx += 1
            else:
                values = []
                for val in line.split(' '):
                    # Take an empty line into consideration
                    if val is not '':
                        values.append(val)
                # Append only the non-empty lines to the list
                if values:
                    perf_val_list.append(values)

        """
          The below code is for identifying if the test is a UDP Stream Test,
          in which case both send and receive stats are reported and hence the value list would have two elements
        """
        if len(perf_val_list) == 2:
            # Insert None for Errors and Message size for the second list
            perf_val_list[1].insert(1, None)
            perf_val_list[1].insert(4, None)
        else:
            perf_val_list.append([None for i in range(0, len(perf_val_list[0]))])
        # Use an Ordered Dictionary so that the keys are sorted and the key-value mapping will be correct.
        perf_dict = OrderedDict([key, []] for key in perf_key_list)
        idx = 0
        for key in list(perf_dict.keys()):
            perf_dict[key] = list(map(list, list(zip(perf_val_list[0], perf_val_list[1]))))[idx]
            idx += 1
        # Return a dictionary of the parsed output
        return dict(perf_dict)

    def get_data(self):
        """
        :return: None if the traffic is still running, else returns the dict obtained from parse_output
        """
        output = super(Netperf, self).get_data()
        if not output in [None, False]:
            return self.__parse_output(output)


class NetServer(NetperfBase):
    def __init__(self):
        super(NetServer, self).__init__('netserver')

    def start(self, srv_ip, port=12865, ipv6=False, taskset_cpus=None, **kwargs):
        options = ['-L', srv_ip, '-p', str(port)]
        for key in list(kwargs.keys()):
            options.extend(['-' + key, str(kwargs[key])])
        if ipv6:
            options.append('-6')
        options.append('-D')
        super(NetServer, self).start(options, taskset_cpus=taskset_cpus)


class Netperf_RR(NetperfBase):
    """
        A class to represent the Request/Response (_RR) kind of netperf tests
    """
    def __init__(self):
        super(Netperf_RR, self).__init__('netperf')

    def start(self, srv_ip, proto='TCP_RR', port=12865, runtime=None, taskset_cpus=None,
              test_specific_options=None, *args, **kwargs):
        """
        :param srv_ip: ip address of server
        :param proto: kind of traffic to be run
        :param port: port number
        :param runtime: length of the test
        :param taskset_cpus: cpu cores for taskset
        :param test_specific_options: test specific args in dict format ex: {'k': 'mean_latency,max_latency'}
        :param args:
        :param kwargs: Generic params of netpef
        :return:
        """
        options = ['-H', srv_ip]  # Append the server ip to the list
        options.extend(['-p', str(port), '-t', proto])
        if runtime:
            options.extend(['-l', str(runtime)])
        for key in list(kwargs.keys()):
            options.extend(('-' + key, str(kwargs[key])))
        if args:
            options.extend(args)

        test_specific_options = test_specific_options or {}
        test_specific_options['k'] = test_specific_options.get('k',
                                                             'min_latency,mean_latency,max_latency,stddev_latency,transaction_rate')
        if test_specific_options:
            options.append('--')
            for key in list(test_specific_options.keys()):
                options.extend(('-' + key, str(test_specific_options[key])))
        super(Netperf_RR, self).start(options, taskset_cpus=taskset_cpus)

    def __parse_output(self, output):
        """
        This is a data parser method to parse the output of netperf request/response
        :param output(str): The output of netperf cmd
        :return perf_stats(dict): This is a dictionary of the perf stats obtained from netperf output

        """
        log.info(output)
        perf_stats = {}
        output_lines = [line for line in output.splitlines() if '=' in line]
        if output_lines[0].find('MIGRATED') != -1:
            output_lines.pop(0)
        if output_lines[0].find('bytes') != -1:
            output_lines.pop(0)
        for line in output_lines:
            key, value = line.split('=')
            perf_stats[key] = value
        return perf_stats

    def get_data(self):
        """
        :return: None if the traffic is still running, else returns the dict obtained from parse_output
        """
        output = super(Netperf_RR, self).get_data()
        if not output in [None, False]:
            return self.__parse_output(output)
