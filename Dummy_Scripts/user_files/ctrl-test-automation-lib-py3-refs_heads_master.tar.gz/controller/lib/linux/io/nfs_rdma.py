"""
:mod:`nfs_rdma` -- NFS-RDMA Wrapper.
====================================

.. module:: controller.lib.linux.io.nfs_rdma
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for NFS-RDMA. Listed below are the functionalities
provided by this module:

1. Setup a linux node as NFS server.
2. Setup a linux node as NFS client.
3. Test transferring a BIG file using NFS-RDMA.
4. Optionally verify the MD5 checksum after file copy.
5. Perform IO on an NFS-RDMA mount point using MLTT.
6. Optionally verify NFS statistics after IO.
7. Restore the states of the NFS server and client nodes.
"""

import time
import re

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
import controller.lib.common.io.mltt as mltt
import controller.lib.linux.eth.ip as ip
from controller.lib.linux.io import fio

__changeset__ = """
ID               WHO         WHEN(MM/DD/YY)   COMMENTS
==============================================================================
DCSG_ALL_ERS     Team        11/07/24         All check-ins till date
DCSG01745560     gs888750    12/07/24         removing unload of driver from cleanup path as it is not necessary

"""
log = log_handler.get_logger(__name__)


class NFSRDMAController(object):
    def __init__(self, mode='server', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which NFS controller runs.
                   - 'server' to run as NFS server.
                   - 'client' to run as NFS client.
            kwargs : A dictionary of additional optional arguments.
                   - 'nfs_dir':'<nfs_dir>'
                     The NFS mount point directory (Mandatory).

                   - 'server_name'='<server_name>'
                     The name or IP address of the NFS server node (Mandatory).

                   - 'io_type'='<io_type>'
                     'file_transfer' - Test file transfer using NFS-RDMA (default).
                     'mltt_io' - Test IO using MLTT.

                   - 'file_size'='<file_size>'
                     The size of the file to use for testing file transfer (default='2G').
                     Valid only if 'io_type' is 'file_transfer'.

                   - 'nfs_rdma_port'='<nfs_rdma_port>'
                     The port number to use for NFS-RDMA (default='20049').

                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO using MLTT (default='120').
                     Valid only if 'io_type' is 'mltt_io'.
        """
        self._mode = mode
        self._server_name = kwargs.get('server_name', None)

        if self._mode is 'client' and self._server_name is None:
            raise exception.ConfigException('No NFS server name specified')

        self._io_tool = None
        self._nfs_dir = kwargs.get('nfs_dir', '/home/nfs-dir-0/')
        self._mount_point_count = kwargs.get('mount_point_count', '1')
        self._interface_count = kwargs.get('interface_count', 1)
        self._block_size = kwargs.get('block_size', '64K')
        self._thread_count = kwargs.get('thread_count', '8')
        self._queue_depth = kwargs.get('queue_depth', '8')
        self._file_size = kwargs.get('file_size', '2G')
        self._nfs_rdma_port = kwargs.get('nfs_rdma_port', '20049')
        self._nfs_version = kwargs.get('nfs_version', '4.0')
        self._io_type = kwargs.get('io_type', 'file_transfer')
        self._io_duration = kwargs.get('io_duration', '120')
        self._total_count_load = '0'
        self._total_count_verify = '0'
        self._file_name = 'file-' + self._file_size + '.img'
        self._toggle_link = kwargs.get('toggle_link', 'no')
        self._monitor_time = kwargs.get('monitor_time', '0')
        self._iface_name = kwargs.get('iface_name', None)
        self._io_mode = kwargs.get('io_mode', 'asynchronous')
        self._rdma_io_tool = kwargs.get("rdma_ulp_io_tool", "mltt")
        self._fio_op_type = kwargs.get("fio").get("operation_type", "write") if kwargs.get("fio") else "write"
        self._fio_engine = kwargs.get("fio").get("io_engine", "libaio") if kwargs.get("fio") else "libaio"
        self._service_name, self._driver_name = self._get_nfs_config_params()
        # The set of information presented as test result.
        self._results = {'THROUGHPUT (MB/s)': '',
                         'IOPS': '',
                         'LATENCY': '',
                         'CPU': '',
                         'ERRORS': ''}

        if self._toggle_link is 'yes' and self._iface_name is None:
            raise exception.ConfigException('No ip interface name specified')
        # initilize it to True by assuming host has valid MLTT license
        self.active_mltt_license = True if self._rdma_io_tool.lower() == "mltt" else False
        self.check_io_tool_to_use()

    def check_io_tool_to_use(self):
        """
        Use FIO tool if MLTT license is not available else use MLTT
        """
        if self._rdma_io_tool not in ['mltt', 'fio']:
            raise exception.ConfigException(
                f"Unsupported IO tool passed:{self._rdma_io_tool}; supported are mltt/fio"
            )

        if self._rdma_io_tool == "mltt":
            if self._io_mode == "synchronous":
                self._io_tool = mltt.Pain()
            else:
                self._io_tool = mltt.Maim()
            if not self._io_tool.check_license():
                log.info(
                    f"Host does not have Active MLTT License; hence switching to FIO as IO tool"
                )
                self.active_mltt_license = False
                self._rdma_io_tool = 'fio'  # switch to FIO when MLTT does not have active license

        if self._rdma_io_tool == "fio":
            self._io_tool = fio.Fio()

    def _get_nfs_config_params(self):
        """
            Helper method that returns the configuration parameters related to
            NFS service on various Linux distro's.
        """
        driver_name = None
        linux_distro = None
        release = None
        service_name = None
        # Check which Linux distro is running on the SUT.
        # CTRL-43129: controller tar ball to include lsb rpm as pre-requisite.
        # Use the file '/etc/os-release' instead of lsb_release tool.
        command_output = exe.block_run('cat /etc/os-release')

        for each_line in command_output.split('\n'):
            # CentOS and RHEL are twins. So, treat them as one.
            if 'Red Hat' in each_line or 'CentOS Linux' in each_line or 'Rocky Linux' in each_line:
                linux_distro = 'RHEL'
            elif 'SUSE Linux' in each_line:
                linux_distro = 'SUSE'
            elif 'Debian' in each_line or 'Ubuntu' in each_line:
                linux_distro = 'Debian'
            # CTRL-45199: roce\QA-Controller-31011.py has no support for oracle distro.
            # Identify Oracle Linux as well.
            elif 'Oracle' in each_line:
                linux_distro = 'Oracle'
            elif 'VERSION_ID' in each_line:
                release = re.search('VERSION_ID="(.*)"', each_line).group(1)
            if linux_distro and release:
                break

        if linux_distro is None or release is None:
            raise exception.TestCaseFailure('Unable to recognize the Linux distro.')
        # CTRL-48759: Automation: NFSRDMA: NFSRDMA scripts incorrectly identify module names on
        # CentOS 7.6 (Core).
        # On CentOS core, strangely the 'VERSION_ID' field contains just a single tuple as in:
        # -
        # -
        # VERSION="7 (Core)"
        # ID="centos"
        # ID_LIKE="rhel fedora"
        # VERSION_ID="7"
        # PRETTY_NAME="CentOS Linux 7 (Core)"
        # ANSI_COLOR="0;31"
        # -
        # -
        # So, in such cases, read the "/etc/redhat-release" file to get the correct 2 tuple version
        # number.
        if release.count('.') == 0 and linux_distro == 'RHEL':
            command = 'cat /etc/redhat-release'
            command_output = exe.block_run(command, shell=True).strip()
            release = re.search(r'(\d.\d)', command_output).group(1)
        # If the release string is too crazy to be a float, force it to be one.
        elif release.count('.') > 1:
            temp_list = release.split('.')
            release = temp_list[0] + '.' + temp_list[1]

        if linux_distro == 'RHEL':
            if float(release) < 7.3:
                driver_name = 'svcrdma' if self._mode == 'server' else 'xprtrdma'
            else:
                driver_name = 'rpcrdma'
            if float(release) >= 8.1:
                service_name = 'nfs-server'
            else:
                service_name = 'nfs'

        elif linux_distro == 'SUSE':
            if float(release) < 12.0:
                driver_name = 'svcrdma' if self._mode == 'server' else 'xprtrdma'
            else:
                driver_name = 'rpcrdma'

            service_name = 'nfsserver'
        # CTRL-45199: roce\QA-Controller-31011.py has no support for oracle distro.
        # Identify Oracle Linux as well.
        elif linux_distro == 'Oracle':
            driver_name = 'rpcrdma'
            service_name = 'nfs'

        elif linux_distro == 'Debian':
            driver_name = 'svcrdma'
            service_name = 'nfs-server'

        return service_name, driver_name

    def setup_nfs_server(self, deep_init=True):
        """
        """
        if self._mode is not 'server':
            raise exception.ConfigException('Attempt to setup NFS server on client node')

        if deep_init is True:
            # On some OS's, if the mount points don't exist, the NFS
            # service doesn't start. So, first of all, create all the
            # necessary directories.
            # clear the /etc/exports to avoid any stale entries to cause problem
            # during test. JIRA CTRL-55474
            self._clear_exports()
            time.sleep(2)
            for index in range(int(self._mount_point_count) * self._interface_count):
                nfs_dir = re.sub(r'(.*)(0)', r'\g<1>' + str(index), self._nfs_dir)
                command = 'mkdir -p ' + nfs_dir
                try:
                    exe.block_run(command)
                except Exception:
                    pass
                # CTRL-43247: roce/nfsordma scripts failing.
                # Make entries into '/etc/exports' if necessary.
                try:
                    command = 'cat /etc/exports | grep -w %s' % \
                        (nfs_dir[:-1] if nfs_dir[-1] == '/' else nfs_dir)
                    command_output = exe.block_run(command, shell=True)
                except exception.ExeExitcodeException:
                    command_output = ''
                # If already configured, nothing more to do.
                if command_output.strip() == '':
                    command = \
                        'echo "%s *(fsid=%s,rw,async,insecure,no_root_squash)" >> /etc/exports' % \
                        ((nfs_dir[:-1] if nfs_dir[-1] == '/' else nfs_dir), (index + 1))
                    exe.block_run(command, shell=True)
            # (Re)Start the NFS service.
            command = 'service ' + self._service_name + ' restart'
            exe.block_run(command)
            # Load the server side NFS RDMA driver module module.
            command = 'modprobe ' + self._driver_name
            time.sleep(3)
            exe.block_run(command)
            # Configure the NFS RDMA port.
            path_found = False
            port_file_name = '/proc/fs/nfsd/portlist'
            fo = open(port_file_name, 'r')
            output = fo.read()
            fo.close()
            for line in output.splitlines():
                if line == 'rdma ' + self._nfs_rdma_port:
                    path_found = True
            if not path_found:
                fo = open(port_file_name, 'a')
                fo.write('rdma ' + str(self._nfs_rdma_port))
                fo.close()
            # command = 'echo "rdma ' + self._nfs_rdma_port + '" > /proc/fs/nfsd/portlist'
            # time.sleep(2)
            # exe.block_run(command, shell=True)
            # Verify that the NFS RDMA port configuration is successful.
            command = 'cat /proc/fs/nfsd/portlist'
            command_output = exe.block_run(command)
            return_status = False

            for each_line in command_output.split('\n'):
                if self._nfs_rdma_port in each_line:
                    return_status = True
                    break

            if return_status is False:
                raise exception.TestCaseFailure('Failed to configure NFS-RDMA port')

        # Create THE BIG file for NFS transfer.
        if self._io_type == 'file_transfer':
            # command = 'fallocate -l ' + self._file_size + ' ' + self._nfs_dir + self._file_name
            command = 'truncate -s ' + self._file_size + ' ' + self._nfs_dir + self._file_name
            exe.block_run(command)

        return True

    def setup_nfs_client(self, deep_init=True):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to setup NFS client on server node')

        if deep_init is True:
            # Load the client side NFS-RDMA driver module.
            command = 'modprobe ' + self._driver_name
            exe.block_run(command)

        # Try creating the NFS directory.
        try:
            exe.block_run('mkdir -p ' + self._nfs_dir)
        except Exception:
            pass
        # Mount the remote NFS directory.
        command = 'mount -o rdma,port=' + self._nfs_rdma_port + ',vers=' + self._nfs_version + \
            ' ' + self._server_name + ':' + self._nfs_dir + ' ' + self._nfs_dir
        exe.block_run(command)
        # Verify that the mount is successful.
        command = 'mount'
        command_output = exe.block_run(command)
        return_status = False

        for each_line in command_output.split('\n'):
            if self._server_name in each_line:
                return_status = True
                break

        if return_status is False:
            raise exception.TestCaseFailure('Failed to configure NFS-RDMA mount point')

        return True

    def do_nfs_file_transfer(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to perform file transfer test on server node')

        # Copy THE BIG file on the mounted directory to /tmp/.
        command = 'cp ' + self._nfs_dir + self._file_name + ' /tmp/'
        exe.block_run(command)
        # Verify that the copy was successful.
        command = 'ls -lh /tmp/' + self._file_name
        command_output = exe.block_run(command)
        return_status = False

        for each_line in command_output.split('\n'):
            if self._file_name in each_line:
                return_status = True
                break

        if return_status is False:
            raise exception.TestCaseFailure('Failed to perform file transfer')

        return True

    def verify_nfs_stats(self, operation='load'):
        """
        """
        # Collect NFS stats on SUT #1.
        command = 'nfsstat -sl' if self._mode is 'server' else 'nfsstat -cl'
        command_output = exe.block_run(command)

        for each_line in command_output.split('\n'):
            if 'total:' in each_line:
                if operation is 'load':
                    self._total_count_load = each_line.split('total:')[1].strip()
                else:
                    self._total_count_verify = each_line.split('total:')[1].strip()
                break

        # If asked to verify, make sure that the value read the second time
        # is larger than that read first.
        if operation is 'verify':
            if int(self._total_count_verify) <= int(self._total_count_load):
                raise exception.TestCaseFailure('NFS statistics validation failed: '
                                                'initial -> ' + self._total_count_load +
                                                'final -> ' + self._total_count_verify)

        return True

    def cleanup_nfs_server(self, deep_cleanup=True):
        """
        """
        if self._mode is not 'server':
            raise exception.ConfigException('Attempt to cleanup NFS server on client node')

        # Remove THE BIG file on SUT #1.
        if self._io_type == 'file_transfer':
            command = 'rm -f ' + self._nfs_dir + self._file_name
        else:
            command = 'rm -f ' + self._nfs_dir + 'targetfile.dat'

        exe.block_run(command)

        if deep_cleanup is True:
            self._clear_exports()
            self.stop_nfs_service()

        return True

    def cleanup_nfs_client(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to cleanup NFS client on server node')

        # Unmount the remote NFS directory.
        command = 'umount -f ' + self._nfs_dir
        exe.block_run(command)
        # Remove THE BIG file from /tmp/ on SUT #2.
        if self._io_type == 'file_transfer':
            command = 'rm -f /tmp/' + self._file_name
            exe.block_run(command)

        if self.active_mltt_license:
            # Remove the temporary folder created by MLTT.
            if self._io_tool is not None:
                command = 'rm -rf ' + self._io_tool.temp_dir
                exe.block_run(command)

        return True

    def configure_mltt(self):
        # setup the MLTT command options.
        block_size_option = "-b" + self._block_size
        thread_count_option = "-t" + self._thread_count
        queue_depth_option = "-Q" + self._queue_depth
        monitor_time = "-M" + self._monitor_time
        mltt_options = [
            block_size_option,
            thread_count_option,
            queue_depth_option,
            "-C1",
            "-o",
            "-%f100",
            monitor_time,
        ]
        return mltt_options

    def configure_fio(self):
        # Setup the FIO command options.
        io_engine = "--ioengine=" + self._fio_engine
        block_size_option = "--bs=" + self._block_size
        queue_depth_option = "--iodepth=" + self._queue_depth
        operation_type = "--rw=" + self._fio_op_type
        numjobs = "--numjobs=" + self._thread_count
        fio_options = [
            io_engine,
            block_size_option,
            queue_depth_option,
            operation_type,
            numjobs,
            "--name=temp-fio",
            f"--size={self._block_size}"
        ]

        return fio_options

    def do_nfs_mltt_io(self, dst_ip=None, block=True):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to perform IO on server node')

        tool_options = self.configure_mltt() if self.active_mltt_license else self.configure_fio()
        dst_ip = dst_ip or self._nfs_dir
        self._io_tool.start(dst_ip, self._io_duration, tool_options)
        if block is True:
            # Sleep until the command is completed. If asked to toggle the
            # link state during the IO, do so roughly in the middle.
            io_run_time = 0
            mid_io_duration = int(self._io_duration) / 2

            while self._io_tool.poll() is None:
                if self._toggle_link == 'yes' and io_run_time == mid_io_duration:
                    print(('bring ip link on %s down' % self._iface_name))
                    ip.down(self._iface_name)
                    time.sleep(3)
                    print(('bring ip link on %s up' % self._iface_name))
                    ip.up(self._iface_name)
                io_run_time = io_run_time + 1
                time.sleep(1)
            # If the command failed, return failure.
            if self._io_tool.poll() != 0:
                raise exception.ExeExitcodeException(self._io_tool.command, self._io_tool.poll(), '')
            self.get_results()

        return True

    @staticmethod
    def _clear_exports():
        # clear the /etc/exports to avoid any stale entries to cause problem
        # during test. JIRA CTRL-55474
        exe.block_run('echo "" > /etc/exports', shell=True)
        time.sleep(2)

    def stop_nfs_service(self):
        # Stop nfs service on SUT #1.
        command = 'service ' + self._service_name + ' stop'
        exe.block_run(command)
        # Unload the server side NFS-RDMA driver module on SUT #1.
        time.sleep(3)

    def unload_driver(self):
        command = 'rmmod ' + self._driver_name
        try:
            exe.block_run(command)
        except Exception as e:
            if 'not currently loaded' in str(e):
                pass
            else:
                raise exception.TestCaseFailure("Unable to unload NFS driver due to %s" % str(e))

    def poll(self):
        """
        """
        while self._io_tool.poll() is None:
            time.sleep(1)

        if self._io_tool.poll() != 0:
            raise exception.ExeExitcodeException(self._io_tool.command, self._io_tool.poll(), '')
        self.get_results()
        return self._io_tool.poll()

    def get_results(self):
        # Compose the results, just in case someone asks for them.
        if self._rdma_io_tool.lower() == "fio":
            self._results = self._io_tool.results()
        else:
            result = self._io_tool.get_data()
            temp_string = re.sub(r'.*\s-\s', '', str(result.throughput)).replace('|', ';').replace('>', '')
            self._results['THROUGHPUT (MB/s)'] = temp_string
            temp_string = re.sub(r'.*\s-\s', '', str(result.iops)).replace('|', ';').replace('>', '')
            self._results['IOPS'] = temp_string
            temp_string = re.sub(r'.*\s-\s', '', str(result.latency)).replace('|', ';').replace('>', '')
            self._results['LATENCY'] = temp_string
            temp_string = re.sub(r'.*\s-\s', '', str(result.cpu_util)).replace('|', ';').replace('>', '')
            self._results['CPU'] = temp_string
            temp_string = re.sub(r'.*\s-\s', '', str(result.errors)).replace('|', ';').replace('>', '')
            self._results['ERRORS'] = temp_string

        return self._results

    @property
    def results(self):
        """
        """
        return self._results


class NFSServer(NFSRDMAController):
    def __init__(self, **kwargs):
        super(NFSServer, self).__init__(mode='server', **kwargs)


class NFSClient(NFSRDMAController):
    def __init__(self, **kwargs):
        super(NFSClient, self).__init__(mode='client', **kwargs)
