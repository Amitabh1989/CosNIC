"""
:mod:`nvmf` -- NVME over Fabric Wrapper.
=========================================

.. module:: controller.lib.linux.io.nvmf
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for NVME over Fabric. Listed below are the
functionalities provided by this module:

1. Setup a linux node as NVMF target.
2. Setup a linux node as NVMF initiator.
3. Perform IO on an NVMF mount point using MLTT.
4. Perform local copy of a BIG file on the NVMF initiator node.
5. Perform remote copy of a BIG file from the NVMF target node to the initiator node.
6. Restore the states of the NVMF target and initiator nodes.
"""

import time
import re
import os
from distutils.spawn import find_executable

from controller.lib.core import log_handler
from controller.lib.core import exception
import controller.lib.common.io.mltt as mltt
from controller.lib.common.shell import exe
import controller.lib.linux.eth.ip as ip
from controller.lib.linux.io import fio

__changeset__ = """
ID               WHO         WHEN(MM/DD/YY)   COMMENTS
==============================================================================
DCSG_ALL_ERS     Team        11/07/24         All check-ins till date
DCSG01658268     gs888750    25/07/24         supporting FIO tool as alternate IO tool

"""
log = log_handler.get_logger(__name__)


class NVMFController(object):
    def __init__(self, mode="target", **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which NVMF controller runs.
                   - 'target' to run as NVMF target.
                   - 'initiator' to run as NVMF initiator.
            kwargs : A dictionary of additional optional arguments.
                   - 'target_name'='<target_name>'
                     The name or IP address of the NVMF target node (Mandatory).

                   - 'initiator_name'='<initiator_name>'
                     The name or IP address of the NVMF initiator node (Mandatory).

                   - 'nvmf_port'='<nvmf_port>'
                     The port number to use for NVMF communication (default='1023').

                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO using MLTT (default='120').
        """
        self._mode = mode

        self._target_name = kwargs.get("target_name", None)
        self._initiator_name = kwargs.get("initiator_name", None)

        if self._target_name is None:
            raise exception.ConfigException("No NVMF target name specified")

        if self._initiator_name is None:
            raise exception.ConfigException("No NVMF initiator name specified")

        self._nvmetcli_path = find_executable("nvmetcli")
        if self._nvmetcli_path is None:
            raise exception.ConfigException("nvmetcli is not available")

        self._io_tool = None
        self._block_size = kwargs.get("block_size", "64K")
        self._thread_count = kwargs.get("thread_count", "8")
        self._queue_depth = kwargs.get("queue_depth", "8")
        self._nvmf_port = kwargs.get("nvmf_port", "1023")
        self._io_duration = kwargs.get("io_duration", "120")
        self._address_family = "ipv4"
        self._file_size = kwargs.get("file_size", "100M")
        self._ram_disk_size = kwargs.get("ram_disk_size", "1G")
        self._file_name = "file-" + self._file_size + ".img"
        self._mount_point_count = kwargs.get("mount_point_count", "1")
        self._mount_point_index = kwargs.get("mount_point_index", "0")
        self._subsystem_name = "test-subsystem-" + self._mount_point_index
        self._toggle_link = kwargs.get("toggle_link", "no")
        self._monitor_time = kwargs.get("monitor_time", "0")
        self._iface_name = kwargs.get("iface_name", None)
        self._io_mode = kwargs.get("io_mode", "asynchronous")
        self._rdma_io_tool = kwargs.get("rdma_ulp_io_tool", "mltt")
        self._fio_op_type = kwargs.get("fio").get("operation_type", "write") if kwargs.get("fio") else "write"
        self._fio_engine = kwargs.get("fio").get("io_engine", "libaio") if kwargs.get("fio") else "libaio"
        # The set of information presented as test result.
        self._results = {"THROUGHPUT (MB/s)": "", "IOPS": "", "CPU": "", "ERRORS": ""}

        # We need not support all possible sizes for the RAM disks. So, if what is
        # requested is not in the list of supported, assume the max.
        if self._ram_disk_size not in ["64M", "128M", "256M", "512M", "1G"]:
            self._ram_disk_size = "1G"

        if self._toggle_link == "yes" and self._iface_name is None:
            raise exception.ConfigException("No ip interface name specified")
        # initilize it to True by assuming host has valid MLTT license
        self.active_mltt_license = True if self._rdma_io_tool.lower() == "mltt" else False
        self.check_io_tool_to_use()

    def check_io_tool_to_use(self):
        """
        Use FIO tool if MLTT license is not available else use MLTT
        """
        if self._rdma_io_tool not in ['mltt', 'fio']:
            raise exception.ConfigException(
                f"Unsupported IO tool passed:{self._rdma_io_tool}; supported are mltt/fio"
            )

        if self._rdma_io_tool == "mltt":
            if self._io_mode == "synchronous":
                self._io_tool = mltt.Pain()
            else:
                self._io_tool = mltt.Maim()
            if not self._io_tool.check_license():
                log.info(
                    f"Host does not have Active MLTT License; hence switching to FIO as IO tool"
                )
                self.active_mltt_license = False
                self._rdma_io_tool = 'fio'  # switch to FIO when MLTT does not have active license

        if self._rdma_io_tool == "fio":
            self._io_tool = fio.Fio()

    def setup_nvmf_target(self, deep_init=True):
        """ """
        if self._mode is not "target":
            raise exception.ConfigException(
                "Attempt to setup NVMF target on initiator node"
            )

        if deep_init is True:
            # Translate the RAM disk size as needed for 'brd' module.
            if self._ram_disk_size == "64M":
                self._ram_disk_size = "67108"
            elif self._ram_disk_size == "128M":
                self._ram_disk_size = "134217"
            elif self._ram_disk_size == "256M":
                self._ram_disk_size = "268435"
            elif self._ram_disk_size == "512M":
                self._ram_disk_size = "536871"
            else:
                self._ram_disk_size = "1073742"
            # Load the 'brd' module to setup RAM disks.
            command = (
                "modprobe brd rd_nr="
                + self._mount_point_count
                + " rd_size="
                + self._ram_disk_size
            )
            exe.block_run(command)
            time.sleep(2)
            # Load the 'nvmet' module.
            command = "modprobe nvmet"
            exe.block_run(command)
            time.sleep(2)
            # Load the 'nvmet-rdma' module.
            command = "modprobe nvmet-rdma"
            exe.block_run(command)
            time.sleep(2)

        # Do the necessary initializations.
        target_id = str(int(self._mount_point_index) + 1)
        # Setup the NVMF target.
        command = "mkdir /sys/kernel/config/nvmet/subsystems/" + self._subsystem_name
        exe.block_run(command)
        time.sleep(1)
        command = (
            "mkdir /sys/kernel/config/nvmet/subsystems/"
            + self._subsystem_name
            + "/namespaces/"
            + target_id
            + "/"
        )
        exe.block_run(command)
        time.sleep(1)
        command = "mkdir /sys/kernel/config/nvmet/ports/" + target_id
        exe.block_run(command)
        time.sleep(1)
        command = (
            "echo -n /dev/ram"
            + self._mount_point_index
            + " > /sys/kernel/config/nvmet/subsystems/"
            + self._subsystem_name
            + "/namespaces/"
            + target_id
            + "/device_path"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "echo 1 > /sys/kernel/config/nvmet/subsystems/"
            + self._subsystem_name
            + "/attr_allow_any_host"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "echo 1 > /sys/kernel/config/nvmet/subsystems/"
            + self._subsystem_name
            + "/namespaces/"
            + target_id
            + "/enable"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "echo "
            + self._nvmf_port
            + " > /sys/kernel/config/nvmet/ports/"
            + target_id
            + "/addr_trsvcid"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "echo "
            + self._target_name
            + " > /sys/kernel/config/nvmet/ports/"
            + target_id
            + "/addr_traddr"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "echo rdma > /sys/kernel/config/nvmet/ports/" + target_id + "/addr_trtype"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "echo "
            + self._address_family
            + " > /sys/kernel/config/nvmet/ports/"
            + target_id
            + "/addr_adrfam"
        )
        exe.block_run(command, shell=True)
        time.sleep(1)
        command = (
            "ln -s /sys/kernel/config/nvmet/subsystems/"
            + self._subsystem_name
            + " /sys/kernel/config/nvmet/ports/"
            + target_id
            + "/subsystems/"
            + self._subsystem_name
        )
        exe.block_run(command)
        time.sleep(1)
        return True

    def setup_nvmf_initiator(self, deep_init=True):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to setup NVMF initiator on target node"
            )

        if deep_init is True:
            # Load the 'nvme' module.
            command = "modprobe nvme"
            exe.block_run(command)
            time.sleep(2)
            # Load the 'nvme-rdma' module.
            command = "modprobe nvme-rdma"
            exe.block_run(command)
            time.sleep(2)

        # Make sure that the target is discovered on the initiator.
        command = (
            "nvme discover -t rdma -a " + self._target_name + " -s " + self._nvmf_port
        )
        exe.block_run(command)
        time.sleep(1)
        # Connect to the discovered NVMF subsystem.
        command = (
            "nvme connect -t rdma -a "
            + self._target_name
            + " -s "
            + self._nvmf_port
            + " -n "
            + self._subsystem_name
        )
        exe.block_run(command)
        time.sleep(1)

        return True

    def cleanup_nvmf_target(self, deep_cleanup=True):
        """ """
        if self._mode is not "target":
            raise exception.ConfigException(
                "Attempt to cleanup NVMF target on initiator node"
            )

        # Do the necessary initializations.
        target_id = str(int(self._mount_point_index) + 1)
        # Remove the entries in the reverse order of creation.
        folder_name = (
            "/sys/kernel/config/nvmet/ports/"
            + target_id
            + "/subsystems/"
            + self._subsystem_name
        )

        if os.path.isdir(folder_name):
            exe.block_run("rm -rf " + folder_name)
        time.sleep(1)

        folder_name = "/sys/kernel/config/nvmet/ports/" + target_id
        if os.path.isdir(folder_name):
            exe.block_run("rmdir " + folder_name)
        time.sleep(1)

        folder_name = (
            "/sys/kernel/config/nvmet/subsystems/"
            + self._subsystem_name
            + "/namespaces/"
            + target_id
            + "/"
        )
        if os.path.isdir(folder_name):
            exe.block_run("rmdir " + folder_name)
        time.sleep(1)
        folder_name = "/sys/kernel/config/nvmet/subsystems/" + self._subsystem_name
        if os.path.isdir(folder_name):
            exe.block_run("rmdir " + folder_name)
        time.sleep(1)

        if deep_cleanup is True:
            self._clear_nvmet_conf()
            driver_list = ["nvmet-rdma", "nvmet", "brd"]
            self.unload_driver(driver_list=driver_list)

        return True

    def _clear_nvmet_conf(self):
        exe.block_run("%s clear" % self._nvmetcli_path)
        time.sleep(1)

    def cleanup_nvmf_initiator(self, deep_cleanup=True):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to cleanup NVMF initiator on target node"
            )

        # Do the necessary initializations.
        return_value = True
        # Remove the temporary folder created by MLTT.
        if self._io_tool is not None:
            command = "rm -rf " + self._io_tool.temp_dir
            exe.block_run(command)
        # Disconnect the NVMF subsystem.
        # There's a known BUG in nvme-cli in disconnecting by subsystem name,
        # So, disconnect using nvme device name instead.
        command = "nvme disconnect -d nvme" + self._mount_point_index
        exe.block_run(command)
        time.sleep(1)

        if deep_cleanup is True:
            driver_list = ["nvme-rdma", "nvme"]
            self.unload_driver(driver_list=driver_list)

        return return_value

    @staticmethod
    def unload_driver(driver_list):
        for driver_name in driver_list:
            try:
                exe.block_run("rmmod %s" % driver_name, shell=True)
            except Exception as e:
                if "not currently loaded" in str(e):
                    pass
                else:
                    raise exception.TestCaseFailure(
                        "Unable to unload %s driver due to %s" % (driver_name, str(e))
                    )
            time.sleep(2)

    def configure_mltt(self):
        # setup the MLTT command options.
        block_size_option = "-b" + self._block_size
        thread_count_option = "-t" + self._thread_count
        queue_depth_option = "-Q" + self._queue_depth
        monitor_time = "-M" + self._monitor_time
        mltt_options = [
            block_size_option,
            thread_count_option,
            queue_depth_option,
            "-C1",
            "-o",
            "-%f100",
            monitor_time,
        ]
        return mltt_options

    def configure_fio(self):
        # Setup the FIO command options.
        io_engine = "--ioengine=" + self._fio_engine
        block_size_option = "--bs=" + self._block_size
        queue_depth_option = "--iodepth=" + self._queue_depth
        operation_type = "--rw=" + self._fio_op_type
        numjobs = "--numjobs=" + self._thread_count
        fio_options = [
            io_engine,
            block_size_option,
            queue_depth_option,
            operation_type,
            numjobs,
            "--name=temp-fio",
            f"--size={self._block_size}"
        ]

        return fio_options

    def do_nvmf_mltt_io(self, dst_ip, block=True):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException("Attempt to perform IO on target node")

        tool_options = self.configure_mltt() if self.active_mltt_license else self.configure_fio()
        self._io_tool.start(dst_ip, self._io_duration, tool_options)

        if block is True:
            # Sleep until the command is completed. If asked to toggle the
            # link state during the IO, do so roughly in the middle.
            io_run_time = 0
            mid_io_duration = int(self._io_duration) / 2

            while self._io_tool.poll() is None:
                if self._toggle_link == "yes" and io_run_time == mid_io_duration:
                    print("bring ip link on %s down" % self._iface_name)
                    ip.down(self._iface_name)
                    time.sleep(3)
                    print("bring ip link on %s up" % self._iface_name)
                    ip.up(self._iface_name)
                io_run_time = io_run_time + 1
                time.sleep(1)

            # If the command failed, return failure.
            if self._io_tool.poll() != 0:
                raise exception.ExeExitcodeException(
                    self._io_tool.command, self._io_tool.poll(), ""
                )
            self.get_results()

        return True

    def poll(self):
        """ """
        while self._io_tool.poll() is None:
            time.sleep(1)

        # If the command failed, return failure.
        if self._io_tool.poll() != 0:
            raise exception.ExeExitcodeException(
                self._io_tool.command, self._io_tool.poll(), ""
            )

        self.get_results()
        return self._io_tool.poll()

    def setup_nvmf_mount_point(self, devices):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to setup mount point on target node"
            )

        # Create an ext3 file system on the NVMF device.

        for device in devices:
            command = f"mkfs.ext3 -F -t ext3 /dev/{device}"
            exe.block_run(command)
        # Create a temporary mount point directory.
        for device in devices:
            command = f"mkdir -p  /mnt/{device}"
            exe.block_run(command)
        # Mount the NVMF file system.
        for device in devices:
            command = "mount %s %s" % ("/dev/" + device, "/mnt/" + device)
            exe.block_run(command)
        return True

    def cleanup_nvmf_mount_point(self, devices):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to cleanup mount point on target node"
            )

        # Unmount the NVMF file system.
        for device in devices:
            command = f"umount /mnt/{device}"
            exe.block_run(command)
        # Remove the temporary mount point directory.
        for device in devices:
            command = f"rm -rf /mnt/{device}"
            exe.block_run(command)
        return True

    def verify_nvmf_file_copy(self, devices):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to verify file copy on target node"
            )

        # Verify the file copy.
        for device in devices:
            command = f"ls -lh /mnt/{device}"
            command_output = exe.block_run(command)
            return_status = False

            for each_line in command_output.split("\n"):
                if self._file_name in each_line:
                    return_status = True
                    break

            if return_status is False:
                raise exception.TestCaseFailure("Failed to perform file transfer")

        return True

    def do_nvmf_local_file_copy(self, devices):
        """ """
        if self._mode is not "initiator":
            raise exception.ConfigException(
                "Attempt to perform local file copy on target node"
            )

        # Create a temporary directory for BIG file.
        for device in devices:
            command = f"mkdir -p /tmp/{device}"
            exe.block_run(command)
        # Create a BIG file for copying.
        for device in devices:
            command = (
                "fallocate -l " + self._file_size + f" /tmp/{device}" + self._file_name
            )
            exe.block_run(command)
        # Copy the BIG file into the NVMF mount point.
        for device in devices:
            command = f"cp /tmp/{device}" + self._file_name + f" /mnt/{device}"
            exe.block_run(command)
        # Remove the temporary stuff.
        for device in devices:
            command = f"rm -rf /tmp/{device}"
            exe.block_run(command)
        return True

    def do_nvmf_remote_file_copy(self, devices):
        """ """
        if self._mode is not "target":
            raise exception.ConfigException(
                "Attempt to perform remote file copy on initiator node"
            )
        # Create a temporary directory for BIG file.
        for device in devices:
            command = f"mkdir -p /tmp/{device}"
            exe.block_run(command)
        # Create a BIG file for copying.
        for device in devices:
            command = (
                "fallocate -l " + self._file_size + f" /tmp/{device}" + self._file_name
            )
            exe.block_run(command)
        # Copy the BIG file into the NVMF mount point.
        # CTRL-45947: [controller-0.3.9b19] roce_iser test suite cases get stalled when trying
        # to connect iscsi targets.
        # Do not prompt adding the host to the list of known hosts; do it
        # silently.
        for device in devices:
            command = (
                f"scp -o StrictHostKeyChecking=no /tmp/{device}"
                + self._file_name
                + " "
                + self._initiator_name
                + ":"
                + f"/mnt/{device}"
            )
            exe.block_run(command)
        # Remove the temporary stuff.
        for device in devices:
            command = f"rm -rf /tmp/{device}"
            exe.block_run(command)
        return True

    def get_results(self):
        # Compose the results, just in case someone asks for them.
        if self._rdma_io_tool.lower() == "fio":
            self._results = self._io_tool.results()
        else:
            result = self._io_tool.get_data()
            temp_string = (
                re.sub(r".*\s-\s", "", str(result.throughput))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["THROUGHPUT (MB/s)"] = temp_string
            temp_string = (
                re.sub(r".*\s-\s", "", str(result.iops))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["IOPS"] = temp_string
            temp_string = (
                re.sub(r".*\s-\s", "", str(result.cpu_util))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["CPU"] = temp_string
            temp_string = (
                re.sub(r".*\s-\s", "", str(result.errors))
                .replace("|", ";")
                .replace(">", "")
            )
            self._results["ERRORS"] = temp_string
        return self._results

    @property
    def results(self):
        """ """
        return self._results


class NVMFTarget(NVMFController):
    def __init__(self, **kwargs):
        super(NVMFTarget, self).__init__(mode="target", **kwargs)


class NVMFInitiator(NVMFController):
    def __init__(self, **kwargs):
        super(NVMFInitiator, self).__init__(mode="initiator", **kwargs)
