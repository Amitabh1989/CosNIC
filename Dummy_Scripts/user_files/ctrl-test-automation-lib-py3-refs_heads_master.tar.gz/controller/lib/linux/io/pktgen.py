"""
:mod:`pktgen` -- pktgen DPDK command Wrapper.
=============================================

.. module:: controller.lib.linux.io.pktgen
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for pktgen DPDK command.
"""
import time
import re
import pexpect
import logging

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.linux.io import DPDKController
log = logging.getLogger(__name__)

class PktgenController(DPDKController):
    def __init__(self, **kwargs):
        """
        The Constructor.

        Args:
            kwargs : A dictionary of additional optional arguments.
              - 'core_mask'=<core_mask>
                The bit-map representing the CPU cores to use.
              - 'num_memory_channels'=<num_memory_channels>
                The number of memory channels to the CPU socket.
              - 'log_level'=<log_level>
                The level of logging messages.
        """
        super(PktgenController, self).__init__(**kwargs)
        self._core_mask = kwargs.get('core_mask', '0xff')
        self._num_memory_channels = kwargs.get('num_memory_channels', '1')
        self._include_bdfs = kwargs.get('include_bdfs', False)
        self._log_level = kwargs.get('log_level', '7')
        self._port_bdfs = []
        self._pktgen_prompt = 'Pktgen:/> '
        self.ifaces = []
        self._pexpect_timeout = kwargs.get('pexpect_timeout', 10)

    def start(self):
        """
        The method that configures and launches the pktgen application. It will:
            - Configure the hugepages.
            - Loads the PMD.
            - Binds the requested interfaces to the PMD.
            - Finally, launches the pktgen application.
        """
        # Do the necessary initializations.
        test_status = super(PktgenController, self).start()

        if test_status is True:
            test_status = self.launch_pktgen()

        return test_status

    def launch_pktgen(self):
        """
        Launch the pktgen application with the specified options.
        """
        test_status = True
        # CTRL-40788: Add support in dpdk scripts for inbox OS.
        # Use the appropriate command to verify the interfaces are bound to the PMD.
        if self._is_inbox_driver() is False:
            command = self.RTE_TARGET + '/app/pktgen'
        else:
            command = 'pktgen'
        # If port BDF's are asked to be included in the command line, do so.
        if self._include_bdfs is True:
            for port_bdf in self._port_bdfs:
                command += ' -w %s' % port_bdf
        # XXX: core allocation is hardcoded and very specific to NS3. Need to make it flexible.
        command += ' -c ' + self._core_mask + ' -n ' + self._num_memory_channels + \
            ' --log-level=' + self._log_level + ' -- proc-type auto -m "[1:2].0"'
        # Execute the command.
        log.info(command)
        # When asked to use SSH, use the SSH object for running pktgen commands too.
        if self._ssh_ip_addr is not None:
            self._pexpect_object = self._exe.run(command, ignore_output=True)
        else:
            self._pexpect_object = pexpect.spawn(command)
        # Wait a while to settle things down.
        time.sleep(5)
        # CTRL-37598: dpdk test scripts are failing while stopping pktgen in SLES15...
        # Increase the timeout value for pexpect to wait for the child to close/terminate.
        # pexpect older than 4.x.y do not have 'ptyproc' wrapper, so expect failure
        # with those versions and ignore it.
        try:
            self._pexpect_object.delayafterclose = self._pexpect_timeout
            self._pexpect_object.ptyproc.delayafterclose = self._pexpect_timeout
        except Exception:
            pass

        try:
            index = self._pexpect_object.expect([self._pktgen_prompt], timeout=30)
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # If the output is a byte stream (as in case of Python 3.X), convert it to str.
            if isinstance(self._pexpect_object.before, bytes):
                self._pexpect_object.before = self._pexpect_object.before.decode('utf-8')

            log.info(self._pexpect_object.before)

            if index == 0:
                log.info('Launched pktgen application successfully.')
            else:
                log.error('Failed to launch pktgen application.')
                test_status = False
        except Exception as e:
            log.error(e)
            test_status = False

        return test_status

    def quit_pktgen(self):
        """
        Quit the pktgen application.
        """
        command = 'quit'
        test_status = self._run_pktgen_command(command)
        # Close the pexpect session only when not using SSH.
        if self._ssh_ip_addr is None:
            self._pexpect_object.close()
            self._pexpect_object = None

        return test_status

    def start_packet_tx(self, port):
        """
        """
        # Start packet transmission.
        command = 'start %s' % port
        return self._run_pktgen_command(command)

    def stop_packet_tx(self, port):
        """
        """
        # Stop packet transmission.
        command = 'stop %s' % port
        test_status = self._run_pktgen_command(command)
        # Collect the basic statistics after stopping the packet Tx.
        if test_status is True:
            command_output = re.findall('([TR]x Pkts)\s+:\s+(\d+)', self._pexpect_object.before)

            for key, value in command_output:
                self.__statistics[key] = value

        return test_status

    def get_port_stats(self, port):
        """
        Return the statistics collected after stopping the packet Tx.
        """
        statistics = {}
        command = "lua 'package.path = \"/usr/bin/Pktgen.lua;\"; require(\"Pktgen\"); " + \
            "prints(\"port_stats\", pktgen.portStats(\"%s\", \"port\"));'" % port
        test_status = self._run_pktgen_command(command)

        if test_status is True:
            command_output = re.findall('\["opackets"\] = (\d+)', self._pexpect_object.before)

            if len(command_output) >= 1:
                statistics['Tx Packets'] = command_output[0]

        return statistics

    def _run_pktgen_command(self, command):
        """
        """
        # Do the necessary initializations.
        test_status = True
        log.info(self._pktgen_prompt + command)
        self._pexpect_object.sendline(command)
        time.sleep(2)
        # The 'quit' command will not return the pktgen prompt. So, expect 'Bye...' in this case.
        # When using SSH, expect the shell prompt.
        if command == 'quit':
            expected_prompt = self._shell_prompt if self._ssh_ip_addr is not None else 'Bye...'
        else:
            expected_prompt = self._pktgen_prompt

        self._pexpect_object.expect(expected_prompt)
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # If the output is a byte stream (as in case of Python 3.X), convert it to str.
        if isinstance(self._pexpect_object.before, bytes):
            self._pexpect_object.before = self._pexpect_object.before.decode('utf-8')
        # Log the output of the pktgen commands run.
        log.info(self._pexpect_object.before)
        return test_status

class PktgenHost(PktgenController):
    def __init__(self, **kwargs):
        super(PktgenHost, self).__init__(**kwargs)

