"""
:mod:`ptp` -- PTP wrapper library
=========================================

.. module:: controller.lib.linux.io.ptp
.. moduleauthor:: Swathi <sr892681@broadcom.com>

This is a wrapper method for ptp

"""
from typing import TYPE_CHECKING, Dict, Union
import time
import logging
import re
import os
from controller.lib.common.shell import exe
from controller.lib.core import exception

if TYPE_CHECKING:
    from controller.lib.core.param.nic import Interface
    from controller.lib.common.shell.exe import ProcessHandler

log = logging.getLogger(__name__)


class PTP:
    """The class that implements the ptp shell commands"""

    def __init__(self, **kwargs):
        """The constructor"""

        self.__iface = kwargs.get('iface', None)
        self.__sut_mac = kwargs.get('sut_mac', None)
        self.__client_mac = kwargs.get('client_mac', None)
        self.__exe = exe
        self.__ver = kwargs.get('ver', None)
        self.__output = None
        self.__pid = None

    def fetch_ptp_tool(self) -> bool:
        """The funtion checks if the ptp4l and phc2sys is installed on the devices"""

        try:
            output = exe.block_run('rpm -qa | grep linuxptp', shell=True)
            pattern = r'(linuxptp-[\d.]+-\d+).*'
            if re.search(pattern, output):
                return re.search(pattern, output).group(1)
            return False
        except:
            return False

    def set_ptp(self, iface: str, ver: int = 4, ptp_file: str = None, slave: bool = True) -> 'ProcessHandler':
        """The function that runs the ptp4l command on the selected node.

        :param iface:    Interface name
        :param ver:      4 for ipv4, 6 for ipv6, 2 for IEEE802.3
        :param ptp_file: PTP config filepath
        :param slave:    If True, run ptp4l in slave mode
        :return:         ptp4l process (ProcessHandler)
        """
        self.__pid = exe.run(f'ptp4l -i {iface} -m -{ver} {"-s" if slave else ""} -f {ptp_file}')
        return self.__pid

    def get_ptp(self):
        """The function provides output of the ptp4l command on the selected node"""

        self.__res = self.__pid.get_output()
        return self.__res

    def get_ptpmac(self) -> Union[str, None]:
        """The function provides the mac address of master/slave accordingly from the ptp4l cmd on the selected node

        :returns: If self is ptp master, return None
                  If self is ptp slave, return mac address of the synced master clock
        """

        pattern = re.compile(
            r'selected best master clock \w{6}\.\w{4}\.\w{6}')
        try:
            m = re.search(pattern, self.__res)
            match = (m.group(0))
            list1 = match.split(" ")
            fetch = list1[4].split(".fffe.")
            macstring = ''.join(map(str, fetch))
            self.mac = ':'.join(macstring[i:i + 2] for i in range(0, len(macstring), 2))
            return self.mac
        except AttributeError:
            pass

    def get_sync_mesg(self):
        """The function outputs whether the SUT and Peer are in PTP sync"""

        pattern = re.compile('UNCALIBRATED to SLAVE on MASTER_CLOCK_SELECTED')
        m = re.search(pattern, self.__res)
        try:
            self.match = m.group(0)
            return self.match
        except AttributeError:
            pass

    def get_sync_error(self, sync_timeout=False):
        """The function catches the sync error"""

        if sync_timeout:
            pat1 = re.compile('received SYNC without timestamp')
            pat2 = re.compile('UNCALIBRATED to FAULTY')
            pat3 = re.compile('MASTER to FAULTY')

            m1 = re.search(pat1, self.__res)
            m2 = re.search(pat2, self.__res)
            m3 = re.search(pat3, self.__res)

            try:
                if m2.group(0):
                    self.match = m2.group(0)
                    return self.match
                elif m3.group(0):
                    self.match = m3.group(0)
                    return self.match
                else:
                    self.match = m1.group(0)
                    return self.match
            except:
                pass

    def get_path_delay(self):
        """The function provides the list of path delay"""

        pat = re.compile(r'path delay\s*(-*\d+)')
        self.__res = re.findall(pat, self.__res)
        self.__res = self.__res[-10::]
        return self.__res

    def verify_path_delay(self, output, phc2sys=False):
        """function verifys if the path delay is in valid range"""

        count = 0
        try:
            for delay in output:
                delay = abs(int(delay))
                if not phc2sys:
                    if delay <= 100:
                        count += 1
                        pass
                    else:
                        log.info("path delay seems to be high - %s" % delay)
                elif phc2sys:
                    if delay <= 1000:
                        count += 1
                        pass
                    else:
                        log.info("path delay seems to be high - %s" % delay)
            return count
        except:
            return False

    def quit_ptp(self, ptp_out=None):
        """The function quits ptp4l cmd on master/slave"""

        self.__output = (ptp_out or self.__pid).kill()

    def quit_phc2sys(self, phc2sys_out=None):
        """The function quits phc2sys cmd on master/slave"""

        self.__output = (phc2sys_out or self.__phc).kill()

    def set_phc2sys(self, iface, master=True, summary_updates=None):
        """Function runs phc2sys tool on the devices

        Args:
        iface (str): interface on which the ptp runs
        summary_updates (int): Number of clock updates included in summary statistics. 0 (disable summary) if None.
        """
        phc2sys_opts = f'-w -m -u {summary_updates or 0}'
        self.__phc = (exe.run(f'phc2sys -s CLOCK_REALTIME -c {iface} {phc2sys_opts}') if master else
                      exe.run(f'phc2sys -s {iface} -c CLOCK_REALTIME {phc2sys_opts}'))
        return self.__phc

    def get_phc2sys(self):
        """function provides output of the phc2sys session"""

        self.__res = self.__phc.get_output()
        return self.__res

    def get_date(self):
        """function provides date ouput from the devices """

        self.__date = self.__exe.block_run('date', shell=True)
        return self.__date

    def read_write_file(self, file_name='/etc/ptp4l.cfg', time_stamp=None) -> Union['True', str]:
        """function that creates ptp4l.cfg file if it isnt present

        :param file_name:  Absolute path of ptp cfg file
        :param time_stamp: If False, append tx_timestamp_timeout string to file <file_name>
        :returns:          If <file_name> exists, read it, append timestamp param if necessary and return output str
                           If <file_name> does not exist, create it, append timestamp param and return True
        """
        if os.path.exists(file_name):
            with open(file_name, 'a+') as file:
                if time_stamp is False:
                    file.write('[global] tx_timestamp_timeout   50')
                return file.read()
        else:
            with open(file_name, 'w+') as file:
                file.write('[global] tx_timestamp_timeout   50')
            return True

    def generate_ptp_cfg(self, source_iface: 'Interface', profile=None, file_dir='/tmp',
                         sink_iface: 'Interface' = None, addtl_attrs: Dict[str, str] = None):
        """Generate PTP config file based on the profile

        If sink_iface is set, append sink attributes and unicast master table

        :param source_iface: source interface
        :param profile: profile name (G.8275.2, G8275.1, 802.1AX, or None)
                        If None, no preset profile is used. Only addtl_attrs will be added to the config.
        :param file_dir: location to save the profile
        :param sink_iface: if given, add sink attributes to cfg file
        :param addtl_attrs: Additional global attributes to append
        """
        if profile is None:
            global_attributes = {}
        elif profile == 'G.8275.2':
            global_attributes = {'dataset_comparison':              'G.8275.x',
                                 'G.8275.defaultDS.localPriority':  '128',
                                 'maxStepsRemoved':                 '255',
                                 'logAnnounceInterval':             '0',
                                 'masterOnly':                      '0',
                                 'G.8275.portDS.localPriority':     '128',
                                 'hybrid_e2e':                      '1',
                                 'inhibit_multicast_service':       '1',
                                 'unicast_listen':                  '1',
                                 'unicast_req_duration':            '60',
                                 'tx_timestamp_timeout':            '50'}
        elif profile == 'G.8275.1':
            global_attributes = {'dataset_comparison':              'G.8275.x',
                                 'G.8275.defaultDS.localPriority':  '128',
                                 'maxStepsRemoved':                 '255',
                                 'logAnnounceInterval':             '-3',
                                 'logSyncInterval':                 '-4',
                                 'logMinDelayReqInterval':          '-4',
                                 'masterOnly':                      '0',
                                 'G.8275.portDS.localPriority':     '128',
                                 'ptp_dst_mac':                     '01:1B:19:00:00:00',
                                 'network_transport':               'L2',
                                 'tx_timestamp_timeout':            '50'}
        elif profile == '802.1AS':
            global_attributes = {'gmCapable':               '1',
                                 'priority1':               '248',
                                 'priority2':               '248',
                                 'logAnnounceInterval':     '0',
                                 'logSyncInterval':         '-3',
                                 'syncReceiptTimeout':      '3',
                                 'neighborPropDelayThresh': '800',
                                 'min_neighbor_prop_delay': '-20000000',
                                 'assume_two_step':         '1',
                                 'path_trace_enabled':      '1',
                                 'follow_up_info':          '1',
                                 'transportSpecific':       '0x1',
                                 'ptp_dst_mac':             '01:1B:19:00:00:00',
                                 'network_transport':       'L2',
                                 'delay_mechanism':         'P2P',
                                 'tx_timestamp_timeout':    '50'}
        else:
            raise ValueError(f'Invalid profile value "{profile}". Must be one of: "G.8275.2", "G8275.1", "802.1AS", '
                             f'"None"')

        if addtl_attrs:
            for attr, val in addtl_attrs.items():
                global_attributes[attr] = str(val)

        iface_attributes = {'table_id': '1',
                            'logQueryInterval': '2',
                            'UDPv4': source_iface.ctrl.ip_addr,
                            'UDPv6': source_iface.ctrl.ip6_addr[0]}

        file_path = (f'{file_dir}/{profile}_{sink_iface.name}_sink.cfg' if sink_iface else
                     f'{file_dir}/{profile}_{source_iface.name}.cfg')

        col_size = 36
        with open(file_path, 'w') as file:
            file.write('[global]\n')
            for key, val in global_attributes.items():
                file.write(key.ljust(col_size) + val + '\n')

            if sink_iface:
                file.write('\n[unicast_master_table]\n')
                for key, val in iface_attributes.items():
                    file.write(key.ljust(col_size) + val + '\n')

                file.write(f'\n[{sink_iface.name}]\n')
                file.write('unicast_master_table'.ljust(col_size) + '1\n')

        log.info(f'{file_path} created')
        log.info(self.__exe.block_run(f'cat {file_path}'))

        return file_path

    def append_sink_cfg(self, sink_iface, source_cfg_file):
        """Append unicast master table attributes for sink cfg"""

        table_id = '1'
        iface_attributes = {'table_id': table_id,
                            'logQueryInterval': '2',
                            'UDPv4': sink_iface.ctrl.ip_addr,
                            'UDPv6': sink_iface.ctrl.ip6_addr[0]}

        sink_cfg_file = source_cfg_file.split('.cfg')[0] + '_sink.cfg'
        col_size = len(max(list(iface_attributes.keys()) + ['[unicast_master_table]'], key=len)) + 2
        self.__exe.block_run(f'cp {source_cfg_file} {sink_cfg_file}')
        with open(sink_cfg_file, 'w+') as file:
            file.write('\n[unicast_master_table]\n')
            for key, val in iface_attributes.items():
                file.write(key.ljust(col_size) + val + '\n')

            file.write(f'\n[{sink_iface.name}]\n')
            file.write('unicast_master_table'.ljust(col_size) + table_id + '\n')

    def verify_ptp_cap(self, capabilities, hwtstamp=False):
        """function provides ptp capabilties and verify the same if flag hwstamp is not set
        else, function verifies hw time stamp support of an interface

        Args:
        flag hwstamp == True, verification of HW transit mode is also done
        """
        list1 = ['hardware-transmit', 'software-transmit', 'hardware-receive',
                 'software-receive', 'software-system-clock', 'hardware-raw-clock']
        list2 = ['off', 'on']
        ptp_cfg_list = list2 if hwtstamp else list1

        for hw_mode in ptp_cfg_list:
            if hw_mode in capabilities:
                continue
            else:
                return False
        else:
            return True

    def get_capability(self, iface):
        """The function fetches the capability info from the device

        Args:
        iface - particular interface of the device
        """
        output = self.__exe.block_run('ethtool -T %s' % iface)
        try:
            return output
        except:
            return False

    def verify_status(self, master=False):
        """The function get the master state"""

        if master:
            pat = re.compile('assuming the grand master role')
            m = re.search(pat, self.__res)
            try:
                self.match = m.group(0)
                return self.match
            except BaseException:
                pass
        else:
            pattern = re.compile('UNCALIBRATED to SLAVE on MASTER_CLOCK_SELECTED')
            m = re.search(pattern, self.__res)
            try:
                self.match = m.group(0)
                return self.match
            except AttributeError:
                pass
