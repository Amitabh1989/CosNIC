"""
:mod:`qperf` -- qperf Command Wrapper.
=========================================

.. module:: controller.lib.linux.io.qperf
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for qperf command.
"""

import time
import re

from controller.lib.common.shell import exe
from controller.lib.core import exception

class QperfController(object):
    def __init__(self, mode='server', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which qperf Command runs.
                   - 'server' to run as qperf command server (default).
                   - 'client' to run as qperf command client.
            kwargs : A dictionary of additional optional arguments.
                   - 'server_name'='<server_name>'
                     The name or IP address of the qperf command server node (Mandatory).

                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO (default='120').

                   - 'message_size'='<message_size>'
                     The size in bytes of the message to use for IO (default='64').

                   - 'mtu_size'='<mtu_size>'
                     The size in bytes of the MTU to use for IO (default='1500').
        """
        self._mode = mode

        self._server_name = kwargs.get('server_name', None)

        if self._server_name is None:
            raise exception.ConfigException('No server name specified')

        self._io_duration = kwargs.get('io_duration', '120')
        self._message_size = kwargs.get('message_size', '65536')
        self._mtu_size = kwargs.get('mtu_size', '1500')
        self._rdma_test = kwargs.get('rdma_test', 'rc_bw')
        self._result = {'THROUGHPUT':'',
                        'LATENCY':''}

    def setup_qperf_server(self, port_no='25000'):
        """
        """
        if self._mode is not 'server':
            raise exception.ConfigException('Attempt to setup server on client node')

        # Build the server-side command.
        self._command = 'qperf -lp %s' % port_no
        return True

    def setup_qperf_client(self, port_no='25000'):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to setup client on server node')

        # Build the client-side command.
        self._command = 'qperf -cm1'
        self._command += ' -m ' + self._message_size
        self._command += ' -t ' + self._io_duration
        self._command += ' -mt ' + self._mtu_size
        self._command += ' -lp ' + str(port_no)
        self._command += ' ' + self._server_name
        self._command += ' ' + self._rdma_test
        return True

    def cleanup_qperf_server(self):
        """
        """
        if self._mode is not 'server':
            raise exception.ConfigException('Attempt to cleanup server on client node')

        return True

    def cleanup_qperf_client(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to cleanup client on server node')

        return True

    def start(self):
        """
        """
        # Run the qperf command.
        self._qperf_proc = exe.run(self._command)
        return True

    def stop(self):
        """
        """
        # Kill the process.
        self._qperf_proc.kill()
        # Wait for the process to die.
        while self._qperf_proc.poll() is None:
            time.sleep(1)

        return True

    def poll(self):
        """
        """
        # If the command failed, return failure.
        if self._qperf_proc.poll() is None:
            return None

        if self._qperf_proc.poll() != 0:
            raise exception.ExeExitcodeException(self._command, self._qperf_proc.poll(), '')

        # Compose the results, just in case someone asks for them.
        attribute = 'THROUGHPUT' if 'bw' in self._rdma_test else 'LATENCY'
        output = self._qperf_proc.get_output()
        self._result[attribute] = re.search('.*=[\s]*(.*)', output).group(1)
        return self._qperf_proc.poll()

    @property
    def result(self):
        """
        """
        return self._result

class QperfServer(QperfController):
    def __init__(self, **kwargs):
        super(QperfServer, self).__init__(mode='server', **kwargs)

class QperfClient(QperfController):
    def __init__(self, **kwargs):
        super(QperfClient, self).__init__(mode='client', **kwargs)
