"""
:mod:`rdmacm_tools` -- RDMACM tools Wrapper.
============================================
.. module:: controller.lib.linux.io.rdmacm_tools
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for the RDMACM tools.
"""
import time
import subprocess

from controller.lib.common.shell import exe
from controller.lib.core import exception


class RDMACMToolsController(object):
    def __init__(self, mode='server', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which ucmatose runs.
                   - 'server' to run as ucmatose server (default).
                   - 'client' to run as ucmatose client.
            kwargs : A dictionary of additional optional arguments.
                   - 'server_name'='<server_name>'
                     The name or IP address of the ucmatose server node (Mandatory).

                   - 'ping_count'='<ping_count>'
                     The number of ping messages to use (default='100').

                   - 'message_size'='<message_size>'
                     The data size in bytes to use (default='64').

        """
        self.__mode = mode
        self.__server_name = kwargs.get('server_name', None)

        if mode == 'client' and self.__server_name is None:
            raise exception.ConfigException('No server name specified')

        self.__iterations = kwargs.get('iterations', '100')
        self.__message_size = kwargs.get('message_size', '64')
        self.__qp_type = kwargs.get('rdma_qp_type', 'RC')
        self.__connections = kwargs.get('connections', '100')

        if self.__qp_type == 'RC':
            self.__command = 'ucmatose'
        elif self.__qp_type == 'UD':
            self.__command = 'udaddy'
        else:
            raise exception.ConfigException(
                'Unsupported RDMA QP type: %s' %
                self.__qp_type)

    def setup_server(self):
        """
        """
        if self.__mode != 'server':
            raise exception.ConfigException(
                'Attempt to setup server on client node')
        # Build the server-side command.
        self.__command += ' -S ' + self.__message_size
        self.__command += ' -C ' + self.__iterations
        self.__command += ' -c ' + self.__connections
        return True

    def setup_client(self):
        """
        """
        if self.__mode != 'client':
            raise exception.ConfigException(
                'Attempt to setup client on server node')
        # Build the client-side command.
        self.__command += ' -S ' + self.__message_size
        self.__command += ' -C ' + self.__iterations
        self.__command += ' -c ' + self.__connections
        self.__command += ' -s ' + self.__server_name
        return True

    def cleanup_server(self):
        """
        """
        if self.__mode != 'server':
            raise exception.ConfigException(
                'Attempt to cleanup server on client node')

        return True

    def cleanup_client(self):
        """
        """
        if self.__mode != 'client':
            raise exception.ConfigException(
                'Attempt to cleanup client on server node')

        return True

    def start(self):
        """
        """
        # Run the IB command.
        self.__command_proc = exe.run(
            self.__command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        return True

    def stop(self):
        """
        """
        # Kill the process.
        self.__command_proc.kill()
        # Wait for the process to die.
        while self.__command_proc.poll() is None:
            time.sleep(1)

        return True

    def poll(self):
        """
        """
        # If the command failed, return failure.
        if self.__command_proc.poll() is None:
            return None

        if self.__command_proc.poll() != 0:
            raise exception.ExeExitcodeException(self.__command, self.__command_proc.poll(),
                                                 self.__command_proc.get_error())

        # Compose the results, just in case someone asks for them.
        self.__result = self.__command_proc.get_output()
        return self.__command_proc.poll()

    @property
    def result(self):
        """
        """
        return self.__result


class RDMACMToolsServer(RDMACMToolsController):
    def __init__(self, **kwargs):
        super(RDMACMToolsServer, self).__init__(mode='server', **kwargs)


class RDMACMToolsClient(RDMACMToolsController):
    def __init__(self, **kwargs):
        super(RDMACMToolsClient, self).__init__(mode='client', **kwargs)
