"""
:mod:`roce_ib.py` -- roce ib traffic library
==================================================================================

.. module:: controller.lib.linux.io.roce_ib
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>
CTRL-48082: This module is deprecated please use controller.lib.linux.io.ib_commands

"""

import time
import subprocess
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from distutils.spawn import find_executable

log = log_handler.get_logger(__name__)

class IBSendBase(object):
    def __init__(self, ib_type="ib_send_bw"):
        self.ib_send_pid = None
        self.__ib_type = ib_type

    def _get_ib_path(self):
        self.ib_send_path = find_executable(self.__ib_type)

    def _parse_data(self, data):
        for line in data.splitlines():
            log.info(line)

        throughPutDict = {}
        throughPut = None
        parsingOn = False

        for line in data.splitlines():
            if (line.find('#bytes') != -1):
                parsingOn = True
                continue

            if (parsingOn == False):
                continue

            if (parsingOn == True) and (line.startswith('--')):
                break

            t = line.split()
            noOfBytes = int(t[0])

        if self.__ib_type.find('lat') != -1:
            throughPut = float(t[2])
        else:
            throughPut = float(t[3])
            peakThroughPut = float(t[2])
            throughPutDict[noOfBytes] = throughPut

        if not parsingOn:
            raise exception.IBExitCodeException(data)

        return throughPut

    def get_data(self):
        # This method is not fully functional yet
        if self.ib_send_pid is None:
            log.warning("Process is still running.")
            return None

        data = self.ib_send_pid.get_output()

        if data is '':
            raise exception.IBException('No data available!')

        return self._parse_data(data)

    def start(self, options, **kwargs):
        self._get_ib_path() # Call this method to get the environ path of the ib_send

        if self.ib_send_path is None:
            raise exception.ConfigException("Cannot find ib tool. Is it installed?")

        for key in list(kwargs.keys()):
            options.append('-'+key)
            options.append(str(kwargs[key]))

        log.info("Starting a non-blocking IB with the following options (%s)" % ' '.join(options))
        self.ib_send_pid = exe.run(self.ib_send_path + ' ' + ' '.join(options), \
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return self.ib_send_pid

    def stop(self):
        if self.ib_send_pid is None:
            log.warning("%s is not running." % self.__ib_type)
            return False

        self.ib_send_pid.kill()

        if self.poll() is not None:
            log.info("%s process is successfully stopped." % self.__ib_type)
            return True

    def poll(self):
        if self.ib_send_pid.poll() is None:
            return None

        if self.ib_send_pid.poll()!= 0:
            raise exception.ExeExitcodeException(self.__ib_type,self.ib_send_pid.poll(), \
                self.ib_send_pid.get_error())

        return self.ib_send_pid.poll()

class IBServer(IBSendBase):
    def __init__(self, ib_type="ib_send_bw"):
        super(IBServer, self).__init__(ib_type)

    def start(self, src_iface, options=None, **kwargs):
        if not options:
            options = ['-a']

        opts = [opt for opt in options]
        iface = '-d ' + src_iface
        opts.append(iface)
        super(IBServer, self).start(opts, **kwargs)

class IBClient(IBSendBase):
    def __init__(self, ib_type="ib_send_bw"):
        super(IBClient, self).__init__(ib_type)

    def start(self, src_iface, dst_ip=None, options=None, **kwargs):
        if not options:
            options = ['-a']

        opts = [opt for opt in options]

        if not dst_ip:
            raise exception.ConfigException("Destination IP Address not specified")

        iface = '-d ' + src_iface
        opts.append(iface)
        opts.append(dst_ip)
        super(IBClient, self).start(opts, **kwargs)
