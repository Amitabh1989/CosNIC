"""
:mod:`rping` -- rping Wrapper.
=========================================

.. module:: controller.lib.linux.io.rping
.. moduleauthor:: Sumit Kumar <sumit.kumar@broadcom.com>

This is a wrapper python module for rping command.

"""
import subprocess
import time
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from controller.lib.common.shell import exe
from controller.lib.core import exception


class RpingController(object):
    def __init__(self, mode: Literal['server', 'client'] = 'server', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which rping runs.
                   - 'server' to run as rping server (default).
                   - 'client' to run as rping client.
            kwargs : A dictionary of additional optional arguments.
                   - 'server_name'='<server_name>'
                     The name or IP address of the rping server node (Mandatory).

                   - 'iterations'='<iterations>'
                     The number of ping messages to use (default='100').

                   - 'message_size'='<message_size>'
                     The data size in bytes to use for rping (default='64').

        """
        self._mode = mode
        self._server_name = kwargs.get('server_name', None)

        if mode == 'client' and self._server_name is None:
            raise exception.ConfigException('No server name specified')

        self._iterations = kwargs.get('iterations', '100')
        self._message_size = kwargs.get('message_size', '64')
        self._rping = 'rping'
        self._rping_proc = None
        self._result = None
        self._tcp_port = None

    def setup_rping_server(self, port_no=None):
        """Build rping server command line string"""
        if self._mode != 'server':
            raise exception.ConfigException(
                'Attempt to setup server on client node')
        self._tcp_port = port_no if port_no is not None else '25000'
        # Build the server-side command.
        self._rping += ' -s '
        self._rping += ' -v '
        self._rping += ' -V '
        self._rping += ' -S ' + self._message_size
        if self._iterations is not None:
            self._rping += ' -C ' + self._iterations
        self._rping += ' -p ' + self._tcp_port
        self._rping += ' -a ' + self._server_name
        return True

    def setup_rping_client(self, port_no=None):
        """Build rping client command line string"""
        if self._mode != 'client':
            raise exception.ConfigException(
                'Attempt to setup client on server node')
        self._tcp_port = port_no if port_no is not None else '25000'
        # Build the client-side command.
        self._rping += ' -c '
        self._rping += ' -v '
        self._rping += ' -V '
        self._rping += ' -S ' + self._message_size
        if self._iterations is not None:
            self._rping += ' -C ' + self._iterations
        self._rping += ' -p ' + self._tcp_port
        self._rping += ' -a ' + self._server_name
        return True

    def cleanup_rping_server(self):
        """
        """
        if self._mode != 'server':
            raise exception.ConfigException(
                'Attempt to cleanup server on client node')

        return True

    def cleanup_rping_client(self):
        """
        """
        if self._mode != 'client':
            raise exception.ConfigException(
                'Attempt to cleanup client on server node')

        return True

    def start(self):
        """Run the rping command"""
        self._rping_proc = exe.run(
            self._rping,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        return True

    def stop(self):
        """Kill, and wait for rping completion"""
        # Kill the process.
        self._rping_proc.kill()
        # Wait for the process to die.
        while self._rping_proc.poll() is None:
            time.sleep(1)

        return True

    def poll(self):
        """Return None if rping still running, else raise exception on error or save result and return exit code"""
        if self._rping_proc.poll() is None:
            return None

        # If the command failed, return failure.
        if self._rping_proc.poll() != 0:
            raise exception.ExeExitcodeException(self._rping, self._rping_proc.poll(),
                                                 self._rping_proc.get_error())

        # Compose the results, just in case someone asks for them.
        self._result = self._rping_proc.get_output()
        return self._rping_proc.poll()

    def wait(self, timeout, force=True) -> bool:
        """Wait for rping completion upto timeout seconds and optionally kill (default) if still running

        :return: True if command exited successfully (poll() == 0), False if still running, exception if cmd failed
        """
        # Wait for the process to complete.
        stop_time = time.time() + timeout
        while self._rping_proc.poll() is None and time.time() < stop_time:
            time.sleep(0.5 if timeout <= 10 else timeout/10.0)

        if self._rping_proc.poll() is None and force:
            self._rping_proc.stop()

        return self._rping_proc.poll() == 0

    @property
    def result(self) -> str:
        """Return rping output if finished running successfully, else None"""
        return self._result

    @property
    def mode(self) -> Literal['server', 'client']:
        """Return mode of the rping controller: server or client"""
        return self._mode

    @property
    def server_name(self) -> str:
        """Return the server name/ip"""
        return self._server_name

    @property
    def tcp_port(self) -> str:
        """Return TCP port number as string"""
        return self._tcp_port

    def __str__(self):
        return f"Rping{self.mode.capitalize()}[{self.server_name}:{self.tcp_port}]"


class RpingServer(RpingController):
    def __init__(self, **kwargs):
        super().__init__(mode='server', **kwargs)


class RpingClient(RpingController):
    def __init__(self, **kwargs):
        super().__init__(mode='client', **kwargs)
