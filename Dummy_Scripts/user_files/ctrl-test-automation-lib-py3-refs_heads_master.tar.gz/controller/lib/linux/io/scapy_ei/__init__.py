"""
:mod:`scapy_ei` -- Scapy EI
===========================================================

.. module:: controller.lib.linux.io.scapy_ei
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

.. warning::
   Some scapy operations require root privilege

This library provides wrapped functions around scapy module. Though this works
almost as proxy to most scapy modules. For example,

>>> from controller.lib.linux.io import scapy_ei
>>> scapy_ei.send(scapy_ei.IP(dst='192.168.1.1')/scapy_ei.ICMP())

is identical to

>>> from scapy.all import *
>>> send(IP(dst='192.168.1.1'/ICMP()))

The main purpose of this module is to override some scapy functions to resolve
compatibility issues with RPyC, including object instantiation.

Due to this module works as a transparent proxy to scapy module, usage should
be very similar to scapy module itself.

Here is one example.  Let's create a Ping request packet to the IP
'192.168.1.1'. Layers that ICMP should have are:

   * Ethernet
   * IP
   * ICMP

The way to create a packet is to stack such layers using '/'.

'/' works as a divider of layers, and first layer means lower layer.
For example, to build a ICMP packet that has above three layers:

>>> icmp_packet = scapy_ei.Ether()/scapy_ei.IP(dst='192.168.1.1')/scapy_ei.ICMP()

Above command stacks three layers - Ethernet, IP and then ICMP. Note that
we specified the IP destination as '192.168.1.1', which one information that
scapy cannot fill out originally.

Speaking of which, scapy is smart enough to fill out most information for you
automatically. Think about all missing information that we did not provide
above - no src and dst MAC addresses, no src IP address, etc. We just left
them as blank. And - scapy will fill out for you.

Imagine when you ping a remote host - mostly the only information that you
need to provide is the destination IP address, because OS can automatically
determine Ethernet layer for you. Scapy does the same thing.

.. warning::
   When you create a packet on SUT over RPyC, layers that you use also should
   be called over RPyC otherwise scapy will use the localhost
   (possibly Harness) network information to fill out some missing
   values, such as source MAC address.

So let's take a look at the packet that we just crafted.

>>> icmp_packet
<Ether  type=0x800 |<IP  frag=0 proto=icmp dst=192.168.1.1 |<ICMP  |>>>

It has mostly empty information, but they will be automatically filled as I
mentioned above. If you want to see that, you can run show()

>>> icmp_packet.show()
###[ Ethernet ]###
  dst       = 00:00:0c:07:ac:28
  src       = 00:50:56:ab:0f:07
  type      = 0x800
###[ IP ]###
     version   = 4
     ihl       = None
     tos       = 0x0
     len       = None
     id        = 1
     flags     =
     frag      = 0
     ttl       = 64
     proto     = icmp
     chksum    = None
     src       = 10.13.246.88
     dst       = 192.168.1.1
     \options   \
###[ ICMP ]###
        type      = echo-request
        code      = 0
        chksum    = None
        id        = 0x0
        seq       = 0x0

So now you can see that all Ethernet type, dst, src are filled out - as well as
the source IP address. Now let's send this packet.

>>> scapy_ei.send(icmp_packet)
.
Sent 1 packets.

That's it.

For more details how to use scapy, please refer at `here`_.

.. _here: http://www.secdev.org/projects/scapy/doc/index.html

"""

import binascii
import platform as sys_platform  # scapy * imports will override platform
import socket
import struct
import sys
import threading
import time

import scapy.all
# Allow users to import scapy_ei and use scapy_ei.Ether(), etc.
from scapy.all import *  # noqa(flake8): F403 pylint: disable=W0622

# Expose theses to users of scapy_ei
from controller.lib.common.io.scapy_ei.protocol import MAC_CONTROL_PAUSE  # noqa(flake8): F401
from controller.lib.core import log_handler
from controller.lib.core import exception

bind_top_down(VXLAN, Ether, flags=8, NextProtocol=0)
bind_top_down(VXLAN, IP, flags=8, NextProtocol=1)
bind_top_down(VXLAN, IPv6, flags=8, NextProtocol=2)
bind_top_down(VXLAN, Ether, flags=8, NextProtocol=3)

log_handler.logging.getLogger("scapy.runtime").setLevel(log_handler.logging.FATAL)
log = log_handler.get_logger(__name__)


class SniffHandler:
    """
    This class creates a non-blocking class object which replaces the
    scapy.sniff which is a blocking function. One main reason for this is it is
    not possible to send stop signal to sniff other than timeout or packet type.

    For example, if you want to capture packets up to dynamic time in secs, it
    is not possible to use sniff unless sending ctrl+c through the interpreter.

    A private class - which shouldn't be accessed directly.

    Args:
        kwargs: keyword arguments that will be passed to scapy.sniff.

    """

    def __init__(self):
        self._packets = []  # Make this read-only

        self._thread = None
        self._stop_signal = False
        self._sniff_started = False

    @property
    def packets(self):
        return self._packets

    @property
    def is_running(self):
        return self._thread.is_alive() if self._thread else False

    def _sniff(self, count=0, iface=None, prn=None, lfilter=None, timeout=0, **kwargs):
        try:
            sock = conf.L2listen(type=ETH_P_ALL, iface=iface, **kwargs)
        except Exception:
            log.exception("Failed to create scapy socket for sniffing!")
            return
        try:
            if sys_platform.system() == 'Linux':
                sock.ins.settimeout(1)
            elif sys_platform.system() == 'FreeBSD':
                sock.set_nonblock()
        except Exception:
            os_msg = 'timeout to 1 for linux' if sys_platform.system() == 'Linux' else 'non-blocking for freebsd'
            log.exception(f"Failed to set socket {os_msg}")
            return

        stop_time = time.time() + timeout
        packet_counter = 0

        self._sniff_started = True

        try:
            while not self._stop_signal:
                if timeout > 0 and time.time() > stop_time:
                    log.info(f"Finished sniffing packets after {timeout}s")
                    return

                try:
                    pkt = sock.recv(MTU)
                except socket.timeout:
                    continue
                except Exception:
                    log.exception("Unhandled exception attempting to recv packets")
                    return

                if pkt is None:
                    # Continue waiting for pkts in non-blocking mode even if no data being rcvd (b2b and no tx yet)
                    time.sleep(0.1)
                    continue

                if lfilter and not lfilter(pkt):
                    continue

                self.packets.append(pkt)

                packet_counter += 1

                if prn:
                    prn(pkt)

                if packet_counter >= count > 0:
                    log.info(f"Finished sniffing {packet_counter} packets")
                    return
            # self._sniff_started = False
        except Exception:
            log.exception("Unhandled exception while sniffing packets...")
        finally:
            sock.close()

    def sniff(self, **kwargs):
        """ Sniff as blocking.

        Proxy to _sniff.

        """
        return self._sniff(**kwargs)

    def start(self, timeout=10, **kwargs):
        """
        Start sniffing.

        Args:
            timeout: timeout for starting sniff. If None, no timeout.
            kwargs: Keyword arguments that will be passed to scapy.sniff (use sniff_timeout to pass timeout to sniff)

        """

        def _normalize_unicode(kwargs):
            # Convert unicode to str for IronPython compatibility
            if sys.version_info[0] >= 3:
                u_code = str
            else:
                u_code = str
            ret_dict = {}
            for key, value in list(kwargs.items()):
                if isinstance(value, u_code):
                    ret_dict[key] = str(value)
                else:
                    ret_dict[key] = value

            return ret_dict

        kwargs = _normalize_unicode(kwargs)
        if 'sniff_timeout' in kwargs:
            kwargs['timeout'] = kwargs.pop('sniff_timeout')

        if self.is_running:
            log.warning('Thread already started running')
            return None

        self._thread = threading.Thread(target=self._sniff, kwargs=kwargs)
        self._thread.setDaemon(True)
        self._thread.start()

        # Wait until the sniff is actually started.
        stop_time = time.time() + timeout if timeout else None
        while True:
            if self._sniff_started:
                log.info(f"Started sniffing packets - running sniff({kwargs}) in thread {self._thread.name}")
                return True

            if stop_time and time.time() > stop_time:
                log.error(f"Timeout starting sniff! Waited {timeout}s")
                break
            time.sleep(1)

        raise exception.ScapyException('Failed to start sniffing')

    def stop(self):
        self._stop_signal = True
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=10)

        if self._thread.is_alive():
            raise exception.ScapyException('Thread is still running')

        return True

    def get_packets(self):
        # IronPython cannot handle plist. Use a regular list
        # return plist.PacketList(self.packets)
        return self.packets

    def save(self, filename, **kwargs):
        wrpcap(filename, self.packets, **kwargs)


def get_crafted_packets(
        packet_type, dst_ip, payload_list, src_mac=None, dport=None, dst_mac=None):
    """
    Due to it's too slow and much overhead to call scapy object types over
    RPyC, create a single method that generates everything locally and return
    as a list

    Args:
        packet_type (str): choices=[arp|udp|tcp]. If arp, dst MAC is
            ff:ff:ff:ff:ff:ff
        dst_ip (str): Destination IP address. If IP address starts with
            224 (224.x.x.x), will use multicast src MAC address
        payload_list (list): List of payload. Will return packets as many as
            this list.
        src_mac (None, str): source MAC address. Required for multicast.
            If provided, Ether layer is prepended
        dport (None, int): destination port for UDP or TCP. If this is not
            given, use 0.
        dst_mac (None, str): destination MAC address. If provided,
            Ether layer is prepended

    Return:
        list: List of crafted packets

    """

    def check_mcast():
        int_ip = struct.unpack('!I', socket.inet_aton(dst_ip))
        min_ip = struct.unpack('!I', socket.inet_aton('224.0.0.0'))
        max_ip = struct.unpack('!I', socket.inet_aton('239.255.255.255'))

        if min_ip < int_ip < max_ip:
            # Return MAC address
            mac_suffix = binascii.hexlify(socket.inet_aton(dst_ip)).decode('utf-8')

            if not src_mac:
                raise exception.ValueException('src_mac should be given for multicast packets')

            return '01:00:5e:' + ':'.join([mac_suffix[i:i+2] for i in range(2, 8, 2)])

        return None

    mcast = check_mcast()

    if packet_type == 'arp':
        return [
            Ether(dst='ff:ff:ff:ff:ff:ff') /
            ARP(pdst=dst_ip) /
            Raw(load=payload) for payload in payload_list
        ]
    if packet_type == 'udp':
        if mcast:
            return [
                Ether(src=src_mac, dst=mcast) /
                IP(dst=dst_ip) / UDP(dport=dport) / Raw(load=payload)
                for payload in payload_list
            ]
        if dst_mac:
            return [
                Ether(dst=dst_mac) / IP(dst=dst_ip) / UDP(dport=dport) / Raw(load=payload) for payload in payload_list
            ]
        return [IP(dst=dst_ip) / UDP(dport=dport) / Raw(load=payload) for payload in payload_list]
    if packet_type == 'tcp':
        if mcast:
            return [
                Ether(src=src_mac, dst=mcast) / IP(dst=dst_ip) /
                TCP(dport=dport) / Raw(load=payload)
                for payload in payload_list
            ]
        if dst_mac:
            return [
                Ether(dst=dst_mac) / IP(dst=dst_ip) / TCP(dport=dport) / Raw(load=payload) for payload in payload_list
            ]
        return [IP(dst=dst_ip) / TCP(dport=dport) / Raw(load=payload) for payload in payload_list]
    log.error("Invalid packet type, %s", packet_type)


def sendp(x, *args, **kwargs):  # pylint: disable=E0102; (override sendp with custom version)
    """
    This is annoying ... but any args / kwargs that will be passed from
    IronPython have unicode, which will break most type checking code
    including struct. Should be converted to string ...

    The problem is if the value is nested dict or any other object types,
    we cannot convert them. This is just a patch, not solution.

    """

    conv_args = []
    conv_kwargs = {}
    if sys.version_info[0] >= 3:
        u_code = str
    else:
        u_code = str

    for arg in args:
        if isinstance(arg, u_code):
            conv_args.append(str(arg))

    for key, value in list(kwargs.items()):
        if isinstance(key, u_code):
            key = str(key)
        if isinstance(value, u_code):
            value = str(value)
        conv_kwargs[key] = value

    if isinstance(x, list):
        x = [packet for packet in x]

    scapy.all.sendp(x, *conv_args, **conv_kwargs)


def send(x, *args, **kwargs):  # pylint: disable=E0102; (override send with custom version)
    conv_args = []
    conv_kwargs = {}
    if sys.version_info[0] >= 3:
        u_code = str
    else:
        u_code = str

    for arg in args:
        if isinstance(arg, u_code):
            conv_args.append(str(arg))

    for key, value in list(kwargs.items()):
        if isinstance(key, u_code):
            key = str(key)
        if isinstance(value, u_code):
            value = str(value)
        conv_kwargs[key] = value

    # Override the scapy.all.send due to the compatibility issue with RPyC
    if isinstance(x, list):
        x = [packet for packet in x]
    scapy.all.send(x, *conv_args, **conv_kwargs)


def unittest():
    return True
