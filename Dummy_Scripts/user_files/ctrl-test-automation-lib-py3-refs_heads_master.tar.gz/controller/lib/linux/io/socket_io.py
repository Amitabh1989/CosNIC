import time
import logging
import socket
import struct
import select
import copy
from multiprocessing import Process
from multiprocessing import Pool
log = logging.getLogger(__name__)


def sending_traffic(addr_with_port, io_time=10):
    #addr_with_port should be a tuple example : ("225.0.0.30",11110)
    i = 1.0
    timeout = time.time() + io_time
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setblocking(False)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 64)
    log.info("Sending traffic from %s" % str(addr_with_port) )
    while time.time() < timeout:
        suffix = ' :: ' + str(i)
        message = 'z' * (1080 - len(suffix)) + suffix
        bytessent = sock.sendto(str.encode(message), addr_with_port)
        if bytessent != len(message):
            log.error("Failure sending all bytes")
        i += 1.0
    sock.close()


def send_multiple_traffics(addr_list,io_time=60):
    process_list = []
    for addr in addr_list:
        process = Process(target=sending_traffic, args=(addr,io_time))
        process_list.append(process)
    for process in process_list:
        process.start()
    return process_list


def receving_traffic(addr, port, io_time=60):
    timeout = time.time() + io_time
    missedTotal = 0.0
    receivedTotal = 0.0
    startTime = 0
    endTime = 0
    seqCount = 0
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((addr, port))
    mreq = struct.pack('4sl', socket.inet_aton(addr), socket.INADDR_ANY)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    msg = ""
    startTime = time.time()
    sock.setblocking(0)
    while time.time() < timeout:
        ready = select.select([sock], [], [], 10)
        if ready[0]:
            rcvddata = sock.recv(65536)
        else:
            rcvddata = 0
            receivedTotal = receivedTotal - 1.0
        seqPrev = float(seqCount)
        try:
            seqCount = float(rcvddata[rcvddata.find(' :: ') + len(' :: '):])
        except:
            pass
        # First time only...
        if seqPrev == 0:
            seqPrev = seqCount - 1
        didMiss = seqPrev + 1
        message = repr(rcvddata)
        suffix = ' :: ' + str(seqCount)
        if didMiss < seqCount:
            missed = seqCount - didMiss
            missedTotal = missedTotal + missed
            if len(message) < 63:
                log.info("Received '%s' :: MISSED %d" % (message, missed))
            else:
                log.info(
                    "Received '%s...%s' :: MISSED %d" % (message[:63], message[-len(suffix):], missed))

        else:
            receivedTotal = receivedTotal + 1.0
            if receivedTotal % 12500 == 0:
                endTime = time.time()
                duration = endTime - startTime
                log.info("Received %f packets, missed %f packets, ran for %f seconds, Bps=%f" % (
                    receivedTotal, missedTotal, duration, (receivedTotal * 1080) / duration))

    endTime = time.time()
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_DROP_MEMBERSHIP, mreq)
    duration = endTime - startTime
    log.info("Received %f packets, missed %f packets, ran for %f seconds, Bps=%f" % (
        receivedTotal, missedTotal, duration, (receivedTotal * 1080) / duration))
    sock.close()
    log.info("<< Goodbye >>")
    return receivedTotal, missedTotal


def receving_multiple_traffics(addr_with_port_list):
    with Pool() as pool:
        addr_with_port_list = copy.deepcopy(addr_with_port_list)
        values = pool.starmap(receving_traffic, addr_with_port_list)
    return values
