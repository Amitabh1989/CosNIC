"""
:mod:`tcpdump` -- tcpdump wrapper library
=========================================

.. module:: controller.lib.linux.io.tcpdump
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for tcpdump

"""
import time
import logging
from distutils.spawn import find_executable

from controller.lib.core import exception
from controller.lib.common.shell import exe
from controller.lib.linux.system import ssh

log = logging.getLogger(__name__)


class TCPDump(object):
    """
    The class that implements the un-buffered tcpdump command.
    """
    def __init__(self, interface, **kwargs):
        """
        The constructor. Currently the implementation supports a limited set of options.
        """
        self._prg_path = find_executable('tcpdump')

        if not self._prg_path:  # No tcpdump lib installed
            raise exception.ConfigException('No tcpdump bin found')
        self.__interface = interface
        self.__packet_count = kwargs.get('packet_count', -1)
        self.__src_ip = kwargs.get('src_ip', None)
        self.__dst_ip = kwargs.get('dst_ip', None)
        self.__protocol = kwargs.get('protocol', None)
        self.__src_port = kwargs.get('src_port', None)
        self.__dst_port = kwargs.get('dst_port', None)
        self.__proto = kwargs.get('proto', None)
        self.__ether_proto = kwargs.get('ether_proto', None)
        self.__ether_proto = kwargs.get('ether_proto', None)
        self.__ether_host = kwargs.get('ether_host', None)
        self.__ether_dst = kwargs.get('ether_dst', None)
        self.__verbose = kwargs.get('verbose', False)
        self.__tcpdump_proc = None
        self.__output = None
        self.__exe = exe
        self.__capture_file = kwargs.get('capture_file', None)
        self.__pkt_len_greater = kwargs.get('pkt_len_greater', None)
        self.__pkt_len_lesser = kwargs.get('pkt_len_lesser', None)
        self.__promisc = kwargs.get('promisc_mode', True)

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the tcpdump command. If ssh_ip_address is
        specified, an SSH connection to that IP address is established and that connection is used to
        run the tcpdump command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running tcpdump command over SSH.
            When None, the SSH mode is exited.
        """
        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def get_output(self):
        """
        The method that returns the buffered output.
        """
        return self.__output

    def start(self):
        """
        The method that starts the un-buffered tcpdump command with the options specified during
        construction.
        """
        if self.__tcpdump_proc is None:
            filter_exists = False
            command = '%s -len -i %s' % (self._prg_path, self.__interface)

            if self.__src_ip is not None:
                command += ' src host %s' % self.__src_ip
                filter_exists = True

            if self.__dst_ip is not None:
                command += ' %s%s' % ('and dst host ' if filter_exists is True else 'dst host ', self.__dst_ip)

            if self.__protocol is not None:
                # If a list of protocols is specified, concatenate them all.
                if isinstance(self.__protocol, list):
                    self.__protocol = ' and '.join(self.__protocol)

                command += ' %s%s' % ('and ' if filter_exists is True else '', self.__protocol)

            if self.__src_port is not None:
                command += ' %s%s' % ('and src port ' if filter_exists is True else 'src port ', self.__src_port)

            if self.__dst_port is not None:
                command += ' %s%s' % ('and dst port ' if filter_exists is True else 'dst port ', self.__dst_port)

            if self.__proto is not None:
                command += ' %s%s' % ('and proto ' if filter_exists is True else ' proto ', self.__proto)
            if self.__ether_proto is not None:
                command += ' %s%s' % ('and  ether proto ' if filter_exists is True else ' ether proto ',
                                      self.__ether_proto)
            if self.__ether_host is not None:
                command += ' %s%s' % ('and  ether host ' if filter_exists is True else ' ether host ',
                                      self.__ether_host)
            if self.__ether_dst is not None:
                command += ' %s%s' % ('and  ether dst ' if filter_exists is True else ' ether dst ',
                                      self.__ether_dst)
            if self.__packet_count != -1:
                command += ' -c %s' % self.__packet_count

            if self.__capture_file is not None:
                command += ' -w %s' % self.__capture_file
            if self.__pkt_len_greater is not None:
                command += ' and greater %s' % self.__pkt_len_greater

            if self.__pkt_len_lesser is not None:
                command += ' and less %s' % self.__pkt_len_lesser
            
            command += ' -enn'

            if self.__verbose:
                command += ' -v'
            if not self.__promisc:
                command += ' -p'

            self.__tcpdump_proc = self.__exe.run(command, shell=True)

    def stop(self):
        """
        The method that stops the running tcpdump command and saves the packets captured (IOW: the
        output of the command)
        """
        if self.__tcpdump_proc is not None:
            exe_proc = self.__exe if isinstance(self.__exe, ssh.SSH) else self.__tcpdump_proc

            if exe_proc.poll() is None:
                exe_proc.stop()
                time.sleep(1)

            self.__output = exe_proc.get_output()
            self.__tcpdump_proc = None

    def remove_pcapfile(self, capture_file):
        """
        the method deletes the pcap file created by capture option of tcpdump
         Args:
             capture_file: Delete the given captured filed
        """
        self.__exe.block_run("rm -f %s" % str(capture_file))
