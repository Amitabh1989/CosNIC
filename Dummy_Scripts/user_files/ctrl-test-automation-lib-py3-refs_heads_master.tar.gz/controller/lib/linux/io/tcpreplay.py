"""
:mod:`tcpreplay` --tcpreplay library
==================================================================================

.. module:: controller.lib.linux.io.tcpreplay
.. moduleauthor:: Madhusudana <madhusudana.annam@broadcom.com>

This is a method for tcpreplay 3.2.5 and above

"""

from distutils.spawn import find_executable
import time

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe


log = log_handler.get_logger(__name__)


class Tcpreplay(object):
    if None in [find_executable('tcpreplay')]:
        raise exception.ConfigException("tcpreplay not found... Please check if tcpreplay is installed with 4.3.2"
                                        " and higher version!")

    def __init__(self):
        self.__tcpreplay_path = find_executable('tcpreplay')
        self.__tcpreplay_pid = None
        self.__cmd = None
        self.loop_count = 1000000000000000000   # max supported loop count
        self.duration = 300

    def start(self,  interface, file_path, duration=None, ip_inc=True, top_speed=True, **kwargs):
        top_speed = '-tK' if top_speed else '-K'
        extra_options = [
            param if value is True else '{} {}'.format(param, value)
            for param, value in kwargs.items()]
        duration = duration or self.duration

        if ip_inc:
            self.__cmd = f"{self.__tcpreplay_path}  -i {interface} {top_speed} --loop={self.loop_count} --unique-ip " \
                f"--duration={duration} {' '.join(extra_options)} {file_path}"
        else:
            self.__cmd = f"{self.__tcpreplay_path}  -i {interface} {top_speed} --loop={self.loop_count} " \
                f"--duration={duration} {' '.join(extra_options)} {file_path}"

        self.__tcpreplay_pid = exe.run(self.__cmd)
        return self.__tcpreplay_pid

    def poll(self):
        if self.__tcpreplay_pid:
            return self.__tcpreplay_pid.poll()
        return False

    def check_proc_status(self):
        output = exe.block_run('ps -Af')
        proc = self.__tcpreplay_path if not self.__cmd else self.__cmd
        for line in output.splitlines():
            if line.find(proc) != -1:
                return True
        return False

    def stop(self):
        if not self.__tcpreplay_pid:
            log.info("{} is not running...".format(self.__tcpreplay_path))
            return True
        self.__tcpreplay_pid.kill()
        time.sleep(3)
        # Using "not None" as poll returns 0 on successful termination and if self.poll() will not work
        if self.poll() is not None:
            log.info("{} process successfully stopped".format(self.__tcpreplay_path))
            return True
        raise exception.NetperfException("Failed to stop {}!".format(self.__tcpreplay_path))
