"""
:mod:`testpmd` -- testpmd DPDK command Wrapper.
===============================================

.. module:: controller.lib.linux.io.testpmd
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for testpmd DPDK command.
"""
import logging
import os
import re
import sys
import time
import pexpect

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.linux import eth
from controller.lib.linux.io import DPDKController

log = logging.getLogger(__name__)


class TestPMDController(DPDKController):
    def __init__(self, **kwargs):
        """
        The Constructor.

        Args:
            kwargs : A dictionary of additional optional arguments.
              - 'core_mask'=<core_mask>
                The bit-map representing the CPU cores to use.
              - 'num_memory_channels'=<num_memory_channels>
                The number of memory channels to the CPU socket.
              - 'num_cores'=<num_cores>
                The number of cores to use for running.
              - 'num_ports'=<num_ports>
                The number of ports to use for running.
                - 'extra_pci_args'=<None>
                pci arguments which are required as part of '-a' option

        """
        super(TestPMDController, self).__init__(**kwargs)
        self._core_mask = kwargs.get('core_mask', '0xff')
        self._lcores = kwargs.get('lcores', None)
        self._main_lcore = kwargs.get('main_lcore', None)
        self._num_memory_channels = str(kwargs.get('num_memory_channels', '1'))
        self._num_cores = str(kwargs.get('num_cores', '2'))
        self._num_ports = str(kwargs.get('num_ports', '2'))
        self._rxq = str(kwargs.get('rxq', '8'))
        self._txq = str(kwargs.get('txq', '8'))
        self._log_level = str(kwargs.get('log_level', '7'))
        self._rss_state = kwargs.get('rss_state', 'enabled')
        self._fwd_mode = kwargs.get('fwd_mode', 'io')
        self._peer1_mac = kwargs.get('peer1_mac', None)
        self._peer2_mac = kwargs.get('peer2_mac', None)
        self._include_bdfs = kwargs.get('include_bdfs', False)
        self._mbuf_size = kwargs.get('mbuf_size', None)
        self._mbuf_count = kwargs.get('mbuf_count', None)
        self._port_topology = kwargs.get('port_topology', None)
        self._rxd = kwargs.get('rxd', None)
        self._txd = kwargs.get('txd', None)
        self._vdev = kwargs.get('vdev', None)
        self._cqe_mode = kwargs.get('cqe-mode', None)
        self._vdev_args = kwargs.get('vdev_args', None)  # Should be dict
        self._burst = kwargs.get('burst', None)
        self._mbcache = kwargs.get('mbcache', None)
        self._socket_num = kwargs.get('socket_num', None)
        self._socket_mem = kwargs.get('socket_mem', None)
        self._dpdk_version = kwargs.get('DPDK_VERSION', None)
        self._env = kwargs.get('env', None)
        self._mpc = kwargs.get('mpc', None)
        self._port_bdfs = []
        self._vib_ids = []   # kwargs.get('vib_ids', None)
        self._testpmd_prompt = 'testpmd> '
        self._scapy_prompt = '>>> '
        self.ifaces = []
        self._verbose = kwargs.get('verbose', False)
        self._pexpect_timeout = kwargs.get('pexpect_timeout', 10)
        self._vf_count = str(kwargs.get('vf_count', 1))
        self._force_max_simd_bitwidth = kwargs.get('force_max_simd_bitwidth')
        # CTRL-43099: DPDK: MTU testates need changes based on the DPDK versions.
        # DPDK versions before 18.05 can change MTU dynamically while newer versions cannot.
        # So, assmume a newer version; but be prepared for older versions.
        self.__can_change_mtu_dynamically = False
        self._pexpect = None
        self._extra_args = kwargs.get('extra_args', {})

    def bind_device(self, port_bdf, driver=None, load_driver=False):
        """
        Bind the specified device to the specified driver. If no driver is specified, the device
        is unbound from the currently bound driver.

        Args:
            port_bdf: The PCI BDF of the device.
            driver: The driver to bind the device to. None means unbind from the currently bound
            driver.
            load_driver: To unload binded driver if its True
        Return:
            previous_driver: The driver that was previously bound to the device.
        """
        previous_driver = None

        if self._is_inbox_driver() is False:
            command = r'%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
        else:
            command = r'dpdk-devbind --status'
        # Get the driver that is currently bound to the device.
        command_output = self._exe.block_run(command)
        command_output = re.findall(r'(%s).*drv=(\w+)' % port_bdf, command_output)

        if len(command_output) == 1:
            previous_driver = command_output[0][1]
        # Do the requested binding.
        if self._is_inbox_driver() is False:
            command = r'%s/usertools/dpdk-devbind.py --force ' % self.RTE_SDK
        else:
            command = r'dpdk-devbind --force '

        if driver is None:
            command += '--unbind %s' % port_bdf
        else:
            if (driver in ['igb_uio', 'vfio-pci']) and load_driver:
                # load the modules necessary for DPDK.
                if driver == 'igb_uio':
                    try:
                        self._exe.block_run('rmmod %s' % driver)
                    except Exception:
                        pass
                    self._exe.block_run('modprobe uio')
                    drv_command = 'insmod %s/kmod/%s.ko' % (self.RTE_TARGET, driver)
                else:
                    drv_command = 'modprobe %s' % driver
                self._exe.block_run(drv_command)
            # else:
            command += '--bind=%s %s' % (driver, port_bdf)

        self._exe.block_run(command)
        return previous_driver

    def start(self):
        """
        The method that configures and launches the testpmd application. It will:
            - Configure the hugepages.
            - Loads the PMD.
            - Binds the requested interfaces to the PMD.
            - Finally, launches the testpmd application.
        """
        # Do the necessary initializations.
        test_status = self.configure_pmd()
        # test_status = super(TestPMDController, self).start()
        if test_status is True:
            test_status = self.launch_testpmd()

        return test_status

    def launch_testpmd(self):
        """
        Launch the testpmd application with the specified options.
        """
        test_status = True

        def cleanup():
            log.error('Failed to launch testpmd application.')
            log.info('Clean up the testpmd application which failed to launch')
            self.stop()
        # CTRL-40788: Add support in dpdk scripts for inbox OS.
        # Use the appropriate command to verify the interfaces are bound to the PMD.
        if self._is_inbox_driver() is False:
            pmd_path = self.RTE_TARGET + '/app/testpmd'
            if os.path.exists(pmd_path):
                command = pmd_path
                pci_arg = '-w'
            else:
                command = self.RTE_TARGET + '/app/dpdk-testpmd'
                pci_arg = '-a'
        else:
            command = 'testpmd'
            pci_arg = '-w'
        # If port BDF's are asked to be included in the command line, do so.
        if self._include_bdfs is True:
            # Remove duplicate port bdfs, if there
            self._port_bdfs = list(set(self._port_bdfs))
            for index, port_bdf in enumerate(self._port_bdfs):
                if self._cqe_mode is not None:
                    command += ' %s %s,cqe-mode=%s' % (pci_arg, port_bdf, str(self._cqe_mode))
                elif pci_arg == '-a':
                    command += ' %s %s' % (pci_arg, port_bdf)
                    if self._extra_args:
                        for k, v in self._extra_args.items():
                            command += ',' + '%s=%s' % (k, v)
                    if self._vib_ids:
                        command += ',vib-id=%s' % self._vib_ids[index]
                    if self._mpc:
                        command += ',mpc=%s' % self._mpc
                else:
                    command += ' %s %s,accum-stats=1' % (pci_arg, port_bdf)
        if self._vdev is not None:
            command += ' --vdev %s' % self._vdev
            if self._vdev_args is not None:
                for k, v in self._vdev_args.items():
                    command += ',' + '%s=%s' % (k, v)
        if self._hugepage_memory:
            command += ' -m %s' % self._hugepage_memory
        if self._file_prefix:
            command += ' --file-prefix=%s' % self._file_prefix
        if self._force_max_simd_bitwidth:
            command += ' --force-max-simd-bitwidth=%s' % self._force_max_simd_bitwidth
        if self._lcores is not None:
            lcores = ','.join(self._lcores) if isinstance(self._lcores, list) else self._lcores
            command += ' -l %s' % lcores
        else:
            command += ' -c %s' % self._core_mask
        if self._main_lcore is not None:
            command += ' --main-lcore %s' % self._main_lcore
        if self._socket_num is not None:
            command += ' --socket_num=' + str(self._socket_num)
        if self._socket_mem is not None:
            socket_mem = ','.join(self._socket_mem) if isinstance(self._socket_mem, list) else self._socket_mem
            command += ' --socket-mem=%s' % socket_mem
        if self._verbose:
            command += ' -v ' + ' -n ' + self._num_memory_channels + \
                   ' --log-level=' + self._log_level + ' -- -i --nb-cores=' + self._num_cores + \
                   ' --nb-ports=' + self._num_ports + ' --rxq=' + self._rxq + ' --txq=' + self._txq + \
                   ' --forward-mode=' + self._fwd_mode
        else:
            command += ' -n ' + self._num_memory_channels + \
                   ' --log-level=' + self._log_level + ' -- -i --nb-cores=' + self._num_cores + \
                   ' --nb-ports=' + self._num_ports + ' --rxq=' + self._rxq + ' --txq=' + self._txq + \
                   ' --forward-mode=' + self._fwd_mode

        if self._rss_state == 'disabled':
            command += ' --disable-rss'

        if self._peer1_mac is not None:
            command += ' --eth-peer=0,' + self._peer1_mac

        if self._peer2_mac is not None:
            command += ' --eth-peer=1,' + self._peer2_mac

        if self._mbuf_size is not None:
            command += ' --mbuf-size=' + str(self._mbuf_size)

        if self._mbuf_count is not None:
            command += ' --total-num-mbufs=' + str(self._mbuf_count)

        if self._port_topology is not None:
            command += ' --port-topology=' + self._port_topology

        if self._rxd is not None:
            command += ' --rxd=' + str(self._rxd)

        if self._txd is not None:
            command += ' --txd=' + str(self._txd)
        if self._burst is not None:
            command += ' --burst=' + str(self._burst)
        if self._mbcache is not None:
            command += ' --mbcache=' + str(self._mbcache)

        # Execute the command.
        log.info(command)
        # When asked to use SSH, use the SSH object for running testpmd commands too.
        if self._ssh_ip_addr is not None:
            self._pexpect_object = self._exe.run(command, ignore_output=True)
        else:
            if self._env is not None:
                self._pexpect_object = pexpect.spawn(command, env=dict(self._env))
                # self._pexpect_object = pexpect.spawn(command, env={'BNXT_ULP_T_HA_SUPPORT': '0'})
            else:
                self._pexpect_object = pexpect.spawn(command)
        # Wait a while to settle things down.
        time.sleep(5)
        # CTRL-37598: dpdk test scripts are failing while stopping testpmd in SLES15...
        # Increase the timeout value for pexpect to wait for the child to close/terminate.
        # pexpect older than 4.x.y do not have 'ptyproc' wrapper, so expect failure
        # with those versions and ignore it.
        try:
            self._pexpect_object.delayafterclose = self._pexpect_timeout
            self._pexpect_object.ptyproc.delayafterclose = self._pexpect_timeout
        except Exception:
            pass

        try:
            # testpmd application must be started within 60 seconds.
            index = self._pexpect_object.expect([self._testpmd_prompt], timeout=60)
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # If the output is a byte stream (as in case of Python 3.X), convert it to str.
            if isinstance(self._pexpect_object.before, bytes):
                self._pexpect_object.before = self._pexpect_object.before.decode('utf-8')

            log.info(self._pexpect_object.before)
            # CTRL-40787: DPDK: Check for command errors during the test.
            # Bail out in case of any error.
            self._bail_out_on_error('testpmd')

            if index == 0:
                log.info('Launched testpmd application successfully.')
            else:
                test_status = False
                cleanup()
        except Exception as e:
            log.error(e)
            test_status = False
            cleanup()

        return test_status

    def quit_testpmd(self):
        """
        Quit the testpmd application.
        """
        command = 'quit'
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        test_status = self._run_testpmd_command(command)
        # Close the pexpect session only when not using SSH.
        if self._ssh_ip_addr is None:
            self._pexpect_object.close()
            self._pexpect_object = None

        return test_status

    def kill_testpmd(self, file_prefix=None, crash_type='kill'):
        """
            Kill or Pkill the speicific testpmd application
        Args:
            file_prefix: Name of the testpmd
            crash_type: Type of crash i.e. Kill or Pkill
        Return:
            crash: Status of crash type i.e. True or False
        """
        killed = False
        pmd_name = file_prefix or self._file_prefix
        if pmd_name is not None:
            log.info(f"{crash_type} {pmd_name} with pid")
        pid = self._pexpect_object.pid
        log.info('Testpmd application process ID is: %s' % pid)
        if isinstance(pid, int):
            if crash_type == 'kill':
                exe.block_run('kill -9 %s' % pid)
            elif crash_type == 'pkill':
                exe.block_run('pkill -ns %s' % pid)
            time.sleep(5) # increased time to 5 sec for wh+
            killed = True
        else:
            log.error('Testpmd application is not found.')
        self._pexpect_object.close()
        return killed

    def get_pmd_name(self):
        """
           The method returns the Testpmd object name
        """
        return self._file_prefix or 'testpmd'

    def isalive(self):
        """
               The method will tell the status of Testpmd object on the host and returns
               """
        test_status = False
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        try:
            self._pexpect_object.isalive()
            test_status = True
        except Exception:
            pass
        # Wait a while to settle things down.
        time.sleep(3)
        return test_status

    def start_packet_forwarding(self):
        """
        """
        # Start packet forwarding.
        command = 'start'
        result = self._run_testpmd_command(command)
        output = self._pexpect_object.before
        if 'Not all ports were started' in output:
            raise exception.TestPMDException('Not all ports were started')
        return result

    def stop_packet_forwarding(self):
        """
        """
        # Stop packet forwarding.
        command = 'stop'
        return self._run_testpmd_command(command)

    def set_macswap(self):
        test_status = self.stop_packet_forwarding()
        if test_status:
            test_status = self._run_testpmd_command("set fwd macswap")
        # Start packet forwarding.
        if test_status is True:
            test_status = self.start_packet_forwarding()
        return test_status

    def set_speed(self, speed, duplex):
        """
        Set speed and duplex on all the ports. It also verifies that the speed and duplex
        values set are indeed effective by reading them back after 10 seconds.

        Args:
            speed: The speed to set.
            duplex: The duplex mode to set.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        duplex = duplex.lower()
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        # Stop all the ports before configuring.
        command = 'port stop all'
        self._run_testpmd_command(command)
        # Set the speed as requested.
        # CTRL-40654: Test fails to change the link speed due to case-sensitive command.
        # Convert the duplex value to all lower case before passing to testpmd.
        command = 'port config all speed ' + speed + ' duplex ' + duplex
        self._run_testpmd_command(command)
        # Start the ports after configuring.
        command = 'port start all'
        test_status = self._run_testpmd_command(command, 'Done')
        # CTRL-40654: Test fails to change the link speed due to case-sensitive command.
        # Wait a while to settle things down and verify that the speed and duplex values are
        # configured on the port.
        time.sleep(10)
        for port in range(int(self._num_ports)):
            # In case of any failure, break out.
            if test_status is False:
                break

            test_status = self.get_port_info(port, 'Link speed: ', speed)
            if test_status == False:
                speed = str(speed)
                speed = int(speed[:-3])
                test_status = self.get_port_info(port, 'Link speed: ', speed)

            if test_status is True and duplex != 'auto':
                duplex = duplex.lower()
                duplex_name = duplex + '-duplex'
                test_status = self.get_port_info(port, 'Link duplex: ', duplex_name)

        return test_status

    def set_port_vlan_filter(self, port, state):
        """
        Configure port vlan filtering.

        Args:
            port: The port to configure vlan filtering on.
            state: The vlan filter state: 'on' or 'off'.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port)
        test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'vlan set filter %s %s' % (state, port)
            test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'port start %s' % str(port)
            test_status = self._run_testpmd_command(command)

        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_port_vlan_strip(self, port, state):
        """
        Configure port vlan stripping.

        Args:
            port: The port to configure vlan stripping on.
            state: The vlan strip state: 'on' or 'off'.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port)
        test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'vlan set strip %s %s' % (state, port)
            test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'port start %s' % str(port)
            test_status = self._run_testpmd_command(command)

        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_port_vlan_qinq(self, port, state):
        """
        Configure port vlan qinq stripping.

        Args:
            port: The port to configure vlan qinq stripping on.
            state: The vlan qinq state: 'on' or 'off'.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port)
        test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'vlan set qinq_strip %s %s' % (state, port)
            test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'port start %s' % str(port)
            test_status = self._run_testpmd_command(command)

        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_port_rx_extend(self, port, state):
        """
        Configure port rx side extenstion.

        Args:
            port: The port to configure rx extension on.
            state: The rx extension state: 'on' or 'off'.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port)
        test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'vlan set extend %s %s' % (state, port)
            test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'port start %s' % str(port)
            test_status = self._run_testpmd_command(command)

        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_port_tpid(self, port, tpid):
        """
        Configure tpid on the specified port.

        Args:
            port: The port to configure tpid on.
            tpid: The tpid to configure.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port)
        test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'vlan set outer tpid %s %s' % (tpid, port)
            test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'port start %s' % str(port)
            test_status = self._run_testpmd_command(command)

        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_port_tx_vlan(self, port, vlan_id):
        """
        Configure the vlan ID to insert on the specified port.

        Args:
            port: The port to configure vLAN insertion on.
            vlan_id: The vLAN ID to insert. A list of vLAN ID's can also be specified.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port)
        test_status = self._run_testpmd_command(command)

        if test_status is True:
            if isinstance(vlan_id, list):
                vlan_id = ' '.join(vlan_id)

            command = 'tx_vlan set %s %s' % (port, vlan_id)
            test_status = self._run_testpmd_command(command)

        if test_status is True:
            command = 'port start %s' % str(port)
            test_status = self._run_testpmd_command(command)

        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_mtu(self, mtu):
        """
            Configure the MTU .

        Args:
            mtu: MTU to configure on all testpmd ports
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        test_status = True
        # Stop packet forwarding.
        self.stop_packet_forwarding()
        # Set the MTU as requested on all the ports.
        for port in range(int(self._num_ports)):
            # CTRL-43099: DPDK: MTU testates need changes based on the DPDK versions.
            # First, stop the port and try MTU change (assuming newer DPDK). If that doesn't work,
            # go dynamic! Also, remember the choice.
            if self.__can_change_mtu_dynamically is False:
                # CTRL-40940: Automation : DPDK 19.08rc2 : Ports needs to be stopped to change the
                # mtu size 2048.
                # Stop the port before changing MTU.
                command = 'port stop %s' % str(port)
                self._run_testpmd_command(command)
        for port in range(int(self._num_ports)):
            try:
                command = 'port config mtu ' + str(port) + ' ' + str(mtu)
                self._run_testpmd_command(command)
            except Exception:
                # Older DPDK? Well, remember we can change MTU dynamically.
                self.__can_change_mtu_dynamically = True
                # Start the port as we can change MTU dynamically.
                command = 'port start %s' % str(port)
                self._run_testpmd_command(command)
                # Start packet forwarding.
                self.start_packet_forwarding()
                # Change the MTU as requested.
                command = 'port config mtu ' + str(port) + ' ' + str(mtu)
                self._run_testpmd_command(command)
        for port in range(int(self._num_ports)):
            if self.__can_change_mtu_dynamically is False:
                # Start the port after changing MTU.
                command = 'port start %s' % str(port)
                self._run_testpmd_command(command)
            # Make sure that the configured MTU is set indeed.
            command = 'show port info ' + str(port)
            test_status = self._run_testpmd_command(command, 'MTU: ' + str(mtu))
            # In case of any failure, break out.
            if test_status is False:
                break
        # Start packet forwarding.
        self.start_packet_forwarding()

        return test_status

    def set_queue_size(self, queue_size):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding, just in case it was started.
        self.stop_packet_forwarding()
        # Stop all the ports before configuring.
        command = 'port stop all'
        self._run_testpmd_command(command)
        # Set the tx and rx queue size as requested on all the ports.
        command = 'port config all txq ' + queue_size
        self._run_testpmd_command(command)
        command = 'port config all rxq ' + queue_size
        self._run_testpmd_command(command)
        # Start the ports after configuring.
        command = 'port start all'
        test_status = self._run_testpmd_command(command, 'Done')
        # Start packet forwarding.
        if test_status is True:
            self.start_packet_forwarding()

        return test_status

    def set_rss(self, rss_state, proto=None):
        """
        Turn RSS on/off on all the ports.
        Args:
            rss_state: The action to take: True - On; False - Off.
            proto: proto to which rss to be done : proto='ip'
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        if proto:
            command = f'port config all rss {proto}'
        else:
            # Turn RSS on/off as requested.
            command = f'port config all rss ' + \
                      ('all' if rss_state is True else 'none')
        return self._run_testpmd_command(command)

    def _get_rss_reta_size(self, port):
        """
        Private method to get the size of the RSS redirection table (reta) of the specified port.

        Args:
            port: The port to get the reta size of.
        Return:
            reta_size: The size of the reta of the specified port. -1 on failure.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        reta_size = -1
        command = 'show port info %s' % str(port)
        self._run_testpmd_command(command)
        re_obj = re.search(r'Redirection table size:[\s]+([\d]+)', self._pexpect_object.before)

        if re_obj is not None:
            reta_size = re_obj.group(1)

        return reta_size

    def get_rss_reta(self, port):
        """
        Get the reta entries of the specified port.

        Args:
            port: The port to get the reta entries of.
        Return:
            reta: The dictionary with the reta entries.
                Format : {hash_0: queue_0, hash_1: queue_1}
                Example: {0: 0, 127: 7}
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        reta = {}
        # First get the size of reta for the port.
        reta_size = self._get_rss_reta_size(port)
        # If valid reta size is found, build the dictionary of reta entries.
        if reta_size != -1:
            command = 'show port %s rss reta %s (-1,-1,-1,-1,-1,-1,-1,-1,-1,-1)' % (port, reta_size)
            self._run_testpmd_command(command)
            reta_entries = re.findall(r'index=(\d+), queue=(\d+)', self._pexpect_object.before)
            # Fill up the dictionary.
            for hash, queue in reta_entries:
                reta[hash] = queue
        # Return the reta.
        return reta

    def set_rss_reta(self, port, reta):
        """
        Configure RSS hash to queue mapping in the reta.

        Args:
            port: The port to configure reta entries on.
            reta: The dictionary with the reta entries.
                Format : {hash_0: queue_0, hash_1: queue_1}
                Example: {0: 0, 127: 7}
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        reta_hash = []
        # Program each of the reta entries specified.
        for index, queue in reta.items():
            reta_hash.append(f'({index},{queue})')
        reta_hash = ','.join(reta_hash)
        command = 'port config %s rss reta %s' % (port, reta_hash)
        test_status = self._run_testpmd_command(command)

        return test_status

    def set_cso(self, protocol, cso_state, port_num):
        """
        Configure CSO on the specified port.

        Args:
            protocol: The protocol to configure CSO for: 'ip', 'tcp' or 'udp'.
            cso_state: The state of CSO: True - enable; False - disable.
            port_num: The port to configure CSO on.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        proto_list = protocol if isinstance(protocol, list) else [protocol]
        port_list = port_num if isinstance(port_num, list) else [port_num]
        self.stop_packet_forwarding()
        # Set the IO forwarding mode to csum.
        command = 'set fwd csum'
        self._run_testpmd_command(command)
        for port_num in port_list:
            command = 'port stop %s' % str(port_num)
            self._run_testpmd_command(command)
        for port_num in port_list:
            # Enable/disable CSO for the specified protocol as requested.
            for protocol in proto_list:
                command = 'csum set ' + protocol + ' ' + \
                          ('hw' if cso_state is True else 'sw') + ' ' + str(port_num)
                self._run_testpmd_command(command)
        for port_num in port_list:
            command = 'port start %s' % str(port_num)
            self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_cso_offload(self, protocol, port_num, offload='rx', cso_state=True, offload_state='on'):
        """
        configure port config on the specified port

        Agrs:
            protocol: The protocol to configure CSO for: 'ip', 'tcp' or 'udp'.
            port_num: The port to configure
            offload: either tx or rx offload
            offload_state: either on or off
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        proto_list = protocol if isinstance(protocol, list) else [protocol]
        port_list = port_num if isinstance(port_num, list) else [port_num]
        self.stop_packet_forwarding()
        if 'on' in offload_state:
            command = 'set fwd csum'
            self._run_testpmd_command(command)
        for port_num in port_list:
            command = 'port stop %s' % str(port_num)
            self._run_testpmd_command(command)
        for port_num in port_list:
            command = f'csum parse-tunnel {offload_state} ' + str(port_num)
            self._run_testpmd_command(command)
            for protocol in proto_list:
                command = 'csum set ' + protocol + ' ' + \
                          ('hw' if cso_state is True else 'sw') + ' ' + str(port_num)
                self._run_testpmd_command(command)
            command = 'port config ' + str(port_num) + ' ' + str(offload) + '_offload ' + 'outer_ipv4_cksum' + ' ' + \
                      offload_state
            self._run_testpmd_command(command)
            for protocol in proto_list:
                if self._dpdk_version and str(self._dpdk_version) > '17.11' and protocol in ['tcp', 'udp']:
                    command = 'port config ' + str(port_num) + ' ' + str(offload) + '_offload ' + \
                              str(protocol) + '_cksum' + ' ' + offload_state
                    self._run_testpmd_command(command)

        for port_num in port_list:
            command = 'port start %s' % str(port_num)
            self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_tso(self, tcp_segment_size, port_num, gre=False, ccn=False, ccn_tunnel=False):
        """
        Configure TSO on the specified port.

        Args:
            tcp_segment_size: The size of each segment.
            port_num: The port to configure TSO on.
            gre: If True set tso on Gre tunnel redirect testpmd
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        port_list = port_num if isinstance(port_num, list) else [port_num]
        self.stop_packet_forwarding()
        # Set the IO forwarding mode to csum.
        command = 'set fwd csum'
        self._run_testpmd_command(command)
        for port_num in port_list:
            command = 'port stop %s' % str(port_num)
            self._run_testpmd_command(command)
        for port_num in port_list:
            # Enable/disable TSO as requested.
            if gre:
                command = 'csum parse-tunnel on ' + str(port_num)
                self._run_testpmd_command(command)
                command = 'csum set outer-ip hw ' + str(port_num)
                self._run_testpmd_command(command)
                command = 'csum set ip hw ' + str(port_num)
                self._run_testpmd_command(command)
                command = 'tunnel_tso set ' + str(tcp_segment_size) + ' ' + str(port_num)
                self._run_testpmd_command(command)
            elif ccn:
                command = 'csum parse-tunnel on ' + str(port_num)
                self._run_testpmd_command(command)
                command = 'csum set outer-ip hw ' + str(port_num)
                self._run_testpmd_command(command)
                command = 'csum set tcp hw ' + str(port_num)
                self._run_testpmd_command(command)
                command = 'csum set ip hw ' + str(port_num)
                self._run_testpmd_command(command)
                if ccn_tunnel:
                    command = 'tunnel_tso set ' + str(tcp_segment_size) + ' ' + str(port_num)
                else:
                    command = 'tso set ' + str(tcp_segment_size) + ' ' + str(port_num)
                self._run_testpmd_command(command)
            else:
                command = 'tso set ' + str(tcp_segment_size) + ' ' + str(port_num)
                self._run_testpmd_command(command)
        for port_num in port_list:
            command = 'port start %s' % str(port_num)
            self._run_testpmd_command(command)
        return self.start_packet_forwarding()

    def del_rx_vlan(self, vlan_id):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop currently running ports
        self.stop_packet_forwarding()
        command = 'rx_vlan rm ' + str(vlan_id) + ' 0'
        self._run_testpmd_command(command)
        command = 'rx_vlan rm ' + str(vlan_id) + ' 1'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_rx_vlan_filter(self, vlan_id):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop currently running ports
        self.stop_packet_forwarding()
        command = 'set fwd mac'
        self._run_testpmd_command(command)
        command = 'port stop all'
        self._run_testpmd_command(command)
        commands = [' all hw-vlan-filter ', ' 0 rx_offload vlan_filter ']
        # Try "hw-vlan-filter", If that fails, try "rx_offload vlan_filter".
        for command in commands:
            if self._run_testpmd_command('port config ' + command + ' on ', 'Bad arguments') is False:
                break

        commands = ['all hw-vlan-filter', ' 1 rx_offload vlan_filter ']
        # Try "hw-vlan", If that fails, try "rx_offload vlan_filter".
        for command in commands:
            if self._run_testpmd_command('port config ' + command + ' on ', 'Bad arguments') is False:
                break
        command = 'port start all'
        self._run_testpmd_command(command)
        command = 'vlan set strip off 0'
        self._run_testpmd_command(command)
        command = 'vlan set strip off 1'
        self._run_testpmd_command(command)
        command = 'set promisc all off'
        self._run_testpmd_command(command)
        command = 'rx_vlan add ' + str(vlan_id) + ' 0'
        self._run_testpmd_command(command)
        command = 'rx_vlan add ' + str(vlan_id) + ' 1'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def del_tx_vlan(self):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop currently running ports
        self.stop_packet_forwarding()
        command = 'port stop all'
        self._run_testpmd_command(command)
        command = 'tx_vlan reset 0'
        self._run_testpmd_command(command)
        command = 'tx_vlan reset 1'
        self._run_testpmd_command(command)
        command = 'port start all'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_tx_vlan_insert(self, vlan_id):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop currently running ports
        self.stop_packet_forwarding()
        command = 'set fwd mac'
        self._run_testpmd_command(command)
        command = 'vlan set strip on 0'
        self._run_testpmd_command(command)
        command = 'vlan set strip on 1'
        self._run_testpmd_command(command)
        command = 'port stop all'
        self._run_testpmd_command(command)
        command = 'tx_vlan set 0 ' + str(vlan_id)
        self._run_testpmd_command(command)
        command = 'tx_vlan set 1 ' + str(vlan_id)
        self._run_testpmd_command(command)
        command = 'port start all'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_vlan_strip(self, state):
        """
        Turn hardware vLAN strip feature on/off on all the ports.

        Args:
            state: The action to take: True - On; False - Off.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Stop packet forwarding and ports before configuration.
        self.stop_packet_forwarding()
        command = 'port stop all'
        self._run_testpmd_command(command)
        # Configure VLAN strip as requested.
        commands = [' all hw-vlan-strip ', ' 0 rx_offload vlan_strip ']
        # Try "hw-vlan-filter", If that fails, try "rx_offload vlan_strip".
        for command in commands:
            if self._run_testpmd_command('port config ' + command + (
                    'on' if state is True else 'off'), 'Bad arguments') is False:
                break

        commands = ['all hw-vlan-strip', ' 1 rx_offload vlan_strip ']
        # Try "hw-vlan", If that fails, try "rx_offload vlan_strip".
        for command in commands:
            if self._run_testpmd_command('port config ' + command + (
                    'on' if state is True else 'off'), 'Bad arguments') is False:
                break
        command = 'port start all'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def configure_promiscuous_mode(self, port, promiscuous_state=True):
        """
        Configure promiscuous mode on the specfied port as requested.
        Args:
            port: The port to configure promiscuous mode on.
            promiscuous_state: The state to set for promiscuous mode.
                (True=on, False=off)
        Return: test_status (True for success; False on failure)
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Configure promiscuous mode as requested.
        state = 'on' if promiscuous_state is True else 'off'
        command = 'set promisc %s %s' % (str(port), state)
        return self._run_testpmd_command(command)

    def configure_mac_address(self, action, port, mac_address, vf_id=-1):
        """
        Configure (add, remove or set) the specified MAC address as an alternative MAC address
        on the specified port or on the specified VF.

        Args:
            action: The configuration action to perform: 'add', 'remove' or 'set'.
            port: The port to configure the MAC address on.
            mac_address: The MAC address to configure on the port.
            vf_id: The VF to configure the MAC address on. Default is -1, meaning MAC address is
                configured for the PF port.
        Return:
            True on success, False on failure.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do some sanity checks.
        if vf_id != -1 and action == 'remove':
            raise exception.UnsupportedException('"Remove" action is unsupported for VFs')
        # Decide the command to use based on if the MAC address specified is a multicast MAC
        # address or not.
        if (int(mac_address.split(':')[0]) & 0x01) == 0x01:
            # Multicast MAC addresses are not applicable for VF's yet. So, reject such requests.
            if vf_id != -1:
                raise exception.UnsupportedException('Multicast MAC %s is unsupported for VFs' % mac_address)
            elif action == 'set':
                raise exception.UnsupportedException('"Set" action is unsupported for %s' %
                                                     'multicast MAC ' + mac_address)

            command = 'mcast_addr '
        else:
            command = 'mac_addr '
        # Execute the requested action, if all is well.
        if vf_id != -1:
            # The command to set VF MAC address alone has a different command format. So, handle
            # this special case.
            if action == 'set':
                command = 'set vf mac addr ' + str(port) + ' ' + str(vf_id) + ' ' + mac_address
            else:
                command = 'mac_addr ' + action + ' port ' + str(port) + ' vf ' + str(vf_id) + \
                          ' ' + mac_address
        else:
            command += action + ' ' + str(port) + ' ' + mac_address

        return self._run_testpmd_command(command)

    def get_port_mac_filters_count(self, port):
        """
        Get the maximum supported number of MAC filters on the specified port.

        Args:
            port: The port to get the MAC filter limit of.
        Return:
            max_mac_filters: The maximum number of MAC filters that can be created on the specified
            port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show port info %s' % str(port)
        self._run_testpmd_command(command)
        max_mac_filters = re.search(r'Maximum number of MAC addresses: (\d+)',
                                    self._pexpect_object.before).group(1)
        return int(max_mac_filters)

    def get_port_max_rxq_count(self, port):
        """
        Get the maximum supported number of MAX RXQ on the specified port.

        Args:
            port: The port to get the RXQ limit of.
        Return:
            max_rxq: The maximum number of RXQ that can be created on the specified
            port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show port info %s' % str(port)
        self._run_testpmd_command(command)
        max_rxq = re.search(r'Max possible RX queues: (\d+)',
                            self._pexpect_object.before).group(1)
        return int(max_rxq)

    def get_current_num_rxq_count(self, port):
        """
        Get the Current number of RX queues on the specified port.

        Args:
            port: The port to get Current number of RX queues.
        Return:
            current_rxq: The Current number of RX queues that can be created on the specified
            port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show port info %s' % str(port)
        self._run_testpmd_command(command)
        current_rxq = re.search(r'Current number of RX queues:\s+(\d+)',
                            self._pexpect_object.before).group(1)
        return int(current_rxq)

    def get_port_mac_filters(self, port):
        """
        Get the list of MAC addresses (aka MAC filters) configured on the specified port.

        Args:
            port: The port to get the MAC addresses of.
        Return:
            A list of MAC addresses configured on the specified port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        start_processing = False
        mac_filters = []
        command = 'show port %s macs' % str(port)
        self._run_testpmd_command(command)
        mac_filters_count = re.search(r'Number of MAC address added: (\d+)',
                                      self._pexpect_object.before).group(1)

        for each_line in self._pexpect_object.before.split('\n'):
            if 'Number of MAC address added' in each_line:
                start_processing = True
            elif start_processing is True and each_line.strip() != '':
                mac_filters.append(each_line.strip())
        # Ensure that the number of MAC filters reported matches the advertized count.
        if len(mac_filters) != int(mac_filters_count):
            raise exception.TestPMDException(
                'MAC filter count mismatch. Advertized: %s; Reported %s' %
                (mac_filters_count, len(mac_filters)))
        # Return the list of MAC filters.
        return mac_filters

    def get_port_mcast_mac_filters(self, port):
        """
        Get the list of multicast MAC addresses (aka mcast MAC filters) configured on the
        specified port.

        Args:
            port: The port to get the mcast MAC addresses of.
        Return:
            A list of mcast MAC addresses configured on the specified port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        start_processing = False
        mac_filters = []
        command = 'show port %s mcast_macs' % str(port)
        self._run_testpmd_command(command)
        mac_filters_count = re.search(r'Number of Multicast MAC address added: (\d+)',
                                      self._pexpect_object.before).group(1)

        for each_line in self._pexpect_object.before.split('\n'):
            if 'Number of MAC address added' in each_line:
                start_processing = True
            elif start_processing is True and each_line.strip() != '':
                mac_filters.append(each_line.strip())
        # Ensure that the number of mcast MAC filters reported matches the advertized count.
        if len(mac_filters) != int(mac_filters_count):
            raise exception.TestPMDException(
                'Multicast MAC filter count mismatch. Advertised: %s; Reported %s' %
                (mac_filters_count, len(mac_filters)))
        # Return the list of MAC filters.
        return mac_filters

    def get_port_mac_address(self, port):
        """
        Get the MAC address configured on the specified port.

        Args:
            port: The port to get the MAC address of.
        Return:
            The MAC address configured on the specified port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # CTRL-45370: Automation: DPDK MAC filter tests should use the new
        # "show port macs|mcast_macs" command.
        # Implement the new get_port_mac_address function to remove the dependency on the
        # get_port_mac_addresses function used with MAC filters. The get_port_mac_addresses
        # function will be implemented later (when needed) using the "macs|mcase_macs" interface.
        command = 'show port info ' + str(port)
        self._run_testpmd_command(command)
        return re.search(r'MAC address:\s+([\w:]+)', self._pexpect_object.before).group(1)

    def get_port_stats(self, port):
        """
        Get the statistics of the specified port.

        Args:
            port: The port to read the stats of.
        Return:
            A dictionary containing the stats of the specified port. E.g:
                {
                    'TX-packets': <tx_packet_count>,
                    'RX-Packets': <rx_packet_count>
                }
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        port_stats = {'TX-packets': 0, 'RX-packets': 0}
        values_read = 0
        command = 'show port stats ' + str(port)
        log.info(self._testpmd_prompt + command)
        self._pexpect_object.sendline(command)
        # Parse the command output line-by-line to get the required stats.
        while True:
            each_line = self._pexpect_object.readline().strip()
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # If the output is a byte stream (as in case of Python 3.X), convert it to str.
            if isinstance(each_line, bytes):
                each_line = each_line.decode('utf-8')

            # CTRL-40787: DPDK: Check for command errors during the test.
            # Bail out in case of any error.
            if 'error' in each_line:
                self._bail_out_on_error(command, each_line)
            # Identify the stats item from each line read.
            if list(port_stats.keys())[0] in each_line:
                key = list(port_stats.keys())[0]
                values_read += 1
            elif list(port_stats.keys())[1] in each_line:
                key = list(port_stats.keys())[1]
                values_read += 1
            else:
                key = None
            # If identified, read its value into the output dictionary.
            if values_read > 0 and key is not None:
                port_stats[key] = int(re.search(r'%s:[\s]+([0-9]+)' % key, each_line).group(1))
            # If all the stats items are read, break out.
            if values_read == 2:
                break

        self._pexpect_object.expect(self._testpmd_prompt)
        # Return the updated stats.
        return port_stats

    def create_flow(self, port, **kwargs):
        """
        Create a flow based filter rule.

        Args:
            port: The port to create the flow rule on.
            direction: The direction of packet flow - 'ingress' or 'egress'. Default: 'ingress'.
            src_mac_spec: Source MAC address specification. Default: None.
            src_mac_mask: Source MAC address mask. Default: ff:ff:ff:ff:ff:ff.
            dst_mac_spec: Destination MAC address specification. Default: None.
            dst_mac_mask: Destination MAC address mask. Default: ff:ff:ff:ff:ff:ff.
            type_spec: Ethertype specification. Default: None.
            type_mask: Ethertype mask. Default: 65535.
            src_ip_spec: Source IP address specification. Default: None.
            src_ip_mask: Source IP address mask. Default: 255.255.255.255.
            dst_ip_spec: Destination IP address specification. Default: None.
            dst_ip_mask: Destination IP address mask. Default: 255.255.255.255.
            l4_protocol: The layer-4 protocol name - 'tcp' or 'udp'. Default: None.
            src_tcp_spec: Source TCP port specification. Default: None.
            src_tcp_mask: Source TCP port mask. Default: 65535.
            dst_tcp_spec: Destination TCP port specification. Default: None.
            dst_tcp_mask: Destination TCP port mask. Default: 65535.
            src_udp_spec: Source UDP port specification. Default: None.
            src_udp_mask: Source UDP port mask. Default: 65535.
            dst_udp_spec: Destination UDP port specification. Default: None.
            dst_udp_mask: Destination UDP port mask. Default: 65535.
            action: The action to take on rule hit - 'allow' or 'count' or 'drop'. Default: 'drop'.
            queue: The queue ID to forward the packet to if action is 'allow'. Default: 0.
        Return:
            test_status: True of flow rule is created successully, False if not.
            rule_id: The ID of the flow rule created, -1 otherwise.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        test_status = True
        rule_id = -1
        direction = kwargs.get('direction', 'ingress')
        src_mac_spec = kwargs.get('src_mac_spec', None)
        src_mac_mask = kwargs.get('src_mac_mask', 'ff:ff:ff:ff:ff:ff')
        dst_mac_spec = kwargs.get('dst_mac_spec', None)
        dst_mac_mask = kwargs.get('dst_mac_mask', 'ff:ff:ff:ff:ff:ff')
        type_spec = kwargs.get('type_spec', None)
        type_mask = kwargs.get('type_mask', '65535')
        src_ip_spec = kwargs.get('src_ip_spec', None)
        src_ip_mask = kwargs.get('src_ip_mask', '255.255.255.255')
        dst_ip_spec = kwargs.get('dst_ip_spec', None)
        dst_ip_mask = kwargs.get('dst_ip_mask', '255.255.255.255')
        l4_protocol = kwargs.get('l4_protocol', None)
        src_tcp_spec = kwargs.get('src_tcp_spec', None)
        src_tcp_mask = kwargs.get('src_tcp_mask', '65535')
        dst_tcp_spec = kwargs.get('dst_tcp_spec', None)
        dst_tcp_mask = kwargs.get('dst_tcp_mask', '65535')
        src_udp_spec = kwargs.get('src_udp_spec', None)
        src_udp_mask = kwargs.get('src_udp_mask', '65535')
        dst_udp_spec = kwargs.get('dst_udp_spec', None)
        dst_udp_mask = kwargs.get('dst_udp_mask', '65535')
        action = kwargs.get('action', 'drop')
        queue = kwargs.get('queue', 0)
        # Do some sanity checks.
        if src_mac_spec is None and dst_mac_spec is None and type_spec is None and \
                src_ip_spec is None and dst_ip_spec is None and src_tcp_spec is None and \
                dst_tcp_spec is None and src_udp_spec is None and dst_udp_spec is None:
            raise exception.ValueException('No filter values specified to build the rule.')
        elif (src_tcp_spec is not None and src_udp_spec is not None) or \
                (dst_tcp_spec is not None and dst_udp_spec is not None):
            raise exception.ValueException('Both TCP and UDP filtering cannot be specified.')
        # Build the rule based on the filter values specified.
        command = 'flow create ' + str(port) + ' ' + direction + ' pattern '
        # If layer-2 specifications are supplied, include them in the command.
        if src_mac_spec is not None or dst_mac_spec is not None or type_spec is not None:
            command += 'eth'

            if src_mac_spec is not None:
                command += ' src spec ' + src_mac_spec + ' src mask ' + src_mac_mask

            if dst_mac_spec is not None:
                command += ' dst spec ' + dst_mac_spec + ' dst mask ' + dst_mac_mask

            if type_spec is not None:
                command += ' type spec ' + str(type_spec) + ' type mask ' + str(type_mask)
        # If layer-3 specifications are supplied, include them in the command.
        if src_ip_spec is not None or dst_ip_spec is not None:
            command += ' / ipv4'

            if src_ip_spec is not None:
                command += ' src spec ' + src_ip_spec + ' src mask ' + src_ip_mask

            if dst_ip_spec is not None:
                command += ' dst spec ' + dst_ip_spec + ' dst mask ' + dst_ip_mask
        # If layer-4 (TCP) specifications are supplied, include them in the command.
        if src_tcp_spec is not None or dst_tcp_spec is not None or l4_protocol == 'tcp':
            command += ' proto spec 6'

            if src_tcp_spec is not None:
                command += ' / tcp src spec ' + str(src_tcp_spec) + ' src mask ' + str(src_tcp_mask)

            if dst_tcp_spec is not None:
                command += ' / tcp dst spec ' + str(dst_tcp_spec) + ' dst mask ' + str(dst_tcp_mask)
        # If layer-4 (UDP) specifications are supplied, include them in the command.
        if src_udp_spec is not None or dst_udp_spec is not None or l4_protocol == 'udp':
            command += ' proto spec 17'

            if src_udp_spec is not None:
                command += ' / udp src spec ' + str(src_udp_spec) + ' src mask ' + str(src_udp_mask)

            if dst_udp_spec is not None:
                command += ' / udp dst spec ' + str(dst_udp_spec) + ' dst mask ' + str(dst_udp_mask)
        # Finally, include the action in the command.
        command += ' / end actions '

        if action == 'count':
            command += 'count / '
            command += 'queue index ' + str(queue)
        elif action == 'allow':
            command += 'queue index ' + str(queue)
        else:
            command += 'drop'
        # Terminate the command.
        command += ' / end'
        # And execute it.
        test_status = self._run_testpmd_command(command)
        # Try to get the ID of the flow rule created.
        if test_status is True:
            re_obj = re.search(r'Flow rule #([\w]+) created', self._pexpect_object.before)
            test_status = re_obj is not None

        if test_status is True:
            rule_id = int(re_obj.group(1))
        # If the flow with the specified pattern already exists, consider it a success.
        # The command doesn't return the rule_id, so return the default rule_id (-1).
        elif 'Flow with pattern exists' in self._pexpect_object.before:
            test_status = True
        # Return the flow rule ID.
        return test_status, rule_id

    def list_flows(self, port):
        """
        Get the list of existing flows.

        Args:
            port: The port to get list of flows from.
        Return:
            flows: The list of flows active on the specified port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        flows = []
        dictionary = {}
        headers = None
        command = 'flow list ' + str(port)
        # Issue the command to list the flow rules.
        self._run_testpmd_command(command)

        for each_line in self._pexpect_object.before.split('\n'):
            # First, extract the table headers from the output.
            if 'ID' in each_line and 'Group' in each_line:
                headers = each_line.split()
            # Then, extract the table filelds and build a dictionary.
            elif headers is not None and each_line != '':
                # Overwrite the pattern ' => ' with '=>' so split functions as expected.
                each_line = each_line.replace(' => ', '=>')
                field_list = each_line.split()

                for index in range(len(headers)):
                    # While saving the fields, restore the ' => ' pattern.
                    dictionary[headers[index]] = field_list[index].replace('=>', ' => ')
                # Append the dictionary of rows into the list of flows.
                flows.append(dictionary)
        # Return the list of flows.
        return flows

    def destroy_flow(self, port, rule=0, rule_list=None):
        """
        Destroy the specified rule or list of rules.

        Args:
            port: The port to destroy the rule on.
            rule: The ID of the rule to destroy.
            rule_list: List rule ids to destroy in batch
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        if rule_list:
            command = 'flow destroy ' + str(port)
            for rule_id in rule_list:
                command += ' rule ' + str(rule_id)
        else:
            command = 'flow destroy ' + str(port) + ' rule ' + str(rule)
        return self._run_testpmd_command(command)

    def destroy_action(self, port, action_id):
        """
        Destroy the specified rule or list of rules.

        Args:
            port: The port to destroy the rule on.
            action_id: action id or list of action ids to be destroyed
        """
        action_id_list = action_id if isinstance(action_id, list) else [action_id]
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        for action_id in action_id_list:
            command = 'flow indirect_action '  + str(port) + ' destroy action_id  ' + str(action_id)
            if not self._run_testpmd_command(command):
                raise exception.TestCaseFailure(f"Failed to destory the indirection action ID {action_id}")


    def flush_flows(self, port):
        """
        Flush all the rules on the specified port.

        Args:
            port: The port to flush the rules on.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'flow flush ' + str(port)
        return self._run_testpmd_command(command)

    def configure_queues(self, port, tx=True, queue=0, start=True, setup=False):
        """
        Start/Stop a specified RSS queue of the specified port.

        Args:
            port : The port to start/stop RSS queue on.
            tx   : The direction of the traffic: (Tx: True; Rx: False; default: True).
            queue: The ID of the RSS queue to start/stop (default: 0).
            start: The action to take: (start: True; stop: False; default: True).
            setup: The action to setup
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'port %s ' % str(port)
        command += 'txq ' if tx is True else 'rxq '
        command += str(queue) + ' '
        if setup:
            command += 'setup'
        else:
            command += 'start' if start is True else 'stop'
        return self._run_testpmd_command(command)

    def get_stats(self):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        lines = []
        line = ''
        stats = {}
        self.statistics = {}
        header = None
        # Stop the packet forwarding first.
        command = 'stop'
        log.info(self._testpmd_prompt + command)
        self._pexpect_object.sendline(command)
        time.sleep(2)
        # Read the output line-by-line until 'Done'.
        while 'Done' not in line:
            line = self._pexpect_object.readline().strip()
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # If the output is a byte stream (as in case of Python 3.X), convert it to str.
            if isinstance(line, bytes):
                line = line.decode('utf-8')
            # CTRL-40787: DPDK: Check for command errors during the test.
            # Bail out in case of any error.
            if 'error' in line:
                self._bail_out_on_error(command, line)
            # Put the lines in a list for later processing.
            if line is not '':
                lines.append(line)
        # Create a dictionary of stats out of the lines read.
        for line in lines:
            # testpmd uses two different line separaters, identify
            # and remember each.
            if '--' in line:
                delimiter = '-'
            elif '++' in line:
                delimiter = '+'
            else:
                delimiter = None
            # If a delimiter is identified, extract the key (header)
            # for the stats.
            # Eg: 'Accumulated forward statistics for all'
            if delimiter is not None:
                if header is not None:
                    self.statistics[header] = stats
                    stats = {}

                header = re.search(r'[' + delimiter + ']*\s(.*)\s[' + delimiter + ']*', line)

                if header is not None:
                    header = header.group(1)
                    self.statistics[header] = None
            # If not, extract the actual stats information.
            # Eg: 'RX-dropped': '0'
            else:
                items = re.findall(r'([\w\-]*:\s[0-9]+)', line)
                # Add the stats as a dictionary under the last header identified.
                for item in items:
                    stats[item.split(': ')[0]] = item.split(': ')[1]
        # Start packet forwarding to restore the initial state.
        self._pexpect_object.expect(self._testpmd_prompt)
        self.start_packet_forwarding()
        # Return the stats dictionary.
        return self.statistics

    def get_port_xstats(self, port, packets=False):
        """
        Get a port's extended statistics.

        Args:
            port: The port to get the whole extended statistics of.
            packets: extended packet stats is fetched
        Return:
            statistics: The extended statistics of the specified port.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        statistics = {}
        command = 'show port xstats ' + str(port)
        # Issue the command to get the port's extended statistics.
        self._run_testpmd_command(command)
        if packets is False:
            # Build a dictionary of the statistics values read.
            for key, value in re.findall(r'([\w]+): ([\w]+)', self._pexpect_object.before):
                statistics[key] = int(value)
            # Return the port's extended statistics.
            return statistics
        else:
            expr = r'(.*q\d+).*packets.*: (\d+)'
            for key, value in re.findall(expr, self._pexpect_object.before):
                key = key+'packets'
                statistics[key] = int(value)
            return statistics

    def clear_port_xstats(self, port):
        """
        Clear the extended statistics of the specified port.

        Args:
            port: The port to clear the extended statistics of.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # CTRL-41914: THOR B0: DPDK: 'clear port xstats [0/1/all]' doesn't clear the stats.
        # Clear both 'port stats' and 'port xstats'.
        command = 'clear port stats %s' % str(port)
        self._run_testpmd_command(command)
        command = 'clear port xstats %s' % str(port)
        return self._run_testpmd_command(command)

    def get_port_info(self, port, parameter_label, expected_value):
        """
        Get the port info and see if the specified parameter label has the expected value or not.
        Args:
            port: The port to get the info of.
            parameter_label: The parameter label to look for in the port info.
            expected_value: The expected value of the parameter.
        Example:
            parameter_label = 'MAC address: '
            expected_value  = 'AA:BB:CC:DD:EE:FF'
        Return:
            True if the specified parameter_label is found in the port info and has the expected
            value; False otherwise
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Issue port info and check if the specified parameter label and expected value
        # are found in the command output.
        command = 'show port info ' + str(port)
        test_status = self._run_testpmd_command(command, parameter_label + str(expected_value))

        if test_status is False:
            log.error('Expected value %s%s is not found on port %s' % (
                parameter_label, str(expected_value), str(port)))

        return test_status

    def _bail_out_on_error(self, command, buffer=None):
        """
        Terminate further execution if any testpmd command reports an error.

        Args:
            buffer: The buffer to look in for errors. Default: None, meaning whole output buffer.
        Throws:
            exception.TestPMDException() with the embedded error.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        if buffer is None:
            buffer = self._pexpect_object.before
        # If the pattern 'error n:nn:nnnnnnnn:nnnn' is found in the command output, bail out.
        re_obj = re.search(r'error\s([\w]+):([\w]+):([\w]+):([\w]+)', buffer)

        if re_obj is not None:
            # CTRL-48164: Automation: TSO test cases are failing with Exception while doing
            # "show port stats 0".
            # Flush the pexpect buffer before bailing out. Also, ignore any error in doing so.
            # When the buffer is already flushed, timeout error is expected.
            try:
                self._pexpect_object.expect(self._testpmd_prompt)
            except Exception:
                pass

            error_message = 'error %s:%s:%s:%s' % (re_obj.group(1), re_obj.group(2), \
                                                   re_obj.group(3), re_obj.group(4))
            raise exception.TestPMDException('"%s" failed with %s' % (command, error_message))

    def _run_testpmd_command(self, command, expected_output=None):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Do the necessary initializations.
        test_status = True
        log.info(self._testpmd_prompt + command)
        self._pexpect_object.sendline(command)
        time.sleep(2)
        # The 'quit' command will not return the testpmd prompt. So, expect 'Bye...' in this case.
        # When using SSH, expect the shell prompt.
        if command == 'quit':
            expected_prompt = self._shell_prompt if self._ssh_ip_addr is not None else 'Bye...'
        else:
            expected_prompt = self._testpmd_prompt

        self._pexpect_object.expect(expected_prompt, timeout=360)
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # If the output is a byte stream (as in case of Python 3.X), convert it to str.
        if isinstance(self._pexpect_object.before, bytes):
            self._pexpect_object.before = self._pexpect_object.before.decode('utf-8')
        # CTRL-40363: Need to print the testpmd command output on the DUT window for basic and VF
        # dpdk testcases.
        # Log the output of the testpmd commands run.
        log.info(self._pexpect_object.before)
        # CTRL-40787: DPDK: Check for command errors during the test.
        # Bail out in case of any error.
        self._bail_out_on_error(command)
        # If anything is expected in the output, look for it.
        if expected_output is not None and expected_output not in self._pexpect_object.before:
            test_status = False

        return test_status

    def flow_query(self, port_id=0, rule_id=0, actions="count"):
        """
               Get a flow query status based on action on each rule on testpmd port.
               Args:
                   port_id: The port to get the stats/function
                   rule_id: The rule id to query the stats/function
                   actions: Type query action
               Return:
                   Stats/function: Stats/function of rule_id.
               """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        cmd = "flow query  %s %s %s" % (port_id, rule_id, actions)
        log.info(self._testpmd_prompt + cmd)
        self._run_testpmd_command(cmd)
        if isinstance(self._pexpect_object.before, bytes):
            output = self._pexpect_object.before.decode('utf-8')
        else:
            output = self._pexpect_object.before
        if actions == 'count':
            hits = int(re.findall(r"hits:\s(\d+)", output)[0])
            hit_bytes = int(re.findall(r"bytes:\s(\d+)", output)[0])
            return hits, hit_bytes
        elif actions == 'rss':
            return re.findall(r"function:\s(\w+)", output)[0]
        else:
            raise exception.TestCaseFailure("Please provide action type is either count or rss")

    def cbs_flow_create(self, port_id, attrs, flow_pattern, actions, promiscuous_state=False):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        rule_id = -1
        self.configure_promiscuous_mode(port_id, promiscuous_state)
        cmd = "flow create %s %s pattern %s actions %s" % (port_id, attrs, flow_pattern, actions)
        test_status = self._run_testpmd_command(cmd)
        # Try to get the ID of the flow rule created.
        if test_status is True:
            re_obj = re.search(r'Flow rule #([\w]+) created', self._pexpect_object.before)
            test_status = re_obj is not None

        if test_status is True:
            rule_id = int(re_obj.group(1))

        # Return the flow rule ID.
        return test_status, rule_id

    def get_port_fwd_stats(self):
        """
        Get Forward statistics for all ports.

        Return:
            port_stats: The forward statistics of all ports.
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show fwd stats all'
        # Issue the command to get the port's extended statistics.
        self._run_testpmd_command(command)
        # Build a dictionary of the statistics values read.
        output = self._pexpect_object.before
        stat_matches = re.findall(r'([\w]+-[\w]+):[\s]+([\d]+)', output)
        port_matches = re.findall(r'Forward statistics for port (\d+)', output)
        key_list = []
        for key, vlaue in stat_matches:
            key_list.append(key)
        # Remove duplicate keys from list
        key_list = list(set(key_list))
        index = 0
        port_stats = {}

        for port_num in port_matches:
            port_vals = stat_matches[index: index + len(key_list)]
            index = index + len(key_list)
            port_stats[int(port_num)] = {key.strip(): int(value) for key, value in port_vals}

        return port_stats

    def get_port_stats_all(self):
        """
        Get statistics of the ports.

        Return:
            port_stats: The dictionary containing the statistics of the ports.
                Example: {0: {'RX-packets': 1000},
                          1: {'RX-bytes: 6000'}}
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # CTRL-42208: Exception caught with port xstats command in GRE tunnel migration testcases.
        # Use the correct command (show port stats). Also fix the regex.
        command = 'show port stats all'
        self._run_testpmd_command(command)
        output = self._pexpect_object.before
        stat_matches = re.findall('([\w]+-[\w]+):[\s]+([\d]+)', output)
        port_matches = re.findall('NIC statistics for port (\d+)', output)
        index = 0
        port_stats = {}
        no_of_ports = len(port_matches)

        for port_num in port_matches:
            port_vals = stat_matches[index: index + (len(stat_matches) // no_of_ports)]
            index = index + (len(stat_matches) // no_of_ports)
            port_stats[int(port_num)] = {key.strip(): int(value) for key, value in port_vals}

        return port_stats

    def get_port_stop_stats(self, csum_stats=False):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show fwd stats all'
        self._run_testpmd_command(command)
        output = self._pexpect_object.before
        if 'Bad arguments' in output:
            if csum_stats:
                command = 'stop'
                self._run_testpmd_command(command)
                output = self._pexpect_object.before
                self.start_packet_forwarding()
            else:
                return self.get_port_stats_all()
        port_indices = [m.start() for m in re.finditer('Forward statistics for port', output)]
        accu_index = output.find('Accumulated forward statistics for all ports')
        port_indices = port_indices + [accu_index]
        ret_dict = {}
        for i in range(len(port_indices) - 1):
            start_ind = port_indices[i]
            stop_ind = port_indices[i + 1]
            stat_output = output[start_ind: stop_ind]
            stat_matches = re.findall(r'(\w+-\w+-?\w+?):\s+(\d+)', stat_output)
            ret_dict[i] = {key.strip(): int(value) for key, value in stat_matches}
        return ret_dict

    def load_commands(self, cmds, s_cmd=False):
        """
        :param
        cmds: file name which has batch of commands or single command
        s_cmd: execute single command if its true
        :return: return output
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        if s_cmd:
            command = '%s' % cmds
        else:
            command = 'load %s' % cmds
        self._run_testpmd_command(command)
        output = self._pexpect_object.before
        return output

    def enable_vfs(self, iface_list):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        test_status = True
        vf_pci_bdfs = []
        eth_iface_list = [eth.get_interface(iface) for iface in iface_list]
        log.info('Resetting the VFs to zero before setting..')
        for iface in eth_iface_list:
            iface.sriov = 0
        time.sleep(1)
        for iface in eth_iface_list:
            log.info('Creating %s VFs on the interface:%s' % (self._vf_count, iface.name))
            iface.sriov = self._vf_count
        time.sleep(2)
        for iface in eth_iface_list:
            if iface.sriov['num'] != int(self._vf_count):
                test_status = False
            else:
                log.info('VFs created on iface: %s are %s' % (iface.name, iface.vf_list))
                vf_pci_bdfs += [pci[pci.find(':') + 1:] for pci in list(iface.vf_list.values())]
        log.info(vf_pci_bdfs)
        return vf_pci_bdfs, test_status

    def add_tunnel_redirect(self, iface, tunneltype, vf_index):
        command = 'bnxtnvm -dev=%s add_tunnel_redirect %s vf %s' % (iface, tunneltype, vf_index)
        command_output = exe.block_run(command)
        if command_output.find('Command Executed Successfully') != -1:
            return True
        return False

    def del_tunnel_redirect(self, iface, tunneltype, vf_index):
        command = 'bnxtnvm -dev=%s del_tunnel_redirect %s vf %s' % (iface, tunneltype, vf_index)
        command_output = exe.block_run(command)
        if command_output.find('Command Executed Successfully') != -1:
            return True
        return False

    def query_tunnel_redirect(self, iface, tunneltype):
        command = 'bnxtnvm -dev=%s query_tunnel_redirect type %s vf' % (iface, tunneltype)
        try:
            command_output = exe.block_run(command)
        except exception.ExeExitcodeException as e:
            command_output = e.output
        if 'VF Index: 65535' in command_output:
            command_output = 'Error: Tunnel Redirection not configured'

        return command_output

    def clear_port_stats(self):
        """
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        # Start packet forwarding.
        command = 'clear port stats all'
        return self._run_testpmd_command(command)

    def query_rss_hash_mode(self, iface):
        command = 'bnxtnvm  -dev=%s cfgtunnel rss_mode' % iface
        command_output = exe.block_run(command)
        expr = r'RSS Hashing Mode : (\w+)'
        matches = re.findall(expr, command_output)
        if len(matches) == 1:
            return matches[0]
        else:
            log.error('Could not query the RSS hash mode..')
            return None

    def set_rss_hash_mode(self, iface, rss_mode):
        command = 'bnxtnvm  -dev=%s cfgtunnel rss_mode %s' % (iface, rss_mode)
        log.info(command)
        command_output = exe.block_run(command)
        test_status = False
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                test_status = True
                continue
        return test_status

    def set_rss_hash_key(self, port, proto, hash_key):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'port config %s rss-hash-key %s %s' % (port, proto, hash_key)
        return self._run_testpmd_command(command)

    def get_rss_hash_key(self, port, key=True):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show port %s rss-hash key' % port
        self._run_testpmd_command(command)
        output = self._pexpect_object.before
        if key:
            expr = r'.*RSS key:\s+(.*)'
        else:
            expr = r'.*RSS functions:\s+(.*)'
        key_found = re.search(expr, output, re.MULTILINE)
        if key_found:
            rss_key = key_found.group(1)
        else:
            command = 'show port %s rss-hash ipv4-tcp key' % port
            self._run_testpmd_command(command)
            output = self._pexpect_object.before
            rss_key = re.search(r'.*RSS key:\s+(.*)', output, re.MULTILINE).group(1)
        return rss_key

    def del_tunnel_redirect_using_testpmd(self, index, rule_id, flow_flush=False):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        if flow_flush:
            command = 'flow flush %s' % index
            test_status = self._run_testpmd_command(command)
            # Try to get the ID of the flow rule destroyed
            if test_status is True:
                re_obj = re.search(r'flow flush ([\w]+)', self._pexpect_object.before)
                test_status = re_obj
            # Return the flow rule ID.
            return test_status
        else:
            command = 'flow destroy %s rule %s' % (index, rule_id)
            test_status = self._run_testpmd_command(command)
            # Try to get the ID of the flow rule destroyed
            if test_status is True:
                re_obj = re.search(r'Flow rule #([\w]+) destroyed', self._pexpect_object.before)
                test_status = re_obj

            # Return the flow rule ID.
            return test_status

    def start_scapy(self):
        test_status = True
        command = 'scapy'
        self._pexpect_scapy_obj = pexpect.spawn(os.environ['SHELL'])
        self._pexpect_scapy_obj.sendline("unset PROMPT_COMMAND")
        self.PROMPT_SET_SH = r"PS1='[PEXPECT]\$ '"
        self.PROMPT_SET_CSH = r"set prompt='[PEXPECT]\$ '"
        self._shell_prompt = r"\[PEXPECT\][\$\#] "
        self._pexpect_scapy_obj.sendline(self.PROMPT_SET_SH)  # sh-style
        i = self._pexpect_scapy_obj.expect([pexpect.TIMEOUT, self._shell_prompt], timeout=10)
        if i == 0:  # csh-style
            self._pexpect_scapy_obj.sendline(self.PROMPT_SET_CSH)
            i = self._pexpect_scapy_obj.expect([pexpect.TIMEOUT, self._shell_prompt], timeout=10)
            if i == 0:
                log.error('Failed to launch shell for testpmd application')
                return False

        self._pexpect_scapy_obj.logfile = sys.stdout
        self._pexpect_scapy_obj.sendline(command)
        # Wait a while to settle things down.
        time.sleep(2)
        try:
            index = self._pexpect_scapy_obj.expect([self._scapy_prompt, self._shell_prompt])
            if index == 0:
                log.info('Launched scapy application successfully...')
            elif index == 1:
                log.info('Failed to launch scapy application...')
                test_status = False
        except Exception as e:
            log.error(e)
            test_status = False

        return test_status

    def stop_scapy(self):
        # Do the necessary initializations.
        test_status = True
        self._pexpect_scapy_obj.send('\003')
        self._pexpect_scapy_obj.expect(self._scapy_prompt)
        command = 'exit()'
        self._pexpect_scapy_obj.logfile = None
        self._pexpect_scapy_obj.sendline(command)
        self._pexpect_scapy_obj.expect(self._shell_prompt)
        return test_status

    def _run_sendp(self, command, wait=True):
        # Do the necessary initializations.
        test_status = False
        self._pexpect_scapy_obj.sendline(command)
        # CTRL-42187: All VXLAN RSS tests fails, same tests works fine manually.
        # Newer versions of scapy are observed to return the prompt ('>>> ') twice after receiving
        # each newline. This behavior results in the wrong assumption that the command issues is
        # completed, while it might still be running. So, expect and discard the extra prompt
        # immediately.
        try:
            self._pexpect_scapy_obj.expect(self._scapy_prompt, timeout=0)
            test_status = True
        except Exception:
            pass

        if wait:
            try:
                self._pexpect_scapy_obj.expect(self._scapy_prompt, timeout=60)
                test_status = True
            except Exception:
                pass

        return test_status

    def get_dpdk_version_via_testpmd(self):
        """
        to get the dpdk version used to run testpmd

        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        pattern = re.compile(r'RTE Version:\s([^\n]*)')
        dpdk_ver = re.search(pattern, self._pexpect_object.before)
        try:
            self.match = dpdk_ver.group(1)
            return self.match
        except:
            pass

    def set_verbose(self, number):
        """
        to set verbose option - from 0 to 3

        Args:
            number - between 0 to 3 - as user desires

        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'set verbose ' + str(number)
        return self._run_testpmd_command(command)

    def get_verbose_output(self):
        """
        to get verbose output

        """
        return self._pexpect_object.before

    def show_queue_info(self, queue_type='rxq', port=0, queue_num=0):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show {} info {} {}'.format(queue_type, port, queue_num)
        self._run_testpmd_command(command)
        output = self._pexpect_object.before
        return output

    def set_queue_ring_size(self, queue_type='rxq', port=0, queue_num=0, ring_size=512):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = "port config {} {} {} ring_size {}".format(port, queue_type, queue_num, ring_size)
        return self._run_testpmd_command(command)

    def query_tunnel_cfg(self, iface):
        """
        to query tunnel cfg

        """
        tunnelport = ''
        command = 'bnxtnvm  -dev=' + iface + ' cfgtunnel vxlan_ipv4 '
        command_output = exe.block_run(command)
        for each_line in command_output.split('\n'):
            if ":" not in each_line:
                continue
            tunnelport = each_line.split(":")[1]
        return tunnelport

    def set_tunnel_port(self, iface, tunnelport):
        """
        to set tunnel cfg

        """
        if tunnelport is None:
            tunnelport = ''
        command = 'bnxtnvm  -dev=' + iface + ' cfgtunnel vxlan_ipv4 dst_port ' + tunnelport
        command_output = exe.block_run(command)
        test_status = False
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                test_status = True
                continue
        return test_status

    def free_tunnel_port(self, iface):
        """
        to free tunnel cfg

        """
        command = 'bnxtnvm  -dev=' + iface + ' cfgtunnel vxlan_ipv4 dst_port '
        command_output = exe.block_run(command)
        test_status = False
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                test_status = True
                continue
        return test_status

    def create_bonded_device(self, mode, socket):
        """
        Create bonded device using testpmd

        Args:
            mode: mode at which the mode to be created
            socket: socket number
        """
        command = 'create bonded device ' + str(mode) + ' ' + str(socket)
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def add_bond_slave(self, slave, port):
        """
        add bonding slave

        Args:
            slave: slave id
            port: port id
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'add bonding slave ' + str(slave) + ' ' + str(port)
        self._run_testpmd_command(command)
        command = 'port start %s' % str(port)
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def remove_bond_slave(self, slave, port):
        """
        remove bonding slave

        Args:
            slave: slave id
            port: port id
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'remove bonding slave ' + str(slave) + ' ' + str(port)
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def show_bond_config(self, port):
        """
        show bonding config

        Args:
            port: port id
        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'show bonding config ' + str(port)
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def detach_port(self, port):
        """
        detach  port via testpmd

        Args:
            port: port id

        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'port stop all'
        self._run_testpmd_command(command)
        port_list = port if isinstance(port, list) else [port]
        for port in port_list:
            command = 'port detach ' + str(port)
            self._run_testpmd_command(command)
        return self._pexpect_object.before

    def attach_port(self, port):
        """
        attach port via testpmd
        Args:
            port: pci id

        """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        port_list = port if isinstance(port, list) else [port]
        for pid in port_list:
            command = 'port attach ' + str(pid)
            self._run_testpmd_command(command)
        command = 'port start all'
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def stop_queue(self, port, index, queue='rxq'):
        """
        Configure stop queue via testpmd
       Args:
           port: testpmd port
           index: queue index or queue number
           queue: type of Queue ie rx or tx

       """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = f'port {port} {queue} {index} stop'
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def start_queue(self, port, index, queue='rxq'):
        """
        Configure start queue via testpmd
       Args:
           port: testpmd port
           index: queue index or queue number
           queue: type of Queue ie rx or tx

       """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = f'port {port} {queue} {index} start'
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def port_stop_all(self):
        """
            Configure stop packet forward and port stop all on ports of testpmd

       """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        self.stop_packet_forwarding()
        command = 'port stop all'
        self._run_testpmd_command(command)
        return self._pexpect_object.before

    def port_start_all(self):
        """
        Configure port start all on ports of testpmd  and start pkt forward

       """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        command = 'port start all'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_rx_vxlan_port(self, ports, vxlan_port=4789):
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        if not isinstance(ports, list):
            ports = [ports]
        for port in ports:
            cmd = f'rx_vxlan_port add {vxlan_port} {port}'
            self.load_commands(cmd, s_cmd=True)

    def configure_lro(self, ports=None, state='on'):
        """
        Configure LRO via testpmd
       Args:
           ports: testpmd port or port list
           state: State of LRO Enable(on) or Disable(off)

       """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        ports = ports or [0]
        port_list = ports if isinstance(ports, list) else [ports]
        self.stop_packet_forwarding()
        command = 'port stop all'
        self._run_testpmd_command(command)
        for port in port_list:
            command = f'port config {port} rx_offload tcp_lro {state}'
            self._run_testpmd_command(command)
        command = 'port start all'
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_all_multi(self, ports=None, state='on'):
        """
        Configure all multi state on testpmd
        Args:
           ports: testpmd port or port list
           state: State of allmulti Enable(on) or Disable(off)

       """
        if self._file_prefix is not None:
            log.info(f"{self._file_prefix}")
        ports = ports or [0, 1]
        port_list = ports if isinstance(ports, list) else [ports]
        for port in port_list:
            command = f'set allmulti {port} {state}'
            self._run_testpmd_command(command)


class TestPMDHost(TestPMDController):
    def __init__(self, **kwargs):
        super(TestPMDHost, self).__init__(**kwargs)
