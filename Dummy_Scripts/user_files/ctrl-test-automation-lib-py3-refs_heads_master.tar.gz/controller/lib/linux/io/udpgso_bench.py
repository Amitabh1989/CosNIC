"""
:mod:`UDP GSO` -- udpgso_bench tool Wrapper.
=========================================

.. module:: controller.lib.linux.io.udpgso_bench
.. moduleauthor:: Subrahmanya Bhat <subrahmanya.Bhat@broadcom.com>

This is a Library File for udpgso_bench tool.

"""
import re

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler
from distutils.spawn import find_executable

log = log_handler.get_logger(__name__)

class UDPGSO_Bench(object):
    def __init__(self, mode):
        """
        The Constructor.
        Args:
            mode   : The mode in which udp_gso runs.
                   - 'server' to run as udp_gso server (default).
                   - 'client' to run as udp_gso client
        """
        self._mode = mode

    def get_options(self, **kwargs):
        """
                Args:
                    mode   : The mode in which udp_gso runs.
                           - 'server' to run as udp_gso server (default).
                           - 'client' to run as udp_gso client
                    port : port number where udp gso runs
                    send_size : message size, used only in client
                    gso_size : segmentation size
                    ip_version : ipv4/ipv6, ipv6 options used only in client
                    run_time : run_time used only in client
        """
        if self._mode == 'server':
            self._server_path = kwargs.get('udpgso_bench_path_server', None)
            if self._server_path is None:
                raise exception.ConfigException('No server path specified')
            self._gso_command_server = find_executable(self._server_path)
            if self._gso_command_server is None:
                raise exception.NotFoundException(f'{self._server_path} server udp_gso_bench_server_path specified in'
                                                  f' __test_config__.yml is not found')
        else:
            self._client_path = kwargs.get('udpgso_bench_path_client', None)
            if self._client_path is None:
                raise exception.ConfigException('No client path specified')
            self._gso_command_client = find_executable(self._client_path)
            if self._gso_command_client is None:
                raise exception.NotFoundException(f'{self._client_path} client udp_gso_bench_client_path specified '
                                                  f'in __test_config__.yml is not found')

        self._port = kwargs.get('port', '12001')
        self._send_size = kwargs.get('message_size', '65506')
        self._gso_size = kwargs.get('gso_size', '0')
        self._server_ip = kwargs.get('server_ip', None)
        self._ip_version = kwargs.get('ip_version', 'ipv4')
        self._run_time = kwargs.get('run_time', '60')
        self._result = None

class UDPGSO_BenchServer(UDPGSO_Bench):
    def __init__(self):
        super(UDPGSO_BenchServer, self).__init__(mode='server')

    def setup_gso(self, **kwargs):
        """
        setup server side commands
        """
        if self._mode != 'server':
            raise exception.ConfigException('start the client(tx) side after server(rx)')
        self.get_options(**kwargs)
        # Build the server-side command.
        self._gso_command_server += ' -b ' + self._server_ip
        self._gso_command_server += ' -p ' + self._port
        self._gso_command_server += ' -S ' + '0' # server side[rx] gso size should be 0 or without -S option
        if self._ip_version == 'ipv4':
            self._gso_command_server += ' -4 '

    def start(self):
        """
        start the server side commands
        ex:./udpgso_bench_rx  -b 102.102.102.10 -p 5001 -S 0 -4
        """
        log.info(self._gso_command_server)
        self._gso_proc_server = exe.run(self._gso_command_server, shell=True)

    def stop(self):
        """
        """
        self._gso_proc_server.stop()


class UDPGSO_BenchClient(UDPGSO_Bench):
    def __init__(self):
        super(UDPGSO_BenchClient, self).__init__(mode='client')

    def setup_gso(self, **kwargs):
        """
        setup client side commands
        """
        if self._mode != 'client':
            raise exception.ConfigException('start the server side first(rx)')
        self.get_options(**kwargs)
        # Build the client-side command.
        self._gso_command_client += ' -D ' + self._server_ip
        self._gso_command_client += ' -p ' + self._port
        self._gso_command_client += ' -S ' + self._gso_size
        self._gso_command_client += ' -s ' + self._send_size
        self._gso_command_client += ' -l ' + self._run_time
        if self._ip_version == 'ipv6':
            self._gso_command_client += ' -6 '
        else:
            self._gso_command_client += ' -4 '

    def start(self):
        """
        start the client side commands
        ex: ./udpgso_bench_tx  -4 -D 102.102.102.10 -p 5001 -s 65507 -S 0
        """
        log.info(self._gso_command_client)
        self._gso_proc_client = exe.run(self._gso_command_client, shell=True)

    def stop(self):
        """
        stop the clinet side
        """
        self._gso_proc_client.stop()

    def poll(self):
        """
        poll method
        """
        # If the command failed, return failure.
        return self._gso_proc_client.poll()

    def result(self):
        """
        get results
        """
        output = self._gso_proc_client.get_output()
        bandwidth = re.findall(r'tx:\s+(\d+\s+\w+)', output)
        log.info(f"bandwidth={bandwidth}")
        return bandwidth
