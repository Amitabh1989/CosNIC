"""
:mod:`testpmd` -- testpmd DPDK command Wrapper.
===============================================

.. module:: controller.lib.linux.io.testpmd
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for testpmd DPDK command.
CTRL-48082: Deprecated. Please use controller.lib.linux.io.testpmd
"""

import logging
import time, sys, os
import re
import pyshark
import tempfile
import pexpect

from controller.lib.linux import eth
from controller.lib.common.shell import exe
from controller.lib.linux.io import DPDKController
from controller.lib.core import exception

log = logging.getLogger( __name__)

class UparTestPMDController(DPDKController):
    def __init__(self, **kwargs):
        """
        The Constructor.

        Args:
            kwargs : A dictionary of additional optional arguments.
              - 'core_mask'=<core_mask>
                The bit-map representing the CPU cores to use.
              - 'num_memory_channels'=<num_memory_channels>
                The number of memory channels to the CPU socket.
              - 'num_cores'=<num_cores>
                The number of cores to use for running.
              - 'num_ports'=<num_ports>
                The number of ports to use for running.
        """
        super(UparTestPMDController, self).__init__(**kwargs)
        self._core_mask = kwargs.get('core_mask', '0xf')
        self._num_memory_channels = kwargs.get('num_memory_channels', '1')
        self._num_cores = kwargs.get('num_cores', '4')
        self._num_ports = kwargs.get('num_ports', '2')
        self._rxq = kwargs.get('rxq', '8')
        self._txq = kwargs.get('txq', '8')
        self._rssstate_cli = kwargs.get('rss_state', 'enabled')
        self._port_bdfs = []
        self._eem_tx = int(kwargs.get('eem_tx', 0))
        self._eem_rx = int(kwargs.get('eem_rx', 0))

        if self._eem_tx > 0 and self._eem_rx > 0:
            self.eem_enabled = True
        else:
            self.eem_enabled = False

        self._vf_count = str(kwargs.get('vf_count', 1))
        self._max_vf_count = str(kwargs.get('max_vf_count', 64))
        self._total_vfs = 0
        self._testpmd_started = False
        self._testpmd_prompt = 'testpmd> '
        self._scapy_prompt = '>>> '
        self._pexpect_testpmd_obj = None
        self._pexpect_scapy_obj = None

    def enable_vfs(self, iface_list):
        test_status = True
        vf_pci_bdfs = []
        eth_iface_list = [eth.get_interface(iface) for iface in iface_list]
        log.info('Resetting the VFs to zero before setting..')
        for iface in eth_iface_list:
            iface.sriov = 0
        time.sleep(1)
        for iface in eth_iface_list:
            log.info('Creating %s VFs on the interface:%s' % (self._vf_count, iface.name))
            iface.sriov = self._vf_count
        time.sleep(2)
        for iface in eth_iface_list:
            if iface.sriov['num'] != int(self._vf_count):
                test_status = False
            else:
                log.info('VFs created on iface: %s are %s' %(iface.name, iface.vf_list))
                vf_pci_bdfs += [pci[pci.find(':') + 1:] for pci in list(iface.vf_list.values())]
        log.info(vf_pci_bdfs)
        return vf_pci_bdfs, test_status

    def enable_max_vfs(self, iface_list):
        test_status = True
        vf_pci_bdfs = []
        eth_iface_list = [eth.get_interface(iface) for iface in iface_list]
        log.info('Resetting the VFs to zero before setting.')

        for iface in eth_iface_list:
            iface.sriov = 0
            time.sleep(2)

        for iface in eth_iface_list:
            log.info('Creating %s VFs on the interface: %s' % (self._max_vf_count, iface.name))
            iface.sriov = int(self._max_vf_count)
            time.sleep(3)

        for iface in eth_iface_list:
            if iface.sriov['num'] != int(self._max_vf_count):
                test_status = False
            else:
                log.info('VFs created on iface: %s are %s' % (iface, iface.vf_list))
                vf_pci_bdfs += [pci[pci.find(':') + 1:] for pci in list(iface.vf_list.values())]

        log.info(vf_pci_bdfs)
        return vf_pci_bdfs, test_status

    def disable_vfs(self, iface_list):
        test_status = True
        eth_iface_list = [eth.get_interface(iface) for iface in iface_list]
        log.info('Resetting the VFs to zero.')

        for iface in eth_iface_list:
            iface.sriov = 0
            time.sleep(2)

        for iface in eth_iface_list:
            if iface.sriov['num'] != 0:
                test_status = False

        return test_status

    def enable_vfs_trust(self, iface, vf_index):
        command = 'bnxtnvm -dev=%s vf %s trust enable' % (iface, vf_index)
        command_output = exe.block_run(command, shell=True)
        if command_output.find('Command Executed Successfully') != -1 or \
                command_output.find('Given value already configured') != -1:
            command = 'bnxtnvm -dev=%s vf %s trust' % (iface, vf_index)
            command_output = exe.block_run(command, shell=True)
            status = re.findall('Trusted VF : (Enabled|Disabled)', command_output)
            log.info(status)
            if status and status[0] == 'Enabled':
                log.info('VF Trust enabled successfully')
                return True
            else:
                log.error('Failed to enable VF Trust..')
                return False
        else:
            log.error('Failed to execute the VF Trust enabling command')
            return False

    def disable_vfs_trust(self, iface, vf_index):
        command = 'bnxtnvm -dev=%s vf %s trust disable' % (iface, vf_index)
        command_output = exe.block_run(command, shell=True)
        if command_output.find('Command Executed Successfully') != -1 or \
                command_output.find('Given value already configured') != -1:
            command = 'bnxtnvm -dev=%s vf %s trust' % (iface, vf_index)
            command_output = exe.block_run(command, shell=True)
            status = re.findall('Trusted VF : (Enabled|Disabled)', command_output)
            if status and status[0] == 'Disabled':
                log.info('VF Trust disabled successfully')
                return True
            else:
                log.error('Failed to disable VF Trust..')
                return False
        else:
            log.error('Failed to execute the VF Trust disabling command')
            return False

    def set_eem_tx(self, iface, tx=1048576):
        tx_old = self.get_eem_tx(iface)
        if tx == 0 or tx != tx_old:
            log.info('Resetting the TX EEM Configuration on Iface:%s' % iface)
            command = 'bnxtnvm -dev=%s set eem tx 0' % iface
            command_output = exe.block_run(command, shell=True)
            if command_output.find('successfully') == -1:
                log.error('Could not reset TX EEM Configuration on Iface:%s' % iface)
                return False

            if tx > 0:
                log.info('Setting the TX EEM on Iface:%s to %s' % (iface, tx))
                command = 'bnxtnvm -dev=%s set eem tx %s' % (iface, tx)
                command_output = exe.block_run(command, shell=True)
                if command_output.find('successfully') == -1:
                    log.error('Could not Enable TX EEM on Iface:%s' % iface)
                    return False

                # Verifying whether setting took affect...
                command = 'bnxtnvm -dev=%s query eem tx' % iface
                command_output = exe.block_run(command, shell=True)
                expr = 'Number of entries: (\d+)'
                matches = re.findall(expr, command_output)
                if len(matches) == 1 and int(matches[0])*1024 == tx:
                    log.info('TX EEM Enabled successfully on Iface:%s' % iface)
                    return True
                else:
                    log.error('Could not Enable TX EEM on Iface:%s' % iface)
                    return False
            else:
                return True
        elif tx_old == tx:
            log.info('EEM TX is already set to %s on Iface:%s' % (tx, iface))
            return True

    def set_eem_rx(self, iface, rx=1048576):
        rx_old = self.get_eem_rx(iface)

        if rx == 0 or rx_old != rx:
            log.info('Resetting the RX EEM Configuration on Iface:%s' % iface)
            command = 'bnxtnvm -dev=%s set eem rx 0' % iface
            command_output = exe.block_run(command, shell=True)
            if command_output.find('successfully') == -1:
                log.error('Could not reset RX EEM Configuration on Iface:%s' % iface)
                return False

            if rx > 0:
                command = 'bnxtnvm -dev=%s set eem rx %s' % (iface, rx)
                command_output = exe.block_run(command, shell=True)
                if command_output.find('successfully') == -1:
                    log.error('Could not Enable RX EEM on Iface:%s' % iface)
                    return False

                # Verifying whether setting took affect...
                command = 'bnxtnvm -dev=%s query eem rx' % iface
                command_output = exe.block_run(command, shell=True)
                expr = 'Number of entries: (\d+)'
                matches = re.findall(expr, command_output)
                if len(matches) == 1 and int(matches[0])*1024 == rx:
                    log.info('RX EEM Enabled successfully on Iface:%s' % iface)
                    return True
                else:
                    log.error('Could not Enable RX EEM on Iface:%s' % iface)
                    return False
            else:
                return True
        elif rx_old == rx:
            log.info('EEM RX is already set to %s on Iface:%s' %(rx, iface))
            return True

    def get_eem_tx(self, iface):
        tx = None
        command = 'bnxtnvm -dev=%s query eem tx' % iface
        command_output = exe.block_run(command, shell=True)
        expr = 'Number of entries: (\d+)'
        matches = re.findall(expr, command_output)
        if len(matches) == 1:
            tx = int(matches[0]) * 1024
        return tx

    def get_eem_rx(self, iface):
        rx = None
        command = 'bnxtnvm -dev=%s query eem rx' % iface
        command_output = exe.block_run(command, shell=True)
        expr = 'Number of entries: (\d+)'
        matches = re.findall(expr, command_output)
        if len(matches) == 1:
            rx = int(matches[0]) * 1024
        return rx

    def unbind_vf_bdf(self, deep_cleanup=True):
        for port_bdf in self._port_bdfs:
            command = '%s/usertools/dpdk-devbind.py --bind=bnxt_en %s' % (self.RTE_SDK, port_bdf)
            exe.block_run(command)

        time.sleep(2)
        # Then, make sure that the interfaces are bound to the bnxt_en driver.
        command = '%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
        command_output = exe.block_run(command)
        expr = '\w+:(\w+:\w+.\w).*if=(\w+) drv=bnxt_en unused=%s' % self.dpdk_driver
        vf_port_bdfs_bnxt = re.findall(expr, command_output)
        bnxt_devices = [port_bdf for port_bdf, vf_name in vf_port_bdfs_bnxt]

        for port_bdf in self._port_bdfs:
            if bnxt_devices.count(port_bdf) == 0:
                log.error('VF Device: %s could not be bound back to bnxt_en')
                return False
            else:
                log.info('VF Device: %s binded to bnxt_en successfully.' % port_bdf)

        for port_bdf, vf_name in vf_port_bdfs_bnxt:
            if port_bdf in self._port_bdfs:
                eth.get_interface(vf_name).up()
        # Remove the DPDK driver only when doing deep cleanup.
        if deep_cleanup is True:
            exe.block_run('rmmod %s' % self.dpdk_driver)

        return True

    def bind_vf_bdf(self, _vf_pci_bdfs, deep_init=True):
        test_status = True
        port_count = 1
        # Loading modules necessary for DPDK
        if deep_init is True:
            try:
                exe.block_run('rmmod %s' % self.dpdk_driver)
                log.info('%s module unloaded successfully..' % self.dpdk_driver)
            except:
                log.info('%s module not presently loaded..' % self.dpdk_driver)
                pass

            exe.block_run('modprobe uio')
            # CTRL-43709: GRE testcases trying to insmod the vfio-pci failing the scripts.
            # This function is meant for use with igb_uio module. So, hardcode it.
            command = 'insmod %s/kmod/%s.ko' % (self.RTE_TARGET, 'igb_uio')
            exe.block_run(command)
        # Bind the VF's to DPDK driver.
        for port_bdf in _vf_pci_bdfs:
            command = r'%s/usertools/dpdk-devbind.py --bind=%s %s' % (self.RTE_SDK, \
                self.dpdk_driver, port_bdf)
            exe.block_run(command)
            self._port_bdfs.append(port_bdf)

        command = r'%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
        command_output = exe.block_run(command)
        dpdk_dev_matches = re.findall(r"\w+:(\w+:\w+.\w).*drv=%s unused" % self.dpdk_driver, \
            command_output)

        for port_bdf in self._port_bdfs:
            if port_bdf not in dpdk_dev_matches:
                log.error('%s VF is not bound to %s' % (port_bdf, self.dpdk_driver))
                return False

        return test_status

    def vfio_bind_vf_bdf(self, _vf_pci_bdfs):
        test_status = True
        port_count = 1
        # Loading modules necessary for DPDK
        exe.block_run('modprobe vfio-pci')
        # Bind the VF's to the vfio-pci DPDK driver.
        for port_bdf in _vf_pci_bdfs:
            command = r'%s/usertools/dpdk-devbind.py --bind=vfio-pci %s' % (self.RTE_SDK, port_bdf)
            exe.block_run(command)
            self._port_bdfs.append(port_bdf)

        command = r'%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
        command_output = exe.block_run(command)
        dpdk_dev_matches = re.findall(r"\w+:(\w+:\w+.\w).*drv=vfio-pci unused", command_output)

        if len(dpdk_dev_matches) != len(_vf_pci_bdfs):
            log.error('All VFs are not bound to vfio-pci')
            return False

        for port_bdf in self._port_bdfs:
            if port_bdf not in dpdk_dev_matches:
                log.error('%s VF is not bound to vfio-pci' % port_bdf)
                return False

        return test_status

    def vfio_unbind_vf_bdf(self):
        for port_bdf in self._port_bdfs:
            command = '%s/usertools/dpdk-devbind.py --bind=bnxt_en %s' % (self.RTE_SDK, port_bdf)
            exe.block_run(command)

        time.sleep(2)
        # Then, make sure that the interfaces are bound to the bnxt_en driver.
        command = '%s/usertools/dpdk-devbind.py --status' % self.RTE_SDK
        command_output = exe.block_run(command)
        expr = '\w+:(\w+:\w+.\w).*if=(\w+) drv=bnxt_en unused=vfio-pci'
        vf_port_bdfs_bnxt = re.findall(expr, command_output)
        bnxt_devices = [port_bdf for port_bdf, vf_name in vf_port_bdfs_bnxt]

        for port_bdf in self._port_bdfs:
            if bnxt_devices.count(port_bdf) == 0:
                log.error('VF Device: %s could not be bound back to bnxt_en')
                return False
            else:
                log.info('VF Device: %s binded to bnxt_en successfully.' % port_bdf)

        for port_bdf, vf_name in vf_port_bdfs_bnxt:
            if port_bdf in self._port_bdfs:
                eth.get_interface(vf_name).up()

        return True

    def load_flows_from_file(self, filename, no_of_flows):
        test_status = True
        log.info('The provided batch file has %s flows. Will load all of them at once..' % \
            no_of_flows)
        command = 'load %s' % filename
        self._run_testpmd_command(command, timeout=3600)
        output = self._pexpect_testpmd_obj.before
        expr = 'Flow .* #(\d+) created'
        matches = re.findall(expr, output)
        index = 0
        log.info('Flows created are %s' % len(matches))

        if len(matches) == 0:
            log.error('The flows from the provided batch file failed to load properly...')
            return False

        for index, line in enumerate(output.splitlines()):
             if re.search(r"bnxt_hwrm_cfa_flow_alloc\(\): error", line):
                log.info('Failed flow index: %s' % index)
                break

        flow_index = index - 3
        log.info('Last correct loaded flow: %s' % flow_index)
        failures_allowed = int(no_of_flows * 0.1 / 100)
        failures_occured = int(no_of_flows - len(matches))
        log.info('Total flows loaded: %s, Failures allowed: %s, Failures occured: %s' % \
            (no_of_flows, failures_allowed, failures_occured))
        return  (True, flow_index)

    def delete_flow(self, port_num, flow_id):
        command = 'flow destroy %s rule %s ' %(port_num, flow_id)
        self._run_testpmd_command(command)
        send_command = self._pexpect_testpmd_obj.before
        output = [line.strip() for line in send_command.splitlines() if
                  line.strip() != '']
        if len(output) != 1 and output[0] == command:
            log.error(output)
            return False
        else:
            log.info(output)
            return True

    def delete_batch_flow_rules(self, port_num, start, end):
        delete_command = 'flow destroy %s ' % port_num
        for i in range(start, end):
            delete_command += ' rule %s' % i
        self._run_testpmd_command(delete_command)
        output = self._pexpect_testpmd_obj.before
        expr = '(\d+) flow rules destroyed'
        matches = re.findall(expr, output)
        if len(matches) == 0:
            log.error('The flows rules are not destroyed properly..')
            return False

        if int(matches[0]) == delete_command.count('rule'):
            log.info('All the flows rules are destroyed successfully...')
            return True
        else:
            log.error('The flows rules are not destroyed properly..')
            return False

    def delete_flows_by_list(self, port_num, flows_list, count=None):
        if count is None:
            count = len(flows_list)
        delete_command = 'flow destroy %s ' % port_num
        for i in flows_list:
            delete_command += ' rule %s' % i

        self._run_testpmd_command(delete_command)
        output = self._pexpect_testpmd_obj.before
        expr = '(\d+) flow rules destroyed'
        matches = re.findall(expr, output)
        if len(matches) == 0:
            log.error('The flows rules are not destroyed properly..')
            return False

        if int(matches[0]) == count:
            log.info('All the flows rules are destroyed successfully...')
            return True
        else:
            log.error('The flows rules are not destroyed properly..')
            return False

    def get_all_flows(self, port_num):
        command = 'flow list %s' % port_num
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = '(\d+)\s+(\d+)\s+(\d+)\s+'
        matches = re.findall(expr, output)
        return matches

    def create_decap(self, port_num, src_ip, dst_ip,
                     ip_type='ipv4',
                     src_port=1234,
                     dst_port=6161,
                     eth_src=None,
                     eth_dst=None,
                     vni=1,
                     group=None,
                     timeout=None,
                     protocol='udp',
                     meter_id=None,
                     mark_id=None):

        if eth_src is not None and eth_dst is not None:
            mac_cmd = 'eth src is %s dst is %s type is 0x800 / ' % (eth_src, eth_dst)
        else:
            mac_cmd = ''

        if protocol == 'udp':
            proto_param = ' proto is 0x11 / udp '
        else:
            proto_param = ' proto is 0x6 / tcp '

        if timeout is not None:
            aging_param = ' aging idle_timeout %s / ' % timeout
        else:
            aging_param = ''

        if mark_id is not None:
            mark_id_param = ' mark id %s / ' % mark_id
        else:
            mark_id_param = ''

        # CREATE FLOW WITH SPECIFIC GROUP...
        if group is not None:
            group_param = ' group %s ' % group
        else:
            group_param = ''

        if meter_id is not None:
            meter_param = ' meter mtr_id %s / ' % meter_id
        else:
            meter_param = ''

        if self.eem_enabled:
            count_param = 'count / '
        else:
            count_param = ''

        # Set the outer mac
        command = 'set vxlan_decap eth-src 11:11:11:11:11:19 eth-dst 22:22:22:22:22:29'
        self._run_testpmd_command(command)
        # Create decap rule on the respective flow

        command = 'flow create %s %s ingress pattern %s %s src is %s dst is %s %s dst is %s src is %s / vxlan vni is %s / end actions %s vxlan_decap / %s %s %s end' % (
            port_num, group_param, mac_cmd, ip_type, src_ip, dst_ip, proto_param, dst_port, src_port, vni, aging_param, meter_param, mark_id_param, count_param
        )

        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = 'Flow rule #(\d+) created'
        matches = re.findall(expr, output)
        if len(matches) == 0:
            return (None, False)

        return (int(matches[0]), True)

    def create_encap(self, port_num, src_ip, dst_ip,
                     ip_type='ipv4',
                     encap_src_ip='192.168.122.55',
                     encap_dst_ip='192.168.122.56',
                     src_port=1234,
                     dst_port=6161,
                     timeout=None,
                     vni=1,
                     group=None,
                     protocol='udp',
                     meter_id=None,
                     metadata=120):

        test_status = True
        if timeout is not None:
            aging_param = ' aging idle_timeout %s / ' % timeout
            metadata = 120
        else:
            aging_param = ''

        if protocol == 'udp':
            proto_param = ' proto is 0x11 / udp '
        else:
            proto_param = ' proto is 0x6 / tcp '

        # CREATE FLOW WITH SPECIFIC GROUP...
        if group is not None:
            group_param = ' group %s ' % group
        else:
            group_param = ''

        if meter_id is not None:
            meter_param = ' meter mtr_id %s / ' % meter_id
        else:
            meter_param = ''

        if metadata is not None:
            metadata_param = 'meta data is %s / any num is 1 / ' % (metadata)
        else:
            metadata_param = ''

        if vni is not None:
            vni_param = 'vxlan vni is %s /' % vni
        else:
            vni_param = ''

        if self.eem_enabled:
            count_param = 'count / '
        else:
            count_param = ''

        # Set vxlan parameters
        command = 'set vxlan ip-version ipv4 vni %s hdr-flags 8 hdr-rsvd0 2 hdr-rsvd1 4 udp-src 4 udp-dst 4 ip-src %s ip-dst %s  ip-ttl 6 eth-src 22:54:11:11:11:77 eth-dst 22:54:22:22:22:77' % (
            vni, encap_src_ip, encap_dst_ip
        )
        self._run_testpmd_command(command)

        # Create encap rule on respective flow
        command = 'flow create %s %s egress pattern %s %s src is %s dst is %s %s dst is %s src is %s / %s end actions %s vxlan_encap / %s %s end' % (
                        port_num, group_param, metadata_param, ip_type, src_ip, dst_ip, proto_param, dst_port, src_port, vni_param, aging_param, meter_param, count_param)

        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = 'Flow rule #(\d+) created'
        matches = re.findall(expr, output)
        if len(matches) == 0:
            return (None, False)

        return (int(matches[0]), True)

    def query_flows(self, rule, port_num=0, flow_id=0, type='count'):
        command = 'flow query %s %s %s' % (port_num, flow_id, type)
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = '(.*): (\d+)'
        matches = re.findall(expr, output)
        if len(matches) == 0:
            logging.error('Rule not hitting for the packets. Output is error..')
            return None

        ret_list = {keyword.strip(): int(value) for keyword, value in matches}
        return ret_list

    def get_port_info(self, port_num):
        command = 'show port info %s' % port_num
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = 'Number of (.*) (\d+)'
        matches = re.findall(expr, output)
        if len(matches) == 0:
            log.error('Could not get the port information...')
            return None

        ret_list = {keyword.strip(): int(value) for keyword, value in matches}
        return ret_list

    # METERING METHODS
    def create_meter(self, direction, port_num=0, meter_value=1, rate_value=131072):
        command = 'meter create %s %s %s' % (port_num, direction, meter_value)
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr_1 = 'RTE flow meter #(\d+) created'
        expr_2 = 'Created Meter id (\d+) with Bps (\d+),'
        matches_1 = re.findall(expr_1, output)
        matches_2 = re.findall(expr_2, output)
        if len(matches_1) == 0 or len(matches_2) == 0:
            return (None, False)

        meter_id_1 = matches_1[0]
        meter_id_2, rps = matches_2[0]
        if (int(meter_id_1) != int(meter_id_2)) or ( int(rate_value) != int(rps)):
            log.error('Failed to create meter properly...')
            return (None, False)

        log.info('Created meter sucessfully...')
        return (int(meter_id_1), True)

    def delete_meter_with_id(self, port_num, meter_id):
        command = 'meter destroy %s %s' %(port_num, meter_id)
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        output = [line.strip() for line in output.splitlines() if
                  line.strip() != '']
        if len(output) == 1 and output[0] == command:
            return True
        return False

    def query_meter_with_id(self, port_num, meter_id):
        command = 'meter query %s %s' % (port_num, meter_id)
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr_1 = 'Meter conf for (\d)+ with BPS (\d+)'
        expr_2 = 'bps: (\d+), dir: (ingress|egress)'
        matches_1 = re.findall(expr_1, output)
        matches_2 = re.findall(expr_2, output)
        if len(matches_1) == 0 or len(matches_2) == 0:
            return None, False

        meter_id_1, bps_1 = matches_1[0]
        bps_2, direction_1 = matches_2[0]
        if int(bps_1) != int(bps_2) or int(meter_id_1) != meter_id:
            log.error('Failed to query the meter properly...')
            return None, False

        log.info('Meter queried successfully..')
        return int(bps_1), True

    def update_meter_with_id(self, port_num, meter_id, new_rate):
        old_rate, status = self.query_meter_with_id(port_num, meter_id)
        if status:
            log.info('Found a valid meter with ID:%s on port:%s' % (meter_id, port_num))
            log.info('Trying to update the meter with ID:%s on port:%s to rate:%s' % (meter_id, port_num, new_rate))
            command = 'meter update %s %s %s' % (port_num, meter_id, new_rate)
            self._run_testpmd_command(command)
            output = self._pexpect_testpmd_obj.before
            if new_rate == old_rate and output.find('meter already has same rate') != -1:
                log.info('Meter is already with the same rate. Same error message printed when update is tried...')

            if new_rate != old_rate and output.find('Updated meter ID') != -1:
                log.info('Meter update command successful...')
                time.sleep(5)
                updated_rate, status = self.query_meter_with_id(port_num, meter_id)
                if status:
                    if updated_rate == new_rate:
                        log.info('Meter is updated with the new rate successfully...')
                        return True
                    else:
                        log.error('Failed to update the meter with new rate value...')
                        return False
                else:
                    log.error('Failed to query the meter after the update is done..')
                    return False
        else:
            log.info('Failed to query the meter. Update cannot be done...')
            return False

    def check_default_meter(self):
        """
        :param src_mac:
        :param dst_mac:
        :return:
        """
        if self._testpmd_started:
            self._run_testpmd_command('----')
            testpmd_output = self._pexpect_testpmd_obj.before
            #log.info("TestPMD OUTPUT is:%s" % testpmd_output)

            def_mtr_expr = r'__bnxt_mtr_create\(\): Created Meter id (\d+) '
            def_mtrs_created = re.findall(def_mtr_expr, testpmd_output)
            if len(def_mtrs_created) == 2:
                log.info('Default meters are present on both ports...')
                if testpmd_output.find('failed') != -1:
                    log.error("Error occured after launching TestPMD")
                    return False
                return True
            else:
                log.error('Failed to create default meters on both ports...')
                return False
        else:
            log.info('TestPMD is not started after Firmware upgrade')
            return False

    def start(self, src_mac=None, dst_mac=None, check_default_meter=True, fwd_mode=None, \
        file_prefix=None, port_bdfs=None):
        """
        """
        test_status = True
        # CTRL-43100: DPDK : Check hugepages before going ahead with testpmd config.
        # Attempt to allocate hugepages.
        self.configure_hugepages()

        if src_mac is not None and dst_mac is not None:
            src_dst_cmd = ' --eth-peer=0,%s --eth-peer=1,%s' % (src_mac, dst_mac)
        else:
            src_dst_cmd = ''

        fwd_mode_str = '' if fwd_mode is None else '--forward-mode=%s' % fwd_mode
        file_prefix = '' if file_prefix is None else '--file-prefix %s' % file_prefix
        bdfs = '' if port_bdfs is None else ' '.join(['-w ' + bdf for bdf in port_bdfs])
        command = '%s/app/testpmd -c %s -n %s %s %s -- -i --nb-cores=%s --nb-ports=%s' \
             ' --rxq=%s --txq=%s %s %s' % (self.RTE_TARGET, self._core_mask, \
             self._num_memory_channels, file_prefix, bdfs, self._num_cores, self._num_ports, \
             self._rxq, self._txq, src_dst_cmd, fwd_mode_str)
        # If RSS is asked to be disabled on start-up, do so.
        if self._rssstate_cli == 'disabled':
            command += ' --disable-rss'
        # Execute the command.
        log.info("Command Executed is:%s" % command)
        self._pexpect_testpmd_obj = pexpect.spawn(command)
        # Wait a while to settle things down.
        time.sleep(5)

        try:
            # testpmd application must be started within 60secnds..
            index = self._pexpect_testpmd_obj.expect([self._testpmd_prompt], timeout=60)
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # If the output is a byte stream (as in case of Python 3.X), convert it to str.
            if isinstance(self._pexpect_testpmd_obj.before, bytes):
                self._pexpect_testpmd_obj.before = self._pexpect_testpmd_obj.before.decode('utf-8')

            testpmd_output = self._pexpect_testpmd_obj.before
            log.info(testpmd_output)

            if index == 0:
                log.info('Launched testpmd application successfully.')
                self._testpmd_started = True
                self.clear_port_stats()

                if check_default_meter:
                    def_mtr_expr = r'__bnxt_mtr_create\(\): Created Meter id (\d+) '
                    def_mtrs_created = re.findall(def_mtr_expr, testpmd_output)

                    if len(def_mtrs_created) == 2:
                        log.info('Created default meters on both ports successfully.')
                        return True
                    else:
                        log.error('Failed to create default meters on both ports.')
                        return False
            elif index == 1:
                log.info('Failed to launch testpmd application.')
                return False
        except Exception as e:
            log.error(e)
            return False

        return test_status

    def enable_metadata_encap(self, meta_vlan=120):
        commands =['set fwd mac',
                   'port stop all',
                   'port config all hw-vlan-filter on',
                   'port config all hw-vlan on',
                   'port start all',
                   'rx_vlan add %s 0' % meta_vlan,
                   'rx_vlan add %s 1' % meta_vlan,
                   'port stop all',
                   'tx_vlan set 0 %s' % meta_vlan,
                   'tx_vlan set 1 %s' % meta_vlan,
                   'port start all',
                   'start']
        for command in commands:
            self._run_testpmd_command(command)
        return True

    def set_max_pkt_len(self, mtu=9000):
        commands = ['port stop all',
                    'port config all max-pkt-len %s' % mtu,
                    'port start all']
        for command in commands:
            self._run_testpmd_command(command)
        return True

    def start_packet_forwarding(self):
        """
        """
        # Start packet forwarding.
        command = 'start'
        return self._run_testpmd_command(command)

    def stop_packet_forwarding(self):
        """
        """
        # Stop packet forwarding.
        command = 'stop'
        return self._run_testpmd_command(command)

    def set_cso(self, port_num):
        """
        """
        # Set the IO forwarding mode to csum.
        command = 'set fwd csum'
        self._run_testpmd_command(command)
        # CTRL-40577: custom gre test suite: Command to enable checksum "csum parse_tunnel" fails.
        # Stop packet forwarding and the port before configuring CSO. Also use the correct command
        # name.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port_num)
        self._run_testpmd_command(command)
        commands = ['parse_tunnel', 'parse-tunnel']
        # First try "parse_tunnel", which is more common. If that fails, try "parse-tunnel".
        for command in commands:
            if self._run_testpmd_command('csum ' + command + ' on ' + str(port_num), \
                'Bad arguments', 3) is False:
                break
        # Enable/disable CSO for the specified protocol as requested.
        command = 'csum set outer-ip hw ' + str(port_num)
        self._run_testpmd_command(command)
        command = 'csum set ip hw ' + str(port_num)
        self._run_testpmd_command(command)
        # Start packet forwarding and the port after configuring CSO.
        command = 'port start %s' % str(port_num)
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def set_tso(self, port_num,  pkt_size):
        # CTRL-43021: THOR B0: DPDK: Warnings seen while configuring tso segment size.
        # CTRL-43891: DPDK: port needs to be stopped before setting the TSO size.
        # Stop/start packet forwarding and the port before/after configuring TSO.
        self.stop_packet_forwarding()
        command = 'port stop %s' % str(port_num)
        self._run_testpmd_command(command)
        command = 'tunnel_tso set %s %s' %(pkt_size, port_num)
        self._run_testpmd_command(command)
        command = 'port start %s' % str(port_num)
        self._run_testpmd_command(command)
        self.start_packet_forwarding()

    def get_stats(self):
        """
        """
        # Do the necessary initializations.
        lines = []
        line = ''
        stats = {}
        self.statistics = {}
        header = None
        # Stop the packet forwarding first.
        command = 'stop'
        self._run_testpmd_command(command)
        lines = self.testpmd_output.splitlines()
        for line in lines:
            # testpmd uses two different line separaters, identify
            # and remember each.
            if '--' in line:
                delimiter = '-'
            elif '++' in line:
                delimiter = '+'
            else:
                delimiter = None
            # If a delimiter is identified, extract the key (header)
            # for the stats.
            # Eg: 'Accumulated forward statistics for all'
            if delimiter is not None:
                if header is not None:
                    self.statistics[header] = stats
                    stats = {}

                header = re.search('[' + delimiter + ']*\s(.*)\s[' + delimiter +']*', line)

                if header != None:
                    header = header.group(1)
                    self.statistics[header] = None
            # If not, extract the actual stats information.
            # Eg: 'RX-dropped': '0'
            else:
                items = re.findall('([A-Za-z0-9\-]*:\s[0-9]+)', line)
                # Add the stats as a dictionary under the last header identified.
                for item in items:
                    stats[item.split(': ')[0]] = item.split(': ')[1]
        command = 'start'
        self._run_testpmd_command(command)
        # Return the stats dictionary.
        return self.statistics

    def get_port_counters(self, statistics, csum_type, port):
        """
        """
        csum_count = statistics['Forward statistics for port ' + port + ' '][csum_type]
        return csum_count

    def get_portInfo(self,validate_params,expected_value):
        """
        """
        # Stop the packet forwarding first.
        self.stop_packet_forwarding()
        # Issue show port info on all the ports.
        for port in range(int(self._num_ports)):
            # Issue port info to check Rx queue value to be 80 for all ports.
            command = 'show port info ' + str(port)
            test_status = self._run_testpmd_command(command, validate_params \
                                                    + str(expected_value))
            if test_status is False:
                log.info('Rx queue value is not set to %s for %s' % (str(expected_value), str(port)))
                break
            else:
                log.info('Rx queue value is set to %s as expected for port %s' % (str(expected_value), str(port)))
        return test_status

    def clear_port_stats(self):
        """
        """
        # Start packet forwarding.
        command = 'clear port stats all'
        return self._run_testpmd_command(command)

    def get_port_stop_stats(self, port_num='all'):
        command = 'stop'
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        self.start_packet_forwarding()
        port_indices = [m.start() for m in re.finditer('Forward statistics for port', output)]
        accu_index = output.find('Accumulated forward statistics for all ports')
        port_indices = port_indices + [accu_index]
        ret_dict = {}
        for i in range(len(port_indices) - 1):
            start_ind = port_indices[i]
            stop_ind = port_indices[i + 1]
            stat_output = output[start_ind: stop_ind]
            stat_matches = re.findall('(\w+-\w+):\s+(\d+)', stat_output)
            ret_dict[i] = {key.strip(): int(value) for key, value in stat_matches}
        return ret_dict

    def get_port_stats(self):
        """
        Get statistics of the ports.

        Return:
            port_stats: The dictionary containing the statistics of the ports.
                Example: {0: {'RX-packets': 1000},
                          1: {'RX-bytes: 6000'}}
        """
        # CTRL-42208: Exception caught with port xstats command in GRE tunnel migration testcases.
        # Use the correct command (show port stats). Also fix the regex.
        command = 'show port stats all'
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        stat_matches = re.findall('([\w]+-[\w]+):[\s]+([\d]+)', output)
        port_matches = re.findall('NIC statistics for port (\d+)', output)
        index = 0
        port_stats = {}
        no_of_ports = len(port_matches)

        for port_num in port_matches:
            port_vals = stat_matches[index: index + (len(stat_matches) / no_of_ports)]
            index = index + (len(stat_matches) / no_of_ports)
            port_stats[int(port_num)] = {key.strip(): int(value) for key, value in port_vals}

        return port_stats

    def get_port_xstats(self, direction=None):
        if direction == 'both':
            dir = ''
        else:
            dir = direction
        #CNTL-51440: changed tthe expr to support both 19_11 and 20_11 dpdk versions
        #expr = '(%s.*q\d+packets.*): (\d+)' % dir
        expr = '(%s.*q\d+.*packets.*): (\d+)' % dir
        command = 'show port xstats all'
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        stat_matches = re.findall(expr, output)
        port_matches = re.findall('NIC extended statistics for port (\d+)', output)
        index = 0
        ret_dict = {}
        no_of_ports = len(port_matches)
        for port_num in port_matches:
            port_vals = stat_matches[index: index + (len(stat_matches) / no_of_ports)]
            index = index + (len(stat_matches) / no_of_ports)
            ret_dict[int(port_num)] = {key.strip(): int(value) for key, value in port_vals if int(value) > 50}
        return ret_dict

    def run_testpmd_command(self, command, timeout=30, output_to_file=None):
        test_status = self._run_testpmd_command(command, timeout=timeout)
        if test_status is True:
            if output_to_file is None:
                return self._pexpect_testpmd_obj.before
            log.info('Creating output file %s' % output_to_file)
            with open(output_to_file, 'w') as fileobj:
                fileobj.write(self._pexpect_testpmd_obj.before)
            return True
        else:
            return None

    def _run_testpmd_command(self, command, expected_output=None, timeout=30):
        """
        """
        # Do the necessary initializations.
        test_status = True
        self.testpmd_output = None
        self._pexpect_testpmd_obj.sendline(command)
        # If anything is expected in the output, look for it.
        if expected_output is not None and \
            self._pexpect_testpmd_obj.expect([expected_output, pexpect.TIMEOUT], \
            timeout=timeout) != 0:
                test_status = False
        self._pexpect_testpmd_obj.expect(self._testpmd_prompt, timeout=timeout)
        # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
        # If the output is a byte stream (as in case of Python 3.X), convert it to str.
        if isinstance(self._pexpect_testpmd_obj.before, bytes):
            self._pexpect_testpmd_obj.before = self._pexpect_testpmd_obj.before.decode('utf-8')

        self.testpmd_output = self._pexpect_testpmd_obj.before.strip()
        log.info('testpmd> %s' % self.testpmd_output)
        return test_status

    def quit_testpmd(self):
        # Do the necessary initializations.
        if self._testpmd_started:
            self.testpmd_output = None
            command = 'quit'
            self._pexpect_testpmd_obj.sendline(command)
            self._pexpect_testpmd_obj.expect('Bye')
            # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
            # If the output is a byte stream (as in case of Python 3.X), convert it to str.
            if isinstance(self._pexpect_testpmd_obj.before, bytes):
                self._pexpect_testpmd_obj.before = self._pexpect_testpmd_obj.before.decode('utf-8')

            quit_log = self._pexpect_testpmd_obj.before
            log.info('testpmd> %s' % quit_log)
            while self._pexpect_testpmd_obj.isalive() == True:
                time.sleep(0.1)
            self._pexpect_testpmd_obj.close()
        return True

    def kill_testpmd(self):
        killed = False
        processes = exe.block_run('ps -eaf| grep testpmd', shell=True)
        expr = '(\w+)\s+(\d+)\s+(\d+)(.*)'
        matches = re.findall(expr, processes)

        if len(matches) == 0:
            log.error('Testpmd application is not found.')
        else:
            for user, pid, parent_pid, desc in matches:
                if desc.find(self.RTE_TARGET) != -1:
                    log.info('Testpmp application process ID is: %s' % int(pid))
                    exe.block_run('kill -9 %s' % int(pid))
                    time.sleep(2)
                    killed = True

        return killed

    def start_tshark(self, iface_name, src_ip=None, dst_ip=None, count=None, timeout=120, field_list=[]):
        if src_ip is None or dst_ip is None:
            ip_flag = ''
        else:
            ip_flag = ' -n "src net %s and dst net %s" ' % (src_ip, dst_ip)

        if count is not None:
            count_flag = '-c %s' % count
        else:
            count_flag = ''

        _tempdir = tempfile.mkdtemp()
        self._tcpdump_file = os.path.join(_tempdir, 'capture.pcap')
        log.info(self._tcpdump_file)

        tshark_command = r'tcpdump -i %s %s %s -w %s' % (iface_name, ip_flag, count_flag, self._tcpdump_file)
        self._tshark_mod = exe.run(tshark_command, shell=True)
        if self._tshark_mod.poll() is None:
            log.info('tshark started successfully..')
            return True
        else:
            log.error('Failed to start tshark...')
            return False

    def get_tshark_packets(self):
        exe.block_run('ps -eaf | grep tcpdump', shell=True)

        try:
            time.sleep(1)
            exe.run('kill %s' % self._tshark_mod.proc.pid)
        except:
            pass

        time.sleep(2)
        output = self._tshark_mod.get_output()
        expr = '(\d+) (packets*\s+captured)'
        match = re.search(expr, output)
        # CTRL-44424: GRE: few spl flag tests fails with error "invalid literal for int()".
        # On some setups, "tcpdump" is observed to _not_ print "0 packets captured" when no packets
        # are captured. In such cases, return an empty list instead of None.
        if match is None:
            return []

        no_pkts_captured = int(match.group(1))
        pcap = pyshark.FileCapture(self._tcpdump_file)
        pcap.load_packets()

        if len(pcap._packets) != no_pkts_captured:
            return []

        ret_packets = []

        for pkt in pcap._packets:
            ret_val = {}
            ret_val['eth.src'] = str(pkt.eth.src)
            ret_val['eth.dst'] = str(pkt.eth.dst)
            ret_val['ip.src'] = str(pkt.ip.src)
            ret_val['ip.dst'] = str(pkt.ip.dst)
            ret_val['length'] = int(pkt.length)
            layers = [layer.layer_name for layer in pkt.layers]

            if layers.count('udp') == 1:
                ret_val['udp.srcport'] = str(pkt.udp.srcport)
                ret_val['udp.dstport'] = str(pkt.udp.dstport)
                ret_val['tcp.srcport'] = None
                ret_val['tcp.dstport'] = None
                ret_val['udp.length'] = str(pkt.udp.len)
            elif layers.count('tcp') == 1:
                ret_val['tcp.srcport'] = str(pkt.tcp.srcport)
                ret_val['tcp.dstport'] = str(pkt.tcp.dstport)
                ret_val['udp.srcport'] = None
                ret_val['udp.dstport'] = None
                ret_val['tcp.length'] = str(pkt.tcp.len)
            # CTRL-42957: Tencent DPDK test cases.
            # Extract all the necessary GRE packet details.
            if layers.count('gre') == 1:
                log.info(pkt.gre.pretty_print())
                # CTRL-44424: GRE: few spl flag tests fails with error "invalid literal for int()".
                # If any field is displayed in hexadecimal notation, do the necessary conversion.
                ret_val['gre.flags_and_version'] = str(int(pkt.gre.flags_and_version, 16)) if \
                    '0x' in pkt.gre.flags_and_version else str(pkt.gre.flags_and_version)
                ret_val['gre.flags_recursion_control'] = str(int(pkt.gre.flags_recursion_control, \
                    16)) if '0x' in pkt.gre.flags_recursion_control else \
                    str(pkt.gre.flags_recursion_control)
                ret_val['gre.flags_routing'] = str(int(pkt.gre.flags_routing, 16)) if \
                    '0x' in pkt.gre.flags_routing else str(pkt.gre.flags_routing)
                ret_val['gre.flags_strict_source_route'] = \
                    str(int(pkt.gre.flags_strict_source_route, 16)) if \
                    '0x' in pkt.gre.flags_strict_source_route else \
                    str(pkt.gre.flags_strict_source_route)
                ret_val['gre.proto'] = str(int(pkt.gre.proto, 16)) if '0x' in pkt.gre.proto else \
                    str(pkt.gre.proto)

            ret_packets.append(ret_val)

        return ret_packets

    def start_scapy(self):
        test_status = True
        command = 'scapy'
        self._pexpect_scapy_obj = pexpect.spawn(os.environ['SHELL'])
        self._pexpect_scapy_obj.sendline("unset PROMPT_COMMAND")
        self.PROMPT_SET_SH = r"PS1='[PEXPECT]\$ '"
        self.PROMPT_SET_CSH = r"set prompt='[PEXPECT]\$ '"
        self._shell_prompt = r"\[PEXPECT\][\$\#] "
        self._pexpect_scapy_obj.sendline(self.PROMPT_SET_SH)  # sh-style
        i = self._pexpect_scapy_obj.expect([pexpect.TIMEOUT, self._shell_prompt], timeout=10)
        if i == 0:  # csh-style
            self._pexpect_scapy_obj.sendline(self.PROMPT_SET_CSH)
            i = self._pexpect_scapy_obj.expect([pexpect.TIMEOUT, self._shell_prompt], timeout=10)
            if i == 0:
                log.error('Failed to launch shell for testpmd application')
                test_status = False
                return

        self._pexpect_scapy_obj.logfile = sys.stdout
        self._pexpect_scapy_obj.sendline(command)
        # Wait a while to settle things down.
        time.sleep(2)
        try:
            index = self._pexpect_scapy_obj.expect([self._scapy_prompt, self._shell_prompt])
            if index == 0:
                log.info('Launched scapy application successfully...')
            elif index == 1:
                log.info('Failed to launch scapy application...')
                test_status = False
        except Exception as e:
            log.error(e)
            test_status = False

        return test_status

    def stop_scapy(self):
        # Do the necessary initializations.
        test_status = True
        self._pexpect_scapy_obj.send('\003')
        self._pexpect_scapy_obj.expect(self._scapy_prompt)
        command = 'exit()'
        self._pexpect_scapy_obj.logfile = None
        self._pexpect_scapy_obj.sendline(command)
        self._pexpect_scapy_obj.expect(self._shell_prompt)
        return test_status

    def _run_sendp(self, command, wait=True):
        # Do the necessary initializations.
        test_status = False
        self._pexpect_scapy_obj.sendline(command)
        # CTRL-42187: All VXLAN RSS tests fails, same tests works fine manually.
        # Newer versions of scapy are observed to return the prompt ('>>> ') twice after receiving
        # each newline. This behavior results in the wrong assumption that the command issues is
        # completed, while it might still be running. So, expect and discard the extra prompt
        # immediately.
        try:
            self._pexpect_scapy_obj.expect(self._scapy_prompt, timeout=0)
            test_status = True
        except Exception:
            pass

        if wait:
            try:
                self._pexpect_scapy_obj.expect(self._scapy_prompt, timeout=60)
                test_status = True
            except Exception:
                pass

        return test_status

    def query_tunnel_cfg(self, iface):
        tunnelport = ''
        command = 'bnxtnvm  -dev=' + iface + ' cfgtunnel vxlan_ipv4 '
        command_output = exe.block_run(command)
        for each_line in command_output.split('\n'):
            if ":" not in each_line:
                continue
            tunnelport = each_line.split(":")[1]
        return tunnelport

    def set_tunnel_port(self, iface, tunnelport):
        test_status = True
        if tunnelport is None:
            tunnelport = ''
        command = 'bnxtnvm  -dev=' + iface + ' cfgtunnel vxlan_ipv4 dst_port ' + tunnelport
        command_output = exe.block_run(command)
        test_status = False
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                test_status = True
                continue
        return test_status

    def free_tunnel_port(self, iface):
        command = 'bnxtnvm  -dev=' + iface + ' cfgtunnel vxlan_ipv4 dst_port '
        command_output = exe.block_run(command)
        test_status = False
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                test_status = True
                continue
        return test_status

    def add_tunnel_redirect(self, iface, tunneltype, vf_index):
        command = 'bnxtnvm -dev=%s add_tunnel_redirect %s vf %s' % (iface, tunneltype, vf_index)
        command_output = exe.block_run(command)
        if command_output.find('Command Executed Successfully') != -1:
            return True
        return False

    def del_tunnel_redirect(self, iface, tunneltype, vf_index):
        command = 'bnxtnvm -dev=%s del_tunnel_redirect %s vf %s' %(iface, tunneltype, vf_index)
        command_output = exe.block_run(command)
        if command_output.find('Command Executed Successfully') != -1:
            return True
        return False

    def query_tunnel_redirect(self, iface, tunneltype):
        command = 'bnxtnvm -dev=%s query_tunnel_redirect type %s vf' %(iface, tunneltype)
        # CTRL-42209: Query tunnel redirection for GRE fails with exception.
        # Newer bnxtnvm's return non-zero exit code on failure as opposed to the older ones, which
        # returned zero. This new behavior results in exe exception. Handle it.
        try:
            command_output = exe.block_run(command)
        except exception.ExeExitcodeException as e:
            command_output = e.output
        # CTRL-40847: DPDK: "Query Tunnel redirection" test is not configuring any tunnel
        # re-directions.
        # Translate all relevant bnxtnvm returned error messages to what is expected by the
        # consumer scripts.
        if 'VF Index: 65535' in command_output:
            command_output = 'Error: Tunnel Redirection not configured'

        return command_output

    def add_tunnel_redirect_using_testpmd(self, iface, tunneltype, index):
        command = 'flow create %s ingress pattern any num is 3 / gre / end actions vf id 0 / end' % index
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = 'Flow rule #(\d+) created'
        match = re.search(expr, output)
        if match is None:
            return (None, False)
        else:
            return (int(match.group(1)), True)

    def del_tunnel_redirect_using_testpmd(self, iface, tunneltype, index, rule):
        command = 'flow destroy %s rule %s' %(index, rule)
        self._run_testpmd_command(command)
        output = self._pexpect_testpmd_obj.before
        expr = 'Flow rule #(\d+) destroyed'
        match = re.search(expr, output)
        return False if match is None else True

    def query_rss_hash_mode(self, iface):
        test_status = True
        rss_mode = ''
        command = 'bnxtnvm  -dev=%s cfgtunnel rss_mode' % iface
        command_output = exe.block_run(command)
        expr = 'RSS Hashing Mode : (\w+)'
        matches = re.findall(expr, command_output)
        if len(matches) == 1:
            return matches[0]
        else:
            log.error('Could not query the RSS hash mode..')
            return None

    def set_rss_hash_mode(self, iface, rss_mode):
        test_status = True
        command = 'bnxtnvm  -dev=%s cfgtunnel rss_mode %s' %(iface, rss_mode)
        log.info(command)
        command_output = exe.block_run(command)
        test_status = False
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                test_status = True
                continue
        return test_status

    def set_rss(self, rss_state):
        """
        Turn RSS on/off on all the ports.

        Args:
            rss_state: The action to take: True - On; False - Off.
        """
        # Turn RSS on/off as requested.
        command = 'port config all rss ' + \
            ('all' if rss_state is True else 'none')
        return self._run_testpmd_command(command)

class TestPMDHost(UparTestPMDController):
    def __init__(self, **kwargs):
        super(TestPMDHost, self).__init__(**kwargs)


