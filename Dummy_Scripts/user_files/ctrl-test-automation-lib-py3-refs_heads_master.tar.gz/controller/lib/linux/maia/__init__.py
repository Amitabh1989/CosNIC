import logging
import controller.lib.common.shell.exe
from . import eth.ip
import controller.lib.linux.eth.tunnel
import controller.lib.linux.driver
import controller.lib.linux.eth.ethtool

exe = controller.lib.common.shell.exe
ip = eth.ip
tunnel = controller.lib.linux.eth.tunnel
driver = controller.lib.linux.driver
ethtool = controller.lib.linux.eth.ethtool


def override_block_run(conn, exe_mod):
    def block_run(command, **kwargs):
        output = conn.exec_command(command)
        output = '\n'.join(output)
        return output

    if not hasattr(exe_mod, 'block_run_old_ref'):
        exe_mod.block_run_old_ref = exe_mod.block_run
        exe_mod.block_run = block_run


def revert_block_run(exe_mod):
    if hasattr(exe_mod, 'block_run_old_ref'):
        exe_mod.block_run = exe_mod.block_run_old_ref
        del exe_mod.block_run_old_ref
    else:
        logging.warning("Nothing to be reverted")
