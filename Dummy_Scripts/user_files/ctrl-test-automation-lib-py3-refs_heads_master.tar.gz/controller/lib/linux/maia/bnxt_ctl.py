"""
:mod:`bnxt_ctl` -- BNXT tool
========================================
.. module_author:: Surender Khetavath <surender.khetavath@broadcom.com>

This module before initializing needs ssh object. 
>>> from controller.lib.core import ssh
>>> ssh_obj = ssh.SSHHandler(<ip>, 'username', 'password')

Once the ssh object is available this module can be initialized
>>> from controller.lib.linux.maia.bnxt_ctl import BNXTTool
>>> tool = BNXTTool(ssh_obj)
"""


import logging
from collections import defaultdict
import re

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = logging.getLogger(__name__)


class BNXTTool(object):
    """
    Wrapper class for bnxt-ctl executable
    """

    def __init__(self, conn):
        self.bnxt_ctl = 'bnxt-ctl'
        self.rep_pci_ids = defaultdict(list)
        self._rep_port = None
        self.conn = conn

    def add_rep_pair(self, rep_port, pfs, vfs, host=1, bus='06', delete_existing=True):
        """
        Adds a representator pair. Analogous to below command
        ex: bnxt-ctl add-rep2fn-pair enP8p1s0f2np0 \
                0000:06:00.$pci_function host 1 pf $pf vf $vf

        Args:
            rep_port (str/list): Representator port name
            pfs (list): list of host(x86) pfs to use while creating rep_pairs
            vfs (int): No: of Virtual functions per PF
            host (int): 1 => x86 0 => maia
            bus (str): pci bus for newly creating pair
            delete_existing (bool): Deletes the existing pairs if true
        """

        if delete_existing:
            self.del_rep_pair()
        self._rep_port = [rep_port]
        pci_ids = defaultdict(list)
        log.info('Adding representator pairs')
        for port in self._rep_port:
            for pf in pfs:
                if vfs > 0:
                    for vf_num in range(vfs):
                        rep_bus_base = '0000:%s:00.%s' % (bus, vf_num % 8)
                        cmd = '%s add-rep2fn-pair %s %s host %s pf %s vf %s' % (self.bnxt_ctl,
                                                                                port,
                                                                                rep_bus_base,
                                                                                host,
                                                                                pf, vf_num)

                        log.info("Adding pair with command: %s" % cmd)
                        output = self.conn.exec_command(cmd)
                        if int(self.conn.ret_code) == 0:
                            self.rep_pci_ids[port].append(rep_bus_base)
                            pci_ids[port].append(rep_bus_base)
                        else:
                            log.error("FAIL: Add pair failed.")
                            return False
                else:
                    rep_bus_base = '0000:%s:00.%s' % (bus, pf % 8)
                    cmd = '%s add-rep2fn-pair %s %s host %s pf %s ' % (self.bnxt_ctl,
                                                                            port,
                                                                            rep_bus_base,
                                                                            host,
                                                                            pf)

                    log.info("Adding pair with command: %s" % cmd)
                    output = self.conn.exec_command(cmd, check_exit=False)
                    log.info("Adding pair with command: %s and output is %s" % (cmd, output))
                    if int(self.conn.ret_code) == 0 and 'exist' not in ' '.join(output):
                        self.rep_pci_ids[port].append(rep_bus_base)
                        pci_ids[port].append(rep_bus_base)
                    else:
                        log.error("FAIL: Add pair failed.")
                        return False

        log.info("REP_PCI_IDS = %s" % pci_ids)
        return pci_ids

    def del_rep_pair(self):
        """
        Deletes the representator pairs.
        Uses the pci_ids of the pairs are stored in self.rep_pci_ids dict
        while adding new pairs

        ex: bnxt-ctl del-pair enP8p1s0f2np0 0000:06:00.0

        Args: None
        """
        output = None
        if not self.rep_pci_ids:
            return output

        for key, values in list(self.rep_pci_ids.items()):
            for value in values:
                cmd = '%s del-pair %s %s' % (self.bnxt_ctl, key, value)
                output = self.conn.exec_command(cmd, check_exit=False)
        return output

    def add_pf_pair(self, maia_pf, name, host_pf, host=1, **kwargs):
        """
        """
        arg_str = ' '.join(' '+key+' '+value for key, value in list(kwargs.items()))
        cmd = '%s add-pf-pair %s %s host %s pf %s' % (self.bnxt_ctl,
                                              maia_pf,
                                              name,
                                              host,
                                              host_pf) + arg_str
        output = self.conn.exec_command(cmd)
        return output

    def delete_pair(self, port, name):
        """
        """
        cmd = '%s del-pair %s %s' % (self.bnxt_ctl, port, name)
        output = self.conn.exec_command(cmd)
        return output

    def add_tunnel_redirect(self, intf, tunnel_type='vxlan', dst_port=250):
        config_cmd = '%s cfg-tunnel control %s vxlan_ipv4 dst_port %s' % (self.bnxt_ctl, intf, dst_port)
        tr_cmd = '%s add-tunnel-redirect %s vxlan' % (self.bnxt_ctl, intf)
        if tunnel_type == 'gre':
            config_cmd = '%s cfg-tunnel control %s ipgre_v1 dst_port %s' % (self.bnxt_ctl, intf, dst_port)
            tr_cmd = '%s add-tunnel-redirect %s ipgre_v1' % (self.bnxt_ctl, intf)
        output = self.conn.exec_command(config_cmd, check_exit=False)
        output = self.conn.exec_command(tr_cmd)
        return output

    def delete_tunnel_redirect(self, intf, tunnel_type='vxlan'):
        config_cmd = '%s cfg-tunnel control %s vxlan_ipv4 dst_port ' % (self.bnxt_ctl, intf)
        tr_cmd = '%s del-tunnel-redirect %s vxlan' % (self.bnxt_ctl, intf)
        if tunnel_type == 'gre':
            config_cmd = '%s cfg-tunnel control %s ipgre_v1 dst_port' % (self.bnxt_ctl, intf)
            tr_cmd = '%s del-tunnel-redirect %s ipgre_v1' % (self.bnxt_ctl, intf)
        output = self.conn.exec_command(config_cmd, check_exit=False)
        output = self.conn.exec_command(tr_cmd)
        return output

    def get_pf_pairs(self, port='', pair_name=''):
        """
        :param port:
        :param pair_name:
        :return:
        """
        pairs = []
        cmd = '%s show-pair %s %s | grep -i interface' % (self.bnxt_ctl, port, pair_name)
        output = self.conn.exec_command(cmd, timeout=5, check_exit=False)
        logging.info('PF pairs are : %s' % output)
        for line in output:
            if 'interface' in line and 'state' in line:
                interface = re.search('(?<=interface:)\s*([^\s]*)', line).group(1)
                name = re.search('(?<=name:)\s*([^\s]*)', line).group(1)
                state = re.search('(?<=state:)\s*([^\s]*)', line).group(1)
                cmd = '%s show-pair %s | grep -i member\(' % (self.bnxt_ctl, interface)
                iface_output = self.conn.exec_command(cmd)
                pf_indices = []
                for ln in iface_output:
                    if 'Linux PF index' in ln:
                        pf_indices.append(re.search('(?<=Linux PF index)\s*([^\s]*)', ln).group(1))
                pairs.append({
                        'interface': interface,
                        'name': name,
                        'state': state,
                        'pf_indices': pf_indices
                    })
        return pairs

    def show_pairs(self, port=str()):
        """

        :param port:
        :return:
        """
        cmd = '%s show-pair %s' % (self.bnxt_ctl, port)
        output = self.conn.exec_command(cmd)
        return output