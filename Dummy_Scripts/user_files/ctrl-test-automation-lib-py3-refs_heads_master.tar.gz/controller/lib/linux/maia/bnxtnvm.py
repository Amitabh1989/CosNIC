"""
:mod:`lcdiag` -- The test script template
===========================================

.. module:: controller.lib.linux.maia.bnxtnvm
.. moduleauthor:: Surendra narala

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

from controller.lib.core import log_handler
from controller.lib.linux.system import bnxtnvm as basebnxtnvm
from controller.lib.linux.maia import exe

log = log_handler.get_logger(__name__)


class Bnxtnvm(basebnxtnvm.BaseBnxtnvm):
    def __init__(self, iface=None):
        """
        Args:
             mac_addr (str): MAC address. Recommended to support cross-platform
                better.
             iface (str): ethX name.

        """
        self._iface = iface
        self._prg_path = 'bnxtnvm'
        # self.__exe is private variable in BaseBnxtnvm, so could it is used with name as _BaseBnxtnvm__exe
        self._BaseBnxtnvm__exe = exe

    def run(self, *args, **kwargs):
        """Run bnxtnvm using given keyword arguments.

        key = option, value=value. If value is None, no value is passed. For
        example,

        run(view=None) will run "bnxtnvm run" and
        run(view='file.pkg') will run "bnxtnvm run=file.pkg"

        Return:
            str: output of bnxtnvm

        """
        option_list = ['-dev=%s' % self._iface]

        for arg in args:
            option_list.append(arg)

        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + '=' + value)

        cmd = ' '.join([self._prg_path] + option_list)
        try:
            output = exe.block_run(cmd)
        except Exception as err:
            output = str(err)
        return output