"""
:mod:`ctl` -- OVS Command Line Utility
========================================

.. moduleauthor:: Surender Khetavath <surender.khetavath@broadcom.com>

This module exposes interfaces for the OVS tools like ovs-vsctl, 
ovs-ofctl, ovs-appctl etc. 

This module before initializing needs ssh object. 
>>> from controller.lib.core import ssh
>>> ssh_obj = ssh.SSHHandler(<ip>, 'username', 'password')

Once the ssh object is available this module can be initialized
>>> from controller.lib.linux.maia.ctl import Vsctl
>>> vsctl = Vsctl('br0', ssh_obj)

"""
import json
import logging
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2019 Broadcom Inc"

log = logging.getLogger(__name__)


class BaseCTL(object):

    def __init__(self, br_iface, conn_obj):
        self.br_iface = br_iface
        self.conn = conn_obj


class Vsctl(BaseCTL):
    tool = 'ovs-vsctl'

    def __init__(self, br_iface, conn):
        """
        """ 
        super(Vsctl, self).__init__(br_iface, conn)
 
    def set(self, opts='', tbl='Open_vSwitch', rec='.',
            key=None, value=None):
        """
        Syntax: set TBL REC COL[:KEY]=VALUE
        Example: set Open_vSwitch . other_config:pmd-cpu-mask=0xfe
        """
        _opts = opts if isinstance(opts, list) else [opts]
        _opts = ' '.join(x for x in _opts)

        cmd = '%s %s set %s %s %s' % (self.tool, _opts, tbl, rec,
                                      '%s=%s' % (key, value))
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def add_br(self, **kwargs):
        options = ''
        cmd = '%s %s %s' % (self.tool, 'add-br', self.br_iface)

        if kwargs:
            options += ' '.join(key+'='+value for key, value in list(kwargs.items()) if key != 'extra')
            cmd += ' -- set bridge %s %s' % (self.br_iface, options)
        cmd += ' -- ' + kwargs['extra']
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def del_br(self):
        cmd = '%s del-br %s' % (self.tool, self.br_iface)
        log.info("Running command: %s" % cmd)
        self.conn.exec_command(cmd, check_exit=False)

    def add_port(self, port_obj):
        """
        Adds the port to bridge defined by port object. 

        Args:  port object
               Port class defined in controller.lib.linux.maia.ovs/Port
        """
        options = ''
        cmd = '%s add-port %s %s' % (self.tool, self.br_iface, port_obj.port_name)
        options += ' '.join(key+'='+str(value) for key, value in list(port_obj.desc.items()))
        cmd += ' -- set Interface %s %s' % (port_obj.port_name, options)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output
 
    def del_port(self, port_name):
        cmd = '%s del-port %s %s' % (self.tool, self.br_iface, port_name)
        log.info("Running command: %s" % cmd)
        self.conn.exec_command(cmd, check_exit=False)

    def get_port_names(self):
        cmd = '%s list-ports %s' % (self.tool, self.br_iface)
        output = self.conn.exec_command(cmd, check_exit=False)
        return output

    def add_bond(self, bond_obj):
        """
        Adds the port to bridge defined by port object.

        Args:  port object
               Port class defined in controller.lib.linux.maia.ovs/Port
        """
        slaves = ' '.join([slave.port_name for slave in bond_obj.slaves])
        cmd_options = ' '.join(['='.join([opt, str(val)]) for opt, val in list(bond_obj.desc.items()) if val is not None])
        cmd = '%s add-bond %s %s %s %s' % (self.tool,
                                           self.br_iface,
                                           bond_obj.name,
                                           slaves,
                                           cmd_options)

        for slave in bond_obj.slaves:
            slave.desc.pop('ofport_request', None)
            options = ' '.join(key+'='+str(value) for key, value in list(slave.desc.items()))
            cmd += ' -- set Interface %s %s ' % (slave.port_name, options)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def get_interface_names(self):
        cmd = '{} --columns=name --format=table --no-heading list interface'.format(self.tool)
        output = self.conn.exec_command(cmd, check_exit=False)
        return output


class Appctl(BaseCTL):
    tool = 'ovs-appctl'

    def __init__(self, br_iface, conn):
        super(Appctl, self).__init__(br_iface, conn)

    def detach_port(self, pci_id):
        cmd = '{} netdev-dpdk/detach {}'.format(self.tool, pci_id)
        log.info('Running command: {}'.format(cmd))
        self.conn.exec_command(cmd, check_exit=False)


class Ofctl(BaseCTL):

    tool = 'ovs-ofctl'

    def __init__(self, br_iface, conn):
        super(Ofctl, self).__init__(br_iface, conn)

    def add_flow(self, br_name, *args, **kwargs):
        cmd = 'ovs-ofctl add-flow {} '.format(br_name)
        options = []
        if args:
            options = [x for x in args]
        if kwargs:
            options += [key + '=' + value for key, value in list(kwargs.items())]
        for item in options:
            if 'action' in item:
                _item = options.pop(options.index(item))
                options.append(_item)
                break
        cmd += ' ' + ','.join(options)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def add_flows(self, file_path):
        cmd = '%s add-flows %s %s' % (self.tool, self.br_iface, file_path)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def del_flows(self):
        cmd = '%s del-flows %s' % (self.tool, self.br_iface)
        log.info("Running command: %s" % cmd)
        self.conn.exec_command(cmd, check_exit=False)

    def del_flow(self):
        pass


class Dpctl(object):
        pass


class DBtool(object):

    schema = r'/usr/share/openvswitch/vswitch.ovsschema'
    db = r'/etc/openvswitch/conf.db'
    tool = r'ovsdb-tool'

    def __init__(self, conn, db=None, schema=None):
        self.db = self.__class__.db if db is None else db
        self.schema = self.__class__.schema if schema is None else schema
        self.conn = conn

    def clean(self):
        _dirs = [r'/etc/openvswitch',
                 r'/var/run/openvswitch',
                 r'/var/log/openvswitch',
                 ]
        for _dir in _dirs:
            self.conn.exec_command('rm -rf %s' % _dir)
            self.conn.exec_command('mkdir -p %s' % _dir)
        
    def create(self):
        self.clean()
        log.info("Create DB=%s" % self.db)
        cmd = '%s create %s %s' % (self.tool, self.db, self.schema)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def delete(self):
        pass
