"""
:mod:`DPDK` -- Maia Dpdk Config
========================================

.. module_author:: Surender Khetavath <surender.khetavath@broadcom.com>

This module before initializing needs ssh object. 
>>> from controller.lib.core import ssh
>>> ssh_obj = ssh.SSHHandler(<ip>, 'username', 'password')

Once the ssh object is available this module can be initialized
>>> from controller.lib.linux.maia.dpdk import DPDK
>>> dpdk = DPDK('br0', ssh_obj, ...)
"""


import logging

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2018 Broadcom Limited"


log = logging.getLogger(__name__)


class DPDK(object):
    tool = 'dpdk-devbind'
    igb_module = r'/usr/share/dpdk/arm64-stingray-linuxapp-gcc/igb_uio.ko'
    huge_pages = r'/dev/hugepages'
    new_id_path = r'/sys/bus/pci/drivers/igb_uio/new_id'
    mount_path = r'/mnt/huge'
    nr_hugepages_path = r'/sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages'
    env_path = r'/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/root/ovs-bin'

    def __init__(self, conn, driver, dpdk_driver_path=None, page_bytes=1024, auto_init=False):
        self.conn = conn
        self.page_bytes = page_bytes
        self.driver = driver
        self.igb_module = dpdk_driver_path or self.igb_module
        if 'igb' in self.igb_module:
            self.new_id_path = r'/sys/bus/pci/drivers/igb_uio/new_id'
        else:
            self.new_id_path = r'/sys/bus/pci/drivers/vfio-pci/new_id'

        if auto_init:
            self.dpdk_init()

    def dpdk_init(self):
        self.load(path=self.igb_module)
        self.hugepage()

    def dpdk_exit(self):
        self.delete_hugepage()
        self.unload()

    def load(self, method='modprobe', path=None):
        module_path = self.igb_module if path is None else path
        cmd = "{0} {1}".format(method, module_path)
        log.debug("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def unload(self, method='rmmod', path=None):
        cmd = 'lsmod | grep igb_uio'
        output = self.conn.exec_command(cmd, check_exit=False)
        if output:
            module_path = self.igb_module if path is None else path
            cmd = "{0} {1}".format(method, module_path)
            log.debug("Running command: %s" % cmd)
            output = self.conn.exec_command(cmd)
            return output

    def driver_bind(self, pci_id):
        cmd = '%s --bind=%s %s' % (self.tool, self.driver, pci_id)
        self.conn.exec_command(cmd, check_exit=False)

    def driver_unbind(self, bus):
        """
        :param bus:
        :return:
        """
        cmd = r'echo {0} > /sys/bus/pci/drivers/{1}/unbind'.format(bus, self.driver)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def dpdk_bind(self, devid, path=None):
        """
        :param devid:
        :return:
        """
        _path = self.new_id_path if path is None else path
        cmd = r"echo '{0}' > {1} ".format(devid, _path)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def dpdk_unbind(self, pci_id):
        cmd = '%s -u %s' % (self.tool, pci_id)
        self.conn.exec_command(cmd, check_exit=False)

    def hugepage(self, umount_existing=False):
        if umount_existing:
            self.delete_hugepage()
        output = None
        cmds = ['mkdir -p {0}'.format(self.mount_path),
                'mount -t hugetlbfs nodev {0}'.format(self.mount_path),
                'echo {0} > {1}'.format(self.page_bytes, self.nr_hugepages_path)
                ]
        for cmd in cmds:
            log.info("Running command: %s" % cmd)
            output = self.conn.exec_command(cmd)
        return output

    def delete_hugepage(self):
        """
        :param path:
        :return:
        """
        cmd = 'umount --recursive {0}'.format(self.huge_pages)
        log.info("Running command: %s" % cmd)
        output = self.conn.exec_command(cmd, check_exit=False)
        return output
