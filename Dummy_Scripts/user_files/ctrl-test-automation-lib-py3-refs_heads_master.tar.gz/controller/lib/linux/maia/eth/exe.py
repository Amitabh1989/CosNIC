import logging
from controller.lib.common.shell.exe import *


def override_block_run(conn, exe_mod):
    def block_run(command, **kwargs):
        output = conn.exec_command_str(command)
        return output

    exe_mod.block_run_old_ref = exe_mod.block_run
    exe_mod.block_run = block_run


def revert_block_run(exe_mod):
    if hasattr(exe_mod, 'block_run_old_ref'):
        exe_mod.block_run = exe_mod.block_run_old_ref
    else:
        logging.warning("Nothing to be reverted")

