from controller.lib.linux.eth.ip import *
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe

def add_vlan(iface, vlan_id=None, vlan_name=None, lower_kernel=False):
    """
    Add vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID

    """
    command = None
    if not lower_kernel:
        if not vlan_name:
            vlan_name = iface[-4:-1] + '.' + str(vlan_id)
            command = 'ip link add link %s name %s type vlan id %s' % (
                iface, vlan_name, vlan_id
            )
    else:
        command = 'vconfig add %s %s' % (iface, vlan_id)

    try:
        exe.block_run(command)
    except exception.ExeExitcodeException as e:
        if 'is unknown,' in e.output:
            # OS is RHEL5 where ip link delete command is not supported. Shall execute vconfig command
            add_vlan(iface, vlan_id, lower_kernel=True)
        else:
            raise exception.IPException('Unable to add vlan. Output: %s' % e)
    return vlan_name


def remove_vlan(iface=None, vlan_id=None, vlan_name=None, lower_kernel=False):
    """
    Remove vlan to the interface. Interface Name and the VLAN ID are the mandatory arguments.

    Args:
        iface (str): ethX name
        vlan_id (int): VLAN ID
        vlan_name (str): vlan interface name
    """
    if vlan_name:
        host_vlan = vlan_name
    else:
        host_vlan = iface[-4:-1] + '.' + str(vlan_id)
    if not lower_kernel:
        command = 'ip link delete %s ' % (host_vlan)
    else:
        command = 'vconfig rem %s' % (host_vlan)
    try:
        exe.block_run(command)
    except exception.ExeExitcodeException as e:
        if 'is unknown,' in e.output:
            # OS is RHEL5 where ip link delete command is not supported. Shall execute vconfig command
            remove_vlan(iface, vlan_id, lower_kernel=True)
        else:
            raise exception.IPException('Unable to remove vlan. Output: %s' % e)
    return True
