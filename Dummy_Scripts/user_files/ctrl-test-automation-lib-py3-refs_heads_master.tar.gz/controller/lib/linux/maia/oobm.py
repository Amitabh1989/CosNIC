from functools import wraps
import traceback
import pexpect
import time
import re
from controller.lib.core import exception
from controller.lib.core import log_handler

import logging
logger = logging.getLogger(__name__)


class OOBM_Handler(object):

    def __init__(self, mgmt_ip_addr, user_name, password, port=22, prompt=None, auto_connect=True):
        self._mgmt_ip = mgmt_ip_addr
        self.port = port
        self.user_name = user_name
        self.password = password
        self.prompt = prompt or ['\r\n\n>', '\r\n>']     # '^>' or '\r\n>\r\n' #Each line in TTY devices ends with a CR/LF combination (\r\n)
        self.ssh = None
        if auto_connect is True:
            self.connect()

    def connect(self):
        self.ssh = ShellHandler(self._mgmt_ip,
                                self.port,
                                self.user_name,
                                self.password,
                                self.prompt)
        self.ssh.connect()
        if self.ssh.conn is None:
            raise Exception('Couldnt connect to OOBM over ssh')

    def disconnect(self):
        self.ssh.disconnect()

    @property
    def connected(self):
        return self.ssh.connected

    @property
    def ip(self):
        return self._mgmt_ip

    def run(self, cmd, prompt=None, timeout=10):
        output = self.ssh.exec_command(cmd, prompt=prompt, timeout=timeout)
        return output

    @property
    def cmd_status(self):
        return self.ssh.cmd_status

    def restart(self):
        """
         Restarts the EA application.
         Connectivity to the application will be lost.
        :return:
        """
        cmd = 'restart'
        output = None
        try:
            output = self.run(cmd, prompt='Disconnected')
        except:
            if self.cmd_status['exit_status'] is not True:
                raise
            else:
                output = self.cmd_status['result']
        return output

    def reset(self):
        """
        Resets the AP complex, all A72 processors.
        :return:
        """
        cmd = 'reset ap'
        output = self.run(cmd)
        return output

    def reset_mod(self, mod):
        cmd = 'reset {}'.format(mod)
        output = self.run(cmd)
        return output

    def os_recovery(self):
        """
        Forces the AP OS to boot from Recovery partition at next AP boot.
        AP should be reset by user for this to take effect.
        :param force:
        :return:
        """
        cmd = 'force ap os recovery'
        output = self.run(cmd)
        return output

    def os_restore(self):
        """
        Forces the AP OS to boot from Restore partition at next AP boot.
        AP should be reset by user for this to take effect.
        :param force:
        :return:
        """
        cmd = 'force ap os restore'
        output = self.run(cmd)
        return output

    def clear_in_band_ip(self):
        """
        Forces the 'in-band IP address clear' to be applied at next AP boot.
        :param force:
        :return:
        """
        cmd = 'force ap clear in-band IP'
        output = self.run(cmd)
        return output

    def show_config(self):
        """
         Displays the OOB Mgmt configuration.
         The individual configuration elements can be changed using
         the 'set <type>' cmd
        :return:
        """
        cmd = 'show config'
        output = self.run(cmd)
        return output

    def get_trace(self):
        """
        Displays the internal trace buffer.
        :param :
        :return:
        """
        cmd = 'show trace'
        trace = self.run(cmd, timeout=30)
        return trace

    @staticmethod
    def set_ip(bnxtnvm, port_id, ip, device=True):
        result = bnxtnvm.set_option('oobm_ipv4_addr_port_{}'.format(port_id), ip, device=device)
        if not result:
            raise Exception('Could not set oobm ip')

    @staticmethod
    def get_ip(bnxtnvm, port_id=0, device=True):
        ip = bnxtnvm.get_option('oobm_ipv4_addr_port_{}'.format(port_id), device=device)
        return ip

    @staticmethod
    def set_option(bnxtnvm, key, value, device=True):
        result = bnxtnvm.set_option(key, value, device=device)
        if not result:
            raise Exception('Could not set {} to {}'.format(key, value))

    @staticmethod
    def get_option(bnxtnvm, key, device=True):
        value = bnxtnvm.get_option(key, device=device)
        return value

    def set_syslog_server_ip(self, bnxtnvm, ip, device=True):
        """
        EA CLI Cmd: set syslog port <port> ipv4 <server_ip>
        bnxtnvm cmd: bnxtnvm -dev=enP8p1s0f7np1 setoption=oobmsyslogserver_addr#<server_ip>
        :param bnxtnvm:
        :param ip:
        :param device:
        :return:
        """
        result = bnxtnvm.set_option('oobm_syslog_server_addr', ip, device=device)
        if not result:
            raise Exception('Could not set syslog server ip')

    def set_session_port(self, port=22):
        cmd = 'set session port {}'.format(port)
        output = self.run(cmd)
        return output

    @staticmethod
    def get_session_port(bnxtnvm, port_id=0, device=True):
        port = bnxtnvm.get_option('oobm_session_port'.format(port_id), device=device)
        return int(str(port), 16)

    def set_session_timeout(self, port_id=0, timeout=600):
        cmd = 'set session timeout {}'.format(timeout)
        output = self.run(cmd)
        return output

    def get_session_timeout(self, bnxtnvm, port_id=0, device=True):
        timeout = bnxtnvm.get_option('oobm_session_timeout'.format(port_id), device=device)
        return int(str(timeout), 16)

    def set_port_mac(self, port_id, mac_addr):
        cmd = 'set interface {} mac {}'.format(port_id, mac_addr)
        output = self.run(cmd)
        return output

    def get_port_mac(self, bnxtnvm, port_id=0, device=True):
        mac_addr = bnxtnvm.get_option('oobm_ipv4_addr_port_{}'.format(port_id), device=device)
        return mac_addr

    def set_interface_ip(self, port_id, ipv4, netmask, gateway=None):
        cmd = 'set interface {} ipv4 {} netmask {}'.format(port_id, ipv4, netmask)
        if gateway:
            cmd += ' gateway {}'.format(gateway)
        output = self.run(cmd)
        return output

    def rename_user(self, name, password, new_name):
        self.run('set user name {}'.format(name), 'password:')
        self.run(password, 'new-username:')
        self.run(new_name)

    def set_password(self, name, password, new_password):
        self.run('set user password {}'.format(name), 'password:')
        self.run(password, 'new-password:')
        self.run(new_password, 'new-password:')
        self.run(new_password)

    def get_port_stats(self):
        cmd = 'show stats'
        stats = self.run(cmd, timeout=30)
        stats = [line.strip() for line in stats.split('\n') if line.strip()]
        stats_dict = {}
        port_num = None
        for line in stats:
            port_match = re.match('Port\s*(\d+)\s*:', line)
            if port_match:
                port_num = port_match.group(1)
                stats_dict[port_num] = {}
            else:
                stat_match = re.match('\s*(.*)\s*:\s*(.*)\s*', line)
                if stat_match and port_num:
                    stats_dict[port_num][stat_match.group(1)] = stat_match.group(2)
        return stats_dict

    def sendcontrol(self, ch):
        self.ssh.sendcontrol(ch)


class ShellHandler(object):
    """
    import pexpect
    p=pexpect.spawn('ssh user@40.1.1.1')
    i=p.expect(['password:',pexpect.EOF])
    i
    p.sendline("user0")
    p.read_nonblocking(size=5000, timeout=5)

    p.sendline("show config")
    p.read_nonblocking(size=5000, timeout=2)

    p.sendline("set session timeout 0")
    p.read_nonblocking(size=5000, timeout=2)
    """

    def __init__(self, host, port=22, user='root', psw='', prompt=None):
        self.host = host
        self.port = port
        self.username = user
        self.password = psw
        self.prompt = prompt
        self.process = None
        self.cmd_status = dict.fromkeys(['command', 'result', 'exit_status', 'eof', 'conn_status', 'timeout'])
        self.success_codes = ['200', '201', 'Connected']
        self.fail_codes = ['400', '417']

    def connect(self, prompt='password:', timeout=30):
        sub_cmd = '-p {}'.format(self.port) if self.port else ''
        process_cmd = 'ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ' \
                      '{}@{} {}'.format(self.username, self.host, sub_cmd)
        logger.info(process_cmd)
        try:
            self.process = pexpect.spawn(process_cmd)
            prompts = [prompt, '(yes/no)?']
            index = self.process.expect(prompts, timeout=timeout)
            logger.info(self.process.before)
            logger.warning('prompts: {}'.format(prompts))
            logger.warning('index: {}'.format(index))
            if index == 1:
                logger.warning('Sending yes')
                self.process.sendline('yes')
                prompts = [prompt]
                index = self.process.expect(prompts, timeout=timeout)
                logger.info(self.process.before)
                logger.warning('prompts: {}'.format(prompts))
                logger.warning('index: {}'.format(index))
            if index == 0:
                logger.warning('password: {}'.format(self.password))
                self.process.sendline(self.password)
                prompts = self.prompt + ['Permission denied']
                index = self.process.expect(prompts, timeout=timeout)
                logger.info(self.process.before)
                logger.warning('prompts: {}'.format(prompts))
                logger.warning('index: {}'.format(index))
                if index == 0:
                    return True
                else:
                    logger.error('FAIL: Wrong password')
                    self.process.close()
                    return False
        except pexpect.EOF:
            logger.warning("Failed to connect due to EOF")
            import traceback
            logger.info(traceback.format_exc())
            return False
        except pexpect.TIMEOUT:
            logger.warning("Failed to connect due to TIMEOUT")
            import traceback
            logger.info(traceback.format_exc())
            return False
        except Exception:
            import traceback
            logger.info(traceback.format_exc())
            return False

    def disconnect(self):
        self.process.close()

    @property
    def conn(self):
        return self.process

    def connected(self):
        return self.process.isalive()

    def connected_only(func, *args, **kwargs):
        @wraps(func)
        def conn_check(self, *args, **kwargs):
            if not self.connected:
                self.connect()
            return func(self, *args, **kwargs)

        return conn_check

    @connected_only
    def exec_command(self, cmd, prompt=None, timeout=10):
        prompt = prompt or self.prompt
        logger.info('Run cmd: {}'.format(cmd))
        logger.info('Prompt: {}'.format(prompt))
        try:
            self.process.sendline(cmd)
            self.cmd_status['cmd'] = cmd
            self.process.expect(prompt, timeout=timeout)
        except pexpect.EOF:
            self.cmd_status['eof'] = True
            logger.warning('Received EOF')
            logger.info(traceback.format_exc())
            raise
        except pexpect.TIMEOUT:
            logger.warning('Command TIMEOUT, waited for {} secs'.format(timeout))
            self.cmd_status['timeout'] = True
            logger.info(traceback.format_exc())
            raise
        except Exception:
            self.cmd_status['timeout'] = True
            logger.info(traceback.format_exc())
            raise
        finally:
            output = self.process.before
            self.cmd_status['exit_status'] = self.cmd_completed(output)
            self.cmd_status['result'] = output
            self.cmd_status['conn_status'] = self.connected()
        return output

    def cmd_completed(self, output):
        for code in self.success_codes:
            if code in output:
                return True
        for code in self.fail_codes:
            if code in output:
                return False

        return None

    @connected_only
    def sendcontrol(self, ch):
        self.process.sendcontrol(ch)
