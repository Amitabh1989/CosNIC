"""
:mod:`ovs` -- OVS Daemons
========================================

.. moduleauthor:: Surender Khetavath <surender.khetavath@broadcom.com>

"""

import logging
import time
import ipaddress
import random
from .ctl import DBtool
from .ctl import Vsctl
from .ctl import Ofctl
from .ctl import Appctl
from controller.lib.core import exception

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2019 Broadcom Inc"

log = logging.getLogger(__name__)


class Bond(object):
    def __init__(self, name, **kwargs):
        self._bond_name = name
        self.slaves = []
        self.bond_mode = kwargs.get('bond_mode', None)
        self.lacp = kwargs.get('lacp', None)
        # self.lacp_time = kwargs.get('lacp_time', None)
        # self.port_num = kwargs.get('port_num', None)
        # self.mtu_request = kwargs.get('mtu_request', 9072)
        self.desc = {
            'bond_mode': self.bond_mode,
            'lacp': self.lacp,
            # 'other_config:lacp-time': self.lacp_time,
            # 'mtu_request': self.mtu_request,
            # 'options:n_rxq_desc': 256,
            # 'options:n_txq_desc': 2048,
            # 'ofport_request': self.port_num,
            # 'options:dpdk-devargs': None,
        }

    @property
    def name(self):
        return self._bond_name

    def add_slave(self, slave_name, slave_type, port_func=None, port_num=None, devargs=None):
        slave_obj = get_port_type(slave_type.upper(), slave_name, port_num, port_func, slave_name)
        slave_obj.desc['options:dpdk-devargs'] = devargs
        self.slaves.append(slave_obj)


class Port(object):
    def __init__(self, port_name, port_num, port_func, orig_name):
        self._port_name = port_name
        self._port_num = port_num
        self._port_func = port_func
        self._orig_name = orig_name

    @property
    def port_name(self):
        return self._port_name

    @property
    def port_num(self):
        return self._port_num

    @property
    def port_func(self):
        return self._port_func

    @property
    def orig_name(self):
        return self._orig_name

    def add_port(self):
        pass

    def del_port(self):
        pass

    @staticmethod
    def _get_all_subclasses(cls):
        all_subclasses = []
        for subclass in cls.__subclasses__():
            all_subclasses.append(subclass)
            all_subclasses.extend(cls._get_all_subclasses(subclass))
        return all_subclasses


class DPDKPort(Port):  
    _type = 'DPDK'

    def __init__(self, port_name, port_num, port_func, orig_name):
        super(DPDKPort, self).__init__(port_name, port_num, port_func, orig_name)
        self.desc = {'type': self.__class__._type.lower(),
                     'options:dpdk-devargs': None,
                     'mtu_request': 9072,
                     'options:n_rxq_desc': 256,
                     'options:n_txq_desc': 2048,
                     'ofport_request': self.port_num}

    @property
    def port_name(self):
        return self._port_name

    @property
    def pciid(self):
        return self.desc['options:dpdk-devargs']


class PatchPort(Port):
    _type = 'PATCH'

    def __init__(self, port_name, port_num, port_func, orig_name):
        super(PatchPort, self).__init__(port_name, port_num, port_func, orig_name)
        self.desc = {'type': self.__class__._type.lower(),
                     'options:peer':  None,
                     'ofport_request': self.port_num}


class VXLANPort(Port):
    _type = 'VXLAN'

    def __init__(self, port_name, port_num, port_func, orig_name):
        super(VXLANPort, self).__init__(port_name, port_num, port_func, orig_name)
        self.desc = {'type': self.__class__._type.lower(),
                     'options:remote_ip': None,
                     'options:key': None,
                     'ofport_request': self.port_num}


class GREPort(Port):
    _type = 'GRE'

    def __init__(self, port_name, port_num, port_func, orig_name):
        super(GREPort, self).__init__(port_name, port_num, port_func, orig_name)
        self.desc = {'type': self.__class__._type.lower(),
                     'options:remote_ip': None,
                     'options:key': None,
                     'ofport_request': self.port_num}


class OVSPort(Port):
    _type = 'OVS'

    def __init__(self, port_name, port_num, port_func, orig_name):
        super(OVSPort, self).__init__(port_name, port_num, port_func, orig_name)
        self.desc = {'mtu_request': 9072,
                     'ofport_request': self.port_num}


def get_port_type(port_type, name=None, port_num=None, func='vf', orig_name=None):
    """
    port name: User given or random generated.
    port_num: ofproto num
    """
    valid_type_list = []
    for subclass in Port.__subclasses__():
        valid_type_list.append(subclass._type)
        if subclass._type == port_type:
            return subclass(name, port_num, func, orig_name)
    raise exception.ValueException(
        'Invalid port_type %s (choices: %s)' % (port_type, ', '.join(valid_type_list)))


class Bridge(object):
    mode = 'OVS'

    def __init__(self, conn, br_name, ports, ip, bonds, datapath_type):
        self.conn = conn
        self.br_name = br_name
        self.br_ip = ip
        self.ports = ports
        self.bonds = bonds
        self.port_objs_list = []
        self.bond_objs = []
        self._vsctl = Vsctl(self.br_name, self.conn)
        self.ofctl = Ofctl(self.br_name, self.conn)
        self._appctl = Appctl(self.br_name, self.conn)
        self.options = {
            'datapath_type': datapath_type,
            'fail-mode': 'standalone',
            'extra': 'br-set-external-id %s bridge-id %s' % (self.br_name, self.br_name),
        }

    @property
    def vsctl(self):
        return self._vsctl

    @property
    def appctl(self):
        return self._appctl

    def add_br(self):
        self.vsctl.add_br(**self.options)

    def del_br(self):
        self.vsctl.del_br()

    def add_ports(self):
        for port_obj in self.port_objs_list:
            if not isinstance(port_obj, (Port, DPDKPort, GREPort)):
                log.info("FAIL: No Port object given")
                return False
            self.vsctl.add_port(port_obj)

    def del_port(self, port_name):
        self.vsctl.del_port(port_name)
        log.info('Detaching...')
        for port in self.port_objs_list:
            pci_id = port.desc.get('options:dpdk-devargs', None)
            log.info('port_name: {} pci_id:{}'.format(port_name, pci_id))
            if port.port_name == port_name and pci_id is not None:
                log.info('Detaching port_name: {}'.format(port_name))
                self.appctl.detach_port(pci_id)
                break
        self.port_objs_list = [port for port in self.port_objs_list if port.port_name != port_name]

    def del_ports(self):
        port_names = self.get_all_port_names()
        if not port_names:
            port_names = self.vsctl.get_port_names()
        for port_name in port_names:
            self.vsctl.del_port(port_name)
        self.port_objs_list = []

    def add_bonds(self):
        for bond_obj in self.bond_objs:
            if not isinstance(bond_obj, Bond):
                log.info("FAIL: No bond object given")
                return False
            self.vsctl.add_bond(bond_obj)

    def set_vswitch_options(self, otherconfig=None):
        otherconfig = {'other_config:dpdk-init': 'true',
                       'other_config:dpdk-socket-mem': '1024,0',
                       'other_config:pmd-cpu-mask': '0xfe'} \
                      if otherconfig is None else otherconfig

        for key, value in list(otherconfig.items()):
            self.vsctl.set(opts='--no-wait', key=key, value=value)

    def build_vf_pair_ports(self, rep_name, num_vfs_per_pf, rep_pci_ids):
        for rep_port in list(rep_pci_ids.keys()):
            for vf_num in range(num_vfs_per_pf):
                port_name = 'dpdk' + str(vf_num)
                log.info("Adding Port=%s on PF=%s" % (port_name, rep_port))
                # The port type i.e DPDK is assumed. It has to be dynamic. Need change here.
                port_obj = get_port_type('DPDK', port_name, vf_num+1)
                port_obj.desc['options:dpdk-devargs'] = rep_pci_ids[rep_name][vf_num]
                log.info("Port description = %s" % port_obj.desc)
                self.port_objs_list.append(port_obj)

    def build_pf_pair_ports(self, rep_name, rep_pci_ids):
        for rep_port, pci_ids in rep_pci_ids.items():
            for rep_index in range(len(pci_ids)):
                port_name = 'dpdk' + str(rep_index)
                log.info("Adding Port=%s on PF=%s" % (port_name, rep_port))
                # The port type i.e DPDK is assumed. It has to be dynamic. Need change here.
                port_obj = get_port_type('DPDK', port_name, rep_index + 1)
                port_obj.desc['options:dpdk-devargs'] = rep_pci_ids[rep_name][rep_index]
                log.info("Port description = %s" % port_obj.desc)
                self.port_objs_list.append(port_obj)

    def build_port(self, port):
        import random
        # This comes from maia config defined by user.
        (pf_name, pf_type, peer) = port
        #port_name = 'dpdk20' + str(num)
        port_name = pf_name
        # Assuming the port type is PF if type is 'dpdk' else the port type is 'patch'
        # pf_func is needed to differentiate a port as 'pf', 'patch' or 'vf' port.
        # This helps while adding flows.
        pf_func = 'pf' if pf_type == 'dpdk' else 'patch'
        of_port_request = self.get_of_port_request()
        port_obj = get_port_type(pf_type.upper(), port_name, of_port_request, pf_func, pf_name)
        log.info("Adding port type (%s) to bridge (%s)" % (pf_type.upper(), self.br_name))
        if pf_type.upper() == 'PATCH':
            port_obj.desc['options:peer'] = peer
        elif pf_type.upper() == 'DPDK':
            if peer == 'rep':
                devargs = port_name
            else:
                devargs = self.get_pci_id(pf_name)
            port_obj.desc['options:dpdk-devargs'] = devargs
        else:
            log.info("A port type ( %s ) given in config" % pf_type)
        self.port_objs_list.append(port_obj)

    def build_tunnel_port(self, port):
        (pf_name, pf_type, peer, remote_ip, key) = port
        port_name = pf_name
        pf_func = 'pf' if pf_type == 'dpdk' else 'patch'
        of_port_request = self.get_of_port_request()
        port_obj = get_port_type(pf_type.upper(), port_name, of_port_request, pf_func, pf_name)
        log.info("Adding port type (%s) to bridge (%s)" % (pf_type.upper(), self.br_name))
        port_obj.desc['options:remote_ip'] = str(remote_ip)
        port_obj.desc['options:key'] = str(key)
        self.port_objs_list.append(port_obj)

    def get_of_port_request(self):
        of_port_request = random.choice(
            list(set(range(200, 400)) - set([obj.desc['ofport_request'] for obj in self.port_objs_list])))
        return of_port_request

    def get_pci_id(self, port_name):
        output = self.conn.exec_command('ethtool -i %s' % port_name)
        log.info("output got = {0}".format(output))
        for item in output:
            if 'bus-info' in item:
                return item.split()[1]
        return None

    def set_ip(self, ip_addr=None, ipv6=False):
        # The ip address must be of format a.b.c.d/24

        if not ip_addr and not self.br_ip:
            raise Exception('Ip addr must be supplied')

        ip_addr = ip_addr if ip_addr else self.br_ip

        cmd = 'ip %s addr add %s dev %s' % (
            '-6' if ipv6 else '', ip_addr, self.br_name)
        self.conn.exec_command(cmd)
        cmd = 'ip link set %s up' % self.br_name
        self.conn.exec_command(cmd)
        if not ipv6:
            self.br_ip = ip_addr

    def get_ip(self):
        return self.br_ip

    def build_ports(self, base_ip_addr, base_ip6_addr):
        import random
        from controller.lib.linux.eth import ip
        (remote_ip, subnet) = base_ip_addr.split("/")
        (remote_ip6, subnet6) = base_ip6_addr.split("/")

        remote_ip = ip.get_next_ip(remote_ip)
        remote_ip6 = ip.get_next_ip(remote_ip6)

        for num, port in enumerate(self.ports):
            # This comes from maia config defined by user.
            tunnel_id = None
            if len(port) == 3:
                (pf_name, pf_type, peer) = port
            elif len(port) == 5:
                (pf_name, pf_type, peer, remote_ip, tunnel_id) = port
            #port_name = 'dpdk20' + str(num)
            port_name = pf_name
            # Assuming the port type is PF if type is 'dpdk' else the port type is 'patch'
            # pf_func is needed to differentiate a port as 'pf', 'patch' or 'vf' port.
            # This helps while adding flows.
            pf_func = 'pf' if pf_type == 'dpdk' and peer is None else 'patch'
            #of_proto_request = '20' + str(num)
            of_port_request = random.choice(list(set(range(200,400))-set([obj.desc['ofport_request'] for obj in self.port_objs_list])))
            port_obj = get_port_type(pf_type.upper(), port_name, of_port_request, pf_func, pf_name)
            log.info("Adding port type (%s) to bridge (%s)" % (pf_type.upper(), self.br_name))
            if pf_type.upper() == 'PATCH':
                port_obj.desc['options:peer'] = peer
            elif pf_type.upper() == 'DPDK':
                if peer == 'rep':
                    devargs = port_name
                else:
                    devargs = self.get_pci_id(pf_name)
                port_obj.desc['options:dpdk-devargs'] = devargs
            elif pf_type.upper() == 'VXLAN' or pf_type.upper() == 'GRE':
                port_obj.desc['options:remote_ip'] = str(remote_ip)
                port_obj.desc['options:key'] = tunnel_id if tunnel_id else str(remote_ip).split('.')[2]
                remote_ip = ip.get_next_network_ip(str(remote_ip))
                remote_ip6 = ip.get_next_network_ip(str(remote_ip6), True)
            else:
                log.info("A port type ( %s ) given in config" % pf_type)
            self.port_objs_list.append(port_obj)

    def build_bonds(self):
        for bond in self.bonds:
            bond_name = bond['name']
            slaves = bond['slaves']
            bond_args = bond.get('args', {})
            bond_obj = Bond(bond_name, **bond_args)
            for slave in slaves:
                (slave_name, slave_type, slave_func) = slave
                of_port_request = random.choice(
                    list(set(range(500, 600)) - set([sl.desc['ofport_request']
                                                     for obj in self.bond_objs for sl in obj.slaves])))
                devargs = self.get_pci_id(slave_name)
                log.info("{} {} {} {} {}".format(slave_name, slave_type, slave_func,
                                   of_port_request, devargs))
                bond_obj.add_slave(slave_name, slave_type, port_func=slave_func,
                                   port_num=of_port_request, devargs=devargs)
            self.bond_objs.append(bond_obj)

    def get_port_by_name(self):
        pass

    def get_port_pciids(self, ports=None, func=None):
        ports = ports or self.port_objs_list
        for port in ports:
            log.info("==========Desc = %s" % port.desc)
            log.info("==========Func = %s" % port.port_func)
        if func:
            port_ids = [x.desc['options:dpdk-devargs'] for x in ports if x.port_func == func]
        else:
            port_ids = [x.desc['options:dpdk-devargs'] for x in ports]
        log.info("==============The PCI ids of PF functions = %s" % port_ids)
        return port_ids

    def get_slave_pciids(self, bonds=None, func=None):
        bonds = bonds or self.bond_objs
        pci_ids = []
        for bond in bonds:
            pci_ids.extend(self.get_port_pciids(bond.slaves, func))
        return pci_ids

    def get_all_port_names(self):
        port_names = []
        if self.port_objs_list:
            for port in self.port_objs_list:
                port_names.append(port.port_name)
        return port_names

    def get_ofproto_by_name(self, port_name):
        if self.port_objs_list:
            for port in self.port_objs_list:
                if port.orig_name == port_name:
                    return port.desc['ofport_request']
        return None

    def get_ofproto_by_func(self, func):
        func_list = []
        if self.port_objs_list:
            for port in self.port_objs_list:
                if port.port_func == func:
                    func_list.append(port.desc['ofport_request'])
        return func_list

    def add_baremetal_flows(self, forward_port, rep_name):

        f_port_num = self.get_ofproto_by_name(forward_port)
        r_port_num = self.get_ofproto_by_name(rep_name)

        self.ofctl.add_flow(self.br_name, action='output:%s' % f_port_num, in_port='%s' % r_port_num)
        self.ofctl.add_flow(self.br_name, action='output:%s' % r_port_num, in_port='%s' % f_port_num)

    def add_flows(self, mac_list, forward_port):
        f_port_num = self.get_ofproto_by_name(forward_port)
        v_port_nums = self.get_ofproto_by_func('vf')

        for vf_port_num, dst_mac in zip(v_port_nums, mac_list):
            self.ofctl.add_flow(self.br_name, action='output:%s' % vf_port_num, in_port='%s' % f_port_num, dl_dst=dst_mac)
            self.ofctl.add_flow(self.br_name, action='output:%s' % f_port_num, in_port='%s' % vf_port_num)


class DBServer(object):
    tool = 'ovsdb-server'

    options = ['--remote=punix:/var/run/openvswitch/db.sock',
               '--remote=db:Open_vSwitch,Open_vSwitch,manager_options',
               '--private-key=db:Open_vSwitch,SSL,private_key',
               '--certificate=db:Open_vSwitch,SSL,certificate',
               '--bootstrap-ca-cert=db:Open_vSwitch,SSL,ca_cert',
               '--pidfile',
               '--detach',
               '--log-file',
               ]

    def __init__(self, conn, dbtool_obj=None):
        self.conn = conn
        self.dbtool_obj = DBtool(self.conn) if dbtool_obj is None else dbtool_obj

    def start(self):
        self.dbtool_obj.create()
        cmd = '%s ' % self.tool + ' '.join(x for x in self.options)
        self.conn.exec_command(cmd)

    def isrunning(self):
        cmd = 'pidof %s' % self.tool
        log.info("Running command %s" % cmd)
        output = self.conn.exec_command(cmd)
        if output:
            return True
        return False

    def stop(self):
        cmd = 'ovs-appctl -t %s exit' % self.tool
        log.info("Running command = %s" % cmd)
        self.conn.exec_command(cmd, check_exit=False)

    def cleanup(self):
        pass


class SwitchDaemon(object):

    tool = 'ovs-vswitchd'
    dbsock = 'unix:/var/run/openvswitch/db.sock'

    def __init__(self, conn, dbsock=None, *args, **kwargs):
        self.conn = conn
        self.options = '--pidfile --detach --log-file'
        self.dbsock = self.__class__.dbsock if dbsock is None else dbsock

        if args:
            self.options = ' '.join(x for x in args)
        if kwargs:
            self.options += ' '.join(x+'='+y for x, y in list(kwargs.items()))

    def start(self):
        cmd = '%s %s %s' % (self.tool, self.dbsock, self.options)
        log.info("Running command = %s" % cmd)
        output = self.conn.exec_command(cmd)
        return output

    def stop(self):
        cmd = 'ovs-appctl -t %s exit --cleanup' % self.tool
        log.info("Running command = %s" % cmd)
        self.conn.exec_command(cmd, check_exit=False)
        
    def cleanup(self):
        cmd = 'killall ovs-vswitchd'
        log.info("Running command = %s" % cmd)
        self.conn.exec_command(cmd)
