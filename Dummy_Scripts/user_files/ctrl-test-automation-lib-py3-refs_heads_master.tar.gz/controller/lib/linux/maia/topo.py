"""
:mod:`topo` -- MAIA topology
========================================

.. moduleauthor:: Surender Khetavath <surender.khetavath@broadcom.com>

"""
import logging
import random
import string
import re
import time
import ipaddress
from collections import defaultdict
from controller.lib.linux.maia import bnxt_ctl
from controller.lib.linux.maia import dpdk
from controller.lib.linux.maia import ovs
from controller.lib.linux.maia.ctl import Appctl, Vsctl, Ofctl
from controller.lib.core import exception


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2019 Broadcom Inc"

log = logging.getLogger(__name__)


class TOPO(object):

    def __init__(self, ssh_obj, rep_port_name, forward_port,
                 host_pf_num, num_vfs, bridge_list, driver=None, dpdk_driver_path=None, page_bytes=1024, rep_bus_base=None,
                 devid='14e4:d802', maia_config='8+4', base_ip_addr=None,
                 base_ip6_addr=None, datapath_type='netdev'):
        self.conn = ssh_obj
        self._rep_port_name = rep_port_name
        self.forward_port = forward_port
        self._host_pf_num = host_pf_num
        self._num_vfs_per_pf = num_vfs
        self._bus = rep_bus_base.split(':')[1] or '0'+random.choice(string.hexdigits)
        self.bnxt_ctl = bnxt_ctl.BNXTTool(self.conn)
        self.dpdk = dpdk.DPDK(self.conn, driver, dpdk_driver_path, page_bytes)
        self.bridge_list = bridge_list
        self.devid = devid
        self.maia_config = maia_config
        self.bridge_objs = []
        self.base_ip_addr = base_ip_addr
        self.base_ip6_addr = base_ip6_addr
        self.datapath_type = datapath_type
        self.rep_pci_ids = defaultdict(list)

    @property
    def rep_name(self):
        """
        Get representator name with mac if not already known
        """
        if self._rep_port_name:
            return self._rep_port_name
        return None

    @property
    def bus(self):
        return self._bus

    def get_pci_id(self, port_name):
        output = self.conn.exec_command('ethtool -i %s' % port_name)
        log.info("output got = {0}".format(output))
        for item in output:
            if 'bus-info' in item:
                return item.split()[1]
        return None

    def get_devid(self, device=None):
        if self.devid:
            return self.devid
        device = device if device is not None else self.forward_port
        output = self.conn.exec_command("lspci -n | grep %s" % self.get_pci_id(device))
        (a, b) = output[-1].split()[-1].split(":")
        return a+' '+b

    def get_target_pciids(self):
        cmd = r"lspci -d %s | awk -F' ' '{print $1}'" % self.get_devid()
        output = self.conn.exec_command(cmd)
        return output

    def get_default_bridge(self):
        # Pick the bridge 'br0'
        base_bridge_obj = None
        for bridge_obj in self.bridge_objs:
            if bridge_obj.br_name == 'br0':
                base_bridge_obj = bridge_obj
                break
        return base_bridge_obj

    def add_tunnel_redirect(self,intf, tunnel_type):
        log.info("Adding tunnel redirect..")
        output = self.bnxt_ctl.add_tunnel_redirect(intf, tunnel_type)
        return output

    def add_rep_pair(self):
        pci_ids = self.bnxt_ctl.add_rep_pair(self.rep_name,
                                          self._host_pf_num,
                                          self._num_vfs_per_pf,
                                          bus=self.bus)

        if pci_ids:
            return pci_ids
        else:
            raise exception.ConfigException("%s Add rep pair failed" % self.__class__)

    def add_rep_pairs(self, rep_iface, host_pf_indices, num_vfs=0, bus='06'):
        if type(host_pf_indices) is not list:
            host_pf_indices = [host_pf_indices]

        pci_ids = self.bnxt_ctl.add_rep_pair(rep_iface,
                                            host_pf_indices,
                                            num_vfs,
                                            bus=bus)

        if pci_ids:
            self.rep_pci_ids[rep_iface] = pci_ids
            return dict(pci_ids)
        else:
            raise exception.ConfigException("%s Add rep pair failed" % self.__class__)

    def add_pf_pair(self, maia_pf, host_pf, name=None, host=1, **kwargs):
        name = '_'.join(['PF', maia_pf[-4:], str(host_pf)]) if not name else name
        self.bnxt_ctl.add_pf_pair(maia_pf, name, host_pf, host, **kwargs)
        if int(self.conn.ret_code) == 0:
            pair = self.bnxt_ctl.get_pf_pairs(port=maia_pf, pair_name=name)
            if pair:
                self.rep_pci_ids[maia_pf] = name
                return name
        else:
            raise exception.ConfigException("Add PF pair {} failed".format(name))

    def get_pf_pairs(self):
        pairs = self.bnxt_ctl.get_pf_pairs()
        return pairs

    def delete_pf_pairs(self):
        pairs = self.bnxt_ctl.get_pf_pairs()
        for pair in pairs:
            log.info('Deleting pair {}'.format(pair))
            self.bnxt_ctl.delete_pair(pair['interface'], pair['name'])

    def get_br_by_name(self, br_name):
        for br in self.bridge_objs:
            if br.br_name == br_name:
                return br

    def add_default_baremetal_flows(self):
        """
        This will add forwarding rules in OVS for PF0 only
        For custom flows use ctl.Ofctl.add_flow()
        """
        base_bridge_obj = self.get_default_bridge()
        log.info("Using the forwarding port : %s" % self.forward_port)
        base_bridge_obj.add_baremetal_flows(self.forward_port, self.rep_name)

    def add_baremetal_flow(self):
        """
        This will add forwarding rules in OVS for PF0 only
        For custom flows use ctl.Ofctl.add_flow()
        """
        base_bridge_obj = self.get_default_bridge()
        log.info("Using the forwarding port : %s" % self.forward_port)
        base_bridge_obj.add_baremetal_flows(self.forward_port, self.rep_name)

    def add_baremetal_flows(self, br_name, forward_port, rep_name):
        """
        This will add forwarding rules in OVS for PF0 only
        For custom flows use ctl.Ofctl.add_flow()
        """
        br_obj = self.get_br_by_name(br_name)
        log.info("Using the forwarding port : %s" % forward_port)
        br_obj.add_baremetal_flows(forward_port, rep_name)

    def add_flows(self, mac_list):
        """
        This will add forwarding rules in OVS for PF0 only
        For custom flows use ctl.Ofctl.add_flow()
        ex : ovs-ofctl add-flow  br0 in_port=1,dl_dst=<mac>,action=output:3
        """
        base_bridge_obj = self.get_default_bridge()

        log.info("Using the forwarding port : %s" % self.forward_port)
        base_bridge_obj.add_flows(mac_list, self.forward_port)

    def setup(self):
        # Initialize Bridge objects
        for bridge in self.bridge_list:
            br_name = bridge['br_name']
            br_ports = bridge['ports']
            bridge_obj = ovs.Bridge(self.conn, br_name, br_ports, self.datapath_type)
            self.bridge_objs.append(bridge_obj)
            if br_name == 'br0' and '8+2' not in self.maia_config:
                bridge_obj.build_vf_pair_ports(self.rep_name,
                                               self._num_vfs_per_pf,
                                               self.bnxt_ctl.rep_pci_ids)
            bridge_obj.build_ports(self.base_ip_addr, self.base_ip6_addr)

        # Get the device id of one PF i.e '14e4 d802'
        pf_dev_id = self.get_devid().replace(':', ' ')

        # Unbind the ports from bnxt_en driver
        if '8+2' not in self.maia_config:
            for bridge_obj in self.bridge_objs:
                for pci_id in bridge_obj.get_port_pciids(func='pf'):
                    self.dpdk.driver_unbind(pci_id)

        # Bind the ports based on Device ID to DPDK
        if '8+2' not in self.maia_config:
            self.dpdk.dpdk_bind(pf_dev_id)

    def setup_generic(self, bridge_list):
        # Initialize Bridge objects
        for bridge in bridge_list:
            br_name = bridge['br_name']
            br_ports = bridge.get('ports', [])
            br_bonds = bridge.get('bonds', [])
            br_ip = bridge.get('ipv4_addr', None)
            bridge_obj = ovs.Bridge(self.conn, br_name, br_ports, br_ip, br_bonds, self.datapath_type)
            self.bridge_objs.append(bridge_obj)
            if br_name == 'br0':
                bridge_obj.build_vf_pair_ports(self.rep_name,
                                               self._num_vfs_per_pf,
                                               self.bnxt_ctl.rep_pci_ids)

                # bridge_obj.build_pf_pair_ports(self.rep_name,
                #                                 self.bnxt_ctl.rep_pci_ids)

            bridge_obj.build_ports(self.base_ip_addr, self.base_ip6_addr)
            bridge_obj.build_bonds()


        # Get the device id of one PF i.e '14e4 d802'
        pf_dev_id = self.get_devid().replace(':', ' ')

        # Unbind the ports from bnxt_en driver
        for bridge_obj in self.bridge_objs:
            for pci_id in bridge_obj.get_port_pciids(func='pf'):
                self.dpdk.driver_unbind(pci_id)
            for pci_id in bridge_obj.get_slave_pciids(func='pf'):
                self.dpdk.driver_unbind(pci_id)

        # Bind the ports based on Device ID to DPDK
        self.dpdk.dpdk_bind(pf_dev_id)

    def get_next_network_ip(self, ip_addr, v6=False):
        subnet = ''
        if '/' in ip_addr:
            (ip_addr, subnet) = ip_addr.split("/")
        if v6:
            new_ip = ipaddress.ip_address('%s' % ip_addr) + 2 ** 96
        else:
            new_ip = ipaddress.ip_address('%s' % ip_addr) + 256
        if subnet:
            new_network_ip_addr = str(new_ip)+'/'+subnet
        else:
            new_network_ip_addr = str(new_ip)
        return new_network_ip_addr

    def create(self, otherconfig=None):
        # Set Vswitch options for DPDK
        # Add bridge and its ports
        self.bridge_objs[0].set_vswitch_options(otherconfig=otherconfig)
        for bridge_obj in self.bridge_objs:
            bridge_obj.add_br()
            if bridge_obj.br_ip:
                bridge_obj.set_ip()
            if bridge_obj.add_ports():
                log.info("FAIL: Add port:")
                return False
            if bridge_obj.add_bonds():
                log.info("FAIL: Add bond:")
                return False

    def assign_ip(self, devices):
        #The ip address must be of format a.b.c.d/24
        from controller.lib.linux.eth import ip
        target_bridges = []
        for bridge_obj in self.bridge_objs:
            if bridge_obj.br_name in devices:
                target_bridges.append(bridge_obj)
        (base_ip, subnet) = self.base_ip_addr.split("/")
        (base_ip6, subnet6) = self.base_ip6_addr.split("/")
        log.info("Assigning ips to bridges %s " % target_bridges)
        for bridge in target_bridges:
            bridge.set_ip(str(base_ip) + '/' + subnet)
            bridge.set_ip(str(base_ip6) + '/' + subnet6, ipv6=True)
            base_ip = ip.get_next_network_ip(base_ip)
            base_ip6 = ip.get_next_network_ip(base_ip6, True)

    def set_ip_addr(self, br_name, ip_addr=None, ipv6=False):
        bridge = self.get_br_by_name(br_name)
        bridge.set_ip(ip_addr, ipv6)

    def remove(self):
        log.info("Cleaning up MAIA")
        for bridge in self.bridge_list:
            log.info("Removing flows")
            br_name = bridge['br_name']
            cmd = 'ovs-ofctl del-flows %s' % br_name
            self.conn.exec_command(cmd, check_exit=False)

            log.info("Getting ports on bridge : %s" % br_name)
            cmd = 'ovs-vsctl list-ifaces %s' % br_name
            output = self.conn.exec_command(cmd, check_exit=False)
            for iface in output:
                log.info("Removing port=%s on bridge=%s" %(iface, br_name))
                cmd = 'ovs-vsctl del-port %s %s' %(br_name, iface)
                self.conn.exec_command(cmd, check_exit=False)

            log.info("Removing Bridge %s" % br_name)
            cmd = 'ovs-vsctl del-br %s' % br_name
            self.conn.exec_command(cmd, check_exit=False)

        pci_ids = self.get_target_pciids()
        log.info("PCI IDs of the forwarding ports = %s" % pci_ids)
        log.info("Re-binding the PFs to driver")
        if pci_ids:
            for pci_id in pci_ids:
                self.dpdk.dpdk_unbind(pci_id)
            for pci_id in pci_ids:
                self.dpdk.driver_bind(pci_id)
        self.dpdk.dpdk_exit()

    def cleanup(self):
        """
        Cleanup all the bridges and its ports, PF pairs, flow rules, bind ifaces to bnxt_en etc.
        :return:
        """
        # Removing bridge,ports and flows
        cmd = 'ovs-vsctl --columns=options --format=table --no-heading list Interface'
        output = self.conn.exec_command(cmd, check_exit=False)
        dpdk_devargs = [ln for ln in output if 'dpdk' in ln]
        detach_pciids = [re.search('"(.*)"', devargs.split(',')[0]).group(1) for devargs in dpdk_devargs]

        cmd = 'ovs-vsctl list-br'
        br_list = self.conn.exec_command(cmd, check_exit=False)
        for br_name in br_list:
            log.info("Bridge {} : Removing flows".format(br_name))
            Ofctl(br_name, self.conn).del_flows()
            vsctl = Vsctl(br_name, self.conn)
            log.info('Bridge {} : Removing ports, {}'.format(br_name, vsctl.get_port_names()))
            for port in vsctl.get_port_names():
                vsctl.del_port(port)
            log.info("Removing Bridge %s" % br_name)
            vsctl.del_br()

        log.info("Removing netdev-dpdk interfces")
        for pci_id in detach_pciids:
            Appctl(None, self.conn).detach_port(pci_id)

        # Binding all PFs to bnxt_en
        pci_ids = self.get_target_pciids()
        log.info("PCI IDs of the forwarding ports = %s" % pci_ids)
        # if '8+2' not in self.maia_config:
        log.info("Re-binding the PFs to driver")
        if pci_ids:
            for pci_id in pci_ids:
                self.dpdk.dpdk_unbind(pci_id)
            for pci_id in pci_ids:
                self.dpdk.driver_bind(pci_id)
        self.dpdk.dpdk_exit()

    def add_bonding(self, slave_list, mode, bonding_devname='bond0', **kwargs):
        log.info("Adding bond %s" % bonding_devname)
        cmd = 'modprobe bonding'
        log.info("Adding bonding driver")
        self.conn.exec_command(cmd)
        for slave in slave_list:
            log.info("Bringing down the slave interfaces")
            cmd = 'ip link set dev %s down' % slave
            self.conn.exec_command(cmd, check_exit=False)

        log.info("Adding bond interface")
        cmd = 'ip link add name %s type bond' % bonding_devname
        self.conn.exec_command(cmd, check_exit=False)
        log.info("Adding mode")
        cmd = 'ip link set dev %s type bond mode %s' % (bonding_devname, mode)
        self.conn.exec_command(cmd, check_exit=False)

        if mode == '802.3ad':
            log.info("Adding LACP settings for bond")
            cmds = [
                'ip link set dev %s type bond miimon 100' % bonding_devname,
                'ip link set dev %s type bond lacp_rate fast' % bonding_devname,
                'ip link set dev %s type bond xmit_hash_policy encap2+3' % bonding_devname,
                'ip link set dev %s mtu 9072' % bonding_devname,
                'ip link set dev %s up' % bonding_devname
            ]

            for cmd in cmds:
                self.conn.exec_command(cmd, check_exit=False)

        log.info("Adding slaves")
        for slave in slave_list:
            cmd = 'ip link set dev %s master %s' % (slave, bonding_devname)
            output = self.conn.exec_command(cmd)
            log.info("Bringing up the slave %s " % slave)
            cmd = 'ip link set dev %s up' % slave
            self.conn.exec_command(cmd, check_exit=False)

