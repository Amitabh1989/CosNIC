import os
import yaml
def read_from_config(config_file='/etc/controller_pkg/ctrl_config.yml', var_name='ctrl_ver_in_vm_template'):
    if os.path.exists(config_file):
        with open(config_file, 'r') as fd:
            ctrl_config = yaml.safe_load(fd)
        return ctrl_config[var_name]
    else:
        return "file not found"
def write_to_config(config_file='/etc/controller_pkg/ctrl_config.yml', var_name='ctrl_ver_in_vm_template', val=None):
    with open(config_file, "r") as fd:
        ctrl_config = yaml.safe_load(fd)
    ctrl_config[var_name] = val
    with open(config_file, 'w') as fd:
        yaml.dump(ctrl_config, fd, default_flow_style=False)

