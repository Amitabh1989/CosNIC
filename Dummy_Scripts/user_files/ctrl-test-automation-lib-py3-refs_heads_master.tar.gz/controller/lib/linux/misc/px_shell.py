""" Shell module is written to create a spawned shell using pexpect and provide the handle to the user.
CTRL-48082: Deprecated do not use.
"""
import pexpect
from pexpect import ExceptionPexpect, TIMEOUT, EOF, spawn
import time
import os
import sys
import re
import crypt

__all__ = ['ExceptionPxssh', 'pxssh']

# Exception classes used by this module.
class ExceptionPxssh(ExceptionPexpect):
    '''Raised for pxssh exceptions.
    '''

class px_shell(spawn):
    def __init__(self):
        spawn.__init__(self, None)
        self.name = '<px_shell>'
        self.UNIQUE_PROMPT = r"\[PEXPECT\][\$\#] "
        self.PROMPT_SET_CSH = r"set prompt='[PEXPECT]\$ '"
        self.PROMPT = self.UNIQUE_PROMPT
        # used to set shell command-line prompt to UNIQUE_PROMPT.
        self.PROMPT_SET_SH = r"PS1='[PEXPECT]\$ '"
        self.timeout = 30


    def prompt(self, timeout=-1):
        '''Match the next shell prompt.

        This is little more than a short-cut to the :meth:`~pexpect.spawn.expect`
        method. Note that if you called :meth:`login` with
        ``auto_prompt_reset=False``, then before calling :meth:`prompt` you must
        set the :attr:`PROMPT` attribute to a regex that it will use for
        matching the prompt.

        Calling :meth:`prompt` will erase the contents of the :attr:`before`
        attribute even if no prompt is ever matched. If timeout is not given or
        it is set to -1 then self.timeout is used.

        :return: True if the shell prompt was matched, False if the timeout was
                 reached.
        '''

        if timeout == -1:
            timeout = self.timeout
        i = self.expect([self.PROMPT, TIMEOUT], timeout=timeout)
        if i==1:
            return False
        return True

    def set_unique_prompt(self):
        '''This sets the remote prompt to something more unique than ``#`` or ``$``.
        This makes it easier for the :meth:`prompt` method to match the shell prompt
        unambiguously. This method is called automatically by the :meth:`login`
        method, but you may want to call it manually if you somehow reset the
        shell prompt. For example, if you 'su' to a different user then you
        will need to manually reset the prompt. This sends shell commands to
        the remote host to set the prompt, so this assumes the remote host is
        ready to receive commands.

        Alternatively, you may use your own prompt pattern. In this case you
        should call :meth:`login` with ``auto_prompt_reset=False``; then set the
        :attr:`PROMPT` attribute to a regular expression. After that, the
        :meth:`prompt` method will try to match your prompt pattern.
        '''

        self.sendline("unset PROMPT_COMMAND")
        self.sendline(self.PROMPT_SET_SH) # sh-style
        i = self.expect ([TIMEOUT, self.PROMPT], timeout=10)
        if i == 0: # csh-style
            self.sendline(self.PROMPT_SET_CSH)
            i = self.expect([TIMEOUT, self.PROMPT], timeout=10)
            if i == 0:
                return False
        return True

    def process_id(self):
        self.sendline('echo $(echo $$)')
        self.prompt()
        return self.before.splitlines()[1].strip()

    def create_shell(self):
        spawn._spawn(self, 'sh')
        if not self.set_unique_prompt():
            self.close()
            raise ExceptionPxssh('could not set shell prompt '
                                 '(received: %r, expected: %r).' % (
                                     self.before, self.PROMPT,))
        return True

    @staticmethod
    def get_crypt_passwd(password):
        encPass = crypt.crypt(password, "22")
        return encPass

    def append_to_csv_file(self, dump_data, file_name, field_names=None, iteration=None, command=None, header=False):
        '''
        dump_data should be a nested dictionary
        field_name should be a list
        '''
        import csv
        with open(file_name, 'a+') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=field_names)
            if header is True:
                writer.writeheader()
            write_list = []
            for key, value in dump_data.items():
                to_del = [key for key in value.keys() if key not in field_names]
                for d in to_del:
                    del value[d]
                if iteration is not None:
                    value['iteration'] = iteration
                if command is not None:
                    value['command'] = command
                write_list.append(value)
            writer.writerows(write_list)
