import os
import re
import time

from controller.lib.common.shell import exe
from controller.lib.core import log_handler
from controller.lib.core.ssh import SSHHandler

from typing import Dict, List, Literal, Union

log = log_handler.get_module_logger(__name__)


class BMC_Emulator:
    """BMC Emulator API

    Usage:
    >>> bmc = BMC_Emulator(scripts_path='/root/automation/BMC/DCSG01751149/versionChangeSet/BMC_Emulator-DCSG01749248',
    >>>                    qemu_path='/root/automation/BMC/qemu-6.1.1/build/', transport='pcievdm')
    >>> bmc.launch_emulator()
    """
    VM_SSH_PORT = 10022

    def __init__(self, scripts_path: str, qemu_path: str, transport: Literal['i2c', 'pcievdm'], i2c_addr: str = None):
        """
        :param scripts_path: Path to bmc_emul_core_rel/bmc_emul_fw_base/vmm/scripts
        :param qemu_path:    Path to directory containing qemu-system-aarch64
        :param transport:    mctp transport ('i2c' or 'pcievd')
        :param i2c_addr:     I2C address (hex str) if transport is 'i2c'
        """
        self.scripts_path = scripts_path
        self.qemu_path = qemu_path
        self.transport = transport
        self.i2c_addr = i2c_addr

        self.ssh: 'SSHHandler' = None

    def stop_emulator(self) -> None:
        """Graceful shutdown of VM"""
        log.info('Powering off the emulator')
        self.cmd('poweroff')
        time.sleep(3)
        exe.block_run('pkill -f vmm2vm')
        time.sleep(2)

    def kill_emulator(self) -> None:
        """Kill emulator processes"""
        for proc_str in ['qemu-system', 'vmm2vm', 'run.py', 'install.py']:
            try:
                exe.block_run(f'pkill -f {proc_str}')
                log.debug(f'Killed running proc {proc_str}')
            except Exception:
                pass

    def launch_emulator(self, transport: Literal['i2c', 'pcievdm'] = None, i2c_addr: str = None) -> None:
        """Setup and launch the BMC Emulator in a VM

        This method does the following:
        1. Kill any existing VM processes
        2. Power on the VM
        3. Connect to the VM
        4. Start MCTP transprot service (I2C or PCIeVdm)
        5. Start SPDM service
        6. Instantiate ScrutinyLibTest

        :param transport: mctp transport ('i2c' or 'pcievd')
        :param i2c_addr:  I2C address (hex str) if transport is 'i2c'
        """
        log.info('Launching BMC Emulator')

        transport = transport or self.transport
        i2c_addr = i2c_addr or self.i2c_addr

        self.kill_emulator()

        # region Power on VM
        log.info('Powering on VM...')
        proc = exe.run(f'cd {self.scripts_path}; python3 ./run.py -headless -qemupath={self.qemu_path}', shell=True)
        time.sleep(1)
        if proc.poll() not in [0, None]:
            output = proc.get_output()
            log.error(output)
            raise Exception(f'Failed to start VM. Error:\n{output}')
        time.sleep(30)
        # endregion

        # region Verify VM is connected
        wait_time = 180
        log.info('Waiting for VM to initialize...')
        stop_time = time.time() + wait_time
        while time.time() < stop_time:
            try:
                self.connect()
                break
            except Exception:
                log.debug('Waiting 30s more...')
                time.sleep(30)
        else:
            raise Exception(f'Failed to initialize VM within {wait_time}s')
        # endregion

        # region Start MCTP transport service
        if transport == 'i2c':
            if i2c_addr is None:
                raise ValueError('i2c_addr required if transport is "i2c"')
            self._i2c_mctpd(cmd='start')
            time.sleep(5)
            self._i2c_mctpd(cmd='status')
        elif transport == 'pcievdm':
            self._pcie_mctpd(cmd='start')
            time.sleep(5)
            self._pcie_mctpd(cmd='status')
        else:
            raise ValueError(f'Invalid transport value: "{transport}". Must be: ["i2c", "pcievdm"]')
        time.sleep(1)
        # endregion

        log.info('Discover endpoints')
        for i in range(5):
            try:
                _ = self.discover()
                break
            except Exception:
                log.error('Failed to discover endpoints. Trying again...')
                time.sleep(5)
        else:
            raise Exception('Failed to discover MCTP endpoints')

        # region Start SPDM service
        self.cmd('/etc/init.d/_S50bmcSpdmd start')
        # endregion

    def _i2c_mctpd(self, cmd: Literal['start', 'stop'], i2c_addr: Union[int, str] = None) -> None:
        """Start/stop I2C MCTP service

        :param cmd:      'start' or 'stop'
        :param i2c_addr: I2C address as a hex string (i.e. 0x61 -> '61')
        """
        i2c_addr = i2c_addr or self.i2c_addr
        cmd_str = f'/etc/init.d/_S50bmcI2cMctpd {cmd}'
        if cmd == 'start':
            cmd_str += f' i2cAddrs={i2c_addr}'
        self.cmd(cmd_str)

    def _pcie_mctpd(self, cmd: Literal['start', 'stop']) -> None:
        """Start/stop PCIe MCTP service

        :param cmd: 'start' or 'stop'
        """
        cmd_str = f'/etc/init.d/_S50bmcPCIeMctpd {cmd}'
        self.cmd(cmd_str)

    def discover(self) -> Dict[str, Dict[str, str]]:
        """Return discovered MCTP endpoints

        :returns: {'pcivdm': {'bdf': '0x9b00',
                              'eid': '0x0b',
                              'bus': '0x000000',
                              ...}}
        """
        pattern = re.compile(r'(\w+)\s*\|'                # Bind
                             r'\s*(0x[0-9a-fA-F]+)\s+\|'  # Bdf/Addr
                             r'\s*(0x[0-9a-fA-F]+)\s*\|'  # EID
                             r'\s*(0x[0-9a-fA-F]+)\s+\|'  # Port/Bus
                             r'\s*(0x[0-9a-fA-F]+)\s+\|'  # VendorID
                             r'\s*(0x[0-9a-fA-F]+)\s+\|'  # VdInfo
                             r'\s*([\S+ ]+?)\s*\|'        # State
                             r'\s*(\S+)\s*\|'             # Protocol
                             r'\s*(\d+\.\d+)')
        output = self.cmd('bmcPCIeEndptUtil')
        matches = pattern.findall(output)
        transports = {}
        for bind, bdf, eid, bus, vendor_id, vd_info, state, protocol, version in matches:
            bind = bind.lower()
            transports[bind] = {'bdf': bdf,
                                'eid': eid,
                                'bus': bus,
                                'vendorID': vendor_id,
                                'vdInfo': vd_info,
                                'state': state,
                                'protocol': protocol,
                                'version': version}
        if not transports:
            log.debug(output)
            log.error(f'transports: {transports}')
            raise Exception('No endpoints found')
        return transports

    def connect(self) -> None:
        """Initializes self.ssh"""

        log.info('Connecting to VM...')
        self.ssh = SSHHandler('localhost', port=self.VM_SSH_PORT, auto_connect=True)

    @property
    def connected(self) -> bool:
        return False if self.ssh is None else self.ssh.connected

    def cmd(self, cmd, working_dir: str = None) -> str:
        """Run a command inside the BMC emulator VM

        :param cmd:         Command to run
        :param working_dir: If specified, run the command from this directory
        :return:            Command output
        """
        if not self.connected:
            raise Exception('BMC SSH session not available. Call launch_emulator() before cmd().')

        if working_dir:
            cmd = f'cd {working_dir}; {cmd}'

        log.info(f'Command: {cmd}')
        output = self.ssh.exec_command(cmd)
        log.info(output)
        return output
