"""
:mod:`scrutinylib_test` -- Library for ScrutinyLibTest
==================================================

.. module:: controller.lib.linux.oob.scrutinylib_test
.. moduleauthor:: Eric Lin <eric.lin@broadcom.com>

"""
import os
import re
from typing import TYPE_CHECKING, Dict, List, Union

from controller.lib.common.shell import exe
from controller.lib.core import log_handler
from controller.lib.core import exception

if TYPE_CHECKING:
    from controller.lib.linux.oob.bmc import BMC_Emulator

__version__ = "1.0.0"
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

log = log_handler.get_module_logger(__name__)


class ScrutinyLibTest:
    """scrutinyLibTest API

    API for Scrutiny LibTest

    This class should not be instantiated by the API user. It should be accessed from the BMC_Emulator class via attribute slt.

    Per DCSG01759236, the following APIs are supported:
        1. Get Temperature
        2. Log Collection (Trace buffer, coredump) in non-decoded format
        3. Error Counters (RAM & Port Error Counters(With extended support))
        4. Reset Error Counters (RAM & Port Error Counters)
        5. Port Properties
        6. Generic API's which contains discovery API's, logger API's etc.
        7. PRBS Support.
        8. Hardware eye support.
        9. LTSSM support.
        10. Get SBR version support.
        11. Address Trap and DLUT management support.
        12. Decoded trace buffer.
        13. Scrutiny Library custom Timeout configuration for Async model of implementation(Starting 4.12).
        14. GPIO Information
        15. Port enable / disable
        16. PCIe config space access(limited offsets).
        17. Manufacturing Information
        18. CCR System Error Status register info.

Usage:
    Instantiate and power on VM
    >>> from controller.lib.linux.oob.bmc import BMC_Emulator
    >>> bmc = BMC_Emulator(scripts_path='/root/automation/BMC/DCSG01751149/versionChangeSet/BMC_Emulator-DCSG01749248',
    >>>                    qemu_path='/root/automation/BMC/qemu-6.1.1/build/', transport='pcievdm')
    >>> bmc.launch_emulator()
    >>> slt = ScrutinyLibTest(bmc, scrutiny_dir='/usr/lib/', remote_src=self.params.aiml.scrutinylibtest_rel_path)

    Get port errors
    >>> port_num = 16
    >>> port_errors = slt.get_errors()
    >>> port_errors[port_num]['counters']['BadDLLPErrors']
    0
    >>> port_errors[port_num]['status']['Correctable']['ReceiverError']
    True

    Get switch temp
    >>> slt.get_temp()
    33

    Generate and Retrieve coredump
    >>> g4xdiag = G4Xdiagnostics(sut, local_src=SCRUTINY_XTOOLS_SRC)
    >>> g4xdiag.cli('coredump generate')
    >>> slt.retrieve_coredump(save_dir='/tmp/')
    """
    TOOL_NAME = 'scrutinyLibTest'

    def __init__(self, bmc: 'BMC_Emulator', tool_path: str = '/usr/lib/scrutinyLibTest'):
        """

        ScrutinyLibTest is expected to already be installed in the VM at <tool_path>

        :param bmc:       BMC_Emulator object
        :param tool_path:  Path to scrutinyLibTest binary
        """
        self.bmc = bmc
        self._prg_path = tool_path
        self.target_idx = 0

        if not bmc.connected:
            bmc.connect()

    def cmd(self, cmd: str, target_idx: int = None, working_dir: str = None) -> str:
        """Run a scrutinyLibTest command <cmd> on device <target_idx>

        :param cmd:         scrutinyLibTest command to run
        :param target_idx:  Index of target to run command on
        :param working_dir: If specified, run the command from this directory
        :returns:           Command output
        """
        target_idx = target_idx or self.target_idx
        return self.bmc.cmd(f'{self._prg_path} -i {target_idx} {cmd}', working_dir=working_dir)

    def interactive_cmd(self, cmd_list: List[Union[int, str]]):
        pass

    def list(self) -> Union[str, Dict[int, Dict[str, str]]]:
        """Return a dict of switches detected by ScrutinyLibTest

        Raw output:
            -------------------------------------------------------------
            ScrutinyLib-Test Utility v0.1.77.0 - Broadcom Inc. (c) 2024
            -------------------------------------------------------------
             value of DeviceAddress is 59
            Num of Devices found - 1

            Handle 0 - Switch Details as below....
            Switch Details
            Handle = 0x1
            Device Id = 0xC030
            FW Version = 4.16.117.0
            SM API Version = 9.0

        todo: Untested with more than one switch. May need to update regex to handle more than one switch.
        """
        output = self.bmc.cmd(f'{self._prg_path} -list')

        return_dict = {}
        pattern = re.compile(r'Handle = (0x[0-9a-fA-F]+)\s+'
                             r'Device Id = (0x[0-9a-fA-F]+)\s+'
                             r'FW Version = (\d+\.\d+\.\d+\.\d+)\s+'
                             r'SM API Version = (\d+\.\d+)')
        for handle, dev_id, fw_ver, smapi_ver in pattern.findall(output):
            return_dict[handle] = {'Device Id': dev_id,
                                   'FW Version': fw_ver,
                                   'SM API Version': smapi_ver}

        return return_dict

    def retrieve_coredump(self, target_idx: int = None, save_dir: str = None) -> str:
        """Retrieve coredump file from VM to <save_dir>. Returns filepath of the saved coredump.

        :param target_idx:  Index of target to run command on
        :param save_dir:    Directory to save coredump file to
        """
        temp_dir = '/tmp/'
        try:
            self.cmd('-getcoredump', target_idx=target_idx, working_dir=temp_dir)
        except Exception:
            log.exception('Failed to retrieve coredump')
            raise

        coredump_filename = 'coredump.bin'
        save_dir = (save_dir or os.getcwd()).rstrip('/') + '/'
        remote_filepath = os.path.join(temp_dir, coredump_filename)
        local_filepath = os.path.join(save_dir, coredump_filename)
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        try:
            sftp = self.bmc.ssh.conn.open_sftp()
            sftp.get(remote_filepath, local_filepath)
            sftp.close()
            log.info(f'Coredump saved to {local_filepath}')
        except Exception:
            log.exception(f'Failed to download coredump')

        return local_filepath

    def get_temp(self, target_idx: int = None) -> int:
        """Return switch temperature in Celsius

        :param target_idx: Index of target to run command on
        :raises:           Exception if failed to parse temp from output
        """
        output = self.cmd('-temp', target_idx=target_idx)
        match = re.search(r'Switch Temperature = (\d+) C degree', output)
        if not match:
            log.debug(output)
            raise Exception('Failed to parse output for switch temperature')
        return int(match.group(1))

    def get_errors(self, target_idx: int = None) -> Union[str, Dict[int, Dict[str, Union[int, Dict]]]]:
        """Return dict of PCIe switch port error counters and flags for all ports

        Usage:
        >>> port_errors = bmc.slt.get_errors()
        >>> port_num = 16
        >>> port_errors[port_num]['counters']['BadDLLPErrors']
        0
        >>> port_errors[port_num]['status']['Correctable']['ReceiverError']
        True

        :param target_idx: Index of target to run command on
        :returns:          Dict of port error counters and flags, keyed by port number

        Example output:
        {16: {'Station Number': 1,
             'Station Port': 0,
             'Global Id': 16,
             'counters': {'BadTLPErrors': 0,
                          'BadDLLPErrors': 0,
                           ...},
             'status':   {'Error Status': {'CorrectableErrorDetected': False,
                                           'NonFatalErrorDetected': False,
                                           ...},
                          'Uncorrectable': {'DataLinkProtocolError': True,
                                            'SurpriseDownError': True,
                                            ...},
                          'Correctable': {'ReceiverError': True,
                                          'BadTLP': True,
                                          ...}
             }, ...
         }
        """
        output = self.cmd('-swerr', target_idx=target_idx)

        return_dict = {}
        ports_pattern = re.compile(r'Port Number\s*:\s*(\d+)\s+((?:^(?!Port Number).*?\n)+)', re.MULTILINE)
        port_info_pattern = re.compile(r'(\w[ \w]+)\s:\s*(\d+)')
        counter_pattern = re.compile(r' {4}(\w+):\s+(\d+)')
        statuses_pattern = re.compile(r'Port \d+ Advanced Error Status:\n([\s\S]+)')
        status_type_pattern = re.compile(r' {2}([\w ]+):\n((?:^(?! {2}\w).*?\n)+)', re.MULTILINE)
        status_pattern = re.compile(r'\s+(\w+):\s*([YN])')
        for port_num, port_info in ports_pattern.findall(output):
            port_num = int(port_num)
            return_dict[port_num] = {'counters': {}, 'status': {}}

            # Parse port info (e.g. Station Number, Station Port, Global Id)
            for key, val in port_info_pattern.findall(port_info):
                return_dict[port_num][key] = int(val)

            # Parse error counters
            for key, val in counter_pattern.findall(port_info):
                return_dict[port_num]['counters'][key] = int(val)

            # Parse error statuses
            error_status_info = re.search(statuses_pattern, port_info).group(1)
            for err_type, err_statuses in status_type_pattern.findall(error_status_info):
                return_dict[port_num]['status'][err_type] = {}
                for key, val in status_pattern.findall(err_statuses):
                    if val in ['Y', 'N']:
                        val = (val == 'Y')
                    return_dict[port_num]['status'][err_type][key] = val

        return return_dict
