"""
:mod:`bnxtnvm` -- The test script template
===========================================

.. module:: controller.lib.linux.system.bnxtnvm
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

import os
import re

from controller.lib.common.shell import exe
from controller.lib.core import log_handler
from distutils.spawn import find_executable
from controller.lib.core import exception

log = log_handler.get_logger(__name__)


class BaseBnxtnvm(object):
    def __init__(self, iface=None, bnxtnvm_path=None):
        """
        Args:
             bnxtnvm_path (str): bnxtnvm  path
             iface (str): ethX name.

        """
        self._iface = iface
        self.__exe = exe

        if bnxtnvm_path is None:
            self._prg_path = find_executable('bnxtnvm')
        else:
            self._prg_path = bnxtnvm_path

        if self._prg_path is None:
            raise exception.ConfigException('bnxtnvm is not available')

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the bnxtnvm command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the bnxtnvm command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running bnxtnvm command over SSH.
            When None, the SSH mode is exited.
        """
        from controller.lib.linux.system import ssh

        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def install(self, pkg, installation_type, **kwargs):
        """Install package

        Args:
            pkg (str): pkg file
            installation_type (dict): Type of installation

        Return:
            int: 0=successful and no reboot required, 1=successful and
                reboot required
        """
        if not self._iface:
            raise ValueError('"iface" parameters are required')

        log.info('Install %s' % pkg)
        kwargs['-y'] = None

        if isinstance(installation_type, dict):
            if installation_type['force'] == 'True':
                kwargs['-force'] = None

            if installation_type['live'] == 'True':
                kwargs['-live'] = None
        else:
            if installation_type == "live":
                kwargs['-live'] = None

            if installation_type == 1:
                kwargs['-force'] = None

        output = self.run(install=pkg, **kwargs)
        return output

    def online(self, **kwargs):
        """
        :param kwargs:
        :return: returns the output of the online command
        """
        kwargs['-online'] = None
        kwargs['-force'] = None
        kwargs['-y'] = None

        output = self.run(install=None, **kwargs)
        return output

    def verify(self, pkg=None, **kwargs):
        """Verify package

        Args:
            pkg (None, str): If None, run without a package name otherwise
                pass the package name as an argument to bnxtnvm
        """
        if not self._iface:
            raise ValueError('"iface" parameters are required')

        log.info('Verify NVM contents')
        output = self.run(verify=pkg, **kwargs)
        log.info('FW verify output:%s' % output)
        return output

    def pkgver(self, pkg=None, **kwargs):
        """Return a package version info

        Args:
            pkg (None, str): If None, does not pass the package argument
                otherwise pass it

        Return:
            dict: key=Firmware component name, value=Firmware component version
            list of tuples: [(active_version,nvm_version)]
        """
        output = self.run(pkgver=pkg, **kwargs)
        active_version = re.findall(r'Active Package version\s+:\s+(.*)', output)
        nvm_version = re.findall(r'Package version on NVM\s+:\s+(.*)', output)
        adapter_info = dict()
        if pkg:
            pkg_version = re.findall('Package version: (.*)', output)
            adapter_info['Package version'] = str(pkg_version[0])

        devid = self.devid()
        log.info('dev_id:%s' % devid[1])

        if active_version or nvm_version:
            adapter_info['Active Package version'] = str(active_version[0])
            adapter_info['Package version on NVM'] = str(nvm_version[0])
            chip_number = self.device_info()["Chip_Number"].replace("\r", "").strip()
            adapter_type = self.verify_chip(chip_number)
            if adapter_type == 'Thor':
                srt_ver_primary = re.findall(r'Primary SRT Version\s*:\s*([\w\.]*)', output)
                crt_ver_primary = re.findall(r'Primary CRT Version\s*:\s*([\w\.]*)', output)
                srt_ver_secondary = re.findall(r'Secondary SRT Version\s*:\s*([\w\.]*)', output)
                crt_ver_secondary = re.findall(r'Secondary CRT Version\s*:\s*([\w\.]*)', output)
                log.info('srt_vers[0]:%s, srt_vers[1]:%s' % (srt_ver_primary, srt_ver_secondary))
                log.info('crt_vers[0]:%s, crt_vers[1]:%s' % (crt_ver_primary, crt_ver_secondary))

                if len(srt_ver_primary) and len(crt_ver_primary) and len(srt_ver_secondary) and len(crt_ver_secondary):
                    adapter_info['Primary SRT Version'] = str(srt_ver_primary[0])
                    adapter_info['Primary CRT Version'] = str(crt_ver_primary[0])
                    adapter_info['Secondary SRT Version'] = str(srt_ver_secondary[0])
                    adapter_info['Secondary CRT Version'] = str(crt_ver_secondary[0])
            return adapter_info
        return adapter_info

    def devid(self, pkg=None, **kwargs):
        """Return a devid

        Args:
            pkg (None, str): If given, return the devid of the package
                otherwise return the local system's devid

        Return:
            tuple: vendor id, device id, sub vendor id, sub device id

        """
        output = self.run(devid=pkg, **kwargs)
        regexp = re.compile(r'PCI-ID: ([0-9a-f]+):([0-9a-f]+):([0-9a-f]+):([0-9a-f]+)')
        # legacy
        if regexp.search(output):
            return regexp.search(output).groups()
        # new format
        regexp = re.compile(
            r'''PCI VendorID\s+:\s+([0-9a-f]+)
PCI DeviceID\s+:\s+([0-9a-f]+)
PCI Subsys VendorID\s+:\s+([0-9a-f]+)
PCI Subsys DeviceID\s+:\s+([0-9a-f]+)''')

        if regexp.search(output):
            return regexp.search(output).groups()

        # windows format
        regexp = re.compile(r'PCI VendorID\s+:\s+([0-9a-f]+)\s+PCI DeviceID\s+:\s+([0-9a-f]+)\s+PCI Subsys'
                            r' VendorID\s+:\s+([0-9a-f]+)\s+PCI Subsys DeviceID\s+:\s+([0-9a-f]+)')
        if regexp.search(output):
            return regexp.search(output).groups()

        return None

    def reset(self, parse_op=True):
        """Reset the given device. Available only on Linux for rest raises Error

        Args: None

        Return:
            On success return True else False

        """
        output = self.run(reset=None)
        if parse_op:
            if 'Reset command executed' in output or 'Device Hot Reset Completed Successfully' in output\
                    or 'Device reset issued successfully' in output:
                return True

            return False
        else:
            return output

    def get_version(self):
        cmd = self._prg_path + ' version'
        output = self.__exe.block_run(cmd, shell=True)
        version = re.search(r'Version v(.*)', output).groups()[0]
        if version != None:
            return version

        return None

    def reset_ap(self):
        """Resets the application processor. Available only on Linux for rest raises Error

        Args:  None

        Return:
            On success return True else False

        """
        output = self.run(reset_ap=None)

        if 'Command Executed Successfully' in output:
            return True

        return False

    def flow_reset(self):
        """Resets the CFA flows of the device.

        Args:  None

        Return:
            On success return True else False

        """
        output = self.run(flow_reset=None)

        if 'Command Executed Successfully' in output:
            return True

        return False

    def listdev(self):
        """
        Returns listdev output

        Args: None

        Return:
            Returns the output of listdev commond
        """
        cmd = self._prg_path + ' listdev'
        output = self.__exe.block_run(cmd, shell=True)
        log.debug('output is : %s' % output)
        return output
#         regexp = re.compile(
#             '''Broadcom\s(.*)
# Device Interface Name\s+:(.*)
# MACAddress\s+:(.*)
# PCI Device Name\s+:(.*)''')
#         if regexp.search(output):
#             return regexp.search(output).groups()

    def pcie_counters(self):
        """
        Collects and returns the PCIe Counters

        Args: None

        Return:
            Returns a dictionary with key as Counter name and value as Counter value
        """
        output = self.run(pcie_counters=None)
        log.debug('output is: %s' % output)
        pcie_counter_dict = {}
        for line in output.split('\n'):
            if 'PCIe Counters' not in line or line is not None:
                match = re.search(r'(.*)\s+:\s+(.*)', line)
                pcie_counter_dict[match.group(1).strip()] = match.group(2).strip()

        return pcie_counter_dict

    def saveoptions(self):
        """
        Generates the file with saveoptions

        Args: None

        Return:
             Returns the file name which is generated with saveoptions command
        """
        cmd = self._prg_path + ' -dev=' + self._iface + ' saveoptions ' + self._iface+'.sh'
        output = self.__exe.block_run(cmd, shell=True)
        nvm_opt_file_name = re.search(r'All NVM options are saved to (.*\.sh)', output).group(1)
        nvm_opt_file_name = os.path.abspath(nvm_opt_file_name)
        return nvm_opt_file_name

    def device_temperature(self):
        """
        Returns the Temperature output

        Args: None

        Return:
            Returns output of the device_temperature command output
        :return:
        """
        output = self.run(device_temperature=None)
        return output
            
    def get_backup_power_config(self):
        """
        Get backup power configuration parameters of the device. This is applicable only for NX-S devices

        Args: None

        Return:
            Return output in dictionary format where key is power description and value power counter
        """
        output = self.run(get_backup_power_config=None)
        backup_power_config_dict = {}
        for line in output.split('\n'):
            match = re.search(r'(.*)\s +=\s + (.*)', line)
            backup_power_config_dict[match.group(1).strip()] = match.group(2).strip()

        return backup_power_config_dict

    def module_info(self):
        """
        Returns Module info

        Args: None

        Return:
            Return output as dict with module information
        """
        output = self.run(moduleinfo=None)
        if 'moduleinfo command not supported on this platform' in output:
            log.error('Module info is supported on this platform')
            return False
        module_info_dict = {}
        regexp = re.compile(
            r'''DAC Cable Length\s+:\s(.*)
DAC Cable AWG Information\s+:\s(.*)
Cable insertion loss\s+:\s(.*)''')

        if regexp.search(output):
            module_info_dict['Cable_Length'] = regexp.search(output).groups()[0]
            module_info_dict['Cable_AWG_Information'] = regexp.search(output).groups()[1]
            module_info_dict['Cable_Insertion_Loss'] = regexp.search(output).groups()[2]
            return module_info_dict

    def get_mtu(self, pf_num):
        """
        Queries MTU of requested PF/VF

        Args: pf_num -> Takes PF number of the adapter as argument

        Return:
            Returns MTU value

        """
        cmd = self._prg_path + ' -dev=' + self._iface + ' get_mtu pf ' + str(pf_num)
        log.info('cmd: %s' % cmd)
        output = self.__exe.block_run(cmd, shell=True)
        mtu = re.search('MTU :(.*)', output).group(1)
        return mtu

    def set_mtu(self, pf_num, mtu):
        """
        Configures MTU of requested PF/VF

        Args:
            pf_num  -> Takes PF number of the adapter as argument
            mtu     -> MTU value to configure

        Return:
            Returns the status of the operation as True or False

        """
        cmd = self._prg_path + ' -dev=' + self._iface + ' set_mtu ' + str(mtu) + ' pf ' + str(pf_num)
        log.info('cmd:%s' % cmd)
        output = self.__exe.block_run(cmd, shell=True)

        if re.search(r'Command Executed Successfully', output):
            log.info('mtu for pf:%s set to %s successfully' % (pf_num, mtu))
            return True
        else:
            log.error('mtu for pf:%s failed to set to %s' % (pf_num, mtu))
            return False

    def resmgmt_set(self, bw_type=None, bw_list=None, profile=None, strategy=None):
        """
        Query and Configure resources of the device

        :param bw_type:
        :param bw_list:
        :param profile:
        :param strategy:
        :return: Returns True or False based on the result Set operation
        """
        if bw_list and bw_type:
            bwlist_num = len(bw_list)
            cmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt ' + bw_type
            output = self.__exe.block_run(cmd, shell=True).strip().split('\n')
            pf_num = sum(1 for s in output if 'PF' in s)

            if bwlist_num != pf_num:
                log.error('Provided Bandwidth %s is not equal to PF %s on the adapter' % (bwlist_num, pf_num))
                return False

            bwcmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt ' + bw_type + " " + \
                ' '.join(str(x) for x in bw_list)
            log.info('Executing the Set command %s' % bwcmd)
            resmgmt_result = self.__exe.block_run(bwcmd, shell=True).strip().split('\n')

        elif profile:
            log.info('Setting Profile to %s' % profile)
            procmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt profile ' + profile
            resmgmt_result = self.__exe.block_run(procmd, shell=True).strip().split('\n')

        elif strategy:
            strategy_num = len(strategy)
            cmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt strategy'
            output = self.__exe.block_run(cmd, shell=True).strip().split('\n')
            pf_num = sum(1 for s in output if 'PF' in s)

            if strategy_num != pf_num:
                log.error('Provided strategy values %s are not equal to PF %s on the adapter' % (strategy_num, pf_num))
                return False
            log.info('Setting Strategy to %s' % strategy)
            strcmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt strategy ' + ' '.join(str(x) for x in strategy)
            resmgmt_result = self.__exe.block_run(strcmd, shell=True).strip().split('\n')

        else:
            log.error("Please provide bw_type or profile or strategy to set values")
            return False

        if any("Successfully" in line for line in resmgmt_result):
            log.info('Resource management Set operation completed Successfully')
            return True
        else:
            log.warning('Unexpected output seen with resmgmt command')
            return False

    def resmgmt_get(self, bw_type=None, profile=None, strategy=None):
        """
        Query and Configure resources of the device

        :param bw_type:
        :param profile:
        :param strategy:
        :return:
        """
        pf = []
        if bw_type:
            cmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt ' + bw_type

        elif profile:
            cmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt profile'

        elif strategy:
            cmd = self._prg_path + ' -dev=' + self._iface + ' resmgmt strategy'
        else:
            log.error("Please provide bw_type or profile or strategy to get values")
            return False

        resmgmt_result = self.__exe.block_run(cmd, shell=True).strip().split('\n')

        for line in resmgmt_result:
            if 'PF' in line:
                arr = line.split()
                pf.append(arr[3])
            elif 'Profile' in line:
                arr = line.split(':')
                return arr[1].strip()

        if pf:
            return pf
        else:
            log.warning('Unexpected output seen with resmgmt command')
            return False

    def device_info(self, dev_info=None, **kwargs):
        """
        Query Broadcom device(s) information and default hardware resources profile version

        :param dev_info:
        :param kwargs:
        :return: Returns Dictionary with Device information
        """
        output = self.run(device_info=dev_info, **kwargs)
        my_dict = {}
        arr = re.findall(r'(.*)\s:(.*)', output)

        if arr:
            for key, value in arr:
                key = key.strip()
                value = value.strip()
                key = re.sub(r'\s', "_", key)
                my_dict[key] = value

        return my_dict

    def set_option(self, option_string, option_value, device=False, function_value="0", validation=True):
        """
        Set NVM configuration option of a device

        :param option_string: Name of NVM option
        :param option_value: Value for the NVM option
        :param device: option is Device specific or function specific
        :param function_value: if option supports function's then function number
        :param validation: bool type, True for checking 'successfully' message after Set operation
                           False to retrun output message of Set operation
        :return: if validation is True:
                   Returns True or False based on the result Set operation
                 if validation is False: 
                   Returns output message after Set operation
        todo : Implement to dynamically take the Device value
        """

        if device:
            option_list = '%s#%s' % (option_string, option_value)
        else:
            option_list = '%s:%s#%s' % (option_string, function_value, option_value)

        output = self.run(setoption=option_list)

        if validation:
            if 'successfully' in output:
                return True
            log.error("Setting option failed")
            return False
        return output

    def get_option(self, option_string, device=False, function_value="0"):
        """
        Get NVM configuration option of a device
        :param option_string: Name of NVM option
        :param device: option is Device specific or function specific
        :param function_value: if option supports function's then function number
        :return: Returns the value of the NVM option requested
        todo : Implement to dynamically take the Device value
        """

        if device:
            option_list = '%s' % option_string
        else:
            option_list = '%s:%s' % (option_string, function_value)

        output = self.run(getoption=option_list)
        return output.split('=')[1].strip()

    def get_option_help(self):
        """
        Get NVM configuration option of a device
        :return: Returns Dictionary of NVM Options and its Scope
        """
        option_list = '?'
        output = self.run(getoption=option_list)
        output = output.split('\n')
        get_option_dict = {}
        pattern = re.compile(r'(\w+)\s{2,}(\w+)')
        for each_line in output:
            match = pattern.match(each_line)
            if match:
                get_option_dict[match.group(1)] = match.group(2)

        return get_option_dict

    def get_option_help_detail(self, option=None):
        """
         Get NVM configuration option detail of a device
        :return: Returns output of the support option details
        """
        option_list = '?' if option == None else option
        output = self.run(optionhelp=option_list)
        return output

    def tunnel_redirect(self, method, tunnel_type, vf_index):
        """
        This function will add/delete tunnel on given VF index
        :param method:
        i) add_tunnel_redirect
        ii) del_tunnel_redirect
        :param tunnel_type:
        i) vxlan_ipv4
        ii) vxlan_ipv6
        :param vf_index is VF# on which opration has to be perform
        """
        command = (" %s %s vf %s" % (method, tunnel_type, str(vf_index)))
        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)

        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                return True
            else:
                return False

    def tunnel_cfg(self, tunnel_type, tunnel_port=None):
        """
        :param tunnel_type:
        i) vxlan_ipv4
        ii) vxlan_ipv6
        :param tunnel_port:
        :return: Returns True or False based on status of command output
        """
        tunnel_type = str(tunnel_type)

        if not tunnel_port:
            # This will be used to free the tunnel port
            command = (" cfgtunnel %s dst_port" % tunnel_type)
        else:
            tunnel_port = str(tunnel_port)
            # This will be used to set tunnel configuration
            command = (" cfgtunnel %s dst_port %s" % (tunnel_type, tunnel_port))

        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)

        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                return True
            else:
                return False

    def query_tunnel_cfg(self, tunnel_type):
        """
        :param tunnel_type:
        i) vxlan_ipv4
        ii) vxlan_ipv6
        :return:
        """
        tunnel_port = ''
        command = (" cfgtunnel %s" % str(tunnel_type))
        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)

        for each_line in command_output.split('\n'):
            if ":" not in each_line:
                continue

            tunnel_port = each_line.split(":")[1]

        return tunnel_port

    def vfs_trust(self, vf_index, trust_type):
        """
        :param vf_index:
        :param trust_type:
        i) trust enable
        ii) trust disable
        :return:
        todo: Add verification for Trust enable command output
        """
        test_status = False
        command = (" vf %s %s" % (str(vf_index), trust_type))
        cmd = self._prg_path + ' -dev=' + self._iface + command
        self.__exe.block_run(cmd)

        # Querying VF trust configuration
        command = (" vf %s trust" % str(vf_index))
        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)

        for each_line in command_output.split('\n'):
            if trust_type == "trust enable":
                if "Enabled" in each_line:
                    test_status = True
                    continue
            else:
                if "Disabled" in each_line:
                    test_status = True
                    continue

        return test_status

    def get_vf_trust(self, vf_index):
        """
        Get the trust state of the specified VF.

        Args:
            vf_index: The ID of the VF to get the trust state of.
        Return:
            trust_state: True if trust is enabled; False otherwise.
        """
        command = self._prg_path + ' -dev=' + self._iface + (" vf %s trust" % str(vf_index))
        command_output = self.__exe.block_run(command, shell=True)
        trust_state = True if 'Enabled' in command_output else False
        return trust_state

    def get_vf_queue(self, vf_index):
        """
        :param vf_index:
        This function will return list of values in dictionary format
        :return Returns Dictionary with the vf_queues values
        """
        command = (" get_vf_queues vf %s" % str(vf_index))
        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)
        my_dict = {}
        arr = re.findall(r'(.*)\s:(.*)', command_output)

        if arr:
            for key, value in arr:
                my_dict[key] = value

        return my_dict

    def set_vf_queue(self, vf_index, min_txq, max_txq, min_rxq, max_rxq):
        """
        :param vf_index:
        :param min_txq:
        :param max_txq:
        :param min_rxq:
        :param max_rxq:
        :return:
        """
        from controller.lib.linux.eth import ip
        command = ("set_vf_queues vf %s min_txq %s max_txq %s min_rxq %s max_rxq %s"
                   % (str(vf_index), str(min_txq), str(max_txq), str(min_rxq), str(max_rxq)))
        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)

        if 'successfully' in command_output:
            ip.set_vf_state(self._iface, vf_index, 'disable')
            ip.set_vf_state(self._iface, vf_index, 'auto')
            return True
        else:
            return False

    def core_dump(self, ddr=''):
        """
        Generate core dump file (.core). The .core file would be generated in the current
        working directory.

        Return:
            core_file_name: The name of the .core file generated on success; None on any failure.
        """
        core_file_name = None
        try:
            command = self._prg_path + ' -dev=%s coredump %s' % (self._iface, ddr)
            command_output = self.__exe.block_run(command, shell=True)
            core_file_name = re.search(r'Generated CoreDump file (.*\.core)', command_output).group(1)
            core_file_name = os.path.abspath(core_file_name)
        except Exception:
            pass

        return core_file_name

    def inject_error(self, error_type="crash null_ptr"):
        """
        :param error_type: type of error
        supported values by bnxtnvm:
        i) crash null_ptr
        ii) srt crash null_ptr
        :return:
        """
        command = '%s -dev=%s fwcli "%s"' % (self._prg_path, self._iface, error_type)
        return self.__exe.block_run(command, shell=True)

    def backup(self):
        """
        Generate nvm contents in a package file(.pkg). The .pkg file would be generated in
        the current working directory.

        Return:
            pkg_file_name: The name of the .pkg file generated on success; None on any failure.
        """
        pkg_file_name = None
        try:
            command = self._prg_path + ' -dev=%s backup' % self._iface
            command_output = self.__exe.block_run(command, shell=True)
            pkg_file_name = re.search(r'Package file (.*\.pkg)', command_output).group(1)
            pkg_file_name = os.path.abspath(pkg_file_name)
        except Exception:
            pass

        return pkg_file_name

    def run(self, **kwargs):
        """Run bnxtnvm using given keyword arguments.

        key = option, value=value. If value is None, no value is passed. For
        example,

        run(view=None) will run "bnxtnvm run" and
        run(view='file.pkg') will run "bnxtnvm run=file.pkg"

        Return:
            str: output of bnxtnvm

        """
        option_list = ['-dev=%s' % self._iface]

        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + '=' + value)

        try:
            output = self.__exe.block_run([self._prg_path] + option_list)
        except Exception as err:
            output = str(err)
            # CTRL-42474: Need console output for firmware upgrade for fw_upgrade testcases.
            # Log the output of bnxtnvm command in the error path. On the normal path,
            # block_run() would log the output.
            log.info(output)

        return output
    
    def verify_chip(self, chip_num):
        """
        Checks the Adapter type
        :param chip_num: Input the Chipnum from device_info
        :return: Returns the Adapter type like 'Thor', 'Wh' or 'Stratus'
        """
        thor_list = ['BCM57508', 'BCM57504', 'BCM57502']
        wh_list = ['BCM57412', 'BCM57414', 'BCM57416']
        stratus_list = ['BCM57454', 'BCM57452']

        if str(chip_num) in thor_list:
            adapter_type = 'Thor'
        elif chip_num in wh_list:
            adapter_type = 'Wh'
        elif chip_num in stratus_list:
            adapter_type = 'Stratus'
        else:
            return False
        return adapter_type

    def loopback(self, loopback_value=None, **kwargs):
        """
        Configure different loopback modes i.e. phy loopback, mac loopback and external loopback
        :param loopback_value:
        :param kwargs:
        :return:
        """
        if loopback_value:
            kwargs[loopback_value] = None
        output = self.run(loopback=None, **kwargs)
        if loopback_value:
            return output
        else:
            return output.split(':')[1].strip()

    def set_rss_hash_mode(self, rss_mode):
        """
        :param rss_mode:
        :return:
        """
        command = self._prg_path + ' -dev=%s cfgtunnel rss_mode %s' % (self._iface, rss_mode)
        command_output = self.__exe.block_run(command, shell=True)
        for each_line in command_output.split('\n'):
            if "Successfully" in each_line:
                return True
        return False
           
    def bnxtnvm_help(self):
        """
        bnxtnvm help option
        """
        command = '%s -dev=%s -h' % (self._prg_path, self._iface)
        return self.__exe.block_run(command, shell=True)
        
    def bnxtnvm_view(self, verbose=False):
        """
        verbose = if True, go for verbose view

        """
        if not verbose:
            cmd = '%s -dev=%s view' % (self._prg_path, self._iface)
        else:
            cmd = '%s -dev=%s -vvv view' % (self._prg_path, self._iface)
        output = self.__exe.block_run(cmd, shell=True)
        return output

    def bnxtnvm_list(self, num=False, typ=1, type_list=False):
        """
        num: list in concise format
        type: list all the FW package components and
        associated version details of the type mentioned.
        type_l: list type number to be specified

        """
        if num:
            cmd = '%s -dev=%s list -num' % (self._prg_path, self._iface)
            output = self.__exe.block_run(cmd, shell=True)
        elif type_list:
            cmd = '%s -dev=%s -type=%s list' % (self._prg_path, self._iface, typ)
            output = self.__exe.block_run(cmd, shell=True)
        else:
            cmd = '%s -dev=%s list' % (self._prg_path, self._iface)
            output = self.__exe.block_run(cmd, shell=True)
        return output

    def livepatch_commands(self, pkg=None, activate=False, deactivate=False,
                           secure_fw=False, common_fw=False, update=False):
        """

        Args:
            pkg: live_patch file path
            activate: to activate the live patch that is installed
            deactivate: to deactivate the live patch that is installed
            secure_fw: activate only secure Firmware live patch that is installed
            common_fw: activate only Common Firmware live patch that is installed
            update: install and update the live patch directly with out installing to nvm

        Returns: output of the live patch command executed

        """
        command = self._prg_path + ' -dev=' + self._iface + " livepatch"

        if deactivate is True and activate is False:
            command = command + " deactivate "
        elif deactivate is False and activate is True:
            command = command + " activate "
        elif deactivate is True and activate is True:
            raise Exception("Both activate and deactivate together can not be executed with livepatch")

        if secure_fw is True and common_fw is False:
            command = command + " secure_fw "
        elif common_fw is True and secure_fw is False:
            command = command + " common_fw "
        elif common_fw is True and secure_fw is True:
            raise Exception("Both secure_fw and common_fw cannot activated indivdually at the same time")

        if update:
            if pkg is None:
                raise Exception("Provide valid livepatch package")
            command = command + " update " + pkg

        output = self.__exe.block_run(command, shell=True)
        return output

    def fwcli_commands(self, fwcli_string):
        """

        Args:
            fwcli_string: provide the fwcli command to be executed

        Returns: bnxtnvm -dev=<iface> fwcli <fwcli_string> command output

        """
        command = self._prg_path + ' -dev=' + self._iface + ' fwcli ' + '"{}"'.format(fwcli_string)
        output = self.__exe.block_run(command, shell=True)
        return output
        
    def fw_sync(self, **kwargs):
        output = self.run(fw_sync=None, **kwargs)
        return output

    def factory_defaults(self, force=True):
        """
        Restores NVM configuration to factory defaults. This command is supported only on BCM9575xxx devices
        :param force: Runs the command with force option
        :return:
        """
        command = " restore_factory_defaults" + (" -y" if force else "")
        cmd = self._prg_path + ' -dev=' + self._iface + command
        command_output = self.__exe.block_run(cmd)
        if "Restored NVM Factory Defaults" in command_output:
            log.info('Factory defaults executed successfully')
            return command_output
        else:
            log.error('Factory defaults operation Failed')
            return False

    def erase_crash_dump(self, ord=1.0):
        kwargs = {"erase": None, "-type": "CrashDmpData", "-ord": str(ord)}
        output = self.run(**kwargs)
        return output

    def erase_nvm_component(self, nvm_item, ord_idx):
        """
        Erase nvm component passed
        Args:
            nvm_item: nvm item to be erased
            ord_idx: ord index of the nvm item
        Returns: Return True or False based on the output parsing

        """
        kwargs = {"erase": None, "-type": nvm_item, "-ord": str(ord_idx)}
        output = self.run(**kwargs)
        return True if "Erasing NVM item" in output else False  # Output as per 229 SIT


def install(pkg, iface=None, **kwargs):
    return BaseBnxtnvm(iface=iface).install(pkg, **kwargs)


def verify(pkg=None, iface=None, **kwargs):
    return BaseBnxtnvm(iface=iface).verify(pkg=pkg, **kwargs)


def pkgver(iface=None, pkg=None, **kwargs):
    return BaseBnxtnvm(iface=iface).pkgver(pkg=pkg, **kwargs)


def devid(iface=None, pkg=None, **kwargs):
    return BaseBnxtnvm(iface=iface).devid(pkg=pkg, **kwargs)


def device_info(iface=None, **kwargs):
    return BaseBnxtnvm(iface=iface).device_info(**kwargs)


def set_option(iface, option_str, option_val, dev: bool = False, func_val: str = '0'):
    return BaseBnxtnvm(iface=iface).set_option(option_str, option_val, dev, func_val)


def get_option(iface, option_str, dev: bool = False, func_val: str = '0'):
    return BaseBnxtnvm(iface=iface).get_option(option_str, dev, func_val)
