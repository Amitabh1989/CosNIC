import logging
from controller.lib.common.shell import exe
from controller.lib.core import exception
from distutils.spawn import find_executable

log = logging.getLogger(__name__)

brctl_exe = find_executable('brctl')


def create_bridge(name: str):
    """Create a bridge interface.

    :param name: The name for the bridge interface.

    """
    log.info(f'Creating bridge: {name}.')
    command = f'{brctl_exe} addbr {name}'
    return exe.block_run(command)


def delete_bridge(name: str):
    """Delete the bridge interface.

    :param name: The name of the bridge interface to delete.

    """
    log.info(f'Deleting bridge: {name}.')
    command = f'{brctl_exe} delbr {name}'
    return exe.block_run(command)


def add_interface(name: str, interface: str):
    """Add an interface to the bridge.

    :param name: The name of the bridge to add the interface to.
    :param interface: The name of the interface to add to the bridge.

    """
    log.info(f'Adding interface {interface} to bridge {name}.')
    command = f'brctl addif {name} {interface}'
    return exe.block_run(command)


def delete_interface(name: str, interface: str):
    """Delete an interface from the bridge.

    :param name: The name of the bridge to delete interface from.
    :param interface: The interface to delete from the bridge.

    """
    log.info(f'Deleting interface {interface} from bridge {name}.')
    command = f'{brctl_exe} delif {name} {interface}'
    return exe.block_run(command)


def show_bridge_info(name: str = '') -> list:
    """Return the details of the bridge(s) in the below format.

    .. code-block:: python

        [
            {
                'bridge_name': 'bridge0',
                'bridge_id': '8000.886fd4895e2c',
                'stp_enabled': 'no',
                'interfaces': ['eno2', 'eno3']
            },
            {
                'bridge_name': 'bridge1',
                'bridge_id': '8000.52540055dbbe',
                'stp_enabled': 'yes',
                'interfaces': ['eno4']
            },
            {
                'bridge_name': 'bridge2',
                'bridge_id': '8000.000000000000',
                'stp_enabled': 'no',
                'interfaces': []
            }
        ]

    :param name: The name of the bridge to get the details of.
                 When None, details of all existing bridges is returned.

    :return: A list containing the details of the bridge(s).
    """
    bridge_name = f'bridge: {name}' if name else 'all existing bridges'
    log.debug(f'Getting details of {bridge_name}.')
    no_bridge_mark = ('does not exist!', 'No such device', 'Operation not supported')

    try:
        output = exe.block_run(f'{brctl_exe} show {name}')
    except exception.ExeExitcodeException as err:
        if any(_ in err.output for _ in no_bridge_mark):
            log.debug(f'No Bridge info has been detected for {bridge_name}. {err.output}')
            return []
        else:
            raise err  # e.g. brctl command not found.
    else:
        if any(_ in output for _ in no_bridge_mark):
            log.debug(f'No Bridge info has been detected for {bridge_name}.')
            return []

    out_lines = iter(output.splitlines())

    headers = ('bridge_name', 'bridge_id', 'STP_enabled', 'interfaces')
    check_valid_brinfo_headers(next(out_lines))

    results = []
    br_info = {}
    for line in out_lines:
        fields = line.split()
        if len(fields) > 1:
            # new bridge information. Add previously collected bridge info.
            if br_info:
                if 'interfaces' not in br_info:
                    br_info['interfaces'] = []
                results.append(br_info)
                br_info = {}

            for key, value in zip(headers, fields):
                br_info[key] = [value] if key == 'interfaces' else value
        else:
            # bridge has many interfaces, add next interface. 'interfaces' key must already added.
            if not br_info['interfaces']:
                raise UserWarning(f'Failed to parse brctl info. Unexpected line with single value {fields}.')

            br_info['interfaces'].append(fields[0])

    if br_info:
        if 'interfaces' not in br_info:
            br_info['interfaces'] = []
        results.append(br_info)
    log.debug(f'Bridge info for {bridge_name}: {results}.')
    return results


def check_valid_brinfo_headers(headers_line: str):
    """Check is line represent valid brinfo headers line.

    Typical headers line:
    "bridge name     bridge id               STP enabled     interfaces"

    Headers line may be without interfaces and with lower case stp.
    "bridge name     bridge id               stp enabled"

    :raises: UserWarning is not a valid headers line.
    """
    squeezed_line = headers_line.strip().replace('\t', '').replace(' ', '').lower()
    if squeezed_line.startswith('bridgenamebridgeidstpenabled'):
        return

    raise UserWarning(f'{headers_line} is not a valid brctl info headers line.')
