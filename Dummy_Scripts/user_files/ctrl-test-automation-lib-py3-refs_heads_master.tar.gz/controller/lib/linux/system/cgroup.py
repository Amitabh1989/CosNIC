"""
:mod:`cgroup` -- Library for configuring cgroups
================================================================================

.. module:: controller.lib.linux.system.cgroup
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

"""

import os
import time
from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)

class CGroup(object):
    def __init__(self):
        pass

    def mount(self):
        output = exe.block_run('mount')
        if output.find('cgroup') != -1:
            return True
        log.info('Mounting cgroups...')
        exe.block_run('mount -t cgroup -onet_prio none /sys/fs/cgroup/net_prio')

    def create_prio_dir(self, iface, prio):
        if not os.access('/sys/fs/cgroup/net_prio/', 0):
            raise exception.ConfigException('croups not found! Are you sure cgroups is mounted?')
        if os.access('/sys/fs/cgroup/net_prio/prio_%s_%s' % (iface, prio), 0):
            return True
        os.makedirs('/sys/fs/cgroup/net_prio/prio_%s_%s' % (iface, prio))

    def assign_prio(self, iface, prio):
        fo = open('/sys/fs/cgroup/net_prio/prio_%s_%s/net_prio.ifpriomap' % (iface, prio), 'w')
        fo.write('%s %s' % (iface, prio))
        fo.close()

    def set_session_task(self, iface, prio):
        # Get the session id
        # Use this to get the session ID till a better way is found
        s_id = exe.block_run('echo $$', shell=True).strip()  # Making the shell=True to execute this as a shell command
        fo = open('/sys/fs/cgroup/net_prio/prio_%s_%s/tasks' % (iface, prio), 'w')
        fo.write(s_id)
        fo.close()