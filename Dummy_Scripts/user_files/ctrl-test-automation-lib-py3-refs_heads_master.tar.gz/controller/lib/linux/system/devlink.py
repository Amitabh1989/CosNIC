"""
:mod:`devlink` -- devlink wrapper library.
==========================================
.. module:: controller.lib.linux.system.devlink
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>, majjiga.tharakanadha-reddy@broadcom.com

This is a wrapper module for devlink.
"""
import re
import logging
import json
from typing import Dict

from controller.lib.common.shell import exe
from controller.lib.linux.system import ssh
from controller.lib.core import exception
from distutils.spawn import find_executable

log = logging.getLogger(__name__)


class Devlink:
    """
    The class that implements the devlink command. The below listed devlink command are currently
    supported.

        - health
        - port
    """

    def __init__(self, app_path=None):
        """
        The Devlink constructor.
        """
        self.__exe = exe

        self.app_path = app_path or find_executable('devlink')
        if not self.app_path:
            raise exception.ConfigException('devlink not found; please install in system ')

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the devlink command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the devlink command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running devlink command over SSH.
            When None, the SSH mode is exited.
        """
        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def health(self):
        """
        The method that runs the health command.

        Return:
            health_data (dict): A dictionary containing various health related details of the pci
            devices.
        """
        command = f'{self.app_path} health -j'
        command_output = self.__exe.block_run(command)
        health_data = json.loads(command_output)

        return health_data

    def port(self):
        """
        The method that runs the port command.

        Return:
            port_data (dict): A dictionary containing various port details of the pci devices.
        """
        command = f'{self.app_path} port -j'
        command_output = self.__exe.block_run(command)
        port_data = json.loads(command_output)

        return port_data

    def set_truflow(self, pci_id, enable=True):
        """

        Args:
            pci_id: str (pci id of the nic example : 0000:af:00.0)
            enable: bool (enable or disable)

        Returns: None

        """
        command = f'{self.app_path} dev param set pci/{pci_id} name truflow value {str(enable).lower()} cmode runtime'
        command_output = self.__exe.block_run(command)
        log.debug(command_output)

    def get_truflow(self, pci_id: str) -> Dict[str, str]:
        """
        Return dict of values for truflow parameters: type, cmode, value

        Args:
            pci_id: str (pci id of the nic example : 0000:af:00.0)

        Returns: E.g. {'type': 'driver-specific', 'cmode': 'runtime', 'value': 'true'}
        Raises: Exception if failed to parse truflow parameters
        """
        command = f'{self.app_path} dev param show pci/{pci_id} name truflow'
        command_output = self.__exe.block_run(command)
        log.debug(command_output)
        pattern = rf'pci/(?:{pci_id}):\s+name truflow type (.+)\s+values:\s+cmode (.*) value (.*)'
        match = re.search(pattern, command_output)
        if match:
            truflow_type, cmode, value = match.groups()
            return {'type': truflow_type, 'cmode': cmode, 'value': value}
        raise Exception(f'Failed to parse truflow output for {pci_id}')

    def reload(self, pci_id):
        """
        Note : devlink reload command is not supported with Truflow enabled
        Args:
            pci_id: str (pci id of the nic example : 0000:af:00.0)

        Returns: None

        """
        command = f'{self.app_path} dev reload pci/{pci_id}'
        command_output = self.__exe.block_run(command)
        log.debug(command_output)
