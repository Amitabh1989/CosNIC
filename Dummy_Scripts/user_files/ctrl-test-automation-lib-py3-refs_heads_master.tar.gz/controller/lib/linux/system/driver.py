"""
:mod:`driver` -- The test script template
===========================================

.. module:: controller.lib.<DIR>.driver
.. moduleauthor:: Eugene Cho <echo@broadcom.com>
CTRL_48082: This file is deprecated
"""


from controller.lib.core import exception
from controller.lib.common.system.driver import BaseDriver
from controller.lib.linux.driver import install as lnx_drv


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


class LinuxDriver(BaseDriver):
    def __init__(self):
        super(LinuxDriver, self).__init__()
        self._handler = None
        self._handler_type = None

    @property
    def handler(self):
        return self._handler

    def install(self, filename):
        if filename.endswith('tar.gz'):
            self._handler = lnx_drv.SrcBase(filename=filename)
            self._handler_type = 'src'
        elif filename.endswith('.rpm'):                                     
            self._handler = lnx_drv.RPMBase(filename=filename)
            self._handler_type = 'rpm'
        elif filename.endswith('.deb'):
            self._handler = lnx_drv.DebBase(filename=filename)
            self._handler_type = 'deb'
        else:
            raise exception.ValueException(
                'Unsupported package type. Only support tar.gz')

        self.handler.install()

    def uninstall(self, driver_name):
        raise NotImplementedError

    def upgrade(self, filename, force=False):
        raise NotImplementedError

    def rollback(self, driver_name):
        raise NotImplementedError

    def is_installed(self, driver_name):
        raise NotImplementedError

    def get_version(self, driver_name):
        raise NotImplementedError

    def get_package_info(self, pkg_name):
        raise NotImplementedError


def install(filename):
    linux_driver = LinuxDriver()
    linux_driver.install(filename)
    
