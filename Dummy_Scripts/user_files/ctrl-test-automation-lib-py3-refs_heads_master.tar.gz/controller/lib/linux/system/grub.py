"""
.. module:: controller.lib.linux.system.grub
.. moduleauthor::

This is a wrapper method for grub commands.

Describe - iommu and intel_iommu/amd_iommu
To enable SR-IOV in the kernel, configure intel_iommu/amd_iommu=on in the grub file.
To get the best performance, add iommu=pt (pass-through) to the grub file when using SR-IOV.

"""

import logging
import sys
import fileinput
import pathlib
import os

from controller.lib.common.shell import exe
from distutils.spawn import find_executable
from controller.lib.core import exception

log = logging.getLogger(__name__)


class ConfigIOMMU(object):
    """
    configuring grub paramaters for SRIOV Environment
    """
    def set_iommu_passthrough(self, cpu_iommu, grub_cmdline):
        """
        Args:
            cpu_iommu: passes string based on BIOS_Vendor_ID i.e: intel/amd based on cpu type.
            grub_cmdline: specify line to be modified in grub file based on system-os type.
        """
        for line in fileinput.input('/etc/default/grub', inplace=True):
            if grub_cmdline not in line:
                sys.stdout.write(line)
                continue

            value = line.split('=', 1)[1].strip().strip('"')
            if cpu_iommu + '=' in line:
                if 'iommu=pt' in line:
                    log.info("Options are already present in GRUB.")
                else:
                    line = f'{grub_cmdline}="{value} iommu=pt"\n'
                    log.info("Options added to GRUB.")
                line = line.replace(cpu_iommu + '=off', cpu_iommu + '=on')
            else:
                line = f'{grub_cmdline}="{value} {cpu_iommu}=on iommu=pt"\n'
                log.info("Options added to GRUB.")
            sys.stdout.write(line)

    def update_sriov_grub(self):
        with open('/etc/os-release', 'r') as fd:
            os_release = fd.read()
            os_release_lower = os_release.lower()
            if 'debian' in os_release_lower or 'ubuntu' in os_release_lower:
                output = exe.block_run('update-grub')
                log.info(f'grub is updated: {output}')
            if ('redhat' in os_release_lower) or \
                    ('sles' in os_release_lower) or \
                    ('fedora' in os_release_lower) or \
                    ('centos' in os_release_lower):

                grub_cfg_paths = []
                grub_cfg_search_paths = ['/boot/grub2', '/boot/efi']
                for path in grub_cfg_search_paths:
                    if os.path.exists(path):
                        for dirpaths, dirnames, filenames in os.walk(path):
                            if 'grub.cfg' in filenames:
                                grub_cfg_paths.append(os.path.join(dirpaths, 'grub.cfg'))
                log.info(f'grub_cfg_paths : {grub_cfg_paths}')

                if grub_cfg_paths is None:
                    raise exception.ConfigException(f'Not able to find grub.cfg in paths {grub_cfg_search_paths}')
                else:
                    for grub_cfg in grub_cfg_paths:
                        if pathlib.Path(grub_cfg).exists():
                            output = exe.block_run(f'grub2-mkconfig -o {grub_cfg}')
                            log.info(f'grub is configured: {output}')
            else:
                log.warning('Unsupported OS distribution')

    def set_iommu_passthrough_using_grubby(self, cpu_iommu):
        """
        Executes and returns the status of the command
        :cpu_iommu: passes string based on BIOS_Vendor_ID i.e: intel/amd based on cpu type
        :return: Returns True or False based on output
        """
        log.info('updating grub using grubby')
        try:
            grub = Grubby()
            grub.update_parameter(add_param=f'{cpu_iommu}=on')
            grub.update_parameter(add_param='iommu=pt')
        except Exception:
            log.exception('Failed to Execute the command')
            return False

    def verify_grub(self, cpu_iommu):
        """
        Args:
            cpu_iommu: passes string based on BIOS_Vendor_ID i.e: intel/amd based on cpu type.
            returns bool ,checks for grub in cmdline if not enabled returns false
        """
        verify_cmdline = True
        with open('/proc/cmdline', 'r') as f:
            cmdline_params = f.read()

            if cpu_iommu+'=on' and 'iommu=pt' in cmdline_params:
                log.info(f'Grub is successfully updated for {cpu_iommu} Server')
            else:
                log.warning('iommu and passthrough is not enabled in grub')
                verify_cmdline = False

        return verify_cmdline


class Grubby(object):
    """
    Grubby is a utility used in Linux systems to manipulate and modify GRUB configuration files.
    """

    def __init__(self):
        """
            Fetch executable path for grubby
        """
        grubby_path = find_executable('grubby')
        if grubby_path is None:
            raise exception.ConfigException('grubby is not available')
        self.grubby_path = grubby_path

    def get_grub_config(self):
        """
            view current GRUB configuration
        """
        #View current GRUB configuration
        log.info("current GRUB configuration")
        output = exe.block_run(f"{self.grubby_path} --info=ALL")

        #default kernel
        log.info("default kernel")
        output = exe.block_run(f"{self.grubby_path} --default-kernel")

        #default index
        log.info("default index")
        output = exe.block_run(f"{self.grubby_path} --default-index")

    def set_default_index(self, index_value):
        """
            set default kernel index as per index value passed
        Args:
            index_value: passes integer based on kernel index that need to be booted.
        """
        #set default kernel index
        log.info(f'set default kernel index as {index_value}')
        output = exe.block_run(f"{self.grubby_path} --set-default-index={index_value}")

    def set_default_kernel(self, default_kernel):
        """
            set default kernel as per kernel passed
        Args:
            default_kernel: passes string, kernel that need to be set as default.
        """
        #set default kernel index
        log.info(f'set default kernel as {default_kernel}')
        output = exe.block_run(f"{self.grubby_path} --set-default {default_kernel}")

    def update_parameter(self, add_param, kernel=None):
        """
            add or modify kernel boot parameters.
        Args:
            add_param: passes string, parameter that need to be added in grub configuration.
            kernel: passes string, kernel to which parameter need to be added, by default it picks default kernel path
        """
        #default kernel path
        kernel_path = kernel or exe.block_run(f"{self.grubby_path} --default-kernel")
        default_path = kernel_path.strip()

        #add parameter
        output = exe.block_run(f"{self.grubby_path} --args='{add_param}' --update-kernel {default_path}")

    def remove_parameter(self, remove_param, kernel=None):
        """
            remove kernel boot parameters.
        Args:
            remove_param: passes string, parameter that need to be removed from grub configuration.
            kernel: passes string, kernel for which parameter need to be removed, by default it picks default kernel path
        """
        # default kernel path
        kernel_path = kernel or exe.block_run(f"{self.grubby_path} --default-kernel")
        default_path = kernel_path.strip()

        # add parameter
        output = exe.block_run(f"{self.grubby_path} --remove-args='{remove_param}' --update-kernel {default_path}")




