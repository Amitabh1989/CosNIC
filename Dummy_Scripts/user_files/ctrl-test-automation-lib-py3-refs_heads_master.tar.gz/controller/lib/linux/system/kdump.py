"""
:mod:`kdump` -- kdump wrapper library.
======================================
.. module:: controller.lib.linux.system.kdump
.. moduleauthor:: Surendra Reddy Narala <surendra-reddy.narala@broadcom.com>

This is a wrapper method for kdump commands.
"""

import fileinput
import glob
import logging
import pathlib
import re
import sys
import time

from controller.lib.common.shell import exe
from controller.lib.core import exception

log = logging.getLogger(__name__)


class Kdump:
    """
    The class that implements the kdump commands.
    """
    def __init__(self, crash_size=None, sysrq='/proc/sys/kernel/sysrq', sysrq_target='/proc/sysrq-trigger'):
        """
        The Kdump constructor.
        """
        self.crash_size = crash_size or self.get_estimated_crash_size()
        self.sysrq = sysrq
        self.sysrq_target = sysrq_target

    @staticmethod
    def crash_server():
        """
        The method that forces the system to crash.
        """
        exe.block_run(f'sysctl -w kernel.sysrq=1')
        cmd = 'echo c > /proc/sysrq-trigger'
        exe.block_run(cmd, shell=True)

    @staticmethod
    def modify_sysctl_cfg(panic_opts=None):
        """
        Sets the crash trigger panic options
        """
        panic_opts = panic_opts or {'kernel.unknown_nmi_panic': 1, 'kernel.panic_on_io_nmi': 1,
                                    'kernel.panic_on_unrecovered_nmi': 1}
        for opt, value in panic_opts.items():
            exe.block_run(f'sysctl -w {opt}={value}')

    def check_crashkernel_config(self):
        """
        verifies for optimum crash mem size

        return: bool, True if already set else False
        """
        output = exe.block_run('cat /proc/cmdline')
        log.info(f'/proc/cmdline is {output}')
        crashkernel = re.search(r'crashkernel=(.*)\s+', output).group(1)
        if f':{self.crash_size}' in crashkernel:
            return True
        else:
            return False

    @staticmethod
    def start_kdump_service():
        command = 'systemctl restart kdump'
        exe.block_run(command)

    @staticmethod
    def verify_kdump_service():
        """
        checks for kdump service status

        return: bool, True if kdump service is active else False
        """
        try:
            output = exe.block_run('systemctl status kdump')
        except:
            log.error('Kdump is not enabled on the machine')
            return False
        if 'Kdump is operational' in output or 'Active: active' in output:
            log.info('Kdump service is running')
            return True
        raise exception.ConfigException('Kdump service is not running')

    @staticmethod
    def get_estimated_crash_size():
        """
        Gets the optimal crash memory size

        return: int, crash dump memory size in MegaBytes
        """
        log.info(f'checking for optimal crashkernel memory')
        crash_mem_size = int(exe.block_run(f'cat /sys/kernel/kexec_crash_size')) // (1024 * 1024)
        return crash_mem_size


class Debian(Kdump):
    """
    Supports Debian platform
    """
    def get_kdump_files(self):
        """
        Gets the list of crash dump files list

        return: list of crash dump files
        """
        kdump_config = self.show_kdump_config()
        log_files = glob.glob(str(pathlib.Path(kdump_config['KDUMP_COREDIR']).joinpath('*')))
        return log_files

    def kdump_files_created(self, old_file_list):
        """
        Gets the list of newly created crash dump files
        input: old_file_list: list of crash dump files before crash
        return: list of crash dump files created
        """
        log_files = set(self.get_kdump_files()).difference(set(old_file_list))
        if log_files:
            log.info(f'crash logs are created')
            return True
        else:
            log.info(f'crash logs are not created')
            return False

    @staticmethod
    def update_grub():
        output = exe.block_run('update-grub')
        log.info(f'grub is updated: {output}')

    @staticmethod
    def show_kdump_config():
        """
        Returns the 'kdump-config show' in dict format
        return: kdump config dict
        """

        output = exe.block_run('kdump-config show')
        ret_dict = {}
        # To bring values spread over multiple lines, replacing \n\s+ with space.
        output = re.sub(r'\n\s+', ' ', output).split('\n')
        for line in output:
            time.sleep(2)
            if line.strip():
                key, value = line.split(':', 1)
                ret_dict[key.strip()] = value.strip()
        return ret_dict

    def check_kdump_config(self):
        """
        checks for the valid kdump config parameters

        return: bool, True if kdump config is configured aa expected else False
        """
        log.info('checking for kdump config')
        kdump_config = self.show_kdump_config()
        expected_config = {'DUMP_MODE': 'kdump', 'USE_KDUMP': '1', 'KDUMP_COREDIR': '/var/crash',
                           'current state': 'ready to kdump'}
        for key in kdump_config:
            if kdump_config[key] != expected_config[key]:
                return False
        return True

    def set_crashkernel_config(self):
        """
        Sets optimum crash dump mem size
        """
        crash_mem_size = self.get_estimated_crash_size()
        for line in fileinput.input('/etc/default/grub.d/kdump-tools.cfg', inplace=True):
            if 'GRUB_CMDLINE_LINUX_DEFAULT' in line:
                line = f'GRUB_CMDLINE_LINUX_DEFAULT="$GRUB_CMDLINE_LINUX_DEFAULT crashkernel=2G-:{crash_mem_size}M"'
            sys.stdout.write(line)

    @staticmethod
    def install_kdump_tools(modules=None):
        """
        installs modules needed to enable enable
        """
        modules = modules or ['kdump-tools', 'crash', 'kexec-tools', 'makedumpfile']
        log.info(f'Installing kdump-tools crash kexec-tools makedumpfile')
        exe.block_run(f'DEBIAN_FRONTEND=noninteractive apt install {" ".join(modules)}')


def get_kdump_handler(crash_size=None, sysrq=None, sysrq_target=None):
    """
    Factory method for platform based kdump class
    """
    with open('/etc/os-release', 'r') as fd:
        os_release = fd.read()
        if 'debian' in os_release.lower():
            return Debian(crash_size=crash_size, sysrq=sysrq, sysrq_target=sysrq_target)
        else:
            raise exception.ValueException('Unsupported OS distribution')
