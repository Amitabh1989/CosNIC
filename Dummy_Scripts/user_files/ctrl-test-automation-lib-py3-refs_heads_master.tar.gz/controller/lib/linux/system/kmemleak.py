"""
:mod:`kmemleak` -- kernel memory leaks module
===============================================

.. module:: controller.lib.common.system.kmemleak
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2023 Broadcom Inc"

import logging
import os

from controller.lib.common.shell import exe
from controller.lib.core import exception

log = logging.getLogger(__name__)


class KMemLeak(object):
    def __init__(self, memleakfile='/sys/kernel/debug/kmemleak', debug_path='/sys/kernel/debug/',
                 device='nodev', fstype='debugfs'):
        self.memleakfile = memleakfile
        self.debug_path = debug_path
        self.device = device
        self.fstype = fstype

        if os.path.exists(self.memleakfile) is False:
            raise exception.ConfigException('%s does not exists' % self.memleakfile)

        if os.path.exists(self.debug_path) is False:
            raise exception.ConfigException('%s does not exists' % self.debug_path)

    def scan(self):
        """
        Scan for kernel memory errors.
        """
        log.info(f'Scan for kernel memory errors')
        command = f'echo scan > {self.memleakfile}'
        return exe.block_run(command)

    def read_mem_leaks(self):
        """
        Read for kernel memory errors.
        """
        log.info(f'Read kernel memory errors')
        command = f'cat {self.memleakfile}'
        return exe.block_run(command)

    def clear(self):
        """
        Clear for kernel memory errors.
        """
        log.info(f'Clear kernel memory errors')
        command = f'echo clear > {self.memleakfile}'
        return exe.block_run(command)

    def mount_debugfs(self):
        """
        Mount debugfs
        """
        log.info(f'Mount debugfs')
        if self.debug_path in exe.block_run('mount'):
            log.info('debugfs is already mounted')
        else:
            command = f'mount -t {self.fstype} {self.device} {self.debug_path}'
            return exe.block_run(command)

    def unmount_debugfs(self):
        """
        un mount debugfs
        """
        log.info(f'un-mount debugfs device {self.device}')
        exe.block_run(f'umount {self.device}')
