"""
:mod:`lcdiag` -- The test script template
===========================================

.. module:: controller.lib.linux.system.lcdiag
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import time

from controller.lib.common.shell import exe
from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


class Lcdiag(object):
    def __init__(self, lcdiag_dir):
        self.lcdiag_dir = lcdiag_dir

    def exec_command(self, command_list):
        return exe.block_run(
            ['./load.sh', '-eval', '; '.join(command_list)],
            cwd=self.lcdiag_dir,
        )

    def upgrade_cfw(self, cfw_filename, force=False):
        log.info('Unload the driver ... ')
        exe.block_run('modprobe -r bnxt_en')

        self.exec_command(
            ['nvm upgrade ' + ('-F ' if force else '') + '-cfw ' + cfw_filename]
        )
        log.info('Sleep for 10 seconds to complete upgrade ... ')
        time.sleep(10)

    def get_chimp_trace(self):
        """Dump some useful information. For now, dump chimp trace"""
        return self.exec_command(
            ['chimp trace']
        )

    def nictest(self):
        log.info('Running nictest ... ')
        self.exec_command(['nictest -I 1'])
