"""
:mod:`pci` -- lstopo module
===========================================

.. module:: controller.lib.linux.system.lstopo
.. moduleauthor:: Sekhar Reddy <reddi-sekhar-reddy.kamalapuram@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import re
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class lstopo(object):
    def __init__(self, lstopo_path=None):
        """
        Args:
             lstopo_path (str): path of the lstopo tool
        """
        self._prg_path = lstopo_path or find_executable('lstopo')

        if self._prg_path is None:
            raise exception.ConfigException('lstopo is not available')

    def pcidev_info(self):
        """"
            Returns: list of all PCI devices and information
        """
        data = self.run()

        host_bridge_re = re.compile(r'\s*HostBridge')
        pci_bridge_re = re.compile(r'\s*PCIBridge')
        pci_re = re.compile(r'PCI ([\d\w:.]+) \(([\w]+)\)')
        net_re = re.compile(r'Net "([\w\d]+)"')
        openfabrics_re = re.compile(r'OpenFabrics "([\w\d_]+)"')

        # Dictionary to store parsed data
        parsed_data = []
        current_host_bridge = None
        current_pci_bridge = {}

        for line in data.splitlines():
            line = line.strip()
            if host_bridge_re.match(line):
                current_host_bridge = {}
                parsed_data.append(current_host_bridge)
            elif pci_bridge_re.match(line):
                if current_host_bridge is not None:
                    current_host_bridge['PCIBridge'] = current_pci_bridge
            else:
                pci_match = pci_re.match(line)
                net_match = net_re.match(line)
                openfabrics_match = openfabrics_re.match(line)

                if pci_match:
                    pci_id, pci_type = pci_match.groups()
                    current_pci_bridge[pci_id] = {'type': pci_type}
                elif net_match:
                    net_name = net_match.group(1)
                    current_pci_bridge[pci_id]['Net'] = net_name
                elif openfabrics_match:
                    openfabrics_name = openfabrics_match.group(1)
                    current_pci_bridge[pci_id]['OpenFabrics'] = openfabrics_name

        return parsed_data

    def run(self, **kwargs):
        option_list = []
        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + ' ' + value)

        output = exe.block_run(' '.join([self._prg_path] + option_list))
        return output


