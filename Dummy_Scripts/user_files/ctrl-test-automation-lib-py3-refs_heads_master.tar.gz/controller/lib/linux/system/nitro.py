"""
:mod:`nitro` -- nitro specific wrapper library.
===============================================
.. module:: controller.lib.linux.system.nitro
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for nitro specific commands.
"""
import time
import logging

from controller.lib.common.shell import exe
from controller.lib.linux.system import ssh

log = logging.getLogger(__name__)

class Nitro():
    """
    The class that implements the nitro specific commands. The below listed devlink command are
    currently supported.

        - firmware upgrade
    """
    def __init__(self, **kwargs):
        """
        The Nitro constructor.
        """
        self.__exe = exe
        self.__local_path = kwargs.get('local_path', '/tmp/nitro-fw')
        # Strip off the trailing '/' character.
        if self.__local_path[-1] == '/':
            self.__local_path = self.__local_path[:-1]

        self.__tool = kwargs.get('tool', 'optee_bcm_elog_fetch_app')

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the nitro command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the nitro command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running nitro command over SSH.
            When None, the SSH mode is exited.
        """
        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def load_fw(self, iface, fw_image_url, **kwargs):
        """
        The method that loads the nitro firmware image into the secure DDR. This will download the
        firmware image from the URL specified when:
            - Explicitly requested to do so.
            - A previously downloaded image doesn't exist.

        Args:
            iface (str): The name of the interface.
            fw_image_url (str): The URL to the nitro firmware image.
        """
        download = kwargs.get('download', False)
        fw_image = fw_image_url.rsplit('/')[-1]
        command = 'mkdir -p %s' % self.__local_path
        self.__exe.block_run(command)
        # Check if the firmware should be downloaded or not.
        if download is False:
            try:
                self.__exe.block_run('ls %s/%s' % (self.__local_path, fw_image))
            except Exception:
                download = True
        # Download the firmware if needed/requested.
        if download is True:
            command = 'wget -O %s/%s %s' % (self.__local_path, fw_image, fw_image_url)
            self.__exe.block_run(command)

        command = '%s load nitro %s/%s' % (self.__tool, self.__local_path, fw_image)
        self.__exe.block_run(command)
        time.sleep(1)
        command = 'ethtool --reset %s all' % iface
        self.__exe.block_run(command)

