"""
:mod:`pci` -- pci module
===========================================

.. module:: controller.lib.linux.system.pci
.. moduleauthor:: Surendra Narala <surendra-reddy.narala@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import re
from distutils.spawn import find_executable

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class LsPci(object):
    def __init__(self, bus_info=None, lspci_path=None):
        """
        Args:
             bus_info (str): bus_info of the device.
        """
        self._bus_info = bus_info
        self.__exe = exe

        if lspci_path is None:
            self._prg_path = find_executable('lspci')
        else:
            self._prg_path = lspci_path

        if self._prg_path is None:
            raise exception.ConfigException('lspci is not available')

    def use_ssh(self, ssh_ip_addr=None):
        """
        The function that selects the method to use to run the lspci command. If ssh_ip_address is
        specified, an SSH connection to that IP adress is established and that connection is used to
        run the lspci command. Otherwise, the usual shell exe module is used.

        Args:
            ssh_ip_addr (str): The IP address to use for running lspci command over SSH.
            When None, the SSH mode is exited.
        """
        from controller.lib.linux.system import ssh

        if ssh_ip_addr is not None:
            self.__exe = ssh.SSH(ssh_ip_addr)
        else:
            if isinstance(self.__exe, ssh.SSH):
                self.__exe.disconnect()

            self.__exe = exe

    def run(self, **kwargs):
        option_list = []
        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + ' ' + value)

        output = self.__exe.block_run(' '.join([self._prg_path] + option_list))
        return output

    def get_speed(self):
        """
        Returns LnkSta and LnkCap speeds for the pci bus.
        """
        cmd = '%s -s %s -vvv | grep Lnk' % (self._prg_path, self._bus_info)
        output = self.__exe.block_run(cmd, shell=True)

        pci_speed = {'LnkSta': None, 'LnkCap': None}
        if re.search(r'LnkSta:\s+Speed\s+(.+?),', output):
            pci_speed['LnkSta'] = re.search(r'LnkSta:\s+Speed\s+(.+?)\s', output).group(1)

        if re.search(r'LnkCap:\s+Port\s+#\d+,\s+Speed\s+(.+?),', output):
            pci_speed['LnkCap'] = re.search(r'LnkCap:\s+Port\s+#\d+,\s+Speed\s+(.+?),', output).group(1)

        return pci_speed

    def get_pci_devices(self, vendor='*', device='*', class_id=''):
        """

        @param vendor: (str) example : for broadcom cards it is 14e4
        @param device: (str) example : for broadcom cards it is 1750
        @param class_id: (str) example : for broadcom ethernet controller it is 02
        @return: (list) list of pci_devices for the given filter
        """
        cmd = f'{self._prg_path} -d {vendor}:{device}:{class_id}'
        output = self.__exe.block_run(cmd, shell=True)
        pci_devices = re.findall(r'[\da-fA-F]{2}:[\da-fA-F]{2}.[\da-fA-F]{1}', output)
        return pci_devices


class SetPci(object):
    def __init__(self, bus_info=None, setpci_path=None):
        """
        Args:
             bus_info (str): bus_info of the device.
             setpci_path (str): path of setpci
        """
        self._bus_info = bus_info
        self.__exe = exe

        if setpci_path is None:
            self._prg_path = find_executable('setpci')
        else:
            self._prg_path = setpci_path

        if self._prg_path is None:
            raise exception.ConfigException('setpci is not available')

    def run(self, **kwargs):
        option_list = []
        for key, value in list(kwargs.items()):
            if value is None:
                option_list.append(key)
            else:
                option_list.append(key + ' ' + value)

        output = self.__exe.block_run(' '.join([self._prg_path] + option_list))
        return output

    def get_reg_support(self, reg, width=None, width_type=None, verbose=False):
        """

        @param reg: (str) register name example: VENDOR_ID , ECAP_ACS
        @param verbose: (bool) execute the command in verbose or not
        @param width: (str) This indicates an offset of given bytes from the start of the register capability structure
        @param width_type: (str) supported width_types Byte (b), Word (w)
        @return: Bool
        """
        cmd = f"{self._prg_path} {'-v' if verbose else ''} -s {self._bus_info} {reg}"
        if width and width_type:
            cmd += '+' + width + '.' + width_type
        elif width or width_type:
            raise exception.ConfigException('Both width and width_type should be provided')
        cmd += '> /dev/null 2>&1'
        try:
            self.__exe.block_run(cmd, shell=True)
        except Exception:
            return False
        else:
            return True

    def get_reg_value(self, reg, width=None, width_type=None, verbose=False):
        """

        @param reg: (str) register name example: VENDOR_ID , ECAP_ACS
        @param verbose: (bool) execute the command in verbose or not
        @param width: (str) This indicates an offset of given bytes from the start of the register capability structure
        @param width_type: (str) supported width_types Byte (b), Word (w)
        @return: (str) register value for given register/width
        """
        cmd = f"{self._prg_path} {'-v' if verbose else ''} -s {self._bus_info} {reg}"
        if width and width_type:
            cmd += '+' + width + '.' + width_type
        elif width or width_type:
            raise exception.ConfigException('Both width and width_type should be provided')

        output = self.__exe.block_run(cmd, shell=True)

        return output

    def set_reg_value(self, reg, value, width=None, width_type=None, verbose=False):
        """

        @param reg: (str) register name example: VENDOR_ID , ECAP_ACS
        @param value: (str) value that needs to be assigned for the given register for the given width if provided
        @param verbose: (bool) execute the command in verbose or not
        @param width: (str)  This indicates an offset of given bytes from the start of the register capability structure
        @param width_type: (str) supported width_types Byte (b), Word (w)
        @return: (str) register value for the given width
        """
        cmd = f"{self._prg_path} {'-v' if verbose else ''} -s {self._bus_info} {reg}"
        if width and width_type:
            cmd += '+' + width + '.' + width_type
        elif width or width_type:
            raise exception.ConfigException('Both width and width_type should be provided')

        cmd += f'={value}'
        output = self.__exe.block_run(cmd, shell=True)
        return output
