"""
:mod:`ptrace' -- Library for in-band PTrace
==================================================

.. module:: controller.lib.linux.system.ptrace
.. moduleauthor:: Eric Lin <eric.lin@broadcom.com>

In-band PTrace API

Pre-requisite: NT Driver must be loaded

PID = PTrace device ID

Usage:
    Instantiate and install from local source zip
    >>> ptrace = PTrace()

    Get dict of PTrace devices
    >>> pids = ptrace.get_pids()

    Capture PTrace on PID 1
    >>> pid = 1  # Set to None to capture on all PIDs
    >>> ini_filepath = '/tmp/scrutiny_rel/PTRACE/ipalstruct.ini'
    >>> ptrace.load_ini(ini_filepath, pid=pid)
    >>> ptrace.start_capture(pid=pid)
    >>> time.sleep(3)
    >>> ptrace.retrieve_cfg(pid=pid)
    >>> ptrace.stop_capture(pid=pid, force=True)
    >>> ptrace.retrieve_trace(pid=pid)

    Get PTrace device info
    >>> pid1_info = ptrace.get_dev_info(pid=1)  # For PID 1
    >>> pall_info = ptrace.get_dev_info()       # For all PIDs

    Get Capture settings
    >>> pid1_settings = ptrace.get_dev_settings(pid=1)  # For PID 1
    >>> pall_settings = ptrace.get_dev_settings()       # For all PIDs

    Get Capture summary
    >>> pid1_capture_summary = ptrace.get_capture_summary(pid=1)  # For PID 1
    >>> pall_capture_summary = ptrace.get_capture_summary()       # For all PIDs

"""
import os
import re
from typing import Dict, List, Union

from controller.lib.common.shell import exe
from controller.lib.core import log_handler
from controller.lib.core import exception

__version__ = "1.0.0"
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

log = log_handler.get_module_logger(__name__)


class PTrace:
    TOOL_NAME = 'ptracecli.x86_64'

    def __init__(self, tool_path: str = None):
        self._prg_path = tool_path or find_executable(TOOL_NAME)
        self.target_idx = 1
        NT2_DRIVER = 'brcm_pex_nt2'

        try:
            exe.block_run(f'lsmod | {NT2_DRIVER}', shell=True)
        except Exception:
            log.error(f'NT driver {NT2_DRIVER} not loaded. Load driver before using {self.TOOL_NAME}')

    def get_device_list(self) -> Dict[int, Dict[str, str]]:
        """ Return dict of dicts for all devices found in ptracecli.x86_64 --list

        Sample raw output of "ptracecli.x86_64 --list"
        -------------------------------------------------------------------------------
        PTrace CLI v0.0.1.16 - Broadcom Inc. (c) 2024 (Bld-94.52.34.117.16.0)
        -------------------------------------------------------------------------------

             DeviceId/RevId      Serial Number      Device Name      Mode
          1) PEX 89000           C8E581FF           Atlas2           PCI

        Dict will contain the following keys (same as reported in ptracecli):
        - DeviceId
        - Serial Number
        - Device Name
        - Mode
        """
        pattern = r'\s*(\d+)\)\s*(PEX \d+)\s+(\w+)\s+(\w+)\s+(\w+)'
        output = exe.block_run(f'{self._prg_path} --list')
        dev_list = {}
        for switch_id, dev_id, serial_num, dev_name, mode in re.findall(pattern, output):
            dev_list[int(switch_id)] = {'DeviceId': dev_id,
                                        'Serial Number': serial_num,
                                        'Device Name': dev_name,
                                        'Mode': mode}
        return dev_list

    def run(self, cmd: str, target_idx: int = None) -> str:
        """Run PTrace command <cmd> on target <target_idx>

        :param cmd:        Command to run
        :param target_idx: Index of target
        :return:
        """
        target_idx = target_idx or self.target_idx
        cmd_str = f'{self._prg_path} -i {target_idx} {cmd}'
        log.info(f'Command: {cmd_str}')
        output = exe.block_run(cmd_str, silent=True)  # silent=True to prevent the host from logging the same message twice
        log.info(output)
        return output

    def get_pids(self, target_idx: int = None) -> Union[str, Dict[int, Dict[str, str]]]:
        """Return all available PTrace devices

        :param target_idx:   Index of target
        :returns: Dict: key: PID (int)
                        val: Dict of PTrace device info
        """
        output = self.run('pid -list', target_idx=target_idx)

        return_dict = {}
        pattern = re.compile(r'(\d+)\s+'                  # PID
                             r'(\d+)\s+'                  # PTraceIndex
                             r'(PTrace \s+\d+\s+\w+)\s+'  # PTraceName
                             r'(\w+)\s+'                  # Type
                             r'(\d+)\s+'                  # TriggerIndex
                             r'(\d+)\s+'                  # Numberoflanes
                             r'(\d+)\s+'                  # HwRev
                             r'([\d, ]+)'                 # PortMap
                             r'')
        for pid, ptrace_idx, ptrace_name, ptrace_type, trigger_idx, num_lanes, hw_rev, port_map in pattern.findall(output):
            return_dict[pid] = {'PTraceIndex': ptrace_idx,
                                'PTraceName': ptrace_name,
                                'Type': ptrace_type,
                                'TriggerIndex': trigger_idx,
                                'Numberoflanes': num_lanes,
                                'HwRev': hw_rev,
                                'PortMap': port_map}
        return return_dict

    def start_capture(self, pid: int = None, target_idx: int = None) -> None:
        """Start a PTrace capture on <pid>

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        pid_opt = '-gang' if pid is None else f'-pid {pid}'
        self.run(f'start {pid_opt}', target_idx=target_idx)

    def stop_capture(self, pid: int = None, force: bool = False, target_idx: int = None) -> None:
        """Stop a PTrace capture on <pid>

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param force:      Use -force option (only when there is a trigger set)
        :param target_idx: Index of target
        """
        pid_opt = '-gang' if pid is None else f'-pid {pid}'
        force_opt = '-force' if force else ''
        self.run(f'stop {pid_opt} {force_opt}', target_idx=target_idx)

    def load_ini(self, filepath: str, pid: int = None, target_idx: int = None) -> None:
        """Load an .INI file

        :param filepath:   Path to ini_file to load
        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        pid_opt = '-pall' if pid is None else f'-pid {pid}'
        self.run(f'load {pid_opt} -ini {filepath}', target_idx=target_idx)

    def clear_cfg(self, pid: int = None, target_idx: int = None) -> None:
        """Clear all previous configurations and reset to defaults

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        pid_opt = '-pall' if pid is None else f'-pid {pid}'
        self.run(f'clrcfg {pid_opt}', target_idx=target_idx)

    def retrieve_trace(self, pid: int = None, target_idx: int = None) -> None:
        """Retrieve captured PTrace for PID <pid>

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        prefix = 'ptrace'  # Only if -pall is used
        pid_opt = f'-pall -prefix {prefix}' if pid is None else f'-pid {pid}'
        self.run(f'pull -trace {pid_opt}', target_idx=target_idx)

    def retrieve_cfg(self, pid: int = None, target_idx: int = None) -> None:
        """Retrieve configuration settings for PID <pid>

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        prefix = 'config'  # Only if -pall is used
        pid_opt = f'-pall -prefix {prefix}' if pid is None else f'-pid {pid}'
        self.run(f'pull -config {pid_opt}', target_idx=target_idx)

    def get_dev_info(self, pid: int = None, target_idx: int = None) -> Dict[int, Dict[str, Union[str, int, bool]]]:
        """Return PTrace device info for PID <pid>

        Note: Only the device status is parsed and returned. PTrace Capture Settings is not parsed.
              To get parsed PTrace Capture Settings, call show_settings()

        Raw output:
        - Ptrace Device  0 :
        --------------------
        PtraceIndex                         : 0
        PtraceName                          : PTrace  0 In
        Type                                : Ingress (0)
        StationIndex                        : 0
        TriggerIndex                        : 0
        NumberOfLanes                       : 16
        HwRev                               : 1
        PortMap                             : Port 0,

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        pid_opt = '-pall' if pid is None else f'-pid {pid}'
        output = self.run(f'show -status {pid_opt}', target_idx=target_idx)

        return_dict = {}
        device_pattern = re.compile(r'- Ptrace Device\s+(\d+)\s:\n((?:^(?!- Ptrace).*?\n)+)', re.MULTILINE)
        key_val_pattern = re.compile(r'(\w+)\s+: *([\S ]+)', re.MULTILINE)
        for dev_idx, device_info in device_pattern.findall(output):
            dev_idx = int(dev_idx)
            return_dict[dev_idx] = {}
            for key, val in key_val_pattern.findall(device_info):
                try:
                    return_dict[dev_idx][key] = eval(val)  # Evaluate val if possible
                except Exception:
                    return_dict[dev_idx][key] = val
        return return_dict

    def get_dev_settings(self, pid: int = None,
                         target_idx: int = None) -> Dict[int, Dict[str, Union[str, int, bool, Dict[str, Union[str, int]]]]]:
        """Return PTrace device Capture/Condition/Trigger/Filter Settings for PID <pid>

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        pid_opt = '-pall' if pid is None else f'-pid {pid}'
        output = self.run(f'show -all {pid_opt}', target_idx=target_idx)

        return_dict = {}
        device_pattern = re.compile(r'- Ptrace Device\s+(\d+)\s:\n((?:^(?!- Ptrace).*?\n)+)', re.MULTILINE)
        settings_pattern = re.compile(r'- PTrace (\w+) Settings\s*:\s*\n*((?:^(?!- PTrace).*?\n)+)', re.MULTILINE)
        for dev_idx, device_info in device_pattern.findall(output):
            dev_idx = int(dev_idx)
            return_dict[dev_idx] = {}
            for category, settings in settings_pattern.findall(device_info):
                return_dict[dev_idx][category] = {}
                key_val_pattern = re.compile(r'^(\w+)\s+: *([\S ]+)', re.MULTILINE)
                for key, val in key_val_pattern.findall(settings):
                    try:
                        return_dict[dev_idx][category][key] = eval(val)  # Evaluate val if possible
                    except Exception:
                        return_dict[dev_idx][category][key] = val

                if category == 'Trigger':
                    event_pattern = re.compile(r'(Event Count \d+):.*?\n((?:^(?!Event).*?\n)+)', re.MULTILINE)
                    for event, event_settings in event_pattern.findall(settings):
                        return_dict[dev_idx][category][event] = {}
                        for line in event_settings.strip().splitlines():
                            key, val = line.split(':')
                            key = key.strip()
                            val = val.strip()
                            try:
                                return_dict[dev_idx][category][event][key] = eval(val)  # Evaluate val if possible
                            except Exception:
                                return_dict[dev_idx][category][event][key] = val

        return return_dict

    def get_capture_summary(self, pid: int = None, target_idx: int = None) -> Dict[int, Dict[str, Dict[str, Union[int, bool]]]]:
        """Return PTrace capture summary for PID <pid>

        :param pid:        PID to run command on. If None, run on all PIDs.
        :param target_idx: Index of target
        """
        pid_opt = '-pall' if pid is None else f'-pid {pid}'
        output = self.run(f'show -summary {pid_opt}', target_idx=target_idx)

        return_dict = {}
        core_pattern = re.compile(r'Ptrace Core\s+(\d+)\s:\n((?:^(?!Ptrace Core).*?\n)+)', re.MULTILINE)
        key_val_pattern = re.compile(r'(\w+)\s+: *([\S ]+)')
        for core_idx, core_info in core_pattern.findall(output):
            core_idx = int(core_idx)
            return_dict[core_idx] = {}
            for key, val in key_val_pattern.findall(core_info):
                try:
                    return_dict[core_idx][key] = eval(val)  # Evaluate val if possible
                except Exception:
                    return_dict[core_idx][key] = val
        return return_dict
