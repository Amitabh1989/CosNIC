"""
:mod:`service` -- Wrapper for service
================================================================================

.. module:: controller.lib.linux.system.service
.. moduleauthor:: Manikanta Ambadipudi <manikanta.ambadipudi@broadcom.com>

"""
from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)

class Service(object):
    def __init__(self, service_name):
        self.__service = service_name

    @property
    def status(self):
        try:
            log.info('Checking if %s service is running.' % self.__service)
            exe.block_run('systemctl status %s' % self.__service)
        except exception.ExeExitcodeException as err:
            if err.output.find('service could not be found') != -1:
                raise

            log.info('Service %s is not running.' % self.__service)
            return False

        log.info('Service %s is running.' % self.__service)
        return True

    def start(self):
        log.info('Starting %s service' % self.__service)
        exe.block_run('systemctl start %s' % self.__service)

    def stop(self):
        log.info('Stopping %s service.' % self.__service)
        exe.block_run('systemctl stop %s' % self.__service)

    def restart(self):
        log.info('Restarting %s service.' % self.__service)
        exe.block_run('systemctl restart %s' % self.__service)

    def disable(self):
        log.info('Disabling %s service.' % self.__service)
        exe.block_run('systemctl disable %s' % self.__service)

    def isenabled(self):
        log.info('checking %s service enabled or not.' % self.__service)
        try:
            exe.block_run('systemctl is-enabled %s' % self.__service)
        except exception.ExeExitcodeException as err:
            if err.output.find('service could not be found') != -1:
                raise

            log.info('Service %s is not enabled.' % self.__service)
            return False
        return True
