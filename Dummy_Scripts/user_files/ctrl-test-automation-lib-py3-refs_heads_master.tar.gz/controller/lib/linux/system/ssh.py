"""
:mod:`ssh` -- SSH wrapper library
=================================
.. module:: controller.lib.linux.system.ssh
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper method for SSH.
"""
import re
import logging
import pexpect
from typing import Optional
import weakref
from time import sleep
from paramiko import SSHClient, AutoAddPolicy, AuthenticationException, Channel
from paramiko.ssh_exception import NoValidConnectionsError, SSHException

from controller.lib.core import exception

log = logging.getLogger(__name__)


class SSH(object):
    """
    The class that implements SSH session using pexpect.
    """
    def __init__(self, ip_address, **kwargs):
        """
        The SSH constructor. It establishes an SSH connection with the specified host using the
        'root' user account. If a password is in place, it assumes the password-less login
        pre-configured.
        """
        self.__ip_addr = ip_address
        self.__shell_prompt = kwargs.get('shell_prompt', '# ')
        self.__pexpect_object = pexpect.spawn('ssh -o strictHostKeyChecking=no root@%s' % self.__ip_addr)
        self.__pexpect_object.expect(self.__shell_prompt)
        # Mimic the exe.run() method by havind a dummy proc.
        self.__pexpect_object.proc = self.__pexpect_object
        self.__pexpect_object.stop = self.stop
        self.__pexpect_object.kill = self.stop
        self.__pexpect_object.poll = self.poll

    def run(self, command, **kwargs):
        """
        The method that runs the command passed over the pre-created pexpect session.

        Args:
            command (str): The command to run.
        Return:
            The pexpect object, for the caller to poll(), stop() and get_output().
        """
        if self.__pexpect_object is None:
            raise exception.SSHException('SSH connection is not established.')
        # If the command passed in is a list, make it a space-separated string.
        if isinstance(command, list):
            command = ' '.join(command)

        logging.info('Run: %s' % command)
        self.__pexpect_object.sendline(command)
        return self.__pexpect_object

    def get_output(self, **kwargs):
        """
        The method that returns the output of the command executed.
        """
        silent = kwargs.get('silent', False)
        command_output = self.__pexpect_object.before

        if isinstance(command_output, bytes):
            command_output = command_output.decode('utf-8')

        if silent is False:
            logging.debug('Output: %s' % command_output)

        return command_output

    def stop(self):
        """
        The method that stops the running command by sending Ctrl+C.
        """
        if self.__pexpect_object is None:
            raise exception.SSHException('SSH connection is not established.')

        self.__pexpect_object.sendcontrol('c')
        self.__pexpect_object.expect(self.__shell_prompt)

    def poll(self):
        """
        The dummy method that mimics the poll() of shell.exe module. The output of this method
        should not be used for anything useful.
        """
        if self.__pexpect_object is None:
            raise exception.SSHException('SSH connection is not established.')

        return None

    def block_run(self, command, **kwargs):
        """
        The method that runs the command passed in, to completion. It also verifies the execution
        status of the command by looking at the '$?' shell variable.
        """
        silent = kwargs.get('silent', False)

        if self.__pexpect_object is None:
            raise exception.SSHException('SSH connection is not established.')
        # If the command passed in is a list, make it a space-separated string.
        if isinstance(command, list):
            command = ' '.join(command)

        logging.info('Run: %s' % command)
        self.__pexpect_object.sendline(command)
        self.__pexpect_object.expect(self.__shell_prompt)
        command_output = self.__pexpect_object.before

        if isinstance(command_output, bytes):
            command_output = command_output.decode('utf-8')

        if silent is False:
            logging.info('Output: %s' % command_output)

        self.__pexpect_object.sendline('echo $?')
        self.__pexpect_object.expect(self.__shell_prompt)

        if isinstance(self.__pexpect_object.before, bytes):
            self.__pexpect_object.before = self.__pexpect_object.before.decode('utf-8')

        exit_code = re.search(r'(\d)+', self.__pexpect_object.before).group(1)

        if int(exit_code) != 0:
            raise exception.ExeExitcodeException(command=command, exitcode=int(exit_code), output=command_output)
        return command_output

    def disconnect(self):
        """
        The method that closes the SSH session.
        """
        if self.__pexpect_object is None:
            raise exception.SSHException('SSH connection is not established.')

        self.__pexpect_object.close()
        self.__pexpect_object = None


class SSHSession:

    def __init__(self,
                 address,
                 port: int = 22,
                 username: str = None,
                 password: str = None,
                 role: str = '',
                 compress: bool = False):
        """Creates SSH Session object to maintain ssh connection to the remote host.
        The session uses Paramiko SSHClient, which  (maybe changed for a faster ssh implementation
        if needed).

        Before executing a command, the client checks either the ssh connection exists or not.
        If no connection established, the connection will be established automatically on command execution.

        For now, it supports only blocking execution using one connection.

        :param address: IP or DNS address to connect.
        :param port: ssh port to connect.
        :param username: ssh username
        :param password: ssh password
        :param role: role of the device. used for better logging and troubleshooting. 'sut', 'client' etc.
        :param compress:
        """
        self.address = address
        self.port = int(port)
        self.username = username
        self.password = password
        self.role = role
        self.compress = compress
        self.client = SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(AutoAddPolicy())
        self._finalizer = weakref.finalize(self, self.close)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def connect(self,
                timeout: float = 10.0,
                auth_timeout: float = 10.0,
                max_attempts: int = 3,
                tunnel: Optional[Channel] = None):
        """Connect the self.client SSHConnection to the remote host.

        :param timeout: Timeout (in seconds) for the TCP connect.
        :param auth_timeout: Timeout to wait for an authentication response.
        :param max_attempts: Number of connection attempts.
        :param tunnel: Paramiko channel, used for tunnelling SSH connections
        """
        if self.is_active() is True:
            return

        att_timeout = 3
        for attempt in range(max_attempts):
            try:
                log.debug(f'Trying to establish SSH connection to {self.role} {self.address}:{self.port}.')

                self.client.connect(hostname=self.address,
                                    port=self.port,
                                    username=self.username,
                                    password=self.password,
                                    timeout=timeout,
                                    auth_timeout=auth_timeout,
                                    compress=self.compress,
                                    sock=tunnel)
                if isinstance(self.client.get_transport().sock, Channel):
                    # Handle AF_INET and AF_INET6. Other family types wouldn't work.
                    src_ip, src_port, *_ = self.client.get_transport().sock.transport.sock.getsockname()
                else:
                    src_ip, src_port, *_ = self.client.get_transport().sock.getsockname()
                log.debug(f'Established SSH: {src_ip}:{src_port} to {self.address}:{self.port}.')
                break
            except AuthenticationException as auth_err:
                # An AuthenticationException will be raised if trying to log in without a password, even on systems
                # which do not have a SSH password. If we encounter an AuthenticationException and there is no
                # password provided, try connecting using auth_none(). If this also fails, ignore that exception and
                # re-raise the original exception.
                if self.username and not self.password:
                    try:
                        self.client.get_transport().auth_none(self.username)
                        if isinstance(self.client.get_transport().sock, Channel):
                            src_ip, src_port, *_ = self.client.get_transport().sock.transport.sock.getsockname()
                        else:
                            src_ip, src_port, *_ = self.client.get_transport().sock.getsockname()
                        log.debug(f'Established SSH: {src_ip}:{src_port} to {self.address}:{self.port}.')
                        break
                    except SSHException:
                        pass
                log.info(f'Authentication failed. Tried {self.username}/{self.password}. 'f'Please check your '
                         f'credentials and ssh keys.')
                log.error(auth_err)
                raise auth_err
            except NoValidConnectionsError as unable_err:
                log.info(f'Unable to connect to {self.address}:{self.port}. Please check settings and ssh server.')
                log.error(unable_err)
                if attempt == max_attempts - 1:
                    raise unable_err
            except TimeoutError as time_err:
                log.info(f'SSH connection attempt to {self.address}:{self.port} has timed out.')
                log.error(time_err)
                if attempt == max_attempts - 1:
                    raise time_err

            log.debug(f'Sleep {att_timeout} before next connection attempt.')
            sleep(att_timeout)

    def close(self) -> None:
        """Close ssh connection. This function will be called automatically by Python garbage collector."""
        if self.client:
            log.debug(f'Close SSH connection to {self.role} {self.address}:{self.port}.')
            self.client.close()

    def exec_command(self, command, check: bool = False, log_out: bool = True, **kwargs) -> str:
        """Execute command using SSH connection. The client will be automatically connected to the SSH server
        if a connection is closed by a reason.

        :param command: command to execute.
        :param check: enable check for non 0 exit code.
        :param log_out: defines log output of note. Set False to do not log output.
        """
        self.get_connected()
        log.debug(f'Executing on {self.role} {self.address}: {command}')

        # if host is just rebooted or ssh server restarted, it is possible that
        # ssh connection will be RST.
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                _, stdout, stderr = self.client.exec_command(command)
                break
            except ConnectionResetError as rst_error:
                log.info('Please check settings and ssh server.')
                log.error(rst_error)
                if attempt == max_attempts - 1:
                    raise rst_error
                self.connect()

            log.debug('Sleep 3 seconds before next command execution attempt.')
            sleep(3)

        exit_code = stdout.channel.recv_exit_status()
        output = ''.join(stdout.readlines())
        err = ''.join(stderr.readlines())

        if exit_code != 0:
            output = f'{output}{err}'
            if check:
                raise exception.ExeExitcodeException(
                    command=command,
                    exitcode=exit_code,
                    output=output
                )

        if log_out:
            log.debug(f'SSH command output: {output}')

        return output

    def exec_command_check(self, command, log_out: bool = True, **kwargs) -> str:
        """Execute command using SSH connection.
        Raise ExeExitcodeException if non 0 exit code returned.
        """
        return self.exec_command(command, check=True, log_out=log_out, **kwargs)

    def exec_command_silent(self, command, check: bool = False, **kwargs) -> str:
        """Execute command using SSH connection and do not print output.
        This is useful when we need to retrieve some big piece of information which will be
        printed anyway.
        Raise ExeExitcodeException if non 0 exit code returned.
        """
        return self.exec_command(command, check=check, log_out=False, **kwargs)

    def exec_command_check_silent(self, command, **kwargs) -> str:
        """Execute command using SSH connection, check for exceptions and do not print output.
        This is useful when we need to retrieve some big piece of information which will be
        printed anyway.
        Raise ExeExitcodeException if non 0 exit code returned.
        """
        return self.exec_command(command, check=True, log_out=False, **kwargs)

    def get_connected(self):
        """Connect to ssh if connection is not active."""
        if self.is_active() is False:
            self.connect()

    def get_src_ip_port(self) -> tuple:
        """Return ip and port of SSH client if connection established else return ('', 0)."""
        if self.is_active():
            return self.client.get_transport().sock.getsockname()

        return '', 0

    def is_active(self) -> bool:
        if self.client and self.client.get_transport():
            return self.client.get_transport().is_active()

        return False

