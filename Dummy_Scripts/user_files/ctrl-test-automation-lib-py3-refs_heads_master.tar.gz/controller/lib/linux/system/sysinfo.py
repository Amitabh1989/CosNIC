"""
:mod:`sysinfo` -- Collect system information
============================================

.. module:: controller.lib.linux.system.sysinfo
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

import logging
import regex as re

from controller.lib.core import exception
from controller.lib.common.system import sysinfo
from controller.lib.linux import eth
from controller.lib.linux.eth import ethtool
import controller.lib.common.shell.exe as exe

log = logging.getLogger(__name__)

class SysInfo(sysinfo.BaseSysInfo):
    platform = 'Linux'

    def __init__(self):
        super(SysInfo, self).__init__()

    @classmethod
    def get_memory(cls):
        with open('/proc/meminfo', 'r') as fileobj:
            meminfo = fileobj.read()

        if not re.search('MemTotal:[\s\t]+(\d+)', meminfo):
            return 'N/A'

        return int(re.search('MemTotal:[\s\t]+(\d+)', meminfo).group(1))

    @classmethod
    def get_driver_info(cls, driver_list):

        ret_dict = {}

        for driver_name in driver_list:
            iface_list = eth.get_interfaces_by_driver(driver_name)
            if len(iface_list) == 0:
                log.warning('No iface found that uses %s' % driver_name)
                continue

            iface = iface_list[0]
            try:
                drv_info = ethtool.get_drvinfo(iface.name)
            except exception.ExeExitcodeException:
                continue

            ret_dict[drv_info['name']] = '%s firmware (%s)' % (
                drv_info['version'], drv_info['firmware']
            )

        return ret_dict

    @classmethod
    def get_bnxt_en_info(cls):
        """Return bnxt_en driver information including firmware versions
        """

        drv_info = cls.get_driver_info(['bnxt_en'])
        drv, bc, rm, ph = re.findall('(\d+\.\d+\.\d+)', drv_info['bnxt_en'])

        return {'bnxt_en': drv, 'bc': bc, 'rm': rm, 'ph': ph}

    @classmethod
    def get_kernel_version(cls):
        return exe.block_run('uname -r', shell=True).strip()
