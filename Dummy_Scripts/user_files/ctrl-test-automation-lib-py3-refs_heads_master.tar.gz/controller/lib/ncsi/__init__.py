import time
import binascii
from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.linux.io.scapy_ei import *

log = log_handler.get_logger(__name__)


def sniff_and_send(src_mac, packet, iface, wait=5):
    sniff_handler = SniffHandler()

    sniff_handler.start(
        filter='ether host %s' % src_mac,
        iface=iface,
    )
    sendp(packet, iface=iface)
    time.sleep(wait)
    sniff_handler.stop()

    return sniff_handler.get_packets()


def exec_bmc_command(cmd_name, iface, port=0, dell=False, get_data=None, **kwargs):
    types = 0x88f8
    src_mac = "00:04:25:1C:A0:02"
    dst_mac = "ff:ff:ff:ff:ff:ff"
    default_command = '\x00\x01\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    commands = {cmd_name: kwargs}
    final_result = True
    index_data = None
    for command, data in commands.items():
        raw_data = data.get('command', default_command)
        alter = "\x01" if port == 1 else "\x02" if port == 2 else "\x03" if port == 3 else "\x00"
        index = 5
        port_1_data = raw_data[:index] + alter + raw_data[index + 1:] \
            if ("\x1f" not in raw_data[index]) and port != 0 else raw_data
        raw_data = raw_data if port == 0 else port_1_data
        cmd_id = data.get('command_id', '01')
        response_id = data.get('response_id', 'x80')
        response_code = data.get('response_code', '00')
        message = f" #################### {cmd_name} with command_id {cmd_id} is going to execute ########################"
        log.info(message)
        packet = Ether(src=src_mac, dst=dst_mac, type=types) / raw_data.encode(encoding='latin1')
        wait = 2
        packets = sniff_and_send(src_mac, packet, iface, wait=wait)
        for packet in packets:
            log.debug(packet.show(dump=True))
            if packet.haslayer('Raw'):
                packet = packet['Raw'].load
                if dell and command not in ['CLEAR_INITIAL_STAGE', 'SELECT_PACKAGE']:
                    result, expected, index_data = validation_dell_command(command, response_id,
                                                                           response_code, packet, get_data)
                    final_result = final_result and expected
                    if result:
                        break
                else:
                    result, expected, index_data = validation_dmtf_command(command, cmd_id, packet, response_id,
                                                                           response_code, get_data)
                    final_result = final_result and expected
                    if result:
                        break
        else:
            message = f"Fail: expected reponse_id {response_id} not found in {packets} for the command {command}"
            raise exception.TestCaseFailure(message)
        message = f"###################### {cmd_name} with command_id {cmd_id} execution completed ###################"
        log.info(message)
    return final_result, index_data


def validation_dmtf_command(command, cmd_id, packet, response_id, response_code, get_data=None):
    found, expected = True, True
    response_id = binascii.unhexlify(response_id)
    response_code = binascii.unhexlify(response_code)
    data = None
    if response_id in packet[4:5]:
        log.info("expected response found %s for the %s of cmd_id %s " % (response_id, command, cmd_id))
        log.info("response for %s is %s " % (command, packet[16:20]))
        if response_code != packet[17:18]:
            log.warning("Command %s is triggered successfully but response code is not expected %s vs actual %s "
                        % (command, response_code, packet[17:18]))
            expected = False
        elif (packet[18:19] != b'\x00' or packet[19:20] != b'\x00') and response_code == packet[17:18] \
                and response_code == b'\x00':
            log.info("command %s is triggered successfully and expected response found and"
                     " reason is also given %s" % (command, packet[17:20]))
        elif packet[17:18] == b'\x00' and response_code == packet[17:18]:
            log.info("command %s is triggered successfully and executed successfully %s"
                     % (command, packet[17:18]))
        elif (packet[18:19] != b'\x00' or packet[19:20] != b'\x00') and response_code == packet[17:18] \
                and response_code != b'\x00':
            log.info("command %s is triggered successfully and response code is expected %s vs actual %s reason is %s"
                     % (command, response_code, packet[17:18], packet[18:20]))
        else:
            found = False
        if get_data:
            data = packet[get_data] if isinstance(get_data, int) else packet[get_data[0]:get_data[1]+1]
    else:
        found = False
    return found, expected, data


def validation_dell_command(command, response_id, response_code, packet, get_data=None):
    found, expected = False, True
    response_id = binascii.unhexlify(response_id)
    response_code = binascii.unhexlify(response_code)
    data = None
    if response_id in packet[4:5]:
        log.info("response for %s is %s " % (command, packet[17:18]))
        if response_code == packet[17:18] and packet[18:19] == b'\x00' and packet[19:20] == b'\x00':
            log.info('command %s is triggered successfully and expected response code found %s'
                     % (command, response_code))
            found = True
        elif response_code == packet[17:18] and (packet[18:19] != b'\x00' or packet[19:20] != b'\x00'):
            log.info('command %s is triggered successfully and expected response code found %s reason %s is also given'
                     % (command, response_code, packet[18:20]))
            found = True
        else:
            log.warning('command %s is triggered successfully but expected %s vs actual %s'
                        % (command, response_code, packet[18:19]))
            found, expected = True, False
        if get_data:
            data = packet[get_data] if isinstance(get_data, int) else packet[get_data[0]:get_data[1]+1]
    return found, expected, data


def unittest():
    return True
