"""
:mod:`base_switch` -- Base switch module
==============================================

.. module:: controller.lib.switch.switch_dell
.. moduleauthor:: Charles Liu <cliu@broadcom.com>

This is common base switch module for all switches.
Form of communication will only be telnet

"""

from controller.lib.core import log_handler
from controller.lib.core import telnet
from controller.lib.core import exception


log = log_handler.get_logger(__name__)


class BaseSwitch(telnet.TelnetHandler):
    """Base switch class"""
    def __init__(
            self, ip_addr, command_prompt, username=None, password=None,
            **kwargs):
        """

        Args:
            ip_addr (str): Switch IP address
            command_prompt (list): A list of possible command prompt in regular
                expression format
            kwargs (**kwargs): keyword arguments to be passed to
                controller.lib.core.telnet
        """
        super(BaseSwitch, self).__init__(
            ip_addr=ip_addr, command_prompt=command_prompt, **kwargs)
        self.username = username
        self.password = password

    @classmethod
    def factory(cls, ip_addr, username=None, password=None):
        for telnet_handler in telnet.TelnetHandler.telnet_handler_list:
            if telnet_handler.ip_addr == ip_addr:
                return telnet_handler
        return cls(ip_addr, username=username, password=password)

    def connect(
            self, username=None, password=None,
            username_prompt='ser:', password_prompt='ssword:'):
        """Connect to a switch

        This method should be overriden if expected username / password
        prompts are different

        Args:
            username (str): username
            password (str): password
            username_prompt (str): regular expression for username prompt
            password_prompt (str): regular expression for password prompt
        """
        super(BaseSwitch, self).connect()

        if not self.recv(username_prompt, timeout=60):
            raise exception.TelnetException('No login prompt is received')
        self.telnet.write(username + self.newline)

        if not self.recv(password_prompt, timeout=30):
            raise exception.TelnetException('No password prompt is received')
        self.telnet.write(password + self.newline)

        if not self.recv(self.command_prompt, timeout=30):
            raise exception.TelnetException('No command prompt is received')

        return True

    def exec_command(self, command, timeout=10):
        """Execute commands to telnet.

        Args:
            command (str): command to send to telnet
            timeout (int,optional): timeout for expected responses
        """
        return super(BaseSwitch, self).exec_command(command, timeout)

    def shut(self, interface=None):
        """Shutdown the port

        Args:
            interface (None, str): If given, enter to the interface
                configuration mode first and then run a command to shut down
                the port. If None, simply run a command to shut down the port.
        """

        raise NotImplementedError

    def noshut(self, interface=None):
        """Bring up the port

        Args:
            interface (None, str): If given, enter to the interface
                configuration mode first and then run a command to bring up
                the port. If None, simply run a command to bring up the port.
        """
        raise NotImplementedError

    def get_stats(self, interface):
        """Get statistics of the port

        Return:
            dict: keys = rx_bytes, tx_bytes, rx_packets, tx_packets,
                rx_discard, tx_discard, rx_errors, tx_errors. Any other keys
                and values can be returned additionally

        """
        raise NotImplementedError

    def get_status(self, interface):
        """Get a status of the interface

        Return dictionary should be following:

        {
            'state': [up|down|unknown],
            'speed': <link speed in Mb>,
            'flow_control': [on|off|unknown]
        }

        """
        raise NotImplementedError

    def reboot(self):
        """Reboot the switch"""
        raise NotImplementedError
