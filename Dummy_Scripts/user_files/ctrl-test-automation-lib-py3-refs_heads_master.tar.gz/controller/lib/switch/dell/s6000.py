"""
:mod:`s6000` -- Dell S6000 switch library
=========================================

.. module:: controller.lib.switch.dell.s6000k
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""


from controller.lib.switch.base_switch import BaseSwitch
from controller.lib.core import exception
from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


class S6000(BaseSwitch):
    def __init__(self, ip_addr, username='admin', password='br0adc0m$'):
        super(S6000, self).__init__(
            ip_addr=ip_addr,
            command_prompt=['\) >$', ' \(conf\)#$', '\)#$', '#$', '>$'],
            username=username, password=password
        )
        self._prompt = None

    def connect(self, username=None, password=None, **kwargs):
        username = username or self.username
        password = password or self.password

        if not username or not password:
            raise exception.ConfigException(
                'username and/or password are not set')

        super(S6000, self).connect(username, password, 'ogin: ', 'ssword: ')

        self.telnet.write('enable' + self.newline)
        if not self.recv('ssword: ', timeout=5):
            raise exception.TelnetException('No password prompt is received')
        self.telnet.write(password + self.newline)

        self.exec_command('terminal length 0')

        return True

    def exec_command(self, command, timeout=5):
        index, output = super(S6000, self).exec_command(command, timeout)
        self._prompt = index
        return index, output

    def configure(self):
        if self._prompt == 1:
            return True  # Already in config
        elif self._prompt == 2:
            while self._prompt not in [1, 3]:
                self.exec_command('exit')
            if self._prompt == 1:
                return True
            return self.exec_command('configure')

        return self.exec_command('configure')

    def shut(self, interface=None):
        if interface:
            self.configure()
            self.exec_command('interface %s' % interface)
        self.exec_command('shut')

    def noshut(self, interface=None):
        if interface:
            self.configure()
            self.exec_command('interface %s' % interface)
        self.exec_command('no shut')

    def get_stats(self, interface):
        raise NotImplementedError

    def get_status(self, interface):
        raise NotImplementedError

    def reboot(self):
        raise NotImplementedError
