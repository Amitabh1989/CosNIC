import netmiko
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class Dell(netmiko.dell.DellOS10SSH):
    def __init__(self, ip, username, password, **kwargs):
        super().__init__(ip=ip, username=username, password=password, **kwargs)

    def config_mode_command(self, command, cmd_verify=True, expect_string=None, exit_config_mode=False, **kwargs):
        if not self.check_config_mode():
            self.config_mode()
        log.info(f"Executing the command {command}")
        self.send_command(command_string=command, cmd_verify=cmd_verify,
                          expect_string=expect_string, **kwargs)
        if exit_config_mode:
            self.exit_config_mode()


class Broadcom(netmiko.broadcom.BroadcomIcosSSH):
    def __init__(self, ip, username, password, **kwargs):
        super().__init__(ip=ip, username=username, password=password, **kwargs)

    def config_mode_command(self, command, cmd_verify=True, expect_string=None, exit_config_mode=False, **kwargs):
        if not self.check_config_mode():
            self.config_mode()
        log.info(f"Executing the command {command}")
        self.send_command(command_string=command, cmd_verify=cmd_verify,
                          expect_string=expect_string, **kwargs)
        if exit_config_mode:
            self.exit_config_mode()


class DellSonic(netmiko.dell.DellSonicSSH):
    def __init__(self, ip, username, password, **kwargs):
        super().__init__(ip=ip, username=username, password=password, **kwargs)

    def config_mode_command(self, command, cmd_verify=True, expect_string=None, exit_config_mode=False, **kwargs):
        if not self.check_config_mode():
            self.config_mode()
        log.info(f"Executing the command {command}")
        self.send_command(command_string=command, cmd_verify=cmd_verify,
                          expect_string=expect_string, **kwargs)
        if exit_config_mode:
            self.exit_config_mode()


def get_maker(ip, username, password, conn_timeout=90, **kwargs):
    # BaseConnection class is having issue in auto_connect for Sonic models hence handling in the below way
    try:
        switch_obj = netmiko.BaseConnection(ip=ip, username=username, password=password, conn_timeout=conn_timeout, **kwargs)
    except Exception:
        switch_obj = netmiko.BaseConnection(ip=ip, username=username, password=password, conn_timeout=conn_timeout, auto_connect=False, **kwargs)
        switch_obj.establish_connection()
    switch_obj.send_command("enable", expect_string=r'(#|\$)')
    output = switch_obj.send_command("show version")
    switch_obj.disconnect()
    if 'Broadcom Tomahawk'.lower() in output.lower():
        return 'Broadcom'
    elif 'Enterprise SONiC Distribution by Dell Technologies'.lower() in output.lower():
        return 'DellSonic'
    elif 'Dell SmartFabric OS10 Enterprise'.lower() in output.lower():
        return 'Dell'
    else:
        raise Exception("Currently we are supporting only Dell OS10 / Dell Sonic and Broadcom switches")


def get_switch(ip, username, password, conn_timeout=90,  **kwargs):
    switch_type = get_maker(ip, username, password, conn_timeout=conn_timeout,  **kwargs)
    return globals()[switch_type](ip=ip, username=username, password=password, **kwargs)
