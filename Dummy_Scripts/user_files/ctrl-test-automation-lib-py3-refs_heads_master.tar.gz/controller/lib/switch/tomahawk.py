"""
:mod:`tomahawk` -- Tomahawk switch library
==========================================

.. module:: controller.lib.switch.tomahawk
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

Allow to interact with Tomahawk through telnet. Usage is quite similar as
any other switch modules.

>>> from controller.lib.switch import tomahawk
>>> t = tomahawk.Tomahawk('tomahawk-1')
>>> t.connect(username='admin', password='password')
True

So now you are connected to Tomahawk. If you want to run specific command,
you can call 'exec_command' method.

>>> t.exec_command('show interfaces status all')

If you need to shut down an interface, you can use 'shut' method

>>> t.shut(interface='0/12')

And you can do bring up the switch port again using 'noshut'

>>> t.noshut(interface='0/12')

"""


import re

from controller.lib.core import telnet
from controller.lib.core import exception
from controller.lib.core import log_handler


log = log_handler.get_logger(__name__)


class Tomahawk(telnet.TelnetHandler):
    def __init__(self, ip_addr, username='admin', password='br0adc0m$'):
        super(Tomahawk, self).__init__(
            # ip_addr, [b'\) >$', b'\)>$', b' #$', b' \(Config\)#$', b' \(Vlan\)#$', b'\)#$'])
            # DCSG01293464: prompt index 2: config, 3: vlan 4: interface 5:enable
            ip_addr, [b'\) >$', b'\)>$', b'\(Config\)#$', b'\(Vlan\)#$', b'\(.*\)\s?\(.*\)#$',  b'\s?#$'])
        self._prompt = None
        self.username = username
        self.password = password

    @staticmethod
    def get_tomahawk(ip_addr):
        for telnet_handler in telnet.TelnetHandler.telnet_handler_list:
            if telnet_handler.ip_addr == ip_addr:
                return telnet_handler

        return Tomahawk(ip_addr)

    def connect(self, username=None, password=None):
        username = self.username if username is None else username
        password = self.password if password is None else password

        super(Tomahawk, self).connect()

        if not self.recv(b'User:', timeout=60):
            raise exception.TelnetException('No login prompt is received')
        _dummy =  bytes(username, encoding='utf8') + self.newline
        self.telnet.write(_dummy)

        if not self.recv(b'ssword:', timeout=30):
            raise exception.TelnetException('No password prompt is received')
        _dummy = bytes(password, encoding='utf8') + self.newline
        self.telnet.write(_dummy)

        if not self.recv(self.command_prompt, timeout=30):
            raise exception.TelnetException('No command prompt is received')

        self.exec_command('enable')
        self.exec_command('terminal length 0')

        return True

    def exec_command(self, command, timeout=5):
        _dummy = bytes(command, encoding='utf8')
        index, output = super(Tomahawk, self).exec_command(_dummy, timeout)
        self._prompt = index
        return output

    def configure(self):
        if self._prompt == 5:
            # In enable prompt
            return self.exec_command('configure')
            # return True  # Already in config
        elif self._prompt == 2:
            # In config prompt
            return True
            # self.exec_command('exit')
        elif self._prompt == 4:
            # In interface prompt
            while self._prompt not in [1, 2, 5]:
                self.exec_command('exit')
            if self._prompt == 2:
                # In config prompt
                return True
            return self.exec_command('configure')

        return self.exec_command('configure')

    def shut(self, interface=None):
        if interface:
            self.configure()
            self.exec_command('interface %s' % interface)
        self.exec_command('shut')

    def noshut(self, interface=None):
        if interface:
            self.configure()
            self.exec_command('interface %s' % interface)
        self.exec_command('no shut')

    def get_stats(self, interface):
        output = self.exec_command('show interface ethernet %s' % interface)

        # Need to normalize statistics names, but for now, only grabbing some
        # critical ones
        mapping = {
            b'Total Packets Received \(Octets\)': b'rx_bytes',
            b'Unicast Packets Received': b'rx_ucast_packets',
            b'Multicast Packets Received': b'rx_mcast_packets',
            b'Broadcast Packets Received': b'rx_bcast_packets',
            b'Receive Packets Discarded': b'rx_discard',
            b'Total Packets Transmitted \(Octets\)': b'tx_bytes',
            b'Unicast Packets Transmitted': b'tx_ucast_packets',
            b'Multicast Packets Transmitted': b'tx_mcast_packets',
            b'Broadcast Packets Transmitted': b'tx_bcast_packets',
            b'Transmit Packets Discarded': b'tx_discard',
            b'FCS Errors': b'rx_crc_errors',
        }

        ret_dict = {}

        for stats_name, norm_name in list(mapping.items()):
            if re.search(stats_name + '[\.\s]+(\d+)', output):
                ret_dict[norm_name] = int(
                    re.search(stats_name + '[\.\s]+(\d+)', output).group(1))
            else:
                log.warning('Cannot find statistics for "%s"' % stats_name)

        return ret_dict

    def clr_stats(self, interface):
        out = self.exec_command('clear counters %s' % interface)
        if out.find('(y/n)') != -1:
            self.exec_command('y')
        else:
            log.warning('Could not clear the counters for the Interface')

    def get_status(self, interface):
        output = self.exec_command(
            'show interfaces status %s | section %s' % (interface, interface))

        if not re.search('\r\n(%s.*)' % interface, output):
            raise exception.ValueException(
                'Failed to parse the interface information. Output: %s'
                % output)

        # This is an ugly way to parse; but let's stick with this for now
        info_list = [
            col.strip() for col in
            re.search(
                '\r\n%s.*' % interface, output).group().split('  ') if col
        ]

        if len(info_list) == 6:  # No name
            iface, state, speed_mode, speed_state, \
                media, flow_control = info_list
        elif len(info_list) == 7:  # has name
            iface, name, state, speed_mode, speed_state, \
                media, flow_control = info_list
        else:
            raise exception.ValueException(
                'Failed to parse the interface information. info_list: %s'
                % info_list
            )

        # Only G based speed for Tomahawk?
        speed = int(re.match('(\d+)G', speed_state).group(1)) * 1000

        if flow_control.lower() == 'active':
            flow_control = 'on'
        else:
            flow_control = 'off' \
                if flow_control.lower() == 'inactive' else 'unknown'

        return {
            'state': state.lower(),
            'speed': speed,
            'flow_control': flow_control,
        }

    def reboot(self):
        self.telnet.write(b'reload' + self.newline)
        self.disconnect()

    def set_mtu(self, interface, mtu):
        self.configure()
        self.exec_command('interface %s' % interface)
        self.exec_command('mtu %s' % mtu)

