"""
:mod:`template` -- The Library Template
=======================================

.. module:: controller.lib.template
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

You can describe additional information regarding this module here.
Note that most rules are from PEP8, PEP12 and Google Python style guide.

* PEP 8: https://www.python.org/dev/peps/pep-0008/
* PEP 12: https://www.python.org/dev/peps/pep-0012/
* Google Python style guide:
  https://google-styleguide.googlecode.com/svn/trunk/pyguide.html

Basic Style Guide
-----------------
Columns
'''''''
Lines should not exceed 79 columns with some exceptions - such as a long URL.

Blank lines
'''''''''''
Two blank lines for top level functions or class definitions otherwise single
blank line between functions / methods

Indentation
'''''''''''
There are many different guides about the indentation. reST requires 3 spaces,
Sphinx requires 2 spaces and PEP12 requires 4 spaces.

We follow PEP12 and Google Python style guide by using 4 spaces for
indentation.

List
''''
For list (bullet point, numbers), lines should be align to the start of the
sentence. For example::

    * This is a sample
      line for a bullet point which uses 2 spaces indentation to align

    1. And this is another sample line for
       a numbers which uses 3 spaces indentation to align

And definition lists are written like this (4 spaces indentation)::

    what-1
        description here

    what-2
        description here

Explicit markup
'''''''''''''''
Explicit markup is for special handling, and it uses 3 spaces indentation.
For example::

    .. note::
       This note uses 3 spaces indentation to align.

Docstring
'''''''''
Follow the Google Python style guide about arguments and returns. Example::

    def sample_function(arg1, arg2, *args, **kwargs):
        \"""Summary of this function

        And more details here. This function is a sample function to show
        how to write functions.

        Args:
            arg1 (str): description here
            arg2 (int, float): You can specify multiple types like this
            *args: description here, and whenever you need to write multi
                lines of description, add 4 spaces indentation just like
                this
            **kwargs: keywoard arguments

        Returns:
            bool: True if successful else False

            Note that napoleon does not support multiple return types, unlike
            Sphinx.

        \"""

        return True

The rendered result is available at the bottom of this page.

How to Use This Template
------------------------
You need to update following lines when you create a new test module from this
template.

   1. Line 2 and 3 ::

         :mod:`<module_name>` -- <title>
         ===============================

      .. note::
         In line 3, underlining the line 2 with a '=' character, at least as
         long as the text.

   3. Line 5::

         .. module:: <the fully qualified module name>

      .. note::
         The fully qualified module name means including the package name for
         submodules

   4. Line 6::

         .. moduleauthor:: <name> <<EMAIL>>

      .. note::
         moduleauthor can appear multiple times.

   5. Line 121::

         __version__ = "<test module version>"

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


def sample_function(arg1, arg2, *args, **kwargs):
    """Summary of this function

    And more details here. This function is a sample function to show
    how to write functions.

    Args:
        arg1 (str): description here
        arg2 (int, float): You can specify multiple types like this
        *args: description here, and whenever you need to write multi
            lines of description, add 4 spaces indentation just like
            this
        **kwargs: keywoard arguments

    Returns:
        bool: True if successful else False

        Note that napoleon does not support multiple return types, unlike
        Sphinx.

    """

    return True


def unittest():
    """
    This is a function which will be executed by GitLab CI whenever
    "push" happens only if this function exists. Namely this is optional.

    Returns:
        bool: True if successful otherwise False
    """

    return True