"""
:mod:`driver` -- VMware driver library
=====================================

.. module:: controller.lib.vmkernel.driver
.. moduleauthor:: Sharath Shanth <sharath.shanth@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Corporation"

import time
import traceback

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe


log = log_handler.get_logger(__name__)

def probe_devices():
    log.info("Invoking controller instance callback..")
    exe.block_run("pkill -POLL vmkdevmgr")


def unload(vib_name):
    output = exe.block_run('vmkload_mod -l')
    if vib_name in str(output):
        log.info("Driver module %s is found" % vib_name)
        log.info('Unloading module %s ... ' % vib_name)
        exe.block_run('vmkload_mod -u %s' % vib_name)
    else:
        log.info("skip Driver(%s) unload - As no driver at present" % vib_name)


def load(vib_name, force_load=False):
    forced_unload_flag = False
    proceed_to_load = False
    if force_load:
        unload(vib_name)
        forced_unload_flag = True   # to avoid to send --list multiple times

    if forced_unload_flag:
        proceed_to_load = True
    else:
        log.info("check if driver is loaded already...")
        output = exe.block_run('vmkload_mod -l')
        if vib_name in str(output):
            log.info("skip Driver(%s) load - As driver already loaded" % vib_name)
        else:
            log.info("No driver(%s) module found" % vib_name)
            proceed_to_load = True

    if proceed_to_load:
        log.info('Loading module %s ...' % vib_name)
        try:
            exe.block_run('vmkload_mod %s' % vib_name)
            time.sleep(2)
            probe_devices()
        except Exception as ex:
            raise exception.ExeException(
                f"Exception '{type(ex).__name__}' occurred while loading the driver module {vib_name} \n"
                f"Traceback : {traceback.format_exc()}")

