from pyVmomi import vim

from controller.lib.vmkernel import pyvmomi
from controller.lib.vmkernel.eth.interface.app_interface import AppInterface
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


def get_interface(iface, method='app'):
    """Factory function to return the Interface object

    Return Interface object depending on the given "method" argument.

    Args:
        iface: interface
        method (str): [app|ioctl]. For application layer testing, should
            use "app" so this object runs tools depending on methods such
            as ethtool, ip, ifconnfig, etc.
            For high performance, should use 'ioctl' which doesn't execute
            shell command

    Returns:
        Interface: Interface object that has methods to interact with
            the Ethernet interface.
    """

    if method == 'app':
        return AppInterface(iface=iface)
    elif method == 'ioctl':
        raise NotImplementedError('IOCTL is currently disabled')
    else:
        raise ValueError('Unknown method type')


def get_interface_by_mac_addr(mac_addr):
    """
    A factory function.

    Return Interface object that has the given MAC address depending on
    the method argument.

    .. note:

       This function cannot detect VLAN interface that has not the
       expected name format - i.e. ethX.<VLAN_ID>

    Args:
        mac_addr (str): MAC address in xx:xx:xx:xx:xx:xx format

    Returns:
        Interface: If interface is detected, return AppInterface or
           IoctlInterface depending on the method
           argument otherwise return None

    """
    pnic = pyvmomi.get_physical_nic_by_mac(mac_addr)
    if pnic is not None:
        name = pnic.device
        return AppInterface(iface=name)
    return None


def get_interfaces_by_driver(driver):
    host = pyvmomi.get_obj([vim.HostSystem], 'localhost.localdomain')
    return [AppInterface(iface=pnic.device, create=False)
            for pnic in host.config.network.pnic if pnic.driver == driver]


def get_interfaces():
    log.warning('Not Implemented...')
    return None


def get_interfaces_by_ip_addr(ip_addr):
    portgroup = pyvmomi.get_physical_nic_by_ip(ip_addr)
    if portgroup:
        name = [nic for nic in portgroup.computedPolicy.nicTeaming.nicOrder.activeNic][0]
        app_interface = AppInterface(iface=name, create=False)
        app_interface.port_group_name = portgroup.spec.name
        return [app_interface]
    return None
