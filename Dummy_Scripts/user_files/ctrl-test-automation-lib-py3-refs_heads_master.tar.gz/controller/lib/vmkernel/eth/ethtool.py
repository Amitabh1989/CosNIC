"""
:mod:`ethtool` -- Linux tool 'ethtool' wrapper
===============================================

.. module:: controller.lib.linux.eth.ethtool
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a wrapper module of ethtool.

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

import re

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


def exec_ethtool(iface, opt, order=None, **kwargs):
    """Execute ethtool command.

    Args:
        iface (str): ethX name
        opt (str): option to be passed to ethtool. i.e.) '-s'
        order (list): List of keys in kwargs so the parameters are provided
            in order as defined here
        kwargs (kwargs): keyword argument which has key=parameter name and
            value=value. i.e. set_duplex('p1p1', 'full', speed=40000) will
            run "ethtool -s p1p1 duplex full speed 40000".

    """
    order = order or list(kwargs.keys())

    params = ' '.join('%s %s' % (key, kwargs[key]) for key in order)
    exe.block_run('ethtool %s %s %s' % (opt, iface, params))


def get_msglvl(iface):
    """Return msglvl

    Args:
        iface (eth): ethX name

    Return:
        int: msglvl in integer

    """
    output = exe.block_run('ethtool %s' % iface)
    return int(re.search(
        r'Current message level: 0x[0-9a-f]+ \((\d+)\)', output).group(1))


def set_msglvl(iface, msglvl):
    """Set msglvl

    Args:
        iface (eth): ethX name
        msglvl (hex, int): message level
    """
    exe.block_run('ethtool -s %s msglvl %s' % (iface, msglvl))


def get_speed(iface):
    """
    Return link speed of the interface

    Args:
        iface (eth): ethX name

    Returns:
        int: link speed in Mb. -1 for unknown.

    """

    output = exe.block_run('ethtool %s' % iface)
    speed = re.search(r'Speed:\s+(\w+)', output).group(1)
    if 'Unknown' in speed:
        return -1
    speed = re.match(r'(\d+)', speed).group(1)

    try:
        return int(speed)
    except Exception:
        raise exception.EthtoolException(
            'Cannot find speed information from ethtool')


def set_speed(iface, speed, **kwargs):
    """
    Set speed of the interface.

    Args:
        iface (eth): ethX name
        speed (int): New speed in Mb
    """
    exec_ethtool(iface, '-s', autoneg='off', **kwargs)
    exec_ethtool(iface, '-s', speed=speed, **kwargs)


def get_duplex(iface):
    """
    Return duplex mode of the interface.

    Args:
        iface (str): ethX name

    Returns:
        str: duplex mode in lower case (which ethtool accepts as values for
           duplex mode setting)
    """
    output = exe.block_run('ethtool %s' % iface)
    try:
        return re.search(r'Duplex:\s+(\w+)', output).group(1).lower()
    except Exception:
        raise exception.EthtoolException(
            'Cannot find duplex information from ethtool')


def set_duplex(iface, duplex, **kwargs):
    """
    Set duplex mode of the interface.

    If showing 'cannot advertise duplex X' error, try to set speed and
    duplex at the same time by using the "set_speed_and_duplex" function

    Args:
        iface (str): ethX name
        duplex (str): duplex mode. choices=[full|half]
    """
    exec_ethtool(iface, '-s', duplex=duplex, **kwargs)


def get_stats(iface):
    """
    Return statistics of the interface, as ethtool -S returns since
    output format is different per NIC type

    Args:
        iface (str): ethX name

    Returns:
        dict: key=statistics name, value=value
    """

    return exe.block_run('ethtool -S %s' % iface)


def get_drvinfo(iface):
    """Return driver name, version and firmware versions

    Args:
        iface (str): ethX name

    Return:
        dict: key=name, version, firmware. value = values
    """
    output = exe.block_run('ethtool -i %s' % iface)
    if not re.search(
            '.*driver: (.*)\n.*version: (.*)\n.*firmware-version: (.*)',
            output, re.MULTILINE
    ):
        raise exception.EthtoolException(
            'Cannot find driver information. Output: %s' % output)

    drv_name, drv_version, firm_version = re.search(
        '.*driver: (.*)\n.*version: (.*)\n.*firmware-version: (.*)',
        output, re.MULTILINE).groups()

    return {
        'name': drv_name, 'version': drv_version, 'firmware': firm_version
    }


def get_features(iface):
    """
    Return ethtool features output. Return value is a dictionary which has a
    tuple as values (<status>, <fixed>)

    <status> is etierh 'on' or 'off'
    <fixed> is True or False depending on it's a fixed value or not.

    Args:
        iface (str): ethX name

    Returns:
        dict: key=feature name, value=(<status=on|off>, <fixed=bool>)
    """

    ret_dict = {}

    output = exe.block_run('ethtool -k %s' % iface)
    for param, value, fixed in re.findall(
            r'(.*):\s+(on|off)\s+(\[fixed\])?', output):
        ret_dict[param.strip()] = (value, True if fixed else False)

    return ret_dict


def set_features(iface, feature, value):
    """
    Set offload feature settings. No error checking about changing settings
    for "fixed" features, but raise exe exception as it is.

    Args:
        iface (str): ethX name
        feature (str): Feature name. e.g.) tx-checksumming
        value (str): choices=[on|off] as ethtool -k returns

    """

    exe.block_run('ethtool -K %s %s %s' % (iface, feature, value))


def get_coalesce(iface):
    """
    Return coalesce parameters as a dictionary.

    Args:
        iface (str): ethX name

    Return:
        dict: key=param, value=value

    """

    ret_dict = {}
    output = exe.block_run('ethtool -c %s' % iface)

    for param, value in re.findall(r'(.*):\s+(.*)', output):
        if re.match(r'\d+', value):  # param, values
            ret_dict[param] = int(value)
        elif value.startswith('Adaptive'):
            rx, tx = re.search(
                r'Adaptive\s+RX:\s+(.*)\s+TX:\s+(.*)', value).groups()
            ret_dict['adapt_rx'] = rx.strip()
            ret_dict['adapt_tx'] = tx.strip()

    return ret_dict


def set_coalesce(iface, param, value):
    """Set coalesce parameter.

    Args:
        iface (str): ethX name
        param (str): parameter name i.e.) rx-frames
        value (str, int): str for adapt_rx and adapt_tx and int for all other
            parameters.
    """

    exe.block_run('ethtool -C %s %s %s' % (iface, param, value))


def get_pause(iface):
    """Return pause options

    Args:
        iface (str): ethX name

    Return:
        dict: auto_neg, rx, tx, rx_neg, tx_neg keys and values
    """
    ret_dict = {}
    key_mapping = {
        'Autonegotiate': 'autoneg',
        'RX': 'rx',
        'TX': 'tx',
        'RX negotiated': 'rx_neg',
        'TX negotiated': 'tx_neg',
    }

    output = exe.block_run('ethtool -a %s' % iface)

    for pause_info in re.findall(r'(.*):[\s\t]+(o(n|ff))', output):
        param, value = pause_info[:2]

        if param in key_mapping:
            ret_dict[key_mapping[param]] = value

    return ret_dict


def set_pause(iface, **kwargs):
    """Set pause options

    Args:
        iface (str): ethX name
        **kwargs (kwargs): key=parameter, value=value

    """
    try:
        exec_ethtool(iface=iface, opt='-A', **kwargs)
    except exception.ExeExitcodeException as err:
        if err.exitcode == 78:
            raise exception.EthtoolNoChanges(err.output)
        elif 'no pause parameters changed' in err.output:
            raise exception.EthtoolNoChanges(err.output)

        raise


def get_channels(iface):
    """Return channel information

    Args:
        iface (str): ethX name

    Return:
        dict: key=queue_type, value=preset, curset. If querying channels is
            not supported, return None

    """
    ret_dict = {'preset': {}, 'curset': {}}
    try:
        output = exe.block_run('ethtool -l %s' % iface)
    except exception.ExeExitcodeException as err:
        if 'not supported' in err.output:
            log.warning('Not supported')
            return None
        raise

    for queue_type in ['RX', 'TX', 'Other', 'Combined']:
        preset, curset = [
            int(queue) for queue in re.findall(
                r'%s:[\s\t]+(\d+)' % queue_type, output)
        ]
        ret_dict['preset'][queue_type.lower()] = preset
        ret_dict['curset'][queue_type.lower()] = curset

    return ret_dict


def set_channels(iface, channel_settings):
    """Configure the channel using the given parameter.

    Args:
        iface: interface
        channel_settings (dict): new channel settings. The format of the
            expected channel_settings is same as the return value of
            get_channels()
    """
    settings_str = ' '.join([
        '%s %s' % (param, value) for param, value in
        list(channel_settings.items())
    ])
    try:
        exe.block_run('ethtool -L %s %s' % (iface, settings_str))
    except exception.ExeExitcodeException as err:
        if 'no channel parameters changed, aborting' in err.output:
            raise exception.EthtoolNoChanges('No channel parameters changed')


def get_ring(iface):
    """Return ring information

    Args:
        iface (str): ethX name

    Return:
        dict: key=queue type, value=preset, curset. If querying ring is not
            supported, return None
    """
    ret_dict = {'preset': {}, 'curset': {}}
    try:
        output = exe.block_run('ethtool -g %s' % iface)
    except exception.ExeExitcodeException as err:
        if 'not supported' in err.output:
            log.warning('Not supported')
            return None
        raise

    for queue_type in ['RX', 'RX Mini', 'RX Jumbo', 'TX']:
        preset, curset = [
            int(ring) for ring in re.findall(
                r'%s:[\s\t]+(\d+)' % queue_type, output)
        ]

        ret_dict['preset'][queue_type.lower()] = preset
        ret_dict['curset'][queue_type.lower()] = curset

    return ret_dict


def get_nvram_dump(iface):
    """Dump NVRAM

    Args:
        iface (str): ethX name
    """

    return exe.block_run('ethtool -e %s' % iface)
