"""
:mod:`app_interface` --
===========================================

.. module:: controller.lib.linux.eth.app_interface
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""
import re
import os

from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.common.shell import exe
from controller.lib.common.eth.interface import BaseInterface
from controller.lib.vmkernel import pyvmomi

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2020 Broadcom Inc"

log = log_handler.get_logger(__name__)


class AppInterface(BaseInterface):
    """
    Can control a single Ethernet interface using this object. Abstract
    backend and perform different interactions with a system depending on
    the method.

    This class uses pyvmomi and esxcli. To use specific application,
    should use the application wrapper instead of this.

    Args:
        iface (str): ethX name

    Returns:
        Interface: Interface object that has methods to interact with
            the Ethernet interface

    """

    def __init__(self, iface, create=True):
        super(AppInterface, self).__init__(iface)

        if create:
            self.create_iface()

        self.port_group_name = None
        self.vmiface = None

    def create_iface(self):
        """
        VM Kernel Interface will be created on the Physical NIC.

        """
        self.vmiface = pyvmomi.create_interface(self.iface)
        print(self.vmiface)

    def up(self):
        """
        Bring up the interface.

        """
        exe.block_run('esxcli network nic up -n %s' % self.iface)

    def down(self):
        """
        Bring down the interface

        """
        exe.block_run('esxcli network nic down -n %s' % self.iface)

    @property
    def ip_addr(self):
        """
        Return IPv4 address of the interface. Use "ip" but returns the only
        first IP address if there are multiple as IP alias to match the
        behavior with ifconfig.

        Returns:
            str: IP address of the interface
            None: If No IP address is assigned

        """
        vmnic = pyvmomi.get_virtual_nic(self.iface, self.port_group_name)
        return vmnic.spec.ip.ipAddress

    @ip_addr.setter
    def ip_addr(self, new_ip_addr):
        """
        Set IP address of the interface. use "ip" but behaves as ifconfig -
        namely

           * If no IP address was assigned, the new IP address will be assigned
           * If IP address was already assigned, the new IP address will
             replace it
           * If 'new_ip_addr' is 0.0.0.0, will remove the IP address

        To interact with "ip" directly, should use "ip" wrapper instead.

        Args:
            new_ip_addr (str): New IP address of the interface with subnet.
                format shuold be x.x.x.x/x

        """
        print(self.iface)
        pyvmomi.set_ipv4_addr(self.iface, new_ip_addr)

    @property
    def ip6_addr(self):
        """
        Return IPv6 addresses of the interface.
        Note that IOCTL does not support IPv6 - therefore using proc instead

        Returns:
            list: List of IPv6 addresses

        """
        return list(pyvmomi.get_ipv6_addr(self.iface).keys())

    @ip6_addr.setter
    def ip6_addr(self, new_ip6_addr):
        """Add a new IPv6 address to the interface

        Args:
            new_ip6_addr (str): IPv6 address with prefix
        """
        pyvmomi.set_ipv6_addr(self.iface, 'replace', new_ip6_addr)

    def set_ip6_addr(self, new_ip6_addr, method):
        if method == 'add' or method == 'del' or method == 'replace':
            if method == 'add' or method == 'replace':
                return pyvmomi.set_ipv6_addr(self.iface, method, new_ip6_addr)
            else:
                return pyvmomi.remove_ipv6_addr(self.iface, new_ip6_addr)

    @property
    def netmask(self):
        """Return netmask of the interface.

        Returns:
            str: netmask of the interface

        """
        vmnic = pyvmomi.get_virtual_nic(self.iface, self.port_group_name)
        return vmnic.spec.ip.subnetMask

    @property
    def prefix(self):
        """Return prefix of the interface

        """
        from netaddr import IPNetwork

        ip_net = IPNetwork('%s/%s' % (self.ip_addr, self.netmask))
        return int(ip_net.prefixlen)

    @property
    def ip6_prefix(self):
        """Return IPv6 prefix of the interface as a dictionary.

        key is a IP address and value is the prefix,
        since it's expected to see multiple addresses
        """
        ret_dict = pyvmomi.get_ipv6_addr(self.iface)
        return ret_dict

    @property
    def mac_addr(self):
        """
        Return MAC addres of the interface

        Returns:
            str: MAC address of the interface
        """
        nic = pyvmomi.get_physical_nic(self.iface)
        return nic.mac

    @mac_addr.setter
    def mac_addr(self, new_mac_addr):
        """
        Set MAC address of the interface

        Args:
            new_mac_addr (str): New MAC address of the interface
            in XX:XX:XX:XX:XX:XX format

        """
        raise NotImplementedError

    @property
    def state(self):
        """
        Return link status. 'up', 'down' and 'unknown'

        Returns:
            str: link status
        """
        output = exe.block_run('esxcli network nic  get -n %s' % self.iface)

        try:
            return re.search(r'Link Status:\s(\w+)\s', output).group(1).lower()
        except Exception:
            raise \
                exception.IPException('Cannot find the state '
                                      'information of the interface')

    @property
    def mtu(self):
        """
        Return MTU of the interface

        Returns:
            int: MTU of the interface

        """
        vswitch = pyvmomi.get_virtual_switch(self.iface)
        return vswitch.mtu

    @mtu.setter
    def mtu(self, new_mtu):
        """
        Set MTU size of the interface

        Args:
            new_mtu (int): New MTU of the interface
        """
        pyvmomi.set_mtu(self.iface, new_mtu)

    @property
    def vlan(self):
        """
        Return VLAN ID set on the interface

        Returns:
        int: VLAN ID of the interface

        """
        portgroup = pyvmomi.get_port_group(self.iface)
        return portgroup.spec.vlanId

    @vlan.setter
    def vlan(self, new_vlanid):
        """
        Set new VLAN ID on the interface

        Args:
            new_vlanid (int): New VLAN ID on the interface
        """
        pyvmomi.set_vlan(self.iface, new_vlanid)

    def enable_autoneg(self):
        """
        Sets the speed and duplexity settings to autonegotiate
        If you set speed and duplex manually, it will be disabled.

        Args:

        """
        pyvmomi.get_physical_nic(self.iface)
        exe.block_run('esxcli network nic set -a -n %s' % self.iface)

    @property
    def speed(self):
        """
        Return link speed of the interface.

        Returns:
            int: link speed in Mb. -1 = unknown

        """
        nic = pyvmomi.get_physical_nic(self.iface)
        return nic.linkSpeed.speedMb

    @speed.setter
    def speed(self, new_speed):
        """
        Set speed of the interface , but speed/duplex together as

        Args:
            new_speed (int): New speed of the interface

        """
        nic = pyvmomi.get_physical_nic(self.iface)
        duplex_vals = {True: 'full', False: 'half'}
        duplex = duplex_vals[nic.linkSpeed.duplex]
        exe.block_run('esxcli network nic set -S '
                      '%s -D %s -n %s' % (new_speed, duplex, self.iface))

    @property
    def duplex(self):
        """
        Return duplex mode of the interface. Use ethtool.

        Returns:
            str: dupldx mode. 0 = half, 1 = full, 0xff = unknown.
        """
        nic = pyvmomi.get_physical_nic(self.iface)
        duplex_vals = {True: 'full', False: 'half'}
        return duplex_vals[nic.linkSpeed.duplex]

    @duplex.setter
    def duplex(self, new_duplex):
        """
        Set duplex mode of the interface

        Args:
            new_duplex (str): full/half

        """
        nic = pyvmomi.get_physical_nic(self.iface)
        speed = nic.linkSpeed.speedMb
        exe.block_run('esxcli network nic set -S %s -D '
                      '%s -n %s' % (speed, new_duplex, self.iface))

    @property
    def stats(self):
        """
        Return statistics of the interface.  Only return the
        basic unicast/multicast/broadcast statistics
        since it's not possible to know the NIC type here.

        Should use controller.lib.linux.eth.stats if you need
        to access TPA related counters.

        Returns:
            dict: key=parameter, value=value
        """
        from .. import stats as ethstats
        return ethstats.get_stats(self.iface)

    @property
    def drvinfo(self):
        """
        Return driver information of the interface. .

        Return value should have following keys:

        * name: driver name
        * version: driver version
        * firmware: Optional. firmware information including name and version

        Returns:
            dict: driver information
        """
        nic = pyvmomi.get_physical_nic(self.iface)
        driver = nic.driver
        output = exe.block_run('vmkload_mod -s %s' % driver)
        version = None

        for line in output.split('\n'):
            line = line.strip()

            if line.find('Version') == 0:
                version = line[9:]

        return {'name': driver, 'version': version}

    def dump(self):
        """
        Dump the NIC property in dict.

        Returns:
            dict: key=param, value=value
        """
        attr_list = ['ip_addr', 'ip6_addr', 'netmask', 'mac_addr', 'state',
                     'mtu', 'speed', 'duplex', 'drvinfo']

        ret_dict = {}

        for attr in attr_list:
            ret_dict[attr] = getattr(self, attr)

        return ret_dict

    @property
    def tso(self):
        """
        Returns the TSO status of the NIC.
        0 if disabled and 1 if enabled
        """
        command = 'esxcli network nic tso get -n %s' % self.iface
        output = exe.block_run(command).split('\n')[2]

        if output.find('on') != -1:
            return 1
        else:
            return 0

    @tso.setter
    def tso(self, value):
        """
        Enable/Disable TSO on the NIC.
        value should be 0 to disable and 1 to enable. Else discarded.
        """
        command = 'esxcli network nic tso set -e ' \
                  '%s -n %s' % (value, self.iface)

        try:
            exe.block_run(command)
        except Exception:
            pass

    @property
    def cso(self):
        """
        Returns the CSO status of the NIC.
        0 if disabled and 1 if enabled
        """
        command = 'esxcli network nic cso get -n %s' % self.iface
        output = exe.block_run(command).split('\n')[2]

        if output.find('on') != -1:
            return 1
        else:
            return 0

    @cso.setter
    def cso(self, value):
        """
        Enable/Disable CSO on the NIC.
        value should be 0 to disable and 1 to enable.
        Else discarded.
        """
        command = 'esxcli network nic cso set -e %s' \
                  ' -n %s' % (value, self.iface)

        try:
            exe.block_run(command)
        except Exception:
            pass

    @property
    def features(self):
        nic = pyvmomi.get_physical_nic(self.iface)
        driver = nic.driver
        command = 'esxcli system module parameters ' \
                  'list -m %s' % driver
        output = exe.block_run(command).strip().split('\n')
        header = output[0]
        retdict = {}

        if header.find('Name') != -1 and \
                header.find('Type') != -1:
            name_ind = header.find('Name')
            type_ind = header.find('Type')
            value_ind = header.find('Value')
            desc_ind = header.find('Description')

            for line in output[2:]:
                param_name = line[name_ind:type_ind - 2].strip()
                param_value = line[value_ind:desc_ind - 2].strip()
                retdict[param_name] = param_value

        return retdict

    def set_promiscuous_mode(self, value):
        if value not in ['on', 'off']:
            raise \
                exception.ValueException('set_promiscous_mode '
                                         'accepts on or off as argument.')

        pyvmomi.set_promisc(self.iface, value)

    def set_feature(self, keyword, value, append=True):
        nic = pyvmomi.get_physical_nic(self.iface)
        driver = nic.driver

        if append:
            command = 'esxcli system module parameters set ' \
                      '-m %s -a -p %s=%s' \
                      % (driver, keyword, value)
        else:
            # Overwriting Existing Module parameter with given parameter
            command = 'esxcli system module parameters ' \
                      'set -m %s -p %s=%s' \
                      % (driver, keyword, value)

        exe.block_run(command)

    def set_features(self, param=None, value=None, param_dict=None):
        if param_dict is None:
            if param is None or value is None:
                return
            else:
                self.set_feature(param, value)
        else:
            for (key, value) in param_dict:
                self.set_feature(param, value)

    @property
    def coalesce(self):
        """

        key is a name of parameter and value is integer,
        except adaptive rx/tx
        which has 'on' and 'off' as possible values

        """
        return pyvmomi.get_coalesce(iface=self.iface)

    def set_coalesce(self, param, value):
        """Set value of the coalesce parameter

        Acceptable parameter / values are as what coalesce() returns

        Args:
            param (str): parametner name i.e.) rx-frames
            value (str, int): str for adaptive rx/tx and
            integer for all other parameters

        """
        pyvmomi.set_coalesce(iface=self.iface, param=param, value=value)

    @property
    def pcidevice(self):
        """ Return PCI device name"""

        return pyvmomi.get_pci_id_interface(nic_name=self.iface)

    @property
    def interrupt(self):
        raise NotImplementedError

    @property
    def smp_affinity(self):
        raise NotImplementedError

    @smp_affinity.setter
    def smp_affinity(self, affinity_dict):
        raise NotImplementedError

    @property
    def netstat(self):
        raise NotImplementedError

    @property
    def snmp(self):
        raise NotImplementedError

    @property
    def flow_control(self):
        """Return the flow control setting"""
        setting = pyvmomi.get_pause(self.iface)

        if setting['autoneg'] == 'on':
            return 'auto_neg'
        elif setting['rx'] == 'on' and setting['tx'] == 'off':
            return 'rx'
        elif setting['rx'] == 'on' and setting['tx'] == 'on':
            return 'rx_tx'
        elif setting['rx'] == 'off' and setting['tx'] == 'on':
            return 'tx'
        else:
            return 'disabled'

    @flow_control.setter
    def flow_control(self, new_mode):
        """Set the flow control to the new setting"""
        try:
            if new_mode == 'rx':
                options = '-a off -r on -t off'
            elif new_mode == 'tx':
                options = '-a off -r off -t on'
            elif new_mode == 'rx_tx':
                options = '-a off -r on -t on'
            elif new_mode == 'auto_neg':
                options = '-a on -r off -t off'
            elif new_mode == 'disabled':
                options = '-a off -r off -t off'
            else:
                raise exception.EthtoolException(
                    'Unsupported parameter for flow control. '
                    'Can be rx, tx, auto_neg or disabled')

            pyvmomi.set_pause(self.iface, options)
        except exception.EthtoolNoChanges:
            pass

    @property
    def route(self):
        raise NotImplementedError

    def set_route(self, method, dst, gateway=None):
        raise NotImplementedError

    @property
    def sysclass_stats(self):
        raise NotImplementedError

    @property
    def queue(self):
        """Return queue settings"""
        raise NotImplementedError

    @queue.setter
    def queue(self, queue_dict):
        raise NotImplementedError

    @property
    def channel(self):
        raise NotImplementedError

    @channel.setter
    def channel(self, channel_settings):
        raise NotImplementedError

    def set_ethtool(self, opt, order=None, **kwargs):
        raise NotImplementedError

    def ping(self, dst_ip, count=10, **kwargs):
        """Ping the remote host"""
        print((list(kwargs.items())))

        for param, value in list(kwargs.items()):
            print((param, value))
        extra_options = \
            [param if value is True else '%s %s' % (param, value)
             for param, value in list(kwargs.items())]
        try:
            exe.block_run('ping -c %s %s %s' %
                          (count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        if self:
            return True

    def ping6(self, dst_ip, count=10, **kwargs):
        """Ping over IPv6 to remote host"""
        extra_options = [param if value is True
                         else '%s %s' % (param, value)
                         for param, value in list(kwargs.items())]

        try:
            exe.block_run('ping6 -c %s %s %s' %
                          (count, ' '.join(extra_options), dst_ip))
        except exception.ExeExitcodeException as err:
            log.error('Ping failed. Error: {}'.format(err))
            return False
        if self:
            return True

    @property
    def sriov(self):
        """Return a number of VFs and total VFs.

        {
            'num': <sriov_numbfs>         # VFS WHICH ARE ATTACHED TO ANY VM
            'total': <sriov_totalvfs>     # TOTAL VFS THAT CAN BE CREATED
        }

        If SR-IOV is not enabled, return None
        """
        ret_dict = pyvmomi.get_sriov_vfs(self.iface)
        return ret_dict

    @sriov.setter
    def sriov(self, new_num):
        """Set the number of VFs"""
        pyvmomi.set_sriov_vfs(self.iface, new_num)

    @property
    def rss(self):
        return True

    @rss.setter
    def rss(self, new_num):
        """Set the number of RSS queue"""
        pyvmomi.set_rss(self.iface, new_num)

    @property
    def drss(self):
        return True

    @drss.setter
    def drss(self, new_num):
        """Set the number of DRSS queue"""
        pyvmomi.set_drss(self.iface, new_num)

    @property
    def ring(self):
        return pyvmomi.get_ring(nic_name=self.iface)

    @ring.setter
    def ring(self, ring_dict):
        pyvmomi.set_ring(nic_name=self.iface, ring_settings=ring_dict)

    def vsish_pf_reset(self):
        from .. import vsish
        vsish.vsish_pf_reset(self.iface)

    @property
    def vsish_link_state(self):
        from .. import vsish
        output = vsish.vsish_get_link_state(self.iface)
        return output

    @vsish_link_state.setter
    def vsish_link_state(self, value):
        """
        :param value:
        0 is for link down
        1 is for link up
        :return:
        """
        from .. import vsish
        vsish.vsish_set_link_state(self.iface, value=value)

    @vsish_link_state.setter
    def vsish_link_flap(self, value):
        """
        :param value:
        1 is for link down
        0 is for link up
        :return:
        """
        from .. import vsish
        vsish.vsish_set_link_flap(self.iface, value=value)

    def add_vlan(self, vlan_id):
        """Add VLAN using the given VLAN ID"""

        self.vlan = vlan_id

    def remove_vlan(self):
        """Delete VLAN using the given VLAN ID"""
        self.vlan = 0


def get_interface_by_driver(driver):
    """Return a list of ethX that uses the given driver

    Args:
        driver (str): driver name

    Return:
        list: list of ethX names
    """
    ret_list = []

    for iface in os.listdir('/sys/class/net'):
        iface_driver = os.path.realpath(''
                                        '/sys/class/net/%s/device/driver' %
                                        iface).split('/')[-1]

        if driver == iface_driver:
            ret_list.append(iface)

    return ret_list


def get_interfaces():
    """Simply return all ethX interface names
    """
    return os.listdir('/sys/class/net')
