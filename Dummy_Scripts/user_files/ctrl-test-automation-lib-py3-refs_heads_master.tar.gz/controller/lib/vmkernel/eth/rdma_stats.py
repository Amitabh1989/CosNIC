"""
:mod:`stats` -- RDMA interface statistics library
=====================================================
.. module:: controller.lib.vmkernel.eth.rdma_stats
.. moduleauthor:: Gaurav Sethi <gaurav.sethi@broadcom.com>
"""
import re
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.common.eth.stats import BaseNIC

log = log_handler.get_logger(__name__)


class Cumulus(BaseNIC):
    @staticmethod
    def get_rdma_stats(rdma_iface):
        """Update attributes to reflect the current statistics
        Args:
            rdma_iface (str): RDMA vmnic name
        """

        output = exe.block_run(
            'localcli --plugin-dir /usr/lib/vmware/esxcli/int'
            ' rdmainternal device privstats get --device %s'
            % rdma_iface, silent=True)
        num_ints = []
        for counter in re.findall(r'\[(\d+)\]\s(num_ints):\s+(\d+)', output):
            queue, counter, value = counter
            num_ints.append(int(value))
        my_dict = {}
        arr = re.findall('(.*):(.*)', output)
        if arr:
            for key, value in arr:
                key = key.strip()
                if 'num_ints' in key:
                    continue
                value = int(value.strip())
                my_dict[key] = [int(value)]

        my_dict['num_ints'] = num_ints
        return my_dict


def get_rdma_stats(rdma_iface):
    """

    Return statistics information of the given RDMA iface
    Args:
        rdma_iface (str): RDMA vmnic name
    """

    for subclass in BaseNIC.__subclasses__():
        return subclass.get_rdma_stats(rdma_iface)
