"""
:mod:`stats` -- Ethernet interface statistics library
=====================================================

.. module:: controller.lib.linux.eth.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This is a library that converts ethtool statistics output information into
an object type.

"""
from typing import List

import re

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.common.eth.stats import BaseNIC, CounterBase

log = log_handler.get_logger(__name__)


class Cumulus(BaseNIC):
    driver_name = 'bnxtnet'

    def __init__(self, counters: List[str] = None):
        counter_list = [
            'ucast_packets', 'ucast_bytes',
            'mcast_packets', 'mcast_bytes',
            'bcast_packets', 'bcast_bytes', 'pause_frames',
        ]
        if counters:
            counters = counters if isinstance(counters, list) else [counters]
            counter_list += counters
        super().__init__(*counter_list)
        self.tpa = CounterBase(*['packets', 'bytes', 'events', 'aborts'])

    def get_diff(self, old_stats, new_stats=None):
        new_stats = new_stats or self
        diff_stats = super(Cumulus, self).get_diff(old_stats, new_stats)
        diff_stats.tpa = new_stats.tpa.get_diff(old_stats.tpa, new_stats.tpa)
        return diff_stats

    @staticmethod
    def get_stats(iface, queue_type='all'):
        """Update attributes to reflect the current statistics

        Args:
            iface (str): ethX name
            queue_type: type of the queue - all, rss, drss, netq
        """
        filter_to_use = ''
        if queue_type == 'all':
            filter_to_use = '.'
        elif queue_type == 'rss':
            filter_to_use = 'rxq-rss'
        elif queue_type == 'drss':
            filter_to_use = 'rxq-drss'
        elif queue_type == 'netq':
            filter_to_use = 'rxq'
        output = \
            exe.block_run(
                'localcli --plugin-dir /usr/lib/vmware/esxcli/int networkinternal nic privstats get -n %s' % iface,
                silent=True)
        cumulus = Cumulus()
        # Handle rx/tx packets and bytes
        for counter in \
                re.findall(
                    r'\[(%s)+(\d+)\]\s([umb]cast)\ '
                    r'(pkts|bytes)\ ([rt]x):\s+(\d+)'
                    % filter_to_use, output):
            qt, queue, cast_type, counter_type, xdir, value = counter

            if counter_type == 'pkts':
                counter_type = 'packets'

            cast_counter_type = cast_type + '_' + counter_type
            cumulus.set_stats_counter(xdir, queue, cast_counter_type, value)
            # Add cast value to packets / bytes
            cumulus.set_stats_counter(xdir, queue, counter_type, value)
        # Handle drop
        for drop_error_counter in \
                re.findall(r'\[%s+(\d+)\].+drops+.+([rt]x): (\d+)' % filter_to_use, output):
            queue, xdir, value = drop_error_counter
            counter_type = 'drops'
            cumulus.set_stats_counter(xdir, queue, counter_type, value)
        for error_counter in \
                re.findall(r'\[%s+(\d+)\].+error+.+([rt]x): (\d+)' % filter_to_use, output):
            queue, xdir, value = error_counter
            counter_type = 'errors'
            cumulus.set_stats_counter(xdir, queue, counter_type, value)
        # Handle TPA counters
        for tpa_counter in \
                re.findall(
                    r'\[%s+(\d+)\]\sLRO\ (pkts|byte|events|aborts)'
                    r'\ (rx|tx):\s+(\d+)'
                    % filter_to_use, output):
            queue, counter_type, dir, value = tpa_counter

            if counter_type == 'pkts':
                counter_type = 'packets'

            if counter_type == 'byte':
                counter_type = 'bytes'

            cumulus.set_stats_counter('tpa', queue, counter_type, value)

        return cumulus


def get_stats(iface, queue_type='all'):
    """Return statistics information of the given iface

    Args:
        iface (str): ethX name
        queue_type: typeof the queue
    """
    drv_name = 'bnxtnet'

    for subclass in BaseNIC.__subclasses__():
        if drv_name == subclass.driver_name:
            return subclass.get_stats(iface, queue_type=queue_type)

    raise exception.ValueException('Not supported driver %s' % drv_name)
