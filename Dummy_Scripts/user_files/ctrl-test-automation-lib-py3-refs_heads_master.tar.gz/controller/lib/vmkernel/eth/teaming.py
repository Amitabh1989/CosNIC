# -*- coding: utf-8 -*-
"""
:mod:`teaming` -- Windows teaming API
===========================================================

.. module:: controller.lib.windows.eth.teaming
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>


API teaming is used to perform teaming operationsd on NIC adapters.
powershell built-in cmdlets are used to create, remove, add, set nic team.

Note: Teaming in windows is supported from windows 2012 server and above.
      For earlier version of windows, teaming drivers are provided separately.
"""
from controller.lib.vmkernel import pyvmomi
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.eth import teaming
from controller.lib.vmkernel.eth.interface.app_interface import AppInterface

log = log_handler.get_logger(__name__)


class EsxTeam(teaming.BaseTeam):
    """
    NIC Teaming, also known as load balancing and failover (LBFO),
    allows multiple network adapters on a computer to be placed into
    a team for the following purposes:
        1. Bandwidth aggregation
        2. Traffic failover to prevent connectivity loss in the event
           of a network component failure.

    Args:
        team_name (str): Specifies the name of the new NIC team.

    Returns:
        Interface : Interface object that has methods to interact with
                    the MSFT NIC Teaming.
    """

    def __init__(self, team_name):
        super(EsxTeam, self).__init__(team_name)
        self.iface = None

    def create_teaming(self, member_names, team_mode=None, team_name='team0'):
        """Function Creates a new NIC team.

        """
        members = member_names

        if len(members) < 2:
            raise \
                exception.ConfigException('Atleast two nics '
                                          'must be specified for NIC teaming.')

        ret_iface = AppInterface(iface=team_name, create=False)
        ret_iface.vmiface = pyvmomi.create_teamed_interface(
            team_name, members, team_mode)
        self.iface = ret_iface
        return ret_iface

    def remove_teaming(self, team_name='team0'):
        """Removes the specified NIC team from the host.

        Args:
            team_name (str): team name

        Returns:
            bool: True

        """
        if self:
            pyvmomi.delete_iface(team_name)
            return True

    def add_team_members(self, member_names, administrative_mode=None):
        raise exception.NotImplemented

    def remove_team_members(self, member_names):
        raise exception.NotImplemented

    def set_team_params(self, team_mode=None, load_balancing=None):
        raise exception.NotImplemented

    def set_team_member_params(self, member_names, administrative_mode):
        raise exception.NotImplemented

    def create_vlan(self, vlan_id):
        """Create vlan on teamed port.

        Args:
            vlan_id (str): Specifies the VLAN ID of the team interface.
                VlanID values must meet the criteria 0 ≤ VlanID < 4095.
                Specify the value 0 to match frames identified with a
                VLAN ID of 0 or untagged frames.

        Returns:
            interface: Interface for managing the teamed vlan port.
        """
        self.iface.vlan = vlan_id
        return True

    def remove_vlan(self):
        """Removes vlan on Teamed port

        This function does not remove the team interface created when the
        team was created.

        You need administrator privileges to use this function on windows.

        Args:

        Returns:
            bool: True
        """
        self.iface.vlan = 0
        return True

    def get_team_info(self, **kwargs):
        pass

    def get_team_member_info(self, **kwargs):
        pass

    def get_vlan(self):
        """Retrieves Vlan ID of team interface.

        Args:

        Returns:
            int: Vlan id
        """
        return self.iface.vlan
