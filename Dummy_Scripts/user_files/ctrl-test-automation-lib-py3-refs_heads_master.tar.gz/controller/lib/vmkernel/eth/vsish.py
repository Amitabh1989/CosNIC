import re
from controller.lib.common.shell import exe


def vsish_pf_reset(nic_name):
    command = ("vsish -e set net/pNics/%s/reset 1" % nic_name)
    exe.block_run(command, silent=True)


def vsish_get_link_state(nic_name):
    command = ("vsish -e get net/pNics/%s/linkStatus" % nic_name)
    output = exe.block_run(command, silent=True)
    my_dict = {}
    arr = re.findall('([a-z]+ status:|last link event)(.*)->(.*)', output)
    if arr:
        for key, value1, value2 in arr:
            key = key.strip().split(':')[0]
            key = re.sub(r'\s', "_", key)
            my_dict[key] = value2.strip()
    return my_dict


def vsish_set_link_state(nic_name, value):
    command = ("vsish -e set net/pNics/%s/linkSet %s" % (nic_name, value))
    exe.block_run(command, silent=True)
    return True


def vsish_set_link_flap(nic_name, value):
    command = ("vsish -e set net/pNics/%s/linkFlapping %s" % (nic_name, value))
    exe.block_run(command, silent=True)
    return True


def vsish_get_rx_queues_info(nic_name):
    command = ("vsish -e cat /net/pNics/%s/rxqueues/info" % nic_name)
    output = exe.block_run(command, silent=True)
    my_dict = {}
    arr = re.findall(r'# ([\w\s]+):(\d+)', output)
    if arr:
        for key, value in arr:
            key = key.strip()
            key = re.sub(r'\s', "_", key)
            my_dict[key] = value
    return my_dict


def vsish_get_mrss_queues(nic_name):
    command = ("vsish -e ls /net/pNics/%s/rxqueues/queues/" % nic_name)
    output = exe.block_run(command, silent=True)
    arr = re.findall(r'(\d+)', output)
    return arr


def vsish_get_mrss_queue_type(nic_name, queue_num):
    command = ("vsish -e cat "
               "/net/pNics/%s/rxqueues/queues/%s/rss/engineInfo/"
               % (nic_name, queue_num))
    output = exe.block_run(command, silent=True)
    my_dict = {}
    arr = \
        re.findall(
            '(RSS engine type|RSS hash function| RSS engine feature)'
            '(.*)->(.*)',
            output)
    if arr:
        for key1, key2, value in arr:
            key = key1.strip()
            key = re.sub(r'\s', "_", key)
            my_dict[key] = value.strip()
    return my_dict
