"""
=========================================
.. module:: controller.lib.vmkernel.io.krdma
.. moduleauthor:: Gaurav Sethi <gaurav.sethi@broadcom.com>
"""
import time
import re
import subprocess
from controller.lib.common.shell import exe
from controller.lib.core import exception
from distutils.spawn import find_executable


class IBCommandController(object):
    def __init__(self, mode='server', tool_name='krdma', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which IB Command runs.
                    - 'server' to run as IB command server (default).
                    - 'client' to run as IB command client.
            kwargs : A dictionary of additional optional arguments.

                    - 'io_duration'='<io_duration_in_seconds>'
                        The duration for which to run IO (default='60').

                    - 'iterations'='<number of iterations>'
                        Number of iterations (default='100').
                        Note: Duration and Iteration are mutually exclusive

                    - 'ib_command'='<ib_command>'
                        The IB command to run for IO (default='read_lat').
                        Supported option=read_lat / read_bw / write_lat
                        / write_bw / send_lat / send_bw

                    - 'message_size'='<message_size>'
                        The size in bytes of the message to use
                         for IO (default='64').

                    - 'event_mode'='<process-type>'
                        Completion process type (default='polling').
                        Supported option = polling, event

                    - 'rdma_qp_type'='<connection-type>'
                        Connection transport type (default='RC').
                        Supported option = RC/UD

                    - 'use_srq'='<srq>'
                        Use shared receive queue (default='no').

                    - 'roce_protocol'='<roce type>'
                        RoCE type: 1 = RoCE V1, 2 = RoCE V2 (default='2').

                    - 'roce_port_num'='<port>'
                        TCP port to use (default='19875').

        """
        self._mode = mode
        self._tool_name = tool_name + 'user'
        self._tool_path = find_executable(self._tool_name)
        self.module_path = find_executable(tool_name)
        self._ib_command = self._tool_path

        self._io_duration = kwargs.get('io_duration', '60')
        self._iterations = kwargs.get('iterations', '100')
        self._ib_type = kwargs.get('ib_command', 'read_lat')
        self._message_size = kwargs.get('message_size', '65536')
        self._event_mode = kwargs.get('event_mode', 'polling')
        self._qp_type = kwargs.get('rdma_qp_type', 'RC')
        self._use_srq = kwargs.get('use_srq', 'no')
        self._roce_version = kwargs.get('roce_protocol', '2')
        self._port_no = kwargs.get('roce_port_num', '19875')
        self._result = {'THROUGHPUT': {},
                        'LATENCY': {}}
        self._ib_proc = None

        if self._qp_type == 'UD':
            if 'send' not in self._ib_type:
                raise exception.ConfigException(
                    'Incorrect QP type specified')

        self._roce_server_interface = \
            kwargs.get('rdma_interface_server_ip', None)
        self._roce_client_interface = \
            kwargs.get('rdma_interface_client_ip', None)

        self._ib_command += ' -s ' + self._message_size
        self._ib_command += ' -c ' + self._qp_type
        self._ib_command += ' -M ' + self._roce_version
        self._ib_command += ' -e ' + self._event_mode
        self._ib_command += ' -o ' + self._ib_type

        if self._use_srq == 'yes':
            if 'send' not in self._ib_command:
                raise exception.ConfigException(
                    'SRQ is supported only for ib_send_*')
            else:
                self._ib_command += ' Q'

        if self._io_duration is None:
            self._ib_command += ' -n ' + self._iterations
        elif self._iterations is None:
            self._ib_command += ' -w ' + self._io_duration
        else:
            raise exception.ConfigException(
                'IO_duration and number of iterations '
                'are mutually exclusive; provide only one value')
        self._ib_command += ' -p ' + self._port_no

    def setup_ib_command_server(self):
        """
        """
        if self._mode != 'server':
            raise exception.ConfigException(
                'Attempt to setup server on client node')

        if self._roce_server_interface is not None:
            self._ib_command += ' -v ' + self._roce_server_interface

        return True

    def setup_ib_command_client(self):
        """
        """
        if self._mode != 'client':
            raise exception.ConfigException(
                'Attempt to setup client on server node')

        if self._roce_server_interface is not None:
            self._ib_command += ' -i ' + self._roce_server_interface
            self._ib_command += ' -v ' + self._roce_client_interface

        return True

    def cleanup_ib_command_server(self):
        """
        """
        if 'server' not in self._mode:
            raise exception.ConfigException(
                'Attempt to cleanup server on client node')

        return True

    def cleanup_ib_command_client(self):
        """
        """
        if 'client' not in self._mode:
            raise exception.ConfigException(
                'Attempt to cleanup client on server node')

        return True

    def start(self):
        """
        """
        try:
            exe.block_run("vmkload_mod %s " % self.module_path)
        except Exception as e:
            if 'is already loaded' in str(e):
                pass
            else:
                raise exception.ConfigException("Cannot load %s module. Error:%s" % (self.module_path, str(e)))

        # Run the IB command.
        self._ib_proc = exe.run(
            self._ib_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        return True

    def stop(self, block=True):
        """
        """
        # Kill the process.
        if self._ib_proc.poll() is not None:
            self._ib_proc.kill()
        # If requested, wait for the process to die.
        while block is True and self._ib_proc.poll() is None:
            time.sleep(1)
        module_name = 'krdma'
        try:
            exe.block_run("vmkload_mod -u %s" % module_name)
        except Exception as e:
            if 'Module not found' in str(e):
                pass
            elif 'Limit exceeded' in str(e):
                time.sleep(2)
                try:
                    exe.block_run("vmkload_mod -u %s" % module_name)
                except:
                    pass
            else:
                raise exception.ConfigException("Cannot unload %s module. Error:%s" % (module_name, str(e)))

        return True

    def poll(self):
        """
        """
        # If the command failed, return failure.
        if self._ib_proc.poll() is None:
            return None

        if self._ib_proc.poll() != 0:
            raise \
                exception.ExeExitcodeException(self._ib_command,
                                               self._ib_proc.poll(),
                                               self._ib_proc.get_error())
        # Compose the results, just in case someone asks for them.
        output = self._ib_proc.get_output()

        if output.strip() != '':
            attribute = 'THROUGHPUT' if 'bw' in self._ib_command \
                else 'LATENCY'

            iter_value = str(re.findall('Iterations:\\s*(\\d*.*)',
                                        output)[0])
            if 'bw' in self._ib_command:
                bw_dict = {}
                bandwidth = str(re.findall('Bandwidth:\\s*(\\d*.*)',
                                           output)[0])
                bw_dict['iter_value'] = iter_value
                bw_dict['bandwidth'] = bandwidth
                self._result[attribute] = bw_dict
            else:
                lat_dict = {}
                min_value = str(re.findall('MIN:\\s*(\\d*.*)', output)[0])
                max_value = str(re.findall('MAX:\\s*(\\d*.*)', output)[0])
                lat_dict['iter_value'] = iter_value
                lat_dict['min_value'] = min_value
                lat_dict['max_value'] = max_value
                if self._io_duration is None:
                    median_value = str(re.findall('MEDIAN:\\s*(\\d*.*)', output)[0])
                    lat_dict['median_value'] = median_value
                else:
                    average_value = str(re.findall('AVERAGE:\\s*(\\d*.*)', output)[0])
                    lat_dict['average_value'] = average_value
                self._result[attribute] = lat_dict

        return self._ib_proc.poll()

    @property
    def result(self):
        """
        """
        return self._result


class IBCommandServer(IBCommandController):
    def __init__(self, **kwargs):
        super(IBCommandServer, self).__init__(mode='server', **kwargs)


class IBCommandClient(IBCommandController):
    def __init__(self, **kwargs):
        super(IBCommandClient, self).__init__(mode='client', **kwargs)
