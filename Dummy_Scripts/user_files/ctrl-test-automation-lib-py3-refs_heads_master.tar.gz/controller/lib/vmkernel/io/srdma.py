"""
:mod:`ib_commands` -- IB Commands Wrapper.
=========================================

.. module:: controller.lib.vmkernel.io.ib_commands
.. moduleauthor:: Gaurav Sethi <gaurav.sethi@broadcom.com>

This is a wrapper python module for IB IO commands.
Listed below are the functionalities
provided by this module:

1. Run 'ib_send_bw' command.
2. Run 'ib_read_bw' command.
3. Run 'ib_write_bw' command.
4. Run 'ib_send_lat' command.
5. Run 'ib_read_lat' command.
6. Run 'ib_write_lat' command.
7. Run 'ib_atomic_bw' command.
"""
import time
import re
import subprocess
from controller.lib.common.shell import exe
from controller.lib.core import exception
from distutils.spawn import find_executable
from controller.lib.core import log_handler

log = log_handler.get_logger(__name__)


class IBCommandController(object):
    def __init__(self, mode='server', tool_name='srdma', **kwargs):
        """
        The Constructor.

        Args:
            mode   : The mode in which IB Command runs.
                   - 'server' to run as IB command server (default).
                   - 'client' to run as IB command client.
            kwargs : A dictionary of additional optional arguments.


                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO (default='120').

                   - 'ib_command'='<ib_command>'
                     The IB command to run for IO (default='send_recv_bw').
                     Supported option=send_recv_bw/send_recv_lat/write_bw/write_lat/read_bw/read_lat/atomic_bw

                   - 'message_size'='<message_size>'
                     The size in bytes of the message to
                     use for IO (default='64').

        """
        self._mode = mode
        self._tool_name = tool_name + 'user'
        self._tool_path = find_executable(self._tool_name)
        self.module_path = find_executable(tool_name)
        self._ib_command = self._tool_path

        self._io_duration = kwargs.get('io_duration', '60')
        self._ib_type = kwargs.get('ib_command', 'send_recv_bw')
        self._message_size = kwargs.get('message_size', '65536')
        self._event_mode = kwargs.get('event_mode', 'polling')
        self._qp_type = kwargs.get('rdma_qp_type', 'RC')
        self._use_srq = kwargs.get('use_srq', 'no')
        self._roce_version = 'v' + kwargs.get('roce_protocol', '2')
        self._port_no = kwargs.get('roce_port_num', '18888')
        self._connec_type = kwargs.get('connections', '1')
        self._queue_depth = kwargs.get('queue_depth', '8')
        self._roce_server_interface = kwargs.get(
            'rdma_interface_server_ip', None)
        self._roce_client_interface = kwargs.get(
            'rdma_interface_client_ip', None)

        self._result = {'THROUGHPUT': '',
                        'LATENCY': ''}
        self._ib_proc = None

        if self._qp_type == 'UD':
            if 'send' not in self._ib_type:
                raise exception.ConfigException(
                    'Incorrect QP type specified')

        self._ib_command += ' -t ' + self._roce_version
        self._ib_command += ' -p ' + self._port_no
        self._ib_command += ' -u ' + self._qp_type


    def setup_ib_command_server(self):
        """
        """
        if self._mode != 'server':
            raise exception.ConfigException(
                'Attempt to setup server on client node')
        self._ib_command += ' -s '
        if self._roce_server_interface is not None:
            self._ib_command += ' -l ' + self._roce_server_interface

        return True

    def setup_ib_command_client(self):
        """
        """
        if self._mode != 'client':
            raise exception.ConfigException(
                'Attempt to setup client on server node')
        self._ib_command += ' -c '
        if self._roce_server_interface is not None:
            self._ib_command += ' -l ' + self._roce_client_interface
            self._ib_command += ' -r ' + self._roce_server_interface
            self._ib_command += ' -d ' + self._io_duration
            self._ib_command += ' -e ' + self._event_mode
            self._ib_command += ' -m ' + self._message_size
            self._ib_command += ' -o ' + self._ib_type
            self._ib_command += ' -n ' + self._connec_type
            self._ib_command += ' -T ' + self._queue_depth

        return True

    def cleanup_ib_command_server(self):
        """
        """
        if self._mode != 'server':
            raise exception.ConfigException(
                'Attempt to cleanup server on client node')

        return True

    def cleanup_ib_command_client(self):
        """
        """
        if self._mode != 'client':
            raise exception.ConfigException(
                'Attempt to cleanup client on server node')

        return True

    def start(self):
        """
        """
        try:
            exe.block_run("vmkload_mod %s" % self.module_path)
        except Exception as e:
            if 'is already loaded' in str(e):
                pass
            else:
                raise exception.ConfigException(
                    "Cannot load %s module. Error:%s"
                    % (self.module_path, str(e)))

        # Run the IB command.
        self._ib_proc = exe.run(
            self._ib_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        return True

    def stop(self, block=True):
        """
        """
        # Kill the process.
        if self._ib_proc.poll() is not None:
            self._ib_proc.kill()
        # If requested, wait for the process to die.
        while block is True and self._ib_proc.poll() is None:
            time.sleep(1)
        module_name = 'srdma'
        try:
            exe.block_run("vmkload_mod -u %s" % module_name)
        except Exception as e:
            if 'Module not found' in str(e):
                pass
            elif 'Limit exceeded' in str(e):
                time.sleep(2)
                try:
                    exe.block_run("vmkload_mod -u %s" % module_name)
                except:
                    pass
            else:
                raise exception.ConfigException("Cannot unload %s module. Error:%s" % (module_name, str(e)))

        return True

    def poll(self):
        """
        """
        # If the command failed, return failure.
        if self._ib_proc.poll() is None:
            return None

        if self._ib_proc.poll() != 0:
            raise exception.ExeExitcodeException(self._ib_command,
                                                 self._ib_proc.poll(),
                                                 self._ib_proc.get_error())
        # Compose the results, just in case someone asks for them.
        output = self._ib_proc.get_output()
        log.info("********************")
        log.info(output)
        log.info("********************")

        if output.strip() != '':
            attribute = 'THROUGHPUT' if 'bw' in self._ib_command else 'LATENCY'
            iterations = str(re.findall('Iterations:\\s*(\\d*.*)', output)[0])
            message_size = str(re.findall('Message size:\\s*(\\d*.*)', output)[0])
            average = str(re.findall('Avg:\\s*(\\d*.*)', output)[0])
            if 'bw' in self._ib_command:
                bw_dict = dict()
                bw_dict['Iterations'] = iterations
                bw_dict['Message_size'] = message_size
                bw_dict['Average'] = average
                self._result[attribute] = bw_dict
            else:
                lat_dict = dict()
                min_value = str(re.findall('Min:\\s*(\\d*.*)', output)[0])
                max_value = str(re.findall('Max:\\s*(\\d*.*)', output)[0])
                lat_dict['Iterations'] = iterations
                lat_dict['Message_size'] = message_size
                lat_dict['Average'] = average
                lat_dict['Min'] = min_value
                lat_dict['Max'] = max_value
                self._result[attribute] = lat_dict

        return self._ib_proc.poll()

    @property
    def result(self):
        """
        """
        return self._result


class IBCommandServer(IBCommandController):
    def __init__(self, **kwargs):
        super(IBCommandServer, self).__init__(mode='server', **kwargs)


class IBCommandClient(IBCommandController):
    def __init__(self, **kwargs):
        super(IBCommandClient, self).__init__(mode='client', **kwargs)
