"""
:mod:`tcpdump` -- tcpdump wrapper library
=========================================

.. module:: controller.lib.vmkernel.io.tcpdump
.. moduleauthor:: Gaurav Sethi <gaurav.sethi@broadcom.com>

"""
import time
import logging
from controller.lib.common.shell import exe

log = logging.getLogger(__name__)


class TCPDump(object):
    """
    The class that implements the un-buffered tcpdump command.
    """
    def __init__(self, vmk_name, **kwargs):
        """
        The constructor. Currently the implementation supports a limited set of options.
        """
        self.__interface = vmk_name
        self.__packet_count = kwargs.get('packet_count', -1)
        self.__src_ip = kwargs.get('src_ip', None)
        self.__dst_ip = kwargs.get('dst_ip', None)
        self.__protocol = kwargs.get('protocol', None)
        self.__src_port = kwargs.get('src_port', None)
        self.__dst_port = kwargs.get('dst_port', None)
        self.__proto = kwargs.get('proto', None)
        self.__ether_proto = kwargs.get('ether_proto', None)
        self.__verbose = kwargs.get('verbose', False)
        self.__tcpdump_proc = None
        self.__output = None
        self.__exe = exe
        self.__capture_file = kwargs.get('capture_file', None)

    def get_output(self):
        """
        The method that returns the buffered output.
        """
        return self.__output

    def start(self):
        """
        The method that starts the un-buffered tcpdump command with the options specified during
        construction.
        """
        src_ip_exists = False
        command = 'tcpdump-uw -len -i %s' % self.__interface

        if self.__src_ip is not None:
            command += ' host %s' % self.__src_ip
            src_ip_exists = True

        if self.__dst_ip is not None:
            command += ' %s%s' % ('and ' if src_ip_exists is True else 'host ', self.__dst_ip)

        if self.__protocol is not None:
            # If a list of protocols is specified, concatenate them all.
            if isinstance(self.__protocol, list):
                self.__protocol = ' and '.join(self.__protocol)

            command += ' %s%s' % ('and ' if src_ip_exists is True else '', self.__protocol)

        if self.__src_port is not None:
            command += ' %s%s' % ('and src port ' if src_ip_exists is True else 'src port ', self.__src_port)

        if self.__dst_port is not None:
            command += ' %s%s' % ('and dst port ' if src_ip_exists is True else 'dst port ', self.__dst_port)

        if self.__proto is not None:
            command += ' %s%s' % ('and proto ' if src_ip_exists is True else ' proto ', self.__proto)
        if self.__ether_proto is not None:
            command += ' %s%s' % ('and  ether proto ' if src_ip_exists is True else ' ether proto ',
                                  self.__ether_proto)

        if self.__packet_count != -1:
            command += ' -c %s' % self.__packet_count

        if self.__capture_file is not None:
            command += ' -w %s' % self.__capture_file

        if self.__verbose:
            command += ' -v'

        self.__tcpdump_proc = self.__exe.run(command)

    def stop(self):
        """
        The method that stops the running tcpdump command and saves the packets captured (IOW: the
        output of the command)
        """
        if self.__tcpdump_proc is not None:
            exe_proc = self.__tcpdump_proc

            if exe_proc.poll() is None:
                exe_proc.stop()
                time.sleep(1)

            self.__output = exe_proc.get_output()
            self.__tcpdump_proc = None
        else:
            log.info("tcpdump_proc is already None")

    def remove_pcapfile(self, capture_file):
        """
        the method deletes the pcap file created by capture option of tcpdump
        """
        self.__exe.block_run("rm -f %s" % str(capture_file))
