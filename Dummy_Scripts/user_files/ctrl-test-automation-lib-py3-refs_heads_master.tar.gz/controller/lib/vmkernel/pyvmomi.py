import re
import logging
import time
import sys
import traceback
import itertools

from netaddr import IPNetwork

from pyVmomi import vim
from pyVim import connect

from controller.lib.core import exception
from controller.lib.common.shell import exe


def get_obj(vimtype, name=None):
    """
    Get the vsphere object associated with a given text name
    """
    si = None
    obj = None
    while True:
        if si is None:
            si = connect.Connect()
        try:
            content = si.RetrieveContent()
            container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
            break
        except vim.fault.NotAuthenticated:
            si = None
    if vimtype == [vim.HostSystem]:
        return container.view[0]

    if name and name == 'GetAll':
        return [obj for obj in container.view]
    for c in container.view:
        if name:
            if c.name == name:
                obj = c
                break
        else:
            obj = c
            break

    return obj


def get_properties(viewtype, props, spectype):
    """
    Obtains a list of specific properties for a
     particular Managed Object Reference data object.

    :param viewtype: Type of Managed Object
    Reference that should populate the View
    :param props: A list of properties
    that should be retrieved for the entity
    :param spectype: Type of Managed Object Reference
    that should be used for the Property Specification
    :return:
    """
    # Get the View based on the viewtype

    si = None
    while True:
        if si is None:
            si = connect.Connect()

        try:
            content = si.RetrieveContent()
            objview = content.viewManager.CreateContainerView(
                content.rootFolder, viewtype, True)
            print('Connected to pyvmomi host.')
            break
        except vim.fault.NotAuthenticated:
            si = None
    # Build the Filter Specification
    tspec = vim.PropertyCollector.TraversalSpec(
        name='tSpecName', path='view', skip=False, type=vim.view.ContainerView)
    pspec = vim.PropertyCollector.PropertySpec(all=False,
                                               pathSet=props, type=spectype)
    ospec = vim.PropertyCollector.ObjectSpec(obj=objview,
                                             selectSet=[tspec], skip=False)
    pfspec = \
        vim.PropertyCollector.FilterSpec(
            objectSet=[ospec], propSet=[pspec],
            reportMissingObjectsInResults=False)
    retoptions = vim.PropertyCollector.RetrieveOptions()
    # Retrieve the properties and look for a token coming back
    # with each RetrievePropertiesEx call
    # If the token is present it indicates there
    # are more items to be returned.
    totalprops = []
    retprops = content.propertyCollector.RetrievePropertiesEx(
        specSet=[pfspec], options=retoptions)
    totalprops += retprops.objects

    while retprops.token:
        retprops = content.propertyCollector.ContinueRetrievePropertiesEx(
            token=retprops.token)
        totalprops += retprops.objects

    objview.Destroy()
    # Turn the output in totalProps into a usable dictionary of values
    gpoutput = []

    for eachprop in totalprops:
        propdic = {}

        for prop in eachprop.propSet:
            propdic[prop.name] = prop.val
            propdic['moref'] = eachprop.obj

        gpoutput.append(propdic)

    return gpoutput


def get_vfs_present(nic_name):
    try:
        output = exe.block_run('esxcli network sriovnic vf list -n %s' % nic_name)
    except Exception as e:
        logging.exception(e)
        logging.info('SRIOV is not configured on the interface %s.' % nic_name)
        return 0

    vfs = 0

    for line in output.split('\n'):
        if line.find('false') != -1 or line.find('true') != -1:
            vfs += 1

    return vfs


def set_sriov_command(driver, param_list):
    command = 'esxcli system module parameters set -m %s -a -p max_vfs=%s' % (driver, param_list)
    exe.block_run(command)


def set_sriov_vfs(nic_name, new_value, execute_set_command=True):
    vfs_set = get_sriov_vfs(nic_name)
    print(vfs_set)

    if vfs_set and vfs_set['num'] > new_value:
        raise exception.ValueException('Some virtual functions on '
                                       'the nic are attached to VMs.')

    host = get_obj([vim.HostSystem], {})

    driver = ""
    pci_id = ""
    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            driver = pnic.driver
            pci_id = pnic.pci

    nics_list = {pnic.pci: get_vfs_present(pnic.device) for pnic in host.config.network.pnic if pnic.device == nic_name}
    nics_list[pci_id] = new_value
    params = ''

    param_list = []
    for key in sorted(nics_list.keys()):
        params += '%s,' % int(nics_list[key])
        param_list.append(int(nics_list[key]))

    if execute_set_command:
        sriov_enabled = True if new_value else False
        nic_sriov = vim.host.SriovConfig()
        nic_sriov.id = pci_id
        nic_sriov.sriovEnabled = sriov_enabled
        nic_sriov.numVirtualFunction = new_value
        try:
            host.configManager.pciPassthruSystem.UpdatePassthruConfig(config=[nic_sriov])
            host.configManager.pciPassthruSystem.Refresh()
            time.sleep(2)
        except vim.fault.HostConfigFault as config_fault:
            raise exception.ConfigException(f"Failed to configure SR-IOV due to {config_fault}")
    else:
        return param_list


def set_rss(nic_name, new_value):
    host = get_obj([vim.HostSystem], {})
    driver = ""
    pci_id = ""
    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            driver = pnic.driver
            pci_id = pnic.pci

    nics_list = {pnic.pci: 0 for pnic in host.config.network.pnic
                 if pnic.driver == driver}
    nics_list[pci_id] = new_value
    params = ''

    for key in sorted(nics_list.keys()):
        params += '%s,' % int(nics_list[key])

    command = 'esxcli system module parameters set -m %s -a -p RSS=%s' % (driver, params[:-1])
    exe.block_run(command)


def set_drss(nic_name, new_value):
    host = get_obj([vim.HostSystem], {})
    driver = ""
    pci_id = ""
    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            driver = pnic.driver
            pci_id = pnic.pci

    nics_list = {pnic.pci: 0 for pnic in host.config.network.pnic
                 if pnic.driver == driver}
    nics_list[pci_id] = new_value
    params = ''

    for key in sorted(nics_list.keys()):
        params += '%s,' % int(nics_list[key])

    command = 'esxcli system module parameters set -m %s -a -p DRSS=%s' % (driver, params[:-1])
    exe.block_run(command)


def get_ring(nic_name):
    """Return ring information

    Args:
        nic_name (str): nic name

    Return:
        dict: key=queue type, value=preset, curset.
        If querying ring is not supported, return None
    """
    ret_dict = {'preset': {}, 'curset': {}}
    command = 'esxcli network nic ring current  get -n %s' % nic_name
    output = exe.block_run(command)

    for queue_type in ['RX', 'RX Mini', 'RX Jumbo', 'TX']:
        curset = [
            int(ring) for ring in re.findall(
                r'%s:[\s\t]+(\d+)' % queue_type, output)
        ]
        ret_dict['curset'][queue_type.lower()] = curset[0]

    command = 'esxcli network nic ring preset  get -n %s' % nic_name
    output = exe.block_run(command)
    for queue_type in ['RX', 'RX Mini', 'RX Jumbo', 'TX']:
        preset = [
            int(ring) for ring in re.findall(
                r'%s:[\s\t]+(\d+)' % queue_type, output)
        ]

        ret_dict['preset'][queue_type.lower()] = preset[0]

    return ret_dict


def set_ring(nic_name, ring_settings):
    """Configure the ring parameters using the given parameter.

    Args:
        nic_name (str): nic name
        ring_settings (dict): new channel settings.
        The rx and tx dictionary items of "curset"
    """
    settings = \
        ' '.join(['--%s %s' %
                  (param, value) for
                  param, value in list(ring_settings.items())])
    try:
        command = 'esxcli network nic ring current set -n %s %s' % (nic_name, settings)
        exe.block_run(command)
    except exception.ExeExitcodeException as err:
        if 'no ring parameters changed, aborting' in err.output:
            pass
        else:
            raise


def get_sriov_vfs(nic_name):
    try:
        output = exe.block_run('esxcli network sriovnic vf list -n %s' % nic_name)
    except (Exception,):
        return {'num': 0, 'total': 0}

    regexp = r'[true|false]+\s+(\w+:\w+.\w+)'
    vf_ids = re.findall(regexp, output)
    total_vfs = len(vf_ids)
    vms = get_obj([vim.VirtualMachine], 'GetAll')
    num_vfs = 0

    if total_vfs > 0 and len(vms) > 0:
        vms = get_obj([vim.VirtualMachine], 'GetAll')
        # pci_passthroughs = vms[0].environmentBrowser.
        # QueryConfigTarget(host=None).pciPassthrough
        # systemid_by_pciid = {item.pciDevice.id:
        # item.systemId for item in pci_passthroughs}
        attached_vfs = []

        for vm in vms:
            for device in vm.config.hardware.device:
                if type(device).__name__ == \
                        'vim.vm.device.VirtualPCIPassthrough':
                    attached_vfs.append(device.backing.id)

        host = get_obj([vim.HostSystem], {})
        devices = host.hardware.pciDevice

        for dev in devices:
            if dev.bus < 0:
                bus = 256 + dev.bus
            else:
                bus = dev.bus

            dev_check_id = '%s:%s.%s' % (str(bus).zfill(3),
                                         str(dev.slot).zfill(2),
                                         str(dev.function))
            print(dev.bus)

            if dev_check_id in vf_ids and dev.id in attached_vfs:
                num_vfs += 1

    return {'num': num_vfs, 'total': total_vfs}


def create_vswitch(host_network_system, vss_name, num_ports, nics):
    vss_spec = vim.host.VirtualSwitch.Specification()
    vss_spec.numPorts = num_ports
    vss_spec.bridge = vim.host.VirtualSwitch.BondBridge(nicDevice=nics)
    vss_spec.policy = vim.host.NetworkPolicy()
    vss_spec.policy.security = vim.host.NetworkPolicy.SecurityPolicy()
    vss_spec.policy.security.allowPromiscuous = True
    vss_spec.policy.security.forgedTransmits = True
    vss_spec.policy.security.macChanges = True
    vss_spec.policy.shapingPolicy = vim.host.NetworkPolicy.TrafficShapingPolicy()
    vss_spec.policy.shapingPolicy.enabled = False
    vss_spec.policy.nicTeaming = vim.host.NetworkPolicy.NicTeamingPolicy()
    vss_spec.policy.nicTeaming.notifySwitches = True
    vss_spec.policy.nicTeaming.rollingOrder = False
    # Default values
    vss_spec.policy.nicTeaming.failureCriteria = vim.host.NetworkPolicy.NicFailureCriteria()
    vss_spec.policy.nicTeaming.failureCriteria.fullDuplex = False
    vss_spec.policy.nicTeaming.failureCriteria.percentage = 0
    vss_spec.policy.nicTeaming.failureCriteria.checkErrorPercent = False
    vss_spec.policy.nicTeaming.failureCriteria.checkDuplex = False
    vss_spec.policy.nicTeaming.failureCriteria.checkBeacon = False
    vss_spec.policy.nicTeaming.failureCriteria.speed = 10
    vss_spec.policy.nicTeaming.failureCriteria.checkSpeed = 'minimum'
    vss_spec.policy.nicTeaming.nicOrder = vim.host.NetworkPolicy.NicOrderPolicy()
    vss_spec.policy.nicTeaming.nicOrder.activeNic = nics
    vss_spec.policy.nicTeaming.nicOrder.standbyNic = []
    vss_spec.policy.nicTeaming.policy = 'loadbalance_srcid'
    vss_spec.policy.nicTeaming.reversePolicy = True
    host_network_system.AddVirtualSwitch(vswitchName=vss_name, spec=vss_spec)


def create_teamed_vswitch(host_network_system, vss_name, nics, team_type):
    vss_spec = vim.host.VirtualSwitch.Specification()
    vss_spec.numPorts = 100
    vss_spec.bridge = vim.host.VirtualSwitch.BondBridge(nicDevice=nics)
    host_network_system.AddVirtualSwitch(vswitchName=vss_name, spec=vss_spec)
    host = get_obj([vim.HostSystem], {})

    for vswitch in host.config.network.vswitch:
        if vswitch.name == vss_name:
            vswitch_spec = vswitch.spec
            vswitch_spec.policy.nicTeaming.policy = team_type
            host_network_system.UpdateVirtualSwitch(vswitchName=vswitch.name, spec=vswitch_spec)


def create_port_group(host_network_system, pg_name, vss_name):
    port_group_spec = vim.host.PortGroup.Specification()
    port_group_spec.name = pg_name
    port_group_spec.vswitchName = vss_name
    security_policy = vim.host.NetworkPolicy.SecurityPolicy()
    security_policy.allowPromiscuous = True
    security_policy.forgedTransmits = True
    security_policy.macChanges = True
    port_group_spec.policy = vim.host.NetworkPolicy(security=security_policy)
    host_network_system.AddPortGroup(portgrp=port_group_spec)


def add_virtual_nic(host_network_system, pg_name):
    vnic_spec = vim.host.VirtualNic.Specification()
    vnic_spec.ip = vim.host.IpConfig()
    vnic_spec.ip.dhcp = True
    host_network_system.AddVirtualNic(portgroup=pg_name,
                                      nic=vnic_spec)


def set_vlan(nic_name, new_vlan, pg_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    switch_name = 'VirtualSwitch-%s' % nic_name

    def config_vlan():
        if portgrp_spec.vlanId != new_vlan:
            portgrp_spec.vlanId = new_vlan
            host_network_system.UpdatePortGroup(
                pgName=portgrp_spec.name,
                portgrp=portgrp_spec)
    for portgroup in host.config.network.portgroup:
        if portgroup.spec.vswitchName == switch_name:
            portgrp_spec = portgroup.spec
            if pg_name:
                if portgrp_spec.name == pg_name:
                    config_vlan()
                    break
            else:
                config_vlan()


def set_promisc(nic_name, value, pg_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem

    if value == 'off':
        value = False
    else:
        value = True

    switch_name = 'VirtualSwitch-%s' % nic_name

    def config_promisc():
        if portgrp_spec.policy.security.allowPromiscuous != value:
            portgrp_spec.policy.security.allowPromiscuous = value
            host_network_system.UpdatePortGroup(pgName=portgrp_spec.name, portgrp=portgrp_spec)

    for portgroup in host.config.network.portgroup:
        if portgroup.spec.vswitchName == switch_name:
            portgrp_spec = portgroup.spec
            if pg_name:
                if portgrp_spec.name == pg_name:
                    config_promisc()
                    break
            else:
                config_promisc()


def set_ipv6_addr(nic_name, method, new_ip_addr, port_group_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    if port_group_name:
        vnic = get_virtual_nic(nic_name, port_group_name)
    else:
        vnic = get_virtual_nic(nic_name)
    vnic_spec = vnic.spec
    ip_net = IPNetwork(new_ip_addr)
    ip_addr = str(ip_net.ip)
    prefixlen = ip_net.prefixlen

    if method == 'replace':
        vnic_spec.ip.ipV6Config = \
            vim.host.IpConfig.IpV6AddressConfiguration()
    else:
        for ip in vnic_spec.ip.ipV6Config.ipV6Address:
            if ip.ipAddress == ip_addr:
                raise exception.ConfigException(
                    'Ipv6 Address specied '
                    'is already configured on the interface.')

    ip6 = vim.host.IpConfig.IpV6Address()
    ip6.origin = 'manual'
    ip6.ipAddress = ip_addr
    ip6.prefixLength = prefixlen
    vnic_spec.ip.ipV6Config.ipV6Address.append(ip6)
    host_network_system.RemoveVirtualNic(device=vnic.device)
    host_network_system.AddVirtualNic(
        portgroup=vnic.portgroup, nic=vnic_spec)


def remove_ipv6_addr(nic_name, ip6_addr, port_group_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    if port_group_name:
        vnic = get_virtual_nic(nic_name, port_group_name)
    else:
        vnic = get_virtual_nic(nic_name)
    vnic_spec = vnic.spec
    ip_addrs = []

    if ip6_addr:
        ip_net = IPNetwork(ip6_addr)
        ip_addr = str(ip_net.ip)
        prefixlen = ip_net.prefixlen

        for ip in vnic_spec.ip.ipV6Config.ipV6Address:
            if ip.ipAddress != ip_addr or ip.prefixLength != prefixlen:
                print(ip.ipAddress)
                ip_addrs.append(ip)

    vnic_spec.ip.ipV6Config = \
        vim.host.IpConfig.IpV6AddressConfiguration()

    if len(ip_addrs) > 0:
        vnic_spec.ip.ipV6Config.ipV6Address = ip_addrs

    host_network_system.RemoveVirtualNic(device=vnic.device)
    host_network_system.AddVirtualNic(
        portgroup=vnic.portgroup, nic=vnic_spec)


def get_ipv6_addr(nic_name, port_group_name=None):
    if port_group_name:
        vnic = get_virtual_nic(nic_name, port_group_name)
    else:
        vnic = get_virtual_nic(nic_name)
    vnic_spec = vnic.spec
    return {ip.ipAddress: ip.prefixLength for
            ip in vnic_spec.ip.ipV6Config.ipV6Address
            if ip.origin == 'manual' or ip.origin == 'dhcp'}


def set_ipv4_addr(nic_name, new_ip_addr, port_group_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    if port_group_name:
        vnic = get_virtual_nic(nic_name, port_group_name)
    else:
        vnic = get_virtual_nic(nic_name)
    vnic_spec = vnic.spec
    ip_net = IPNetwork(new_ip_addr)
    ip_addr = str(ip_net.ip)
    netmask = str(ip_net.netmask)

    if vnic_spec.ip.ipAddress != ip_addr or \
            vnic_spec.ip.subnetMask != netmask:
        vnic_spec.ip.ipAddress = ip_addr
        vnic_spec.ip.subnetMask = netmask
        vnic_spec.ip.dhcp = False
        host_network_system.UpdateVirtualNic(
            device=vnic.device, nic=vnic_spec)


def set_mtu(nic_name, new_mtu):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    for vnic in host.config.network.vnic:
        if vnic.portgroup != 'Management Network':
            vnic_spec = vnic.spec
            if vnic_spec.mtu != new_mtu:
                vnic_spec.mtu = new_mtu
                host_network_system.UpdateVirtualNic(
                    device=vnic.device, nic=vnic_spec)

    vswitch = get_virtual_switch(nic_name)
    vswitch_spec = vswitch.spec

    if vswitch.spec.mtu != new_mtu:
        vswitch_spec.mtu = new_mtu
        host_network_system.UpdateVirtualSwitch(
            vswitchName=vswitch.name, spec=vswitch_spec)


def get_physical_nic(nic_name):
    host = get_obj([vim.HostSystem], {})
    # host_network_system = host.configManager.networkSystem
    ret_nic = None

    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            ret_nic = pnic
            break

    return ret_nic


def get_physical_nic_by_mac(mac_addr):
    host = get_obj([vim.HostSystem], {})
    # host_network_system = host.configManager.networkSystem
    ret_nic = None

    for pnic in host.config.network.pnic:
        if pnic.mac.lower() == mac_addr.lower():
            ret_nic = pnic
            break

    return ret_nic


def get_physical_nic_by_ip(ip_addr):
    host = get_obj([vim.HostSystem], {})
    # host_network_system = host.configManager.networkSystem
    port_group_name = None
    ret_prg = None

    for vnic in host.config.network.vnic:
        # if vnic.spec.ip.ipAddress == ip_addr or vnic.spec.ip.ipV6Config.ipV6Address.ipAddress == ip_addr:
        #     port_group_name = vnic.portgroup
        # ER_DCSG01749778: On 8.0U3 ipV6Config.ipV6Address is an instance of List().
        # Traverse through list object to find ipAddress to fetch portgroup
        logging.debug(f'ipV6Config.ipV6Address is instance of "{type(vnic.spec.ip.ipV6Config.ipV6Address)}"')
        if isinstance(vnic.spec.ip.ipV6Config.ipV6Address, list):
            ipv6_addr_list = []
            for ipv6_addr_obj in vnic.spec.ip.ipV6Config.ipV6Address:
                ipv6_addr_list.append(ipv6_addr_obj.ipAddress)
            logging.debug(f'ipV6Config.ipV6Address List: {ipv6_addr_list}')

            if any(ipAddress == ip_addr for ipAddress in ipv6_addr_list) or (vnic.spec.ip.ipAddress == ip_addr):
                port_group_name = vnic.portgroup
        else:
            if (vnic.spec.ip.ipAddress == ip_addr) or (vnic.spec.ip.ipV6Config.ipV6Address.ipAddress == ip_addr):
                port_group_name = vnic.portgroup

    if port_group_name:
        for portgroup in host.config.network.portgroup:
            if port_group_name == portgroup.spec.name:
                ret_prg = portgroup
                break

    logging.debug(f'PortGroup of IP:{ip_addr} is "{ret_prg}"')
    return ret_prg


def get_virtual_nic(nic_name, port_group_name=None):
    host = get_obj([vim.HostSystem], {})
    # host_network_system = host.configManager.networkSystem
    ret_vnic = None

    if not port_group_name:
        pg_name = 'TestNetwork-%s' % nic_name
    else:
        pg_name = port_group_name

    for vnic in host.config.network.vnic:
        if vnic.portgroup == pg_name:
            ret_vnic = vnic
            break

    # print ret_vnic.device
    return ret_vnic


def get_virtual_nic_ens(switchuuid=None):
    host = get_obj([vim.HostSystem], {})
    ret_vnic = []
    for vnic in host.config.network.vnic:
        if vnic.spec.distributedVirtualPort is not None:
            if vnic.spec.distributedVirtualPort.switchUuid == switchuuid:
                ret_vnic.append(vnic)
                # print(vnic.spec.mac)
                # print(vnic.spec.distributedVirtualPort)
    return ret_vnic


def get_virtual_switch_ens(nic_name):
    host = get_obj([vim.HostSystem], {})
    logging.info('NVDVS-%s' % nic_name)
    ret_vs = None
    for dvswitch in host.config.network.proxySwitch:
        if len(dvswitch.spec.backing.pnicSpec) > 0:
            if dvswitch.spec.backing.pnicSpec[0].pnicDevice == nic_name:
                ret_vs = dvswitch
                # print(dvswitch)
                # print(dvswitch.spec.backing.pnicSpec[0].pnicDevice)
                break
    return ret_vs


def get_ens_vnic_mac(nic_name):
    dvswitch = get_virtual_switch_ens(nic_name)
    dvnic_list = get_virtual_nic_ens(dvswitch.dvsUuid)
    ret_mac_list = []
    for dvnic in dvnic_list:
        print(dvnic.spec.mac)
        ret_mac_list.append(dvnic.spec.mac)
    return ret_mac_list


def get_port_group(nic_name):
    host = get_obj([vim.HostSystem], {})
    # host_network_system = host.configManager.networkSystem
    ret_prg = None
    switch_name = 'VirtualSwitch-%s' % nic_name

    for portgroup in host.config.network.portgroup:
        if portgroup.spec.vswitchName == switch_name:
            ret_prg = portgroup
            break

    return ret_prg


def get_virtual_switch(nic_name):
    host = get_obj([vim.HostSystem], {})
    # host_network_system = host.configManager.networkSystem
    switch_name = 'VirtualSwitch-%s' % nic_name
    ret_vs = None

    for vswitch in host.config.network.vswitch:
        if vswitch.name == switch_name:
            ret_vs = vswitch
            break

    return ret_vs


def create_teamed_interface(team_name, member_nics, teaming_type):
    for nic in member_nics:
        delete_iface(nic, remove_vswitch=True)

    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    switch_name = 'VirtualSwitch-%s' % team_name
    port_group_name = 'TestNetwork-%s' % team_name

    for vswitch in host.config.network.vswitch:
        nics = \
            [nic for nic in
             vswitch.spec.policy.nicTeaming.nicOrder.activeNic] \
            + [nic for nic in
               vswitch.spec.policy.nicTeaming.nicOrder.standbyNic]

        for nic in member_nics:
            print(nics.count(nic))

            if nics.count(nic) > 0:
                raise exception.ConfigException(
                    'The physical nic %s is already '
                    'associated with another vswitch %s' %
                    (nic, vswitch.name))

    create_teamed_vswitch(host_network_system, switch_name,
                          member_nics, teaming_type)
    create_port_group(host_network_system, port_group_name,
                      switch_name)
    add_virtual_nic(host_network_system, port_group_name)


def create_interface(nic_name, vswitch_name=None, port_group_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    switch_name = \
        vswitch_name if vswitch_name is not None else 'VirtualSwitch-%s' % nic_name
    if port_group_name:
        pg_name = port_group_name
    else:
        pg_name = 'TestNetwork-%s' % nic_name
    switch_found = False
    port_found = False
    vnic_found = False

    for vswitch in host.config.network.vswitch:
        if vswitch.name == switch_name:
            switch_found = True
            break

    if not switch_found:
        create_vswitch(host_network_system, switch_name, 100, [nic_name])

    for portgroup in host.config.network.portgroup:
        if portgroup.spec.vswitchName == switch_name and\
                portgroup.spec.name == pg_name:
            port_found = True

    if not port_found:
        create_port_group(host_network_system, pg_name, switch_name)

    for vnic in host.config.network.vnic:
        if vnic.portgroup == pg_name:
            vnic_found = True

    if not vnic_found:
        add_virtual_nic(host_network_system, pg_name)

    if port_group_name:
        vnic = get_virtual_nic(nic_name, pg_name)
    else:
        vnic = get_virtual_nic(nic_name)
    return vnic.device


def get_dvswitch_list():
    host = get_obj([vim.HostSystem], {})
    dvswitch_list = list()
    # collect DVSwitch details
    for dvswitch in host.config.network.proxySwitch:
        vswitch_dict = dict()
        vswitch_portgroup = list()
        vnic_portgroup = None
        vnic_device = None
        vswitch_pnic = None
        vswitch_spec_nicdevice = None
        vswitch_name = None
        uplink_port = None
        vswitch_type = 'dvswitch'
        if len(dvswitch.spec.backing.pnicSpec) > 0:
            vswitch_name = dvswitch.dvsName
            if len(list(dvswitch.pnic)) > 0:
                vswitch_pnic = dvswitch.pnic[0].replace(r'key-vim.host.PhysicalNic-', '')
            if len(list(dvswitch.spec.backing.pnicSpec)) > 0:
                vswitch_spec_nicdevice = dvswitch.spec.backing.pnicSpec[0].pnicDevice
            if len(list(dvswitch.uplinkPort)) > 0:
                uplink_port = dvswitch.uplinkPort[0].value
            vswitch_dict = {'vswitch_type': vswitch_type,
                            'vnic_portgroup': vnic_portgroup,
                            'vnic_device': vnic_device,
                            'vswitch_name': vswitch_name,
                            'vswitch_portgroup': vswitch_portgroup,
                            'vswitch_pnic': vswitch_pnic,
                            'vswitch_spec_nicdevice': vswitch_spec_nicdevice,
                            'uplink_port': uplink_port}
            dvswitch_list.append(vswitch_dict)
    logging.info(f'DVSwitchList = {dvswitch_list}')
    return dvswitch_list


def get_vswitch_list(dvswitch=True):
    """
        Returns vswitch list (Standard and DVSwitch) available on ESX host (except Management Network and BMC_Network)

        @return : List or dict()
        Example :
        vSwitchList = [
                        {'vswitch_type': 'standard',
                        'vnic_portgroup': 'TestNetwork-vmnic1',
                        'vnic_device': 'vmk1',
                        'vswitch_name': 'VirtualSwitch-vmnic1',
                        'vswitch_portgroup': ['TestNetwork-vmnic1'],
                        'vswitch_pnic': 'vmnic1',
                        'vswitch_spec_nicdevice': 'vmnic1',
                        'uplink_port': None},

                        {'vswitch_type': 'dvswitch',
                        'vnic_portgroup': None,
                        'vnic_device': None,
                        'vswitch_name': 'NVDVS-vmnic2',
                        'vswitch_portgroup': [],
                        'vswitch_pnic': 'vmnic2',
                        'vswitch_spec_nicdevice': 'vmnic2',
                        'uplink_port': 'uplink0'}
                    ]
    """
    host = get_obj([vim.HostSystem], {})
    vswitch_list = list()
    # collect Standard Switch details
    for vnic in host.config.network.vnic:
        vnic_portgroup = None
        vnic_device = None
        if vnic.portgroup != 'Management Network' and vnic.portgroup != 'BMC_Network':
            vnic_portgroup = vnic.portgroup
            vnic_device = vnic.device
            for vswitch in host.config.network.vswitch:
                vswitch_dict = dict()
                vswitch_portgroup = list()
                vswitch_pnic = None
                vswitch_spec_nicdevice = None
                vswitch_name = None
                vswitch_type = 'standard'
                uplink_port = None

                vswitch_portgroup = list(vswitch.portgroup)
                if len(vswitch_portgroup) > 0:
                    vswitch_portgroup = [re.sub(r'key\-vim\.host\.PortGroup\-', '', str(pg))
                                         for pg in vswitch_portgroup]

                if isinstance(vswitch_portgroup, list) \
                        and len(vswitch_portgroup) > 0 \
                        and any(pg for pg in vswitch_portgroup if re.search(vnic_portgroup, pg)):
                    vswitch_name = vswitch.name

                    if len(list(vswitch.pnic)) > 0:
                        vswitch_pnic = vswitch.pnic[0].replace(r'key-vim.host.PhysicalNic-', '')
                    if len(vswitch.spec.bridge.nicDevice) > 0:
                        vswitch_spec_nicdevice = vswitch.spec.bridge.nicDevice[0]

                    vswitch_dict = {'vswitch_type': vswitch_type,
                                    'vnic_portgroup': vnic_portgroup,
                                    'vnic_device': vnic_device,
                                    'vswitch_name': vswitch_name,
                                    'vswitch_portgroup': vswitch_portgroup,
                                    'vswitch_pnic': vswitch_pnic,
                                    'vswitch_spec_nicdevice': vswitch_spec_nicdevice,
                                    'uplink_port': uplink_port}
                    vswitch_list.append(vswitch_dict)
                    break
    logging.info(f'vSwitchList = {vswitch_list}')
    if dvswitch:
        dvswitch_list = get_dvswitch_list()
        if len(dvswitch_list) > 0:
            vswitch_list = list(itertools.chain(vswitch_list, dvswitch_list))

    return vswitch_list


def delete_all_vswicthes():
    pyvmomi_host = get_obj([vim.HostSystem], {})
    host_network_system = pyvmomi_host.configManager.networkSystem
    vswitch_list = get_vswitch_list()
    for vswitch in vswitch_list:
        if vswitch['vswitch_type'] == 'standard':
            logging.info(f"Deleting vnic_portgroup:{vswitch['vnic_portgroup']}, "
                         f"vnic_device:{vswitch['vnic_device']}, vswitch_pnic={vswitch['vswitch_pnic']}")
            host_network_system.RemoveVirtualNic(device=vswitch['vnic_device'])
            logging.info(f"Deleting vswitch_name:{vswitch['vswitch_name']}, vswitch_pnic={vswitch['vswitch_pnic']}")
            host_network_system.RemoveVirtualSwitch(vswitchName=vswitch['vswitch_name'])
        elif vswitch['vswitch_type'] == 'dvswitch':
            try:
                logging.info(f"Delete VMkernel NIC {vswitch['vswitch_pnic']} from a dvswitch {vswitch['vswitch_name']}")
                exe.block_run("esxcfg-vmknic -d -s %s -v %s"
                              % (vswitch['vswitch_name'], vswitch['vswitch_pnic']))
                time.sleep(2)
            except Exception as ex:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                logging.warning(f"Exception {type(ex).__name__} while deleting VMkernel NIC {vswitch['vswitch_pnic']} "
                                f"from a dvswitch {vswitch['vswitch_name']} ")
                logging.warning(f'Exception Message :  {str(ex_value)}'
                                f'Traceback Info: {traceback.format_exc()}')
                logging.warning(f"Continuing with exception")

            try:
                logging.info(f"Delete port {vswitch['vswitch_pnic']} from a dvswitch {vswitch['vswitch_name']}")
                exe.block_run("net-dvs -D -p %s %s"
                              % (vswitch['vswitch_pnic'], vswitch['vswitch_name']))
                time.sleep(2)
                logging.info(f"Deactivate ENS on the virtual switch {vswitch['vswitch_name']}")
                exe.block_run("esxcfg-vswitch -Y %s" % vswitch['vswitch_name'])
                time.sleep(2)
                logging.info(f"Delete an uplink {vswitch['uplink_port']} from a  "
                             f"DVPort {vswitch['vswitch_pnic']} on a DVSwitch {vswitch['vswitch_name']}")
                exe.block_run("esxcfg-vswitch -Q %s -V %s %s"
                              % (vswitch['vswitch_pnic'], vswitch['uplink_port'], vswitch['vswitch_name']))
                time.sleep(2)
                logging.info(f"Deleting DVSwitch {vswitch['vswitch_name']}")
                exe.block_run("nsxdp-cli vswitch instance destroy %s" % vswitch['vswitch_name'])
                time.sleep(2)
            except Exception as ex:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                logging.warning(f"Encountered an exception {type(ex).__name__} while removing "
                                f"DVSwitch {vswitch['vswitch_name']} ")
                logging.warning(f'Exception Message :  {str(ex_value)}'
                                f'Traceback : {str(ex_traceback)}')
        else:
            pass
    postop_vswitch_list = get_vswitch_list()
    if len(postop_vswitch_list) > 0:
        raise exception.ConfigException(f'Removing existing vswitch configurations was unsuccessful'
                                        f'Debug : existing_vswitch_list={postop_vswitch_list}')
    else:
        logging.info(f"Existing vswitch configurations were removed successfully")


def delete_iface(nic_name, remove_vswitch=False, pg_name=None):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem

    for vnic in host.config.network.vnic:
        print(vnic.portgroup)
        if vnic.portgroup != 'Management Network':
            if pg_name:
                if vnic.portgroup == pg_name:
                    host_network_system.RemoveVirtualNic(device=vnic.device)
                    break
            else:
                host_network_system.RemoveVirtualNic(device=vnic.device)
    if remove_vswitch:
        delete_vswitch(nic_name)


def delete_vswitch(nic_name):
    host = get_obj([vim.HostSystem], {})
    host_network_system = host.configManager.networkSystem
    logging.info('VirtualSwitch-%s' % nic_name)
    for vswitch in host.config.network.vswitch:
        if vswitch.name.startswith('VirtualSwitch'):
            host_network_system.RemoveVirtualSwitch(vswitchName=vswitch.name)
        # if vswitch.name == switch_name:
        #     host_network_system.RemoveVirtualSwitch(vswitchName=switch_name)


def get_coalesce(iface):
    """
    Return coalesce parameters as a dictionary.

    Args:
        iface (str): ethX name

    Return:
        dict: key=param, value=value

    """
    ret_dict = {}
    output = exe.block_run('esxcli network nic coalesce'
                           ' get -n %s' % iface).strip().split('\n')

    if len(output) == 3:
        header = output[0]
        info = output[2]
        rx_usec_ind = header.find('RX microseconds')
        rx_frames_ind = header.find('RX maximum frames')
        tx_usec_ind = header.find('TX microseconds')
        tx_frames_ind = header.find('TX Maximum frames')
        adapt_rx_ind = header.find('Adaptive RX')
        adapt_tx_ind = header.find('Adaptive TX')
        sample_int_ind = header.find('Sample interval seco')
        ret_dict['rx-usecs'] = int(info[rx_usec_ind: rx_frames_ind - 2])
        ret_dict['rx-max-frames'] = int(info[rx_frames_ind:tx_usec_ind - 2])
        ret_dict['tx-usecs'] = int(info[tx_usec_ind:tx_frames_ind - 2])
        ret_dict['tx-max-frames'] = int(info[tx_frames_ind:adapt_rx_ind - 2])
        ret_dict['adapt-rx'] = info[adapt_rx_ind:adapt_tx_ind - 2].strip()
        ret_dict['adapt-tx'] = info[adapt_tx_ind:sample_int_ind - 2].strip()
        ret_dict['sample-interval'] = int(info[sample_int_ind])

    return ret_dict


def set_coalesce(iface, param, value):
    """Set coalesce parameter.

    Args:
        iface (str): ethX name
        param (str): parameter name i.e.) rx-frames
        value (str, int): str for adapt_rx and adapt_tx
        and int for all other parameters.
    """
    params_dict = {'rx-usecs': '-r',
                   'rx-max-frames': '-R',
                   'tx-usecs': '-t',
                   'tx-max-frames': '-T',
                   'adapt-rx': '-a',
                   'adapt-tx': '-A',
                   'sample-interval': '-i'}

    if param in params_dict:
        exe.block_run('esxcli network nic coalesce set %s %s  -n %s'
                      % (params_dict[param], value, iface))
        return
    raise exception.ValueException(
        'Unsupported parameter for coalesce.')


def get_pause(iface):
    """Return pause options

    Args:
        iface (str): ethX name

    Return:
        dict: auto_neg, rx, tx, rx_neg, tx_neg keys and values
    """
    ret_val = {}
    ret_map = {'true': 'on', 'false': 'off'}
    output = exe.block_run('esxcli network nic pauseParams '
                           'list -n %s' % iface).strip().split('\n')
    print(output)

    if len(output) == 3:
        header = output[0]
        info = output[2]
        supp_ind = header.find('Pause Params Supported')
        rx_ind = header.find('Pause RX')
        tx_ind = header.find('Pause TX')
        auto_neg_ind = header.find('Auto Negotiation')
        auto_res_ind = header.find('Auto Negotiation Resolution Avail')
        rx_neg_ind = header.find('RX Auto Negotiation Resolution')
        tx_neg_ind = header.find('TX Auto Negotiation Resolution')
        ret_val['supported'] = \
            ret_map[info[supp_ind: rx_ind - 2].strip()]
        ret_val['autoneg'] = \
            ret_map[info[auto_neg_ind: auto_res_ind - 2].strip()]
        ret_val['rx'] = ret_map[info[rx_ind: tx_ind - 2].strip()]
        ret_val['tx'] = ret_map[info[tx_ind: auto_neg_ind - 2].strip()]
        ret_val['rx_neg'] = \
            ret_map[info[rx_neg_ind: tx_neg_ind - 2].strip()]
        ret_val['tx_neg'] = ret_map[info[tx_neg_ind:].strip()]

    print(ret_val)
    return ret_val


def set_pause(iface, options):
    """Set pause options

    Args:
        iface (str): ethX name
        options: as string

    """
    exe.block_run('esxcli network nic pauseParams set'
                  ' %s -n %s' % (options, iface))


def get_pci_id_interface(nic_name):
    host = get_obj([vim.HostSystem], {})
    pci_id = None
    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            pci_id = pnic.pci
            break
    return pci_id


def get_driver_info(nic_name):
    host = get_obj([vim.HostSystem], {})
    ret_dict = {}
    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            ret_dict = {'name': pnic.driver,
                        'version': pnic.driverVersion,
                        'firmware': pnic.firmwareVersion}
            break
    return ret_dict

