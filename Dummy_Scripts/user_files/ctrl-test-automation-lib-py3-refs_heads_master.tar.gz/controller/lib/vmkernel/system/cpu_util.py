"""
:mod:`stats` -- System statistics library
=========================================

.. module:: controller.lib.linux.system.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

This library is to access system statistics related information such as
CPU usage.


Get CPU Utilization
-------------------

get_cpu_util() takes less arguments and works simpler. Without any arguments,
it will return CPU utilization % in 0.1 sec

# >>> stats.get_cpu_usage()
32.43

Of course you can call the function as blocking with the interval argument.

# >>> stats.get_cpu_usage(interval=5)
31.03

Unlike interrupt counters, CPU utilization is not a cumulative number, you
cannot calculate it as a non-blocking.

"""

import time

from pyVmomi import vim
from controller.lib.vmkernel import pyvmomi

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


def get_cpu_util(interval=None):
    """
    Return CPU utilization.

    If interval is None, it will measure for 0.1 sec.
    If cpu is None, it will return utilization of all CPUs.

    Args:
        interval (None, int): interval time to measure CPU utilization

    Returns:
        float: CPU utilization in percentage...
        Average if interval is not None
        list: A list of CPU utilization if cpu is list

    """
    hostprops = pyvmomi.get_properties([vim.HostSystem],
                                       ['name'], vim.HostSystem)
    host = hostprops[0]
    host_moref = host['moref']
    if interval is None:
        host_cpu = host_moref.summary.quickStats.overallCpuUsage
        print(host_moref.summary.quickStats)
        host_total_cpu = \
            host_moref.summary.hardware.cpuMhz \
            * host_moref.summary.hardware.numCpuCores
        print((host_cpu, host_total_cpu))
        final_output = (float(host_cpu) / float(host_total_cpu)) * 100
        return final_output
    else:
        stop_time = time.time() + interval
        cpu_utils = []
        while time.time() < stop_time:
            host_cpu = host_moref.summary.quickStats.overallCpuUsage
            host_total_cpu = \
                host_moref.summary.hardware.cpuMhz \
                * host_moref.summary.hardware.numCpuCores
            final_output = (float(host_cpu) / float(host_total_cpu)) * 100
            cpu_utils.append(final_output)
        return sum(cpu_utils) / len(cpu_utils)


def get_no_cpus():
    hostprops = pyvmomi.get_properties([vim.HostSystem],
                                       ['name'], vim.HostSystem)
    host = hostprops[0]
    host_moref = host['moref']
    return host_moref.summary.hardware.numCpuThreads
