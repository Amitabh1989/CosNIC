"""
:mod:`driver` -- VMWare ESXi driver install/uninstall API
===========================================================

.. module:: controller.lib.common.vmkernel.system.driver
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>


esxcli software vib command is used for installing/removing/getting info
about the vib packages.

"""
import re

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.system import driver
from controller.lib.common.shell import exe
from controller.lib.vmkernel import pyvmomi

log = log_handler.get_logger(__name__)


class BaseDrv(driver.BaseDriver):
    def __init__(self):
        super(BaseDrv, self).__init__()

    def get_driver_name(self, macaddress):
        """Function to get service name of the driver installed.

        Args:
            macaddress (str): Macaddress of the network port.

        Note: parse macaddress with ":" as separator or delimiter.

        Returns:
            driver_name (str): service name of the driver.
        """
        pnic = pyvmomi.get_physical_nic_by_mac(macaddress)

        if pnic is not None:
            return pnic.driver

        if self:
            return None

    @staticmethod
    def _parse_output(output):
        """Function to parse output
        Args:
            output: output that needs to be parsed
        Returns:
            my_dict: parsed output in a user readable format
        """

        my_dict = dict()
        for item in output.split('\n'):
            if item.find(':') != -1:
                arr = re.findall('(.*):(.*)', item)
                if arr:
                    for key, value in arr:
                        key = key.strip()
                        key = re.sub('\s', "_", key)
                        my_dict[key] = value.strip()
        return my_dict


class EsxDrv(BaseDrv):
    """Driver operations method implementation

    This class uses user-space tools to do driver operation on the NIC

    Args:

    Returns:
        Interface: Interface object that has methods to interact with
            the driver operations

    """

    def __init__(self):
        super(EsxDrv, self).__init__()

    def install(self, filename):
        """Function to install driver.

        Args:
            filename (str): Path of device driver (Absolute path)

        Returns:
            res: output of driver installation.

        Info: Reboot might be required when the package is installed.
              Output must be parsed and system must be rebooted if required.


        """
        log.info('Install %s' % filename)
        if filename.endswith("vib"):
            cmd = "esxcli software vib install --no-sig-check -v \"%s\"" % filename
            res = exe.block_run(cmd)
            return res
        else:
            raise exception.ValueException('Cannot recognize the filename. Expect <driver_name>.vib')

    def uninstall(self, vib_name):
        """Function to uninstall the device driver.

        Args:
            vib_name (str): Name of the driver

        Returns:
            bool: True if successful else False

        """
        log.info('Uninstall %s' % vib_name)
        cmd = "esxcli software vib remove -n \"%s\"" % vib_name
        res = exe.block_run(cmd)
        return res

    def is_installed(self, vib_name):
        """Function to verify device is installed or not?

        Args:
            vib_name (str): Name of the driver

        Returns:
            bool: True if successful else False
        """
        if self.get_driver_info(vib_name) is not None:
            return True

        return False

    def get_version(self, vib_name):
        """Function to get the driver version installed on the device.

        Args:
            vib_name (str): Name of the driver

        Returns:
            driver_version (str): Driver version
        """
        output = self.get_driver_info(vib_name)

        if output is None:
            log.info('The software with the provided vib name is not installed')
            return None

        if 'Version' in output:
            return output['Version']

        if self:
            return None

    def get_driver_info(self, vib_name):
        """Function to get published driver package name

        Args:
            vib_name (str): Name of the driver

        Returns:
            dict with vib/component info

        """
        cmd = "esxcli software vib get -n \"%s\"" % vib_name

        try:
            output = exe.block_run(cmd)
        except exception.ExeExitcodeException:
            return None

        return self._parse_output(output)

    def get_package_info(self, pkg_name):
        raise NotImplementedError

    def rollback(self, driver_name):
        raise NotImplementedError

    def upgrade(self, filename, force=False):
        raise NotImplementedError


class CompEsxDrv(BaseDrv):

    def __init__(self):
        super(CompEsxDrv, self).__init__()

    def install(self, filename):
        """Function to install driver.

        Args:
            filename (str): Path of device driver (Absolute path)

        Returns:
            res: output of driver installation.

        Info: Reboot might be required when the package is installed.
              Output must be parsed and system must be rebooted if required.


        """
        log.info('Install %s' % filename)
        if filename.endswith("zip"):
            cmd = "esxcli software component apply --no-sig-check -d \"%s\"" % filename
            res = exe.block_run(cmd)
            return res
        else:
            raise exception.ValueException('Cannot recognize the filename. Expect <driver_name>.zip')

    def uninstall(self, vib_name):
        """Function to uninstall the device driver.

        Args:
            vib_name (str): Name of the driver

        Returns:
            bool: True if successful else False

        """
        log.info('Uninstall %s' % vib_name)
        cmd = "esxcli software component remove -n \"%s\"" % vib_name
        res = exe.block_run(cmd)
        return res

    def is_installed(self, vib_name):
        """Function to verify device is installed or not?

        Args:
            vib_name (str): Name of the driver

        Returns:
            bool: True if successful else False
        """
        if self.get_driver_info(vib_name) is not None:
            return True

        return False

    def get_version(self, vib_name):
        """Function to get the driver version installed on the device.

        Args:
            vib_name (str): Name of the driver

        Returns:
            driver_version (str): Driver version
        """
        output = self.get_driver_info(vib_name)

        if output is None:
            log.info('The software with the provided vib name is not installed')
            return None

        if 'Version' in output:
            return output['Version']

        if self:
            return None

    def get_driver_info(self, component_name):
        """Function to get published driver package name

        Args:
            component_name (str): Name of ESXi component

        Returns:
            dict with component info

        """
        cmd = "esxcli software component get -n \"%s\"" % component_name

        try:
            output = exe.block_run(cmd)
        except exception.ExeExitcodeException:
            return None

        return self._parse_output(output)

    def get_package_info(self, pkg_name):
        raise NotImplementedError

    def rollback(self, driver_name):
        raise NotImplementedError

    def upgrade(self, filename, force=False):
        raise NotImplementedError


def install(filename):
    esx_driver = CompEsxDrv() if filename.endswith('.zip') else EsxDrv()
    esx_driver.install(filename)


def get_version(driver_name, component=False):
    """
    Function to get the driver version installed on the device.

            Args:
                driver_name (str): Name of the driver
                component (boolean) : If True, driver 'component' version will be returned,
                                    else 'vib' version will be returned

            Returns:
                driver_version (str): Driver version
    """
    esx_driver = CompEsxDrv() if component else EsxDrv()
    return esx_driver.get_version(driver_name)


