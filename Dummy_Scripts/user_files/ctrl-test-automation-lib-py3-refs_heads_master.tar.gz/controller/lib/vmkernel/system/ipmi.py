"""
:mod:`ipmi` -- IPMI controller
===========================================

.. module:: controller.lib.vmkernel.system.ipmi
.. moduleauthor:: Sharath Shanth <sharath.shanth@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Inc"

import re
import logging

from distutils.spawn import find_executable
from controller.lib.core import exception
from controller.lib.common.shell import exe

log = logging.getLogger(__name__)


class Ipmi(object):
    """
    IPMI controller Class
    """
    def __init__(self):
        self._prg_path = find_executable('ipmitool')

        if not self._prg_path:
            raise exception.ConfigException('No ipmitool found')
        else:
            log.debug(f'ipmitool path: {self._prg_path}')

    def on(self):
        self.exec_command('power on')

    def off(self):
        self.exec_command('power off')

    def cycle(self):
        self.exec_command('power cycle')

    def soft(self):
        self.exec_command('power soft')

    def status(self):
        output = self.exec_command('power status')
        return re.search('Chassis Power is (.*)', output).group(1)

    def exec_command(self, command):
        return exe.block_run('%s %s' % (self._prg_path, command))


def on():
    return cmd('on')


def off():
    return cmd('off')


def cycle():
    return cmd('cycle')


def soft():
    return cmd('soft')


def status():
    return cmd('status')


def cmd(cmd):
    ipmi = Ipmi()
    return getattr(ipmi, cmd)()



