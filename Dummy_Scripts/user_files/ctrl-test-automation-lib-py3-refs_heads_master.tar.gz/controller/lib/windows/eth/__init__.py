"""
:mod:`eth` -- Ethernet interface API
====================================

.. module:: controller.lib.windows.eth
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

CTRL:48082 Deprecated wmic please replace wmic methods  to lib/windows/eth/interface/powershell.py methods
"""

import platform

from controller.lib.windows.system import wmic as system_wmic
from .interface.powershell import PowerShellInterface
from .interface.wmic import WmicInterface


def get_interface(iface, method=None):
    """Factory function to return the Interface object

    Return Interface object depending on the given "method" argument.

    Args:
        iface (str): Interface name
        method (None, str): choices=[None|wmic|powershell]. If None, use
            wmic for Win2k8 R2 and powershell for Win2k12 and later.

    """

    win_ver = platform.win32_ver()[0]
    if (method is None and win_ver == '2012Server') or 'powershell':
        return PowerShellInterface(iface=iface)
    elif (method is None and win_ver == '2008ServerR2') or 'wmic':
        return WmicInterface(iface=iface)
    raise ValueError('Unknown method type')


def get_interface_by_mac_addr(mac_addr, method=None):
    """A factory function to return the Interface object

    Return Interface object that has the given MAC address depending on
    the method argument.

    Args:
        mac_addr (str): MAC address in xx:xx:xx:xx:xx:xx format
        method (None, str): choices=[None|wmic|powershell]. If None, use
            wmic for Win2k8 R2 and powershell for Win2k12 and later.

    Return:
        Interface: Interface object that has the given MAC address

    """
    mac_addr = mac_addr.replace('-',':')
    for nic in system_wmic.network_adapter(MACAddress=mac_addr):
        iface = get_interface(nic.NetConnectionID, method)
        if iface.is_netipinterface is True:
            return iface

    return None


def get_interfaces_by_driver(driver, **kwargs):
    ret_list = []

    for nic in system_wmic.network_adapter(ServiceName=driver):
        ret_list.append(get_interface(nic.NetConnectionID, **kwargs))

    return ret_list


def get_interfaces():
    # Use WMIC since it has better compatibility
    return [
        eth.NetConnectionID for eth in system_wmic.network_adapter()
        if eth.NetConnectionID
    ]


def get_interfaces_by_ip_addr(ip_addr):
    ret_list = []

    for iface in system_wmic.network_adapter_config():
        if ip_addr in iface.IPAddress:
            _iface = system_wmic.network_adapter(Index=iface.Index)[0]
            ret_list.append(get_interface(_iface.NetConnectionID))

    return ret_list
