"""
:mod:`powershell` -- AppInterface with PowerShell implementation
================================================================

.. module:: controller.lib.windows.eth.app_interface.powershell
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import netaddr
import time

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.eth.interface import BaseInterface

from controller.lib.windows.eth import powershell
from controller.lib.windows.eth import stats
from controller.lib.windows.eth import netsh


log = log_handler.get_logger(__name__)


class PowerShellInterface(BaseInterface):
    """PowerShell wrapper.

    Do not use registry or WMIC. Support Windows 2012 and later.
    This should reflect more user-space level environment.

    """
    def __init__(self, iface):
        super(PowerShellInterface, self).__init__(iface=iface)

    @property
    def is_netipinterface(self):
        return powershell.is_netipinterface(self.iface)

    def up(self):
        """Bring up the interface by enabling"""
        powershell.up(self.iface)

    def down(self):
        """Bring down the interface by disabling"""
        powershell.down(self.iface)

    @property
    def _ip_addr(self):
        """Return <IP address>/<prefix>"""
        return powershell.get_ip_addr(self.iface)

    @property
    def _ip6_addr(self):
        """Return <IPv6 address>/<prefix>"""
        return powershell.get_ip_addr(self.iface, ip_ver=6)

    @property
    def ip_addr(self):
        """Return the IP address without prefix"""
        ret_value = self._ip_addr
        return ret_value[0].split('/')[0] if ret_value else None

    @property
    def ip6_addr(self):
        ret_value = self._ip6_addr
        return ret_value[0].split('/')[0] if ret_value else None

    @ip_addr.setter
    def ip_addr(self, new_ip_addr):
        """Set a new IP address to the interface.

        If any other IPv4 addresses exist, remove them and then assign a new
        one.

        Args:
            new_ip_addr (None, str): IP address with prefix i.e.) x.x.x.x/x.
                If None, remove all IPv4 addresses
        """

        # Disable DHCP
        powershell.set_dhcp(self.iface, False)
        # Delete all assigned IPv4 address
        for ip_addr in self._ip_addr:
            log.debug('Removing IP address ... ')
            powershell.remove_ip_addr(self.iface, ip_addr)

        if new_ip_addr is None:  # Just remove all IP address. Return here.
            return

        # Add a new IP address
        try:
            powershell.set_ip_addr(self.iface, new_ip_addr)
        except exception.ExeExitcodeException as err:
            if 'MSFT_NetIPAddress already exists' in err.output:
                log.warning(
                    'Failed to assign the IP address due to the same one is '
                    'already assigned')
                return
            raise

    @ip6_addr.setter
    def ip6_addr(self, new_ip_addr):
        """Add a new IP address to the interface

        Note that this does NOT remove IPv6 addresses before assigning, since
        that's the default behavior.

        Args:
            new_ip_addr (str): IPv6 address with prefix i.e.) x::x/x

        """

        # Add a new IP address
        try:
            powershell.set_ip_addr(self.iface, new_ip_addr, ip_ver=6)
        except exception.ExeExitcodeException as err:
            if 'already exists' in err.output:
                return
            raise

    def set_ip6_addr(self, new_ip6_addr, method, **kwargs):
        """Add or remove IPv6 addresses

        Args:
            new_ip6_addr (str): IPv6 address with prefix i.e.) x::x/x
            method (str): choices=[add|del]

        """
        if method == 'del':
            powershell.remove_ip_addr(self.iface, new_ip6_addr, ip_ver=6)
        else:
            self.ip6_addr = new_ip6_addr

    @property
    def netmask(self):
        ret_value = self._ip_addr
        if not ret_value:
            return None

        return str(netaddr.IPNetwork(ret_value[0]).netmask)

    @property
    def prefix(self):
        ret_value = self._ip_addr
        if not ret_value:
            return None

        return ret_value[0].split('/')[1]

    @property
    def ip6_prefix(self):
        ret_value = self._ip6_addr
        if not ret_value:
            return None

        return {
            ip6_addr.split('/')[0]: [ip6_addr.split('/')[1] for ip6_addr in
            self._ip6_addr]
        }

    @property
    def mac_addr(self):
        """Return MAC address of NIC, as in format xx:xx:xx:xx:xx:xx"""
        return powershell.get_mac_addr(self.iface)

    @mac_addr.setter
    def mac_addr(self, new_mac_addr):
        """Set new MAC address to the interface.

        If new_mac_addr is None, restore the original MAC address.

        Args:
            new_mac_addr (None, str): New MAC address in xx:xx:xx:xx:xx:xx
                If None, reset to the default MAC address.
        """
        powershell.set_mac_addr(self.iface, new_mac_addr)

    @property
    def admin_status(self):
        """Return whether the interface is enabled

        The return value is normalized as 'up' and 'down' to match with
        state.

        """
        admin_status = powershell.get_netadapter(self.iface).AdminStatus
        if admin_status == 1:
            return 'up'
        elif admin_status == 2:
            return 'down'
        raise exception.ValueException(
            'Unknown AdminStatus value %s' % admin_status)

    @property
    def state(self):
        """Return link status. Mapping information as below:

        * Connected = up
        * Disconnected = down

        All other states will be returned as unknown.

        """
        status = powershell.get_netadapter(self.iface).Status

        if status.lower() == 'up':
            return 'up'

        return 'down' if status.lower() in [
            'disabled', 'disconnected'] else 'unknown'

    @property
    def drvinfo(self):
        """Return driver information of the interface.

        TODO: Need to implement.

        Returns:
            dict: driver information. Format is below.
            {
                'name': <driver_name>,
                'version': <driver_version,
                'firmware": <optional. Firmware version>
            }

        """
        net_adapter = powershell.get_netadapter(self.iface)

        return {
            'name': net_adapter.DriverFileName,
            'version': net_adapter.DriverVersion,
        }

    @property
    def mtu(self):
        """Get MTU size"""
        return self.jumbo_packet

    @mtu.setter
    def mtu(self, new_mtu):
        """Set MTU use a registry value *JumboPacket

        This means the argument new_mtu only accepts the pre-defined sizes

        Args:
            new_mtu (int): MTU size
        """
        self.jumbo_packet = new_mtu

    @property
    def mtu_valid_list(self):
        """Return a list of MTU sizes that are allowed to be set"""
        if powershell.get_netadapter_advanced_property(self.iface)[
            '*JumboPacket'].ValidDisplayValues:
            return powershell.get_netadapter_advanced_property(self.iface)[
                '*JumboPacket'].ValidDisplayValues
        else:
            return None

    def set_mtu(self, new_mtu, method='netsh'):
        """Another method to change the MTU.

        Unlike "mtu", this allows to set the MTU using different methods.

        Args:
            new_mtu (int): New MTU value
            method (str): choices=[netsh] only one choice for now.
        """

        if method == 'netsh':
            netsh.set_mtu(iface=self.iface, mtu=new_mtu)
        else:
            raise exception.ValueException('method is invalid')

    def get_mtu(self, method='netsh'):
        """Another method to get the MTU.

        Unlike "mtu", this gets a MTU size from netsh

        Args:
            method (str): choices=[netsh] only one choice for now.
        """
        if method == 'netsh':
            return netsh.get_mtu(iface=self.iface)
        raise exception.ValueException('method is invalid')

    @property
    def speed(self):
        """
        Speed will be returned as Mb as defined in the template.

        """
        speed = powershell.get_netadapter(self.iface).Speed
        return -1 if speed == '' else int(speed)/1000000

    @speed.setter
    def speed(self, new_speed):
        """Set the speed using registry. Speed must be in Mb.
        """
        raise NotImplementedError('Should use set_speed_duplex() instead')

    @property
    def duplex(self):
        """Return the current duplex mode. Need to implement."""
        return 'full' if powershell.get_netadapter(
            self.iface).FullDuplex else 'half'

    @duplex.setter
    def duplex(self, new_mode):
        """Set the speed using registry. Speed must be in Mb.
        """
        raise NotImplementedError('Should use set_speed_duplex() instead')

    def set_speed_duplex(self, regvalue=None, dispvalue=None):
        """Set speed and duplex

        Note that the passing value is Registry Value, not a display one. This
        means developers should be well aware what values they need to pass,
        since this value can be different depending on product type.

        Args:
            regvalue (str): Registry value
            dispvalue (str): Display value

        """
        powershell.set_networkadapter_advanced_property(
            self.iface, regkey='*SpeedDuplex',
            regvalue=regvalue, dispvalue=dispvalue)

    def dump(self, attr_list=None):
        """Dump the NIC properties

        Do not erturn duplex due to it hasn't implemented yet

        Returns:
            dict: key=param, value=value

        """
        return super(PowerShellInterface, self).dump(
            attr_list=attr_list or [
                'ip_addr', 'ip6_addr', 'netmask', 'mac_addr', 'state',
                'mtu', 'speed', 'drvinfo',
            ]
        )

    @property
    def features(self):
        """Return the available advanced properties.

        Will display RegistryKeyword and DisplayValue
        """
        ret_dict = {}

        for regkey, regvalue in list(powershell.get_netadapter_advanced_property(
                self.iface).items()):
            ret_dict[regkey] = regvalue.DisplayValue

        return ret_dict

    def set_feature(self, feature, regvalue=None, dispvalue=None):
        """Set a feature to a new setting

        Note that new_setting must be "display value"

        Args:
            feature (str): A registory keyword name of feature. i.e.) *Sriov
            regvalue (str): A new registry value
            dispvalue (str): A new display value

        """
        powershell.set_networkadapter_advanced_property(
            self.iface, regkey=feature, regvalue=regvalue, dispvalue=dispvalue
        )

    @property
    def flow_control(self):
        """Return the normalized display name of flow control setting.

        * Auto negotiation = auto_neg
        * rx only = rx
        * tx only = tx
        * rx & tx = rx_tx
        * disabled = disabled

        """
        mapping = {
            '0': 'disabled', '1': 'tx', '2': 'rx',
            '3': 'rx_tx', '4': 'auto_neg'
        }

        return mapping[
            powershell.get_netadapter_advanced_property(
                self.iface)['*FlowControl'].RegistryValue[0]]

    @flow_control.setter
    def flow_control(self, new_setting):
        """Set the new flow control value using the normalized name

        For normalized values, refer the property flow_control()

        Args:
            new_flow_control (str): choices=[auto_neg|rx|tx|rx_tx|disabled]

        """
        mapping = {
            'disabled': '0', 'tx': '1', 'rx': '2',
            'rx_tx': '3', 'auto_neg': '4'
        }

        powershell.set_networkadapter_advanced_property(
            iface=self.iface, regkey='*FlowControl',
            regvalue=mapping[new_setting])

    @property
    def queue(self):
        """Return RSS queue size"""
        return int(
            powershell.get_netadapter_advanced_property(
                self.iface)['*NumRSSQueues'].DisplayValue)

    @queue.setter
    def queue(self, queue_dict):
        """Set a RSS queue size.

        Since Windows does not allow to have different queue sizes for Rx and
        Tx, check rx and tx values and if they are different, raise exception
        since it's not supportted

        Args:
            queue_dict (dict): {'rx': <rx_queue_num>, 'tx': <tx_queue_num>}

        """

        if queue_dict['rx'] != queue_dict['tx']:
            raise exception.ValueException(
                '"rx" and "tx" queue sizes cannot be different')

        powershell.set_networkadapter_advanced_property(
            iface=self.iface, regkey='*NumRSSQueues',
            regvalue=queue_dict['rx']
        )

    @property
    def stats(self):
        return stats.get_stats(self.iface)

    @property
    def route(self):
        raise NotImplementedError('Not implemented')

    def set_route(self, method, dst, gateway=None):
        raise NotImplementedError('Not implemented')

    @property
    def interrupt(self):
        return powershell.get_interrupt(self.iface)

    @property
    def jumbo_packet(self):
        return powershell.get_netadapter_advanced_property(
            self.iface)['*JumboPacket'].DisplayValue

    @jumbo_packet.setter
    def jumbo_packet(self, new_setting):
        powershell.set_networkadapter_advanced_property(
            self.iface, regkey='*JumboPacket', dispvalue=new_setting)

    def ping(self, dst_ip, count=2, **kwargs):
        """Ping the remote host

        Due to Windows does not return non-zero exit code at failures, instead
        of using '-c' option, this method will run "ping" command as many as
        the "count" argument to check each ping's result, since ping statistics
        (packets sent, received, lost) does not reflect overall result
        correctly.

        Args:
            dst_ip (str): Destination IP address
            count (int): A number of ping
            **kwargs (kwargs): key=param, value=value. This can be used to pass
                extra options to ping

        """

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        overall_result = True
        err_output_list = []
        for _ in range(count):
            try:
                output = exe.block_run(
                    'ping -n 5 %s %s' % (' '.join(extra_options), dst_ip))
            except exception.ExeExitcodeException as err:
                err_output_list.append(err.output)
                overall_result = False
            else:
                if 'TTL' not in output:
                    err_output_list.append(output)
                    overall_result = False
                else:
                    # Sleep 1 sec to send ping every 1 sec
                    time.sleep(1)
                    overall_result = True
                    break

        if not overall_result:
            log.error(
                'Ping failed. Error: {}'.format('\n'.join(err_output_list)))
            return False

        return overall_result

    def ping6(self, dst_ip, count=2, **kwargs):
        """Ping over IPv6 to remote host"""
        if '-6' not in kwargs:
            kwargs['-6'] = True

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        overall_result = True
        err_output_list = []
        for _ in range(count):
            try:
                output = exe.block_run(
                    'ping -n 3 %s %s' % (' '.join(extra_options), dst_ip))
            except exception.ExeExitcodeException as err:
                err_output_list.append(err.output)
                overall_result = False
            else:
                if 'Reply from' not in output or 'time' not in output:
                    err_output_list.append(output)
                    overall_result = False
                else:
                    # Sleep 1 sec to send ping every 1 sec
                    time.sleep(1)
                    overall_result = True
                    break

        if not overall_result:
            log.error(
                'Ping failed. Error: {}'.format('\n'.join(err_output_list)))
            return False

        return overall_result

    def add_vlan(self, vlan_id):
        """Set VLAN over the interface using PowerShell"""
        powershell.set_vlan(self.iface, vlan_id)

    def remove_vlan(self, vlan_id=None):
        """Remove VLAN over the interface by setting to 0

        Args:
            vlan_id (int, None): Will be ignored, since only one VLAN ID can
                be assigned per interface

        """
        powershell.set_vlan(self.iface, 0)

    @property
    def pcidevice(self):
        """ Return PCI device name
        :return str. domain:bus:device.function  Ex: 0000:b3:00:00
        """
        hw_info = powershell.get_adapter_hardware_info(self.iface)
        segment = hw_info[0].Segment
        bus = hw_info[0].Bus
        device = hw_info[0].Device
        function = hw_info[0].Function
        dbdf = f'{segment:04x}:{bus:02x}:{device:02x}.{function:01x}'

        return dbdf

    def get_vnic(self):
        """Return a vNIC name which is bound to this physical interface"""
        pnic_mac_addr = self.mac_addr.replace(':', '-').upper()

        iface = [
            nic for nic in
            powershell.ps.exec_powershell(
                'get-netadapter', select_clause='Name,MacAddress,Virtual')
            if nic.MacAddress ==  pnic_mac_addr and nic.Virtual
        ]

        if len(iface) == 1:
            return iface[0].Name

        elif len(iface) > 1:
            raise exception.ValueException(
                'Detect more than one NIC that has the MAC address %s '
                '(NICs: %s)' % (self.mac_addr, iface)
            )

        elif len(iface) == 0:
            log.warning('No vNIC detected')
            return None

        raise exception.STATException(
            'Coding error? This should not be reached')

    @property
    def roce_capable(self):
        if '*NetworkDirect' in powershell.get_netadapter_advanced_property(self.iface):
            return True
        else:
            return False

    @property
    def roce(self):
        """Return RSS queue size"""
        return int(
            powershell.get_netadapter_advanced_property(
                self.iface)['*NetworkDirect'].DisplayValue)

    @roce.setter
    def roce(self, state):
        """Set a RSS queue size.

        Since Windows does not allow to have different queue sizes for Rx and
        Tx, check rx and tx values and if they are different, raise exception
        since it's not supportted

        Args:
            queue_dict (dict): {'rx': <rx_queue_num>, 'tx': <tx_queue_num>}

        """
        powershell.set_networkadapter_advanced_property(
            iface=self.iface, regkey='*NetworkDirect',
            regvalue=1 if state else 0
        )

    @property
    def roce_version(self):
        """Return RSS queue size"""
        return int(
            powershell.get_netadapter_advanced_property(
                self.iface)['RoCEVersion'].DisplayValue)

    @roce_version.setter
    def roce_version(self, version):
        """Set a RSS queue size.

        Since Windows does not allow to have different queue sizes for Rx and
        Tx, check rx and tx values and if they are different, raise exception
        since it's not supportted

        Args:
            queue_dict (dict): {'rx': <rx_queue_num>, 'tx': <tx_queue_num>}

        """
        powershell.set_networkadapter_advanced_property(
            iface=self.iface, regkey='RoCEVersion',
            regvalue=version
        )

