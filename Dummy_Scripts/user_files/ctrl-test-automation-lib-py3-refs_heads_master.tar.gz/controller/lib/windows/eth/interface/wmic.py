"""
:mod:`wmic` -- AppInterface with wmic implementation
====================================================

.. module:: controller.lib.windows.eth.app_interface.wmic
.. moduleauthor:: Eugene Cho <echo@broadcom.com>
CTRL:48082 Deprecated it please use/port code to lib/windows/eth/interface/powershell.py
"""

import time
import netaddr

from functools import wraps

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.shell import exe
from controller.lib.common.eth.interface import BaseInterface
from controller.lib.windows.system import sysinfo

from .. import registry
from .. import wmic
from .. import netsh


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


log = log_handler.get_logger(__name__)


class WmicInterface(BaseInterface):
    """A class to interact with network adapter using various user-space tools

    """
    def __init__(self, iface):
        super(WmicInterface, self).__init__(iface=iface)
        self._reg = registry.get_registry_handler(iface=iface)
        self._index = wmic.get_index(iface)

    @property
    def reg(self):
        return self._reg

    @property
    def index(self):
        return self._index

    @property
    def name(self):
        return wmic.system_wmic.network_adapter(index=self.index)[0].Name

    def enabled_only(func, *args, **kwargs):
        @wraps(func)
        def enabled_check(self, *args, **kwargs):
            if not self.enabled:
                raise exception.ConfigException(
                    'Cannot call this method when the interface is disabled')
            return func(self, *args, **kwargs)
        return enabled_check

    def up(self):
        """Bring up the interface by enabling"""
        netsh.up(iface=self.iface)

    def down(self):
        """Bring down the interface by disabling

        Track the internal setting, so do not run methods that will not work
        when the interface is disabled.

        """
        netsh.down(iface=self.iface)

    @property
    def _ip_addr(self):
        return wmic.get_ip_addr(self.index)

    @property
    def _ip6_addr(self):
        return wmic.get_ip_addr(self.index, ip_ver=6)

    @property
    @enabled_only
    def ip_addr(self):
        if not self._ip_addr:
            return None
        return self._ip_addr[0].split('/')[0]

    @ip_addr.setter
    @enabled_only
    def ip_addr(self, new_ip_addr):
        wmic.set_ip_addr(self.index, [new_ip_addr])

    @property
    @enabled_only
    def ip6_addr(self):
        ret_value = self._ip6_addr
        if not ret_value:
            return None

        return [
            _ip6_addr.split('/')[0] for _ip6_addr in ret_value
        ] if ret_value else None

    @ip6_addr.setter
    def ip6_addr(self, new_ip_addr):
        raise NotImplementedError(
            'IPv6 address can only be set through set_ip6_addr method. Please '
            'use set_ip6_addr instead.'
        )

    def set_ip6_addr(self, new_ip6_addr, method, **kwargs):
        netsh.set_ip_addr(
            iface=self.iface, method=method, ip_addr=new_ip6_addr, ipv6=True)

    @property
    @enabled_only
    def netmask(self):
        return None if not self._ip_addr else str(
            netaddr.IPNetwork(self._ip_addr[0]).netmask)

    @property
    @enabled_only
    def prefix(self):
        return None if not self._ip_addr else self._ip_addr[0].split('/')[1]

    @property
    @enabled_only
    def ip6_prefix(self):
        return {
            ip6_addr.split('/')[0]: [ip6_addr.split('/')[1] for ip6_addr in
            self._ip6_addr]
        }

    @property
    @enabled_only
    def mac_addr(self):
        """Return MAC address of NIC, as a lowercase

        """
        return wmic.get_mac_addr(self.index)

    @mac_addr.setter
    def mac_addr(self, new_mac_addr):
        """Set new MAC address to the interface.

        If new_mac_addr is None, restore the original MAC address.

        Args:
            new_mac_addr (None, str): New MAC address in xx:xx:xx:xx:xx:xx
                If None, reset to the default MAC address.
        """

        if not new_mac_addr:
            self.reg.del_value(key='NetworkAddress')
            return

        # Normalize the MAC address
        new_mac_addr = new_mac_addr.replace(':', '')
        self.reg.set_value(key='NetworkAddress', value=new_mac_addr)

    @property
    def enabled(self):
        """Return whether the interface is enabled

        The return value is normalized as 'up' and 'down' to match with
        state.

        """
        return wmic.get_enabled(self.index)

    @property
    def state(self):
        """Return link status. Mapping information as below:

        * Connected = up
        * Disconnected = down

        All other states will be returned as unknown.

        """
        return wmic.get_state(self.index)

    @property
    def drvinfo(self):
        """Return driver information of the interface.

        TODO: Need to implement.

        Returns:
            dict: driver information. Format is below.
            {
                'name': <driver_name>,
                'version': <driver_version,
                'firmware": <optional. Firmware version>
            }

        """
        return {
            'name': self.reg.driver,
            'version': sysinfo.SysInfo.get_driver_info(self.reg.driver)
        }

    @property
    @enabled_only
    def mtu(self):
        """Get MTU size using netsh"""
        return netsh.get_mtu(iface=self.iface)

    @mtu.setter
    @enabled_only
    def mtu(self, new_mtu):
        netsh.set_mtu(iface=self.iface, mtu=new_mtu)

    @property
    @enabled_only
    def speed(self):
        """
        Speed will be returned as Mb as defined in the template.
        Due to WMI returns unicode, covert to string before returning.

        """
        raise NotImplementedError('Not implemented')

    @speed.setter
    def speed(self, new_speed):
        """Set the speed using registry. Speed must be in Mb.
        """
        raise NotImplementedError('Should use set_speed_duplex() instead')

    @property
    def duplex(self):
        """Return the current duplex mode. Need to implement."""
        raise NotImplementedError('Not implemented')

    @duplex.setter
    def duplex(self, new_mode):
        """Set the speed using registry. Speed must be in Mb.
        """
        raise NotImplementedError('Should use set_speed_duplex() instead')

    def set_speed_duplex(self, speed, duplex):
        """Set speed and duplex

        Args:
            speed (int): Speed in Mb
            duplex (str): choices=[half|full]

        """
        self.reg.set_speed_duplex(speed, duplex)

    @enabled_only
    def dump(self, attr_list=None):
        """Dump the NIC properties

        Do not erturn duplex due to it hasn't implemented yet

        Returns:
            dict: key=param, value=value

        """
        return super(WmicInterface, self).dump(
            attr_list=attr_list or [
                'ip_addr', 'ip6_addr', 'netmask', 'mac_addr', 'state',
                'mtu', 'speed', 'drvinfo',
            ]
        )

    @property
    def features(self):
        """Return the available advanced properties from registry"""
        return self.reg.features

    def set_feature(self, feature, new_setting):
        """Set a feature to a new setting

        Note that new_setting must be "display value"

        Args:
            feature (str): A name of feature. i.e.) Sriov
            new_setting (str): A new setting. Not the enum but display name.
                i.e.) Enabled

        """
        self.reg.set_feature(feature=feature, display_value=new_setting)

    @property
    def flow_control(self):
        """Return the normalized display name of flow control setting.

        * Auto negotiation = auto_neg
        * rx only = rx
        * tx only = tx
        * rx & tx = rx_tx
        * disabled = disabled

        """

        return self.reg.flow_control

    @flow_control.setter
    def flow_control(self, new_setting):
        """Set the new flow control value using the normalized name

        For normalized values, refer the property flow_control()

        Args:
            new_flow_control (str): choices=[auto_neg|rx|tx|rx_tx|disabled]

        """

        self.reg.flow_control = new_setting

    @property
    def route(self):
        return netsh.get_route(iface=self.iface)

    @property
    def jumbo_packet(self):
        return self.reg.jumbo_packet

    @jumbo_packet.setter
    def jumbo_packet(self, new_setting):
        self.reg.jumbo_packet = new_setting

    def interrupt(self):
        raise NotImplementedError('Not implemented')

    @property
    def queue(self):
        raise NotImplementedError('Not implemented')

    @queue.setter
    def queue(self):
        raise NotImplementedError('Not implemented')

    @property
    def stats(self):
        raise NotImplementedError('Not implemented')

    def ping(self, dst_ip, count=2, **kwargs):
        """Ping the remote host

        Args:
            dst_ip (str): Destination IP address
            count (int): A number of ping
            **kwargs (kwargs): key=param, value=value. This can be used to pass
                extra options to ping

        """

        extra_options = [
            param if value is True else '%s %s' % (param, value)
            for param, value in list(kwargs.items())]

        overall_result = True
        err_output_list = []
        for _ in range(count):
            try:
                output = exe.block_run(
                    'ping -n 3 %s %s' % (' '.join(extra_options), dst_ip))
            except exception.ExeExitcodeException as err:
                err_output_list.append(err.output)
                overall_result = False
            else:
                if 'TTL' not in output:
                    err_output_list.append(output)
                    overall_result = False
                else:
                    time.sleep(1)

        if not overall_result:
            log.error(
                'Ping failed. Error: {}'.format('\n'.join(err_output_list)))
            return False

        return True

    def ping6(self, dst_ip, count=2, **kwargs):
        """Ping over IPv6 to remote host"""
        if '-6' not in kwargs:
            kwargs['-6'] = True

        return self.ping(dst_ip=dst_ip, count=10, **kwargs)

    def add_vlan(self, vlan_id):
        self.reg.set_valid_value('VlanID', vlan_id)

    def remove_vlan(self, vlan_id):
        self.reg.set_valid_value('VlanID', '0')

    @property
    def pcidevice(self):
        """ Return PCI device name"""
        raise NotImplementedError('Not implemented')
