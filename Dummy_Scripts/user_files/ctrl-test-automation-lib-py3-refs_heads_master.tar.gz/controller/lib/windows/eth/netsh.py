"""
:mod:`netsh` -- A wrapper for "netsh"
=====================================

.. module:: controller.lib.windows.eth.netsh
.. moduleauthor:: Eugene Cho <echo@broadcom.com>
CTRL:48082 Deprecated it, use lib/windows/eth/inerface/powershell.py methods
"""


import re
import netaddr

from controller.lib.common.shell import exe
from controller.lib.core import exception


def up(iface):
    """Bring up the interface by enabling

    Args:
        iface (str): Interface name

    """
    exe.block_run(
        'netsh interface set interface name="{iface}" admin=enabled'.format(
            iface=iface))


def down(iface):
    """Bring down the interface by disabling

    Args:
        iface (str): Interface name

    """
    exe.block_run(
        'netsh interface set interface name="{iface}" admin=disabled'.format(
            iface=iface))


def get_ip_addr(iface, ipv6=False):
    """Return a list of IP addresses/netmask

    Args:
        iface (str): Interface name
        ipv6 (bool): Get IPv6 address if True else IPv4

    """

    output = exe.block_run(
        'netsh interface {ip_type} show addresses "{iface}"'.format(
            iface=iface, ip_type='ipv6' if ipv6 else 'ipv4'
        )
    )

    if ipv6:
        ret_list = []
        for ip6_addr in re.findall('Address\s(.*) Parameters', output):
            # Remove zone ID
            ip6_addr = ip6_addr.split('%')[0]

            for route in get_route(iface=iface, ipv6=True):
                if netaddr.IPAddress(ip6_addr) in netaddr.IPNetwork(route):
                    ret_ip_addr = ip6_addr + '/' + route.split('/')[1]
                    if not netaddr.IPNetwork(ret_ip_addr).netmask.is_hostmask():
                        ret_list.append(ret_ip_addr)
        return ret_list

    return [
        '{}/{}'.format(ip_addr, prefix) for ip_addr, prefix
        in re.findall(
            'IP Address:\s+(\d+\.\d+\.\d+.\d+)\r\n\s+Subnet Prefix:'
            '\s+\d+\.\d+\.\d+\.\d+/(\d+)\s\(mask\s\d+\.\d+\.\d+\.\d+', output)
    ]


def set_ip_addr(iface, method='add', ip_addr=None, ipv6=False):
    """Set IP address to the given iface

    Default method is "add"; namely the new IP address will NOT replace the
    exisiting one but being added

    Args:
        iface (str): Interface name
        ip_addr (str): IP address in X.X.X.X/X format which includes subnet
        method (str): [add|del|set|dhcp] as "netsh" command accepts to
            assign a new IP address
        ipv6 (bool): Configure IPv6 address if True else IPv4
    """

    if method == 'dhcp':
        exe.block_run(
            'netsh interface {ip_type} set address "{iface}" dhcp'.format(
                ip_type='ipv6' if ipv6 else 'ipv4', iface=iface
            ))

    elif ip_addr in [None, '0.0.0.0']:
        exe.block_run(
            'netsh interface {ip_type} set address "{iface}"'.format(
                ip_type='ipv6' if ipv6 else 'ipv4', iface=iface
            ))

    exe.block_run(
        'netsh interface {ip_type} set address '
        '"{iface}" static {ip_addr}'.format(
            ip_type='ipv6' if ipv6 else 'ipv4', iface=iface, ip_addr=ip_addr))


def get_route(iface, ipv6=False):
    """Return routing information as dictionary

    Args:
        iface (str): Interface name
        ipv6 (bool): IPv6 if True else IPv4
    """

    output = exe.block_run(
        'netsh interface {ip_type} show route'.format(
            ip_type='ipv6' if ipv6 else 'ipv4'))

    if ipv6:
        return [
            '{}/{}'.format(ip_addr, prefix) for ip_addr, prefix in
            re.findall('([a-f0-9:]+)/(\d+).*%s' % iface, output)
        ]

    return [
        '{}/{}'.format(ip_addr, prefix) for ip_addr, prefix in
        re.findall('(\d+\.\d+\.\d+\.\d+)/(\d+).*%s' % iface, output)
    ]


def get_ip_interface_info(iface, ipv6=False):
    """Return the IPv4/IPv6 interface information by running
    "netsh interface [ipv4|ipv6] show interfaces <iface_name>"

    For now, use the raw data as they are. Will normalize the parameter names
    and values when it's necessary

    Args:
        iface (str): Interface name
        ipv6 (bool): IPv6 if True else IPv4

    """

    output = exe.block_run(
        'netsh interface %s show interfaces "%s"'
        % ('ipv6' if ipv6 else 'ipv4', iface),
        universal_newlines=True
    )
    return {
        key.lower().strip(): value for key, value
        in re.findall('([\w\s]+)\s+:\s(.*)', output)}


def get_interface_info(iface):
    """Return the interface information by running
    "netsh interface show interface <iface_name>"

    Args:
        iface (str): Interface name
    """

    output = exe.block_run(
        'netsh interface show interface "{iface}"'.format(iface=iface))

    regexp = re.compile(
        'Type:\s+(.*)\n\s+Administrative State:\s+(.*)\n\s+'
        'Connect state:\s+(.*)',
        re.IGNORECASE
    )

    if regexp.search(output):
        conn_type, admin_state, conn_state = regexp.search(output).groups()
        return {
            'conn_type': conn_type.strip(),
            'admin_state': admin_state.strip(),
            'conn_state': conn_state.strip(),
        }


def get_mtu(iface):
    """Return the MTU size of the given interface

    Args:
        iface (str): Interface name
    """    
    mtu_size = get_ip_interface_info(iface=iface)['link mtu']
    if re.match('(\d+) bytes', mtu_size):
        return int(re.match('(\d+) bytes', mtu_size).group(1))

    raise exception.IPException('Cannot find MTU information')


def set_mtu(iface, mtu, persistent=False):
    """Set MTU size

    Args:
        iface (str): Interface name
        mtu (int): New MTU size
    """

    exe.block_run(
        'netsh interface ipv4 set subinterface "%s" mtu=%s %s' % (
            iface, mtu, 'store=persisent' if persistent else ''
        ))
