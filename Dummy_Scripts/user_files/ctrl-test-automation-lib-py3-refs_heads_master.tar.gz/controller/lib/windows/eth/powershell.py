"""
:mod:`powershell` -- The test script template
===========================================

.. module:: controller.lib.linux.<DIR>.powershell
.. moduleauthor:: Eugene Cho <echo@broadcom.com>
CTRL:48082 Deprecated it, use lib/windows/eth/inerface/powershell.py methods
"""


from controller.lib.core import exception
from controller.lib.windows.system import powershell as ps


def up(iface):
    return ps.exec_powershell('enable-netadapter', name=iface)


def down(iface):
    return ps.exec_powershell(
        'disable-netadapter', name=iface, confirm=False)

def is_netipinterface(iface):
    try:
        ps.exec_powershell('get-netipinterface', interfacealias=iface)
    except exception.ExeExitcodeException:
        return False
    return True

def get_netadapter(iface):
    """Return netadapter output as an object

    Args:
        iface (str): interface name
    """
    return ps.exec_powershell('get-netadapter', name=iface)[0]


def get_ip_addr(iface, ip_ver=4):
    ip_ver_mapping = {2: 4, 23: 6}
    ret_list = []

    for nic in ps.exec_powershell('get-netipaddress', interfacealias=iface):
        if ip_ver_mapping[nic.AddressFamily] == ip_ver:
            if nic.SuffixOrigin != 4:
                ret_list.append(
                    '%s/%s' % (
                        getattr(nic, 'IPv%sAddress' % ip_ver), nic.PrefixLength)
                )

    return ret_list


def get_dhcp(iface, ip_ver=4):
    """Return the DHCP setting"""
    psobj = ps.exec_powershell(
        'get-netipinterface',
        addressfamily='ipv' + str(ip_ver), interfacealias=iface)[0]

    # JSON returns 0 or 1 whether it's enabled or not
    return True if psobj.Dhcp else False


def set_dhcp(iface, enable, ip_ver=None):
    """Set the DHCP setting of the given interface

    Args:
        enable (bool): Enable DHCP if True else disable
        ip_ver (None, int): choices=[None, 4, 6] If None, do not specify
            addressfamily.
    """
    ps.exec_powershell(
        'set-netipinterface',
        interfacealias=iface,
        addressfamily='ipv' + str(ip_ver) if ip_ver else None,
        dhcp='enabled' if enable else 'disabled',
        policystore='persistentstore'
    )


def set_ip_addr(iface, new_ip_addr, ip_ver=4):
    """Add a new IP address to the interface

    If new_ip_addr is None, do not pass any IP address arguments; namely
    remove all IP addresses.

    Args:
        new_ip_addr (str): New IP address in x.x.x.x/x (IPv4) or ::/x (IPv6)
            format

    """
    if new_ip_addr is None:
        remove_ip_addr(iface, new_ip_addr, ip_ver)
        return
    try:
        ip_addr, prefix = new_ip_addr.split('/')
    except ValueError:
        raise exception.ValueException(
            'Given new IP address %s is missing prefix. Must be x.x.x.x/x or '
            '::/x format' % new_ip_addr)

    # Disable the DHCP first
    set_dhcp(iface, False)

    ps.exec_powershell(
        'new-netipaddress',
        interfacealias=iface, ipaddress=ip_addr,
        prefixlength=prefix, confirm=False,
    )


def remove_ip_addr(iface, ip_addr, ip_ver=4):
    """Remove the given IP address from the interface

    If ip_addr is None, delete all IP address

    Args:
        iface (str): Interface name
        ip_addr (str): IP address needs to be removed

    """
    if ip_addr is None:
        ps.exec_powershell(
            'remove-netipaddress',
            addressfamily='ipv' + str(ip_ver),
            interfacealias=iface,
            confirm=False,
        )
        return

    ip_addr = ip_addr.split('/')[0]

    ps.exec_powershell(
        'remove-netipaddress',
        interfacealias=iface, ipaddress=ip_addr, confirm=False
    )


def get_mac_addr(iface):
    """Return MAC address of the interface

    Args:
        iface(str): Interface name
    """
    return ps.exec_powershell(
        'get-netadapter', name=iface
    )[0].MacAddress.replace('-', ':').lower()


def set_mac_addr(iface, new_mac_addr):
    """Set MAC address of the Interface

    If new_mac_addr is None, restore the original MAC address

    Args:
        iface (str): Interface name
        new_mac_addr (None, str): New MAC address in xx:xx:xx:xx:xx:xx format.
            If None, restore the original MAC address
    """

    if new_mac_addr is None:
        ps.exec_powershell(
            'remove-netadapteradvancedproperty',
            name=iface, registrykeyword='networkaddress')
        return

    ps.exec_powershell(
        'set-netadapter',
        name=iface, macaddress=new_mac_addr, confirm=False)


def get_interrupt(iface):
    """Return the RawValue of the interrupt counter

    Args:
        iface (str): interface name

    Return:
        dict: key=<cpu_num>, value=<raw_interrupt_num>

    """
    if_desc = get_netadapter(iface).ifDesc
    int_info = ps.exec_powershell(
        '(get-counter -counter '
        '\'\Per Processor Network Interface Card Activity(*, %s)'
        '\Interrupts/sec\').CounterSamples' % if_desc, raw_command=True)

    ret_dict = {}
    for cpu_int_info in int_info:
        cpu_num = cpu_int_info.InstanceName.split(',')[0]
        if cpu_num == 'total':
            ret_dict[cpu_num] = int(cpu_int_info.RawValue)
            continue
        ret_dict[int(cpu_num)] = int(cpu_int_info.RawValue)

    return ret_dict


def get_netadapter_advanced_property(iface):
    """Return network adapter advanced properties

    Args:
        iface (str): Interface name
    """
    property_list = ps.exec_powershell(
        'get-netadapteradvancedproperty', name=iface)

    return {prop.RegistryKeyword: prop for prop in property_list}



def set_networkadapter_advanced_property(
        iface, regkey=None, dispname=None, regvalue=None, dispvalue=None):
    """Set network adapter advanced property values

    At least regkey/dispname and regvalue/dispvalue arguments must be combined.
    If both registry and display arguments are defined for the same category,
    registry will be used.

    Args:
        iface (str): Interface name
        regkey (str): registry key
        dispname (str): Display name
        regvalue (str): registry value
        dispvalue (str): Display value

    """

    ps.exec_powershell(
        'set-netadapteradvancedproperty', name=iface,
        registrykeyword=regkey, displayname=dispname,
        registryvalue=regvalue, displayvalue=dispvalue,
    )


def get_statistics(iface):
    return ps.exec_powershell('get-netadapterstatistics', name=iface)[0]


def set_vlan(iface, vlan_id):
    """Set VLAN ID over the given interface

    Args:
        ifaec (str): interface name
        vlan_id (int): VLAN ID
    """
    ps.exec_powershell(
        'set-netadapter', name=iface, vlanid=vlan_id, confirm=False)

def get_computer_info():
    return ps.exec_powershell(
        'get-computerinfo')

def get_adapter_hardware_info(iface=None):
    return ps.exec_powershell(
        'get-netadapterhardwareinfo', name=iface)

def clear_event_logs(logfiles):
    for item in logfiles:
        ps.exec_powershell('Clear-EventLog', logname=item)
    return True

def win_eventlogs(logfiles, entry_type): # logfiles is an array of logfiles like 'system','application'
    logs = {}
    for item in logfiles:
        if 'system' in item:
            try:
                logs[item] = ps.exec_powershell('get-eventlog', logname=item, source='bnxtnd', entrytype=entry_type)
            except Exception as e:
                if 'No matches found' in str(e):
                    logs[item] = None
        else:
            try:
                logs[item] = ps.exec_powershell('get-eventlog', logname=item, entrytype=entry_type)
            except Exception as e:
                if 'No matches found' in str(e):
                    logs[item] = None
    return logs
    
def get_vmnetwork_property(vm_name, vnic):
    return ps.exec_powershell('Get-VMNetworkAdapter', vmname=vm_name, name=vnic)
