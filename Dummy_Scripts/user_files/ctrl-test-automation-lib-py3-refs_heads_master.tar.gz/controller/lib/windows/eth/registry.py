import re
import winreg as winreg

from controller.lib.core import exception
from controller.lib.core import log_handler

# CTRL:48082  Wmic is Deprecated, use lib/windows/eth/inerface/powershell.py methods
from . import wmic


log = log_handler.get_logger(__name__)

REGISTER_PREFIX = (
    'SYSTEM\\CurrentControlSet\\Control\\Class\\'
    '{4D36E972-E325-11CE-BFC1-08002BE10318}')


class BaseType(object):
    def __init__(self, key_path):
        """
        Args
            key_path (str): root of the key where parameters are defined
        """
        self._key_path = key_path
        self.type = None  # Should be overriden
        self._parse()

    @classmethod
    def factory(cls, key_path):
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as param_key:
            for idx in range(0, winreg.QueryInfoKey(param_key)[1]):
                value_name, value_data, value_type = winreg.EnumValue(param_key, idx)
                if value_name == 'type':
                    if value_data == 'enum':
                        return EnumType(key_path)
                    elif value_data == 'dword':
                        return DwordType(key_path)

    def _parse(self):
        raise NotImplementedError

    def validate(self, value):
        raise NotImplementedError

    def get_display_value(self, reg_value):
        raise NotImplementedError

    def get_reg_value(self, display_value):
        raise NotImplementedError


class EnumType(BaseType):
    def __init__(self, key_path):
        """
        Args
            key_path (str): root of the key where paramaeters are defined
        """
        self._enum_list = {}
        super(EnumType, self).__init__(key_path)

    def _parse(self):
        """Parse the enum value"""
        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE, self._key_path) as param_key:
            for idx in range(0, winreg.QueryInfoKey(param_key)[0]):
                if winreg.EnumKey(param_key, idx) == 'enum':
                    self._set_enum_list(self._key_path + '\\enum')
                else:
                    raise exception.ValueException('No "enum" key found')

            for idx in range(0, winreg.QueryInfoKey(param_key)[1]):
                value_name, value_data, value_type = winreg.EnumValue(
                    param_key, idx)
                setattr(self, value_name, value_data)

    def _set_enum_list(self, key_path):
        """Set enum values"""
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as param_key:
            for idx in range(0, winreg.QueryInfoKey(param_key)[1]):
                value_name, value_data, value_type = winreg.EnumValue(
                    param_key, idx)
                self._enum_list[value_name] = value_data

    def validate(self, value):
        """Validate the value against the enum"""
        if value not in self._enum_list:
            raise exception.ValueException(
                'Value %s is invalid. Choices=%s'
                % (value, list(self._enum_list.keys())))
        return True

    def get_display_value(self, reg_value):
        """Return the display value of the given regvalue"""
        return self._enum_list[reg_value]

    def get_reg_value(self, display_value):
        for key, value in list(self._enum_list.items()):
            if value == display_value:
                return key


class DwordType(BaseType):
    def __init__(self, key_path):
        self.min = None
        self.max = None
        self.step = None
        super(DwordType, self).__init__(key_path)

    def _parse(self):
        """Parse the enum value"""
        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE, self._key_path) as param_key:

            for idx in range(0, winreg.QueryInfoKey(param_key)[1]):
                value_name, value_data, value_type = winreg.EnumValue(
                    param_key, idx)
                setattr(self, value_name, value_data)

        if not self.type == 'dword':
            raise exception.ValueException(
                'Type is not dword but %s' % self.type)

    def validate(self, value):
        """Validate the value against the enum"""
        # Check min and max
        if not self.min <= value <= self.max:
            raise exception.ValueException(
                'Value is not within range min %s max %s'
                % (self.min, self.max))

        if value % self.step != 0:
            raise exception.ValueException(
                'Value should be incremented by %s' % self.step)

        if hasattr(self, 'base'):
            if self.base == '10':
                regexp = '[0-9]+'
            elif self.base == '16':
                regexp = '[0-9a-f]+'
            else:
                raise exception.ValueException(
                    'Invalid base value %s' % self.base)
            if not re.match(regexp, value):
                raise exception.ValueException(
                    'Value is invalid. Only accept base %s' % self.base)

        return True

    def get_display_value(self, reg_value):
        return reg_value  # Use the regvalue as it is

    def get_reg_value(self, display_value):
        return display_value


class RegistryHandler(object):
    def __init__(self, iface):
        self._iface = iface
        self._index = wmic.get_index(iface)
        self._param_dict = self._get_params()

    @property
    def iface(self):
        return self._iface

    @property
    def index(self):
        return self._index

    @property
    def key_path(self):
        return REGISTER_PREFIX + '\\' + str(self._index).zfill(4)

    @property
    def param_dict(self):
        return self._param_dict

    def set_value(self, name, data, sub_key=None):
        """Set the value of the key under the NIC registry

        Args:
            name (str): A name of a data to be changed
            data (str): A new data for the value
            sub_key (None, str): An extra path (i.e. ndi\\params) where the
                key is located. If None, access the NIC registry directly
                (i.e. REGISTER_PREFIX + NIC idx)
        """
        key_path = self.key_path if not sub_key \
            else self.key_path + '\\' + sub_key

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_WRITE
        ) as iface_key:
            winreg.SetValueEx(iface_key, name, 0, winreg.REG_SZ, data)

    def get_value(self, name, sub_key=None, ret_type=False):
        """Return the data of the given name under the key

        Args:
            name (str): Name of the value
            sub_key (None, str): sub-key path under the NIC key
            ret_type (bool): If True, return a tuple as winreg.QueryValueEx
                returns. Otherwise return only the value.
        """
        key_path = self.key_path if not sub_key \
            else self.key_path + '\\' + sub_key

        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE, key_path) as iface_key:
            value, key_type = winreg.QueryValueEx(iface_key, name)

        return str(value) if not ret_type else (str(value), key_type)

    def del_value(self, name, sub_key=None):
        """Delete the value

        Args:
            name (str): Name of the value
            sub_key (None, str): sub-key path under the NIC key
        """
        key_path = self.key_path if not sub_key \
            else self.key_path + '\\' + sub_key

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_WRITE
        ) as iface_key:
            winreg.DeleteKey(iface_key, name)

    def _get_params(self):
        """Get NDIS parameter registry values"""
        ndis_params_key = self.key_path + '\\ndi\\params'
        ret_value = {}

        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE, ndis_params_key) as param_key:
            for idx in range(0, winreg.QueryInfoKey(param_key)[0]):
                key = winreg.EnumKey(param_key, idx)
                ret_value[key] = BaseType.factory(ndis_params_key + '\\' + key)

        return ret_value

    def set_valid_value(self, name, data):
        """Set a new data to the given value name"""
        if name not in self.param_dict:
            raise exception.ValueException('Value name %s is not valid' % name)

        if self.param_dict[name].validate(data):
            self.set_value(name, data)

    @property
    def flow_control(self):
        """Return the flow control mode"""
        return self.get_value('*FlowControl')

    @flow_control.setter
    def flow_control(self, new_reg_value):
        """Set a new flow control mode.

        Args:
            new_reg_value (str): A new registry value (not the display value).
                If None, reset the value to the default one.
        """
        self.set_valid_value('*FlowControl', new_reg_value)

    @property
    def jumbo_packet(self):
        return self.get_value('*JumboPacket')

    @jumbo_packet.setter
    def jumbo_packet(self, new_reg_value):
        """Set a new jumbo packet size.

        Args:
            new_value (str): A new reg value. If None,
                reset the value to the default one.
        """
        self.set_valid_value('*JumboPacket', new_reg_value)

    @property
    def speed(self):
        raise NotImplementedError(
            'Not implemented. Call "speed_duplex" instead')

    @speed.setter
    def speed(self, new_speed):
        raise NotImplementedError(
            'Not implemented. Call "speed_duplex" instead')

    @property
    def duplex(self):
        raise NotImplementedError(
            'Not implemented. Call "speed_duplex" instead')

    @duplex.setter
    def duplex(self, new_duplex_mode):
        raise NotImplementedError(
            'Not implemented. Call "speed_duplex" instead')

    @property
    def speed_duplex(self):
        """Return the registry value for speed and duplex"""
        return self.get_value('*SpeedDuplex')

    @speed_duplex.setter
    def speed_duplex(self, new_reg_value):
        """Set a new speed / duplex mode

        Args:
            new_reg_value (str): A new registry value (not the display value).
                If None, reset the value to the default one.
        """
        self.set_valid_value('*SpeedDuplex', new_reg_value)

    @property
    def driver(self):
        return self.get_value(name='service', sub_key='ndi')

    @property
    def features(self):
        """Return all Advanced Properties of the NIC.

        Identical to PowerShell Get-NetAdapterAdvancedProperty, but for
        Windows 2008 R2 compatible, access the registry.

        No normalizing here; and since all features are Windows specific
        (except flow_control, speed, duplex which are defined as separate
        namespaces)

        """
        ret_dict = {}

        for key, value in list(self._param_dict.items()):
            if not key.startswith('*'):
                continue
            ret_dict[key] = value.get_display_value(self.get_value(key))

        return ret_dict

    def set_feature(self, feature, reg_value=None, display_value=None):
        """Set the feature to the given setting.

        Two types of values can be passed

        * reg_value (str): Registry value that will be set as it is
        * display_value (str): A display name which will be converted to the
            reg_value and set to the registry

        If both values are None, it means to reset to the default value
        """
        if feature not in self._param_dict:
            raise exception.ValueException(
                'feature name %s is invalid. choices=%s'
                % (feature, list(self.param_dict.keys())))

        if reg_value is None and display_value is None:  # reset to efault
            self.set_value(
                name=feature, data=self.param_dict[feature].default)

        elif reg_value:
            self.set_valid_value(name=feature, data=reg_value)

        elif display_value:
            self.set_valid_value(
                name=feature,
                data=self.param_dict[feature].get_reg_value(display_value))


class Cumulus(RegistryHandler):
    _flow_control_mapping = {
        '0': 'disabled', '1': 'tx', '2': 'rx', '3': 'rx_tx', '4': 'auto_neg'}
    _speed_mapping = {
        '0': 'auto_neg', '1000': '1000', '10000': '10000', '20000': '20000',
        '25000': '25000', '40000': '40000', '50000': '50000'}

    @property
    def flow_control(self):
        """Return the normalized display name of flow control setting.

        * Auto negotiation = auto_neg
        * rx only = rx
        * tx only = tx
        * rx & tx = rx_tx
        * disabled = disabled

        """
        return self._flow_control_mapping[self.get_value('*FlowControl')]

    @flow_control.setter
    def flow_control(self, new_flow_control):
        """Set the new flow control value using the normalized name

        For normalized values, refer the property flow_control()

        Args:
            new_flow_control (str): choices=[auto_neg|rx|tx|rx_tx|disabled]

        """
        for key, value in self._flow_control_mapping:
            if value == new_flow_control:
                self.set_valid_value('*FlowControl', key)
                return

        raise exception.ValueException(
            'New value %s is not valid' % new_flow_control)

    @property
    def speed(self):
        """Return the speed in Mb/s"""
        return self._speed_mapping[self.speed_duplex]

    @speed.setter
    def speed(self, new_speed):
        # With SFP+. all supported speed only supports Full duplex, but BaseT?
        for key, value in self._speed_mapping:
            if value == new_speed:
                self.set_valid_value('*SpeedDuplex', new_speed)
        raise exception.ValueException(
            'New value %s is not valid' % new_speed)

    @property
    def duplex(self):
        # All SFP and SFP28 Cumulus only support full duplex. Need to consider
        # BaseT models however, and should be updated once it is available
        return 'full'

    @duplex.setter
    def duplex(self, new_duplex_mode):
        if new_duplex_mode == 'full':
            return  # Do nothing.

        raise exception.ConfigException('Only support full duplex mode')


def get_registry_handler(iface):
    na = wmic.system_wmic.network_adapter(NetConnectionID=iface)
    if not na:
        raise exception.ValueException('iface %s does not exist' % iface)

    driver = wmic.system_wmic.pnp_entity(deviceid=na[0].PNPDeviceID)[0].Service

    if driver == 'bnxtnd':
        return Cumulus(iface)
    else:
        return RegistryHandler(iface)
