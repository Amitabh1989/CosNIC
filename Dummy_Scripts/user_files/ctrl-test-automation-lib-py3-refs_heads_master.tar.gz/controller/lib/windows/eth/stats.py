"""
:mod:`stats` -- The test script template
===========================================

.. module:: controller.lib.linux.<DIR>.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import re
import platform

from controller.lib.core import log_handler
from controller.lib.core import exception
from controller.lib.common.eth.stats import BaseNIC, CounterBase
from controller.lib.windows.eth import powershell
from controller.lib.windows.system import wmic


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


log = log_handler.get_logger(__name__)


class BaseWindowsNIC(BaseNIC):
    """A bass class for statistics

    Unlike Linux, Windows maintains the statistics counters, so most NICs will
    use this class

    """
    def __init__(self):
        counter_list = [
            'ucast_packets', 'ucast_bytes',
            'mcast_packets', 'mcast_bytes',
            'bcast_packets', 'bcast_bytes',
        ]
        super().__init__(*counter_list)
        self.tpa = CounterBase(*['packets', 'bytes', 'events', 'aborts'])

    @staticmethod
    def get_stats(iface):
        def _get_normalized_counter_name(xdir, cast_type, cnt_type):
            mapping = {
                'Received': 'rx', 'Sent': 'tx',
                'Broadcast': 'bcast', 'Multicast': 'mcast', 'Unicast': 'ucast',
            }

            return (
                mapping[xdir], mapping[cast_type] + '_' + cnt_type.lower())

        def _set_sum_counter(na_obj, xdir, cnt_type):
            """Update the artificial number of packets and bytes. Add all
            cast types, drops and errors.

            Args:
                na_obj (obj): netadapter object
                xdir (str): rx or tx
                cnt_type (str): bytes or packets
            """

            # netadapter.<xdir>
            na_xdir = getattr(na_obj, xdir)

            # Since Windows does not report statistics per queue, grab the
            # first value (namely the only queue) and get sum of all counter
            # type values
            cnt_value = sum([
                getattr(na_xdir, cast_type + '_' + cnt_type)[0] for
                cast_type in ['bcast', 'mcast', 'ucast']
            ])

            cnt_value += sum(
                getattr(na_xdir, 'drops') + getattr(na_xdir, 'errors'))

            na_obj.set_stats_counter(
                attr=xdir, queue=0, counter_type=cnt_type, value=cnt_value
            )

        regexp = '(Received|Sent)(Broadcast|Multicast|Unicast)(Bytes|Packets)'

        stats = powershell.get_statistics(iface)
        netadapter = BaseWindowsNIC()

        for counter_name, value in list(stats.__dict__.items()):
            if not re.match(regexp, counter_name):
                continue

            attr, counter_type = _get_normalized_counter_name(
                *re.match(regexp, counter_name).groups())

            netadapter.set_stats_counter(
                attr=attr, queue=0, counter_type=counter_type, value=int(value)
            )

        # Handle errors and drops
        netadapter.set_stats_counter(
            attr='rx', queue=0, counter_type='errors',
            value=int(stats.ReceivedPacketErrors))

        netadapter.set_stats_counter(
            attr='rx', queue=0, counter_type='drops',
            value=int(stats.ReceivedDiscardedPackets))

        netadapter.set_stats_counter(
            attr='tx', queue=0, counter_type='errors',
            value=int(stats.OutboundPacketErrors))

        netadapter.set_stats_counter(
            attr='tx', queue=0, counter_type='drops',
            value=int(stats.OutboundDiscardedPackets))

        # Handle the total bytes
        netadapter.set_stats_counter(
            attr='rx', queue=0, counter_type='bytes',
            value=int(stats.ReceivedBytes))

        netadapter.set_stats_counter(
            attr='tx', queue=0, counter_type='bytes',
            value=int(stats.SentBytes))

        # Create the artificial counters
        _set_sum_counter(netadapter, 'rx', 'packets')
        _set_sum_counter(netadapter, 'tx', 'packets')

        # Set RSC counters
        tpa_mapping = {
            'CoalescedBytes': 'bytes',
            'CoalescedPackets': 'packets',
            'CoalescingEvents': 'events',
            'CoalescingExceptions': 'aborts',
        }

        if not stats.RscStatistics:
            # No TPA information is available. Return.
            return netadapter

        for tpa_info in stats.RscStatistics['CimInstanceProperties']:
            if not re.match('(\w+)\s=\s(\d+)', tpa_info):
                log.warning(
                    'Failed to get the statistics info for TPA. Output: %s'
                    % tpa_info
                )
                continue

            counter_name, counter_value = re.match(
                '(\w+)\s=\s(\d+)', tpa_info).groups()
            netadapter.set_stats_counter(
                attr='tpa', queue=0, counter_type=tpa_mapping[counter_name],
                value=int(counter_value)
            )

        return netadapter


class GetCounter(BaseNIC):
    """Get a counter using get-counter powershell command

    This is for supporting Windows 2k8 R2 version
    """

    def __init__(self):
        counter_list = [
            'ucast_packets', 'non_unicast_packets'
        ]
        super().__init__(*counter_list)
        self.tpa = CounterBase(*['packets', 'aborts'])

    @staticmethod
    def _get_normalized_counter_name(counter_name):
        mapping = {
            'BytesReceivedPersec': ('rx', 'bytes'),
            'BytesSentPersec': ('tx', 'bytes'),
            'PacketsOutboundDiscarded': ('tx', 'drops'),
            'PacketsOutboundErrors': ('tx', 'errors'),
            'PacketsReceivedDiscarded': ('rx', 'drops'),
            'PacketsReceivedErrors': ('rx', 'errors'),
            'PacketsReceivedNonUnicastPersec': ('rx', 'non_unicast_packets'),
            'PacketsReceivedPersec': ('rx', 'packets'),
            'PacketsReceivedUnicastPersec': ('rx', 'ucast_packets'),
            'PacketsSentPersec': ('tx', 'packets'),
            'PacketsSentNonUnicastPersec': ('tx', 'non_unicast_packets'),
            'PacketsSentUnicastPersec': ('tx', 'ucast_packets'),
            'TCPRSCCoalescedPacketsPersec': ('tpa', 'packets'),
            'TCPRSCExceptionsPersec': ('tpa', 'aborts'),
        }

        return mapping.get(counter_name, False)

    @staticmethod
    def get_stats(iface):
        try:
            iface = wmic.network_adapter(NetConnectionID=iface)[0]
        except exception.WmicNoInstance:
            log.warning('No such instance available')
            return None

        ifdesc = iface.Name

        if re.match('.*#\d+$', ifdesc):
            ifdesc = re.sub('(.*)(#)(\d+)$', '\\1_\\3', ifdesc.name)

        netadapter = GetCounter()
        net_counter = wmic.perf_raw_network_interface(name=ifdesc)[0]

        for counter in net_counter.__dict__:
            _counter = GetCounter._get_normalized_counter_name(counter)

            if not _counter:
                continue

            attr, counter_type = _counter

            netadapter.set_stats_counter(
                attr=attr, queue=0, counter_type=counter_type,
                value=int(getattr(net_counter, counter))
            )

        return netadapter


def get_stats(iface, method=None):
    """Return a BaseWindowsNIC() object

    Args:
        iface (str): Interface name
        method (None, str): choices=[powershell|wmic|None]
            If None, auto detect the Windows version and
            return proper one (WMIC for 2k8 R2, PowerShell later versions)

    """
    win_ver = platform.win32_ver()[0]
    if (method is None and win_ver == '2012Server') or 'powershell':
        return BaseWindowsNIC.get_stats(iface)
    elif (method is None and win_ver == '2008ServerR2') or 'wmic':
        return GetCounter.get_stats(iface=iface)
    raise ValueError('Unknown method type')
