# -*- coding: utf-8 -*-
"""
:mod:`teaming` -- Windows teaming API
===========================================================

.. module:: controller.lib.windows.eth.teaming
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>



API teaming is used to perform teaming operationsd on NIC adapters.
powershell built-in cmdlets are used to create, remove, add, set nic team.

Note: Teaming in windows is supported from windows 2012 server and above.
      For earlier version of windows, teaming drivers are provided separately.
"""


from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.eth import teaming
from controller.lib.common.shell import exe
from controller.lib.windows.system import powershell as ps
from controller.lib.windows import eth

log = log_handler.get_logger(__name__)

class WinTeam(teaming.BaseTeam):
    """
    NIC Teaming, also known as load balancing and failover (LBFO),
    allows multiple network adapters on a computer to be placed into
    a team for the following purposes:
        1. Bandwidth aggregation
        2. Traffic failover to prevent connectivity loss in the event
           of a network component failure.

    Args:
        team_name (str): Specifies the name of the new NIC team.

    Returns:
        Interface : Interface object that has methods to interact with
                    the MSFT NIC Teaming.
    """

    def __init__(self, team_name):
        super(WinTeam, self).__init__(team_name)

    def create_teaming(self, members, team_mode=None,
                       load_balancing=None):
        """Function Creates a new NIC team.

        Creates a new NIC team that consists of one or more network adapters.
        Teaming network adapters of different speeds is not supported.
        You can create a team with network adapters of different speeds,
        but the network traffic distribution algorithms do not take the speed
        of each network adapter into consideration when distributing traffic.
        When you create a team, you can specify additional properties such as
        TeamingMode and LoadBalancingAlgorithm. You need administrator
        privileges to create teaming on windows.

        Args:
            member_names (str): Specifies the names of the network adapters
                that are members of the new team. Specify multiple network
                adapter names (or wildcard patterns) separated by a comma.

            team_mode (str): Specifies the mode of the NIC teaming.
                You can specify one of the following three teaming modes:

                LACP: Uses the IEEE 802.1ax Link Aggregation Control Protocol
                (LACP) to dynamically identify links that are connected between
                the host and a given switch. (This protocol was formerly known
                as IEEE 802.3ad draft)

                Static: Requires configuration on both the switch and the host
                to identify which links form the team.

                SwitchIndependent: Specifies that a network switch
                configuration is not needed for the NIC team.
                Because the network switch is not configured to know about the
                interface teaming, the team interfaces can be connected to
                different switches.

            load_balancing (str): Specifies the load-balancing algorithm
                the new team uses to distribute network traffic between
                the interfaces.

                Dynamic:  Uses the source and destination TCP ports and
                the IP addresses to create a hash for outbound traffic.
                Moves outbound streams from team member to team member as
                needed to balance team member utilization.  When you specify
                this algorithm with the TeamingMode parameter and the
                SwitchIndependent value, inbound traffic is routed to a
                particular team member.

                TransportPorts: Uses the source and destination TCP ports and
                the IP addresses to create a hash and then assigns the packets
                that have the matching hash value to one of the available
                interfaces. When you specify this algorithm with the
                TeamingMode parameter and the SwitchIndependent value all
                inbound traffic arrives on the primary team member.

                IPAddresses: Uses the source and destination IP addresses
                to create a hash and then assigns the packets that have the
                matching hash value to one of the available interfaces. When
                you specify this algorithm with the TeamingMode parameter and
                the SwitchIndependent value, all inbound traffic arrives on
                the primary team member.

                MacAddresses: Uses the source and destination MAC addresses
                to create a hash and then assigns the packets that have the
                matching hash value to one of the available interfaces. When
                you specify this algorithm with the TeamingMode parameter
                and the SwitchIndependent value, all inbound traffic arrives
                on the primary team member.

                HyperVPort: Distributes network traffic based on the source
                virtual machine Hyper-V switch port identifier. When you
                specify this algorithm with the TeamingMode parameter and
                the SwitchIndependent value, inbound traffic is routed to
                the same team member as the switch port’s outgoing traffic.

        Returns:
            dict: Dictionary of pointers to eth module or an interface to
                    manage the teamed port along with members.

        """            
        if (members and team_mode and load_balancing):
            ps.exec_powershell('New-NetLbfoTeam',
                               name=self.team_name,
                               teammembers=members[0],
                               teamingmode=team_mode,
                               loadbalancingalgorithm=load_balancing,
                               confirm=False)
        elif (members and team_mode):
            ps.exec_powershell('New-NetLbfoTeam',
                               name=self.team_name,
                               teammembers=members[0],
                               teamingmode=team_mode,
                               confirm=False)
        elif (members and load_balancing):
            ps.exec_powershell('New-NetLbfoTeam',
                               name=self.team_name,
                               teammembers=members[0],
                               loadbalancingalgorithm=load_balancing,
                               confirm=False)
        else:
            ps.exec_powershell('New-NetLbfoTeam',
                               name=self.team_name,
                               teammembers=members[0],
                               confirm=False)
        for member in members[1:]:
            ps.exec_powershell('Add-NetLbfoTeamMember',
                               team=self.team_name,
                               name=member,                               
                               confirm=False)
                               
        self.ctrl = {self.team_name: eth.get_interface(self.team_name)}
        for team_member in members:
            team_member = team_member.strip()
            self.ctrl[team_member] = eth.get_interface(team_member)
        return self.ctrl

    def remove_teaming(self):
        """Removes the specified NIC team from the host.

        Args:
            None

        Returns:
            bool: True

        """
        ps.exec_powershell('Remove-NetLbfoTeam' , name=self.team_name, confirm=False)
        return True

    def add_team_members(self, member_names, administrative_mode=None):
        """Adds a new member (network adapter) to a specified NIC team.

        Args:
            member_names (str): Specifies the names of the network adapters
                that are members of the new team. Specify multiple network
                adapter names (or wildcard patterns) separated by a comma.

            administrative_mode (str): Specifies the initial role of
                                       the new member (network adapter).

                You can specify one of the following two status options:

                Active: Allows the team member to participate in the NIC team.
                By default, the initial role of the team member is Active.

                Standby: Places the member in a standby state where it does
                not participate in the team. The team member will be
                automatically moved to Active state if any other member of
                the team fails.

                At most one member in a team can be in Standby mode.

        Returns:
            bool: True
        """
        if administrative_mode:
            ps.exec_powershell('Add-NetLbfoTeamMember',
                               name=member_names,
                               team=self.team_name,
                               administrativemode=administrative_mode,
                               confirm=False)
        else:
            ps.exec_powershell('Add-NetLbfoTeamMember',
                               name=member_names,
                               team=self.team_name,
                               confirm=False)
        return True

    def remove_team_members(self, member_names):
        """Removes one or more network adapters from a specified NIC team.
        You must specify at least one network adapter to remove from the team.

        Args:
            member_names (str): Specifies the names of the network adapters
                that are members of the new team. Specify multiple network
                adapter names (or wildcard patterns) separated by a comma.

        Returns:
            bool: True
        """
        ps.exec_powershell('Remove-NetLbfoTeamMember',
                           name=member_names,
                           team=self.team_name,
                           confirm=False)
        return True

    def create_vlan(self, vlan_id):
        """Create vlan on teamed port.

        Args:
            vlan_id (str): Specifies the VLAN ID of the team interface.
                VlanID values must meet the criteria 0 ≤ VlanID < 4095.
                Specify the value 0 to match frames identified with a
                VLAN ID of 0 or untagged frames.

        Returns:
            interface: Interface for managing the teamed vlan port. 
        """
        ps.exec_powershell('Add-NetLbfoTeamNIC',
                           team=self.team_name,
                           vlanid=vlan_id,
                           confirm=False)

        self.vlan_team_ctrl = eth.get_interface('%s - VLAN %s' %(self.team_name,vlan_id))
        return self.vlan_team_ctrl

    def remove_vlan(self, vlan_id):
        """Removes vlan on Teamed port

        This function does not remove the team interface created when the
        team was created.

        You need administrator privileges to use this function on windows.

        Args:
            vlan_id (str): Specifies the VLAN ID of the team interface to
                           remove.

        Returns:
            bool: True
        """
        ps.exec_powershell('Remove-NetLbfoTeamNIC',
                           team=self.team_name,
                           vlanid=vlan_id,
                           confirm=False)
        return True

    def get_vlan(self):
        """Retrieves Vlan ID of team interface.

        Args:
            None

        Returns:
            int: Vlan id
        """
        team_info = ps.exec_powershell('Get-NetLbfoTeamNic',
                           team=self.team_name)[0]
        return team_info.VlanID
        return res

    def set_team_params(self, team_mode=None, load_balancing=None):
        """Sets parameters on the specified NIC team.

        Function, sets the TeamingMode or LoadBalancingAlgorithm parameters
        on the specified NIC team.

        Args:
            team_mode (str): Specifies the mode of the NIC teaming.

            load_balancing (str): Specifies the load-balancing algorithm
                the new team uses to distribute network traffic between
                the interfaces.

        Returns:
            bool: True if successful else False
        """
        if (team_mode and load_balancing):
            ps.exec_powershell('Set-NetLbfoTeam',
                               name=self.team_name,
                               teamingmode=team_mode,
                               loadbalancingalgorithm=load_balancing,
                               confirm=False)
        elif team_mode:
            ps.exec_powershell('Set-NetLbfoTeam',
                               name=self.team_name,
                               teamingmode=team_mode,
                               confirm=False)
        elif load_balancing:
            ps.exec_powershell('Set-NetLbfoTeam',
                               name=self.team_name,
                               loadbalancingalgorithm=load_balancing,
                               confirm=False)
        else:
            log.info("Please pass atleast one argument: team_mode or loadbalancing_algorithm")
            return False
        return True

    def set_team_member_params(self, member_names, administrative_mode):
        """Function to Set the role of a member network adapter in a NIC team.

        Args:
            member_names (str): Specifies the names of the network adapters
                that are members of the new team. Specify multiple network
                adapter names (or wildcard patterns) separated by a comma.

            administrative_mode (str): Specifies the initial role of
                                       the new member (network adapter).
        Returns:
            bool: True
        """
        ps.exec_powershell('Set-NetLbfoTeamMember',
                           name=member_names,
                           team=self.team_name,
                           administrativemode=administrative_mode,
                           confirm=False)
        return True

    def get_team_info(self):
        """Retrieves a dictionary of properties of NIC teams on the system.

        Args:
            None

        Returns:
            dict : team information.

        Sample output:

            {'state': 'Down',
            'LoadBalancingAlgorithm': 'Dynamic',
            'members': ["CorpNet2", " LocalNet"],
            'mode': 'SwitchIndependent'}
        """
        cmd = "(Get-NetLbfoTeam -Name \"" + self.team_name + "\")."
        res_dict = {}
        prop_dict = {"Status": "state",
                     "LoadBalancingAlgorithm": "LoadBalancingAlgorithm",
                     "Members": "members",
                     "TeamingMode": "mode"}
        for prop in prop_dict:
            cmd1 = ["powershell", cmd + prop]
            res = exe.block_run(cmd1, shell=True)
            if prop == "Members":
                res_dict[prop_dict[prop]] = [_f for _f in res.splitlines() if _f]
            else:
                res_dict[prop_dict[prop]] = res.splitlines()[0]
        return res_dict

    def get_team_member_info(self):
        """Function to Retrieves a dictionary of properties of
        network adapters that are members of a NIC team.

        Args:
            None

        Returns:
            dict : team member information.

        Sample output:

            {'CorpNet2': {'InterfaceDescription': 'Broadcom NetXtreme Gigabit
                                                  Ethernet #2',
                          'AdministrativeMode': 'Active',
                          'ReceiveLinkSpeed': '0',
                          'OperationalStatus': 'Failed',
                          'TransmitLinkSpeed': '0',
                          'FailureReason': 'PhysicalMediaDisconnected'},
             'LocalNet': {'InterfaceDescription': 'Broadcom NetXtreme Gigabit
                                                  Ethernet #2',
                          'AdministrativeMode': 'Active',
                          'ReceiveLinkSpeed': '0',
                          'OperationalStatus': 'Failed',
                          'TransmitLinkSpeed': '0',
                          'FailureReason': 'PhysicalMediaDisconnected'}}
        """
        cmd = ["powershell", "(Get-NetLbfoTeamMember -Team \"" +
               self.team_name + "\").Name"]
        res = exe.block_run(cmd, shell=True)
        res1_dict = {}
        res_dict = {}
        for member in res.splitlines():
            if member:
                cmd = "(Get-NetLbfoTeamMember -Team \"" + \
                       self.team_name + "\" -Name " + member + ")."
                for prop in ["InterfaceDescription",
                             "AdministrativeMode", "ReceiveLinkSpeed",
                             "OperationalStatus", "TransmitLinkSpeed",
                             "FailureReason"]:
                    cmd1 = ["powershell", cmd + prop]
                    res = exe.block_run(cmd1, shell=True)
                    res_dict[prop] = res.splitlines()[0]
                res1_dict[member] = res_dict
        return res1_dict

    def get_teamed_ports(self):
        """Function to get the list of available teamed ports.

        Args:
            None

        Returns:
            list : Name of teamed ports.

        Sample output:

            ["team1", "team2"]
        """
        cmd = ["powershell", "(Get-NetLbfoTeam).Name"]
        res = exe.block_run(cmd, shell=True)
        return [_f for _f in res.splitlines() if _f]
