"""
:mod:`tunnel` -- Windows NVGRE tunnel wrapper
=============================================

.. module:: controller.lib.windows.eth.tunnel
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

import re
import netaddr

from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.eth.tunnel import BaseTunnel
from controller.lib.windows.system import powershell


log = log_handler.get_logger(__name__)


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


class Nvgre(BaseTunnel):
    def __init__(self, iface):
        super(Nvgre, self).__init__(iface=iface)

    @staticmethod
    def _add_lookup_record(
            virtual_subnet_id, pnic_ip_addr, vnic_ip_addr, vnic_mac_addr):
        """Set up the lookup record

        Args:
            virtual_subnet_id (int): virtual subnet ID
            pnic_ip_addr (str): Physical NIC IP address / prefix
            vnic_ip_addr (str): Virtual NIC IP address / prefix
            vnic_mac_addr (str): Virtual NIC MAC address
        """
        if not re.search('\d+\.\d+\.\d+\.\d+/\d+', pnic_ip_addr):
            raise exception.ValueException(
                '"pnic_ip_addr" is not in format x.x.x.x/x')
        if not re.search('\d+\.\d+\.\d+\.\d+/\d+', vnic_ip_addr):
            raise exception.ValueException(
                '"pnic_ip_addr" is not in format x.x.x.x/x')

        _pnic_ip_addr, _pnic_prefix = pnic_ip_addr.split('/')
        _vnic_ip_addr, _vnic_prefix = vnic_ip_addr.split('/')

        log.info('Trying to detect any existing look up record ... ')
        try:
            powershell.exec_powershell(
                'get-netvirtualizationlookuprecord',
                customeraddress=_vnic_ip_addr,
                # provideraddress=_pnic_ip_addr,
                # macaddress=vnic_mac_addr.replace(':', ''),
            )
        except exception.ExeExitcodeException as err:
            if 'ObjectNotFound' not in err.output:
                raise
        else:
            log.warning(
                'The same lookup record already exists. Skip to create')
            return True

        log.info(
            'Creating a new lookup record (virtual subnet ID: %s, '
            'Customer Address: %s, Provider Address: %s) ... '
            % (virtual_subnet_id, _vnic_ip_addr, _pnic_ip_addr)
        )
        powershell.exec_powershell(
            'new-netvirtualizationlookuprecord',
            virtualsubnetid=virtual_subnet_id,
            customeraddress=_vnic_ip_addr,
            provideraddress=_pnic_ip_addr,
            macaddress=vnic_mac_addr.replace(':', ''),
            rule='TranslationMethodEncap',
        )
    def set_virtualization_provider_address(self,vlan_id):
        _iface = powershell.exec_powershell(
            'get-netadapter', name=self.ctrl.iface)[0]

        powershell.exec_powershell(
            'set-netvirtualizationprovideraddress',
            interfaceindex=_iface.InterfaceIndex,
            VlanID=vlan_id
            
        )

    @staticmethod
    def _del_lookup_record(virtual_subnet_id, **kwargs):
        """Delete the lookup record

        Args:
            **kwargs (kwargs): Any key and value that will be passed to
                "remove-netvirtualizationlookuprecord"
        """
        log.info(
            'Deleting the lookup record ... (virutal subnet ID: %s)'
            % virtual_subnet_id
        )
        powershell.exec_powershell(
            'remove-netvirtualizationlookuprecord',
            virtualsubnetid=virtual_subnet_id, **kwargs)

    @staticmethod
    def _add_customer_route(virtual_subnet_id, dest_prefix):
        routing_domain_id = '{00000000-0000-0000-0000-0000' + str(
            virtual_subnet_id).zfill(8) + '}'
        log.info('Created routing domain ID: %s' % routing_domain_id)
        log.info('Trying to detect any existing customer route ... ')
        try:
            powershell.exec_powershell(
                'get-netvirtualizationcustomerroute',
                virtualsubnetid=virtual_subnet_id,
            )
        except exception.ExeExitcodeException as err:
            if 'ObjectNotFound' not in err.output:
                raise
        else:
            log.warning(
                'The same customer route already exists. Skip to create')
            return True

        log.info(
            'Creating a new customer route ... (Routing Domain ID: %s, '
            'Virtual Subnet ID: %s)' % (routing_domain_id, virtual_subnet_id)
        )
        powershell.exec_powershell(
            'new-netvirtualizationcustomerroute',
            routingdomainid=routing_domain_id,
            virtualsubnetid=virtual_subnet_id,
            destinationprefix=dest_prefix,
            nexthop='0.0.0.0',
            metric=255,
        )

    @staticmethod
    def _del_customer_route(virtual_subnet_id):
        log.info(
            'Deleting the customer route ... (Virtual Subnet ID: %s'
            % virtual_subnet_id
        )
        powershell.exec_powershell(
            'remove-netvirtualizationcustomerroute',
            virtualsubnetid=virtual_subnet_id,
        )

    def set_vm_network_adapter(self, vm_name, vnic_mac_addr, virtual_subnet_id):
        log.info('Trying to detect any existing provider address ... ')
        try:
            powershell.exec_powershell(
                'get-netvirtualizationprovideraddress',
                macaddress=self.ctrl.mac_addr.replace(':', ''),
            )
        except exception.ExeExitcodeException as err:
            if 'ObjectNotFound' not in err.output:
                raise
        else:
            log.warning(
                'The same provider address exists. Skip to create')
            return True

        log.info(
            'Creating a new provider address ... (Provider Address: %s)'
            % self.vctrl.ip_addr,  # Get the IP from vEth (not vNIC)
        )

        _iface = powershell.exec_powershell(
            'get-netadapter', name=self.ctrl.iface)[0]

        powershell.exec_powershell(
            'new-netvirtualizationprovideraddress',
            interfaceindex=_iface.InterfaceIndex,
            provideraddress=self.vctrl.ip_addr,
            prefixlength=self.vctrl.prefix,
        )
        log.info(
            'Configuring vNIC %s ... (Virtual Subnet ID: %s)' % (
                vnic_mac_addr, virtual_subnet_id))
        powershell.exec_powershell(
            'set-vmnetworkadapter',
            vmname=vm_name,
            name=vnic_mac_addr,
            virtualsubnetid=virtual_subnet_id,
        )

    def add(self, virtual_subnet_id, vm_addr_dict, **kwargs):
        """Configure NVGRE

        Routing domain ID will be automatically generated as a form
        {00000000-0000-0000-0000-0000<8 digit virtual subnet ID>}

        vm_addr_dict will have following format:

        {
            <vNIC_MAC_ADDR>: {
                'pnic_ip_addr': <physical NIC IP address>/<prefix>,
                'vnic_ip_addr': <virtual NIC IP address>/<prefix>,
            }
        }

        Args:
            virtual_subnet_id (int): Virtual subnet ID
            vm_addr_dict (dict): Refer the description above for its structure
        """

        # No need to run below for Win2k12 R2. I don't have the return value of
        # win32_ver() for Windows 2k12, so comment below out until I have it to
        # check the version of the Windows
        # powershell.exec_powershell(
        #     'enable-netadapterbinding', name=iface, componentid='ms_netwnv')

        _network = None
        dest_prefix = None

        for vnic_mac_addr, ip_addr in list(vm_addr_dict.items()):
            vnic_ip_addr = ip_addr['vnic_ip_addr']
            pnic_ip_addr = ip_addr['pnic_ip_addr']

            self._add_lookup_record(
                virtual_subnet_id, pnic_ip_addr, vnic_ip_addr, vnic_mac_addr)

            _network = _network or netaddr.IPNetwork(vnic_ip_addr)
            dest_prefix = str(_network.network) + '/' + str(_network.prefixlen)
            if netaddr.IPNetwork(vnic_ip_addr) not in _network:
                raise exception.ValueException(
                    'VM IP address %s is not belong to network %s' % (
                        vnic_ip_addr, dest_prefix))

            # If the vnic_mac_addr is locally available, set the adapter
            _vm_nic = [
                vm_nic for vm_nic in powershell.exec_powershell(
                    'get-vmnetworkadapter',
                    all=True, select_clause='MacAddress,VMName'
                ) if vm_nic.MacAddress == vnic_mac_addr.replace(':', '').upper()
            ]

            if len(_vm_nic) == 1:
                self.set_vm_network_adapter(
                    _vm_nic[0].VMName, vnic_mac_addr, virtual_subnet_id)

        if not dest_prefix:
            raise exception.ValueException(
                '"dest_prefix" is "None". Maybe "vm_addr_dict" is empty?'
            )

        self._add_customer_route(virtual_subnet_id, dest_prefix)

    @staticmethod
    def remove(virtual_subnet_id, provider_ip_addr=None):
        """Remove NVGRE which has the given virtual subnet ID"""
        def _skip_at_not_exist(command, **kwargs):
            try:
                powershell.exec_powershell(command, **kwargs)
            except exception.ExeExitcodeException as err:
                if "ObjectNotFound" in err.output:
                    pass
                else:
                    raise

        _skip_at_not_exist(
            'remove-netvirtualizationlookuprecord',
            virtualsubnetid=virtual_subnet_id)
        _skip_at_not_exist(
            'remove-netvirtualizationcustomerroute',
            virtualsubnetid=virtual_subnet_id)
        if provider_ip_addr:
            _skip_at_not_exist(
                'remove-netvirtualizationprovideraddress',
                provideraddress=provider_ip_addr

            )

        for vnic in powershell.exec_powershell(
                'get-vmnetworkadapter',
                all=True, select_clause='VMName,name,virtualsubnetid'
        ):
            if vnic.VMName and vnic.VirtualSubnetId == int(virtual_subnet_id):
                log.info(
                    'Removing %s:%s ... ' % (vnic.VMName, virtual_subnet_id))
                powershell.exec_powershell(
                    'set-vmnetworkadapter',
                    vmname=vnic.VMName,
                    name=vnic.Name,
                    virtualsubnetid=0
                )


def unittest(reset=False):
    if reset:
        powershell.exec_powershell('remove-netvirtualizationlookuprecord')
        powershell.exec_powershell('remove-netvirtualizationcustomerroute')
        powershell.exec_powershell('remove-netvirtualizationprovideraddress')

    blue = {
        'b2:18:c0:a8:04:66': {
            'vnic_ip_addr': '192.168.4.102/24',
            'pnic_ip_addr': '192.168.0.102/24',
        },
        'b2:18:c0:a8:04:68': {
            'vnic_ip_addr': '192.168.4.104/24',
            'pnic_ip_addr': '192.168.0.104/24',
        },
    }

    red = {
        'b2:18:c0:a8:04:67': {
            'vnic_ip_addr': '192.168.4.103/24',
            'pnic_ip_addr': '192.168.0.102/24',
        },
        'b2:18:c0:a8:04:69': {
            'vnic_ip_addr': '192.168.4.105/24',
            'pnic_ip_addr': '192.168.0.104/24',
        }
    }

    blue_nvgre = Nvgre(iface='NIC 1')
    red_nvgre = Nvgre(iface='NIC 1')

    blue_nvgre.add(5001, blue)
    red_nvgre.add(6001, red)
