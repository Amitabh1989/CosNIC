"""
:mod:`wmic` -- WMIC wrapper for NIC
===========================================

.. module:: controller.lib.windows.eth.wmic
.. moduleauthor:: Eugene Cho <echo@broadcom.com>
CTRL:48082 Deprecated it please use/port code to lib/windows/eth/interface/powershell.py

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import netaddr

from controller.lib.core import exception
from controller.lib.common.shell import exe
from controller.lib.windows.system import wmic as system_wmic


def get_index(iface):
    """Return the WMI object of the given interface

    Args:
        iface (str): NetConnectionID

    """

    network_adapter = system_wmic.network_adapter(NetConnectionID=iface)
    if not network_adapter:
        return None

    return network_adapter[0].Index


def get_ip_addr(index, ip_ver=4):
    """Get IP Address from the given interface or index

    Args:
        index (int): Index number
        ip_ver (int): IP version

    """

    ip_addr_list = system_wmic.network_adapter_config(index=index)[0].IPAddress
    netmask_list = system_wmic.network_adapter_config(index=index)[0].IPSubnet

    ret_list = []

    for ip_addr, netmask in zip(ip_addr_list, netmask_list):
        ip_network = netaddr.IPNetwork(ip_addr + '/' + netmask)
        if ip_network.version == ip_ver:
            ret_list.append(str(ip_network))

    return ret_list


def set_ip_addr(index, ip_addr_list):
    """Set the IPv4 address using WMIC

    Set the IP addresses to the given "ip_addr_list". Namely previously
    assigned IP address will be removed.

    Args:
        index (int): index number
        ip_addr_list (list): A list of IP address with prefix
            i.e.) [x.x.x.x/x, x.x.x.x/x]
        ip_ver (int): IP version
    """

    _ip_addr_list = []
    _netmask_list = []

    for ip_addr in ip_addr_list:
        ip_network = netaddr.IPNetwork(ip_addr)
        if len(ip_network) == 1:  # No prefix is given
            raise exception.ValueException(
                'IP address %s is missing prefix or subnet' % ip_addr)

        _ip_addr_list.append(str(ip_network.ip))
        _netmask_list.append(str(ip_network.netmask))

    exe.block_run(
        'wmic path Win32_NetworkAdapterConfiguration where index=%s '
        'call enablestatic (%s),(%s)' % (
            index, ','.join(_ip_addr_list), ','.join(_netmask_list)),
    )


def get_mac_addr(index):
    """Return MAC address of the NIC"""
    return system_wmic.network_adapter(index=index)[0].MACAddress.lower()


def get_enabled(index):
    return True if system_wmic.network_adapter(
        index=index)[0].NetEnabled == 'TRUE' else False


def get_state(index):
    state = system_wmic.network_adapter(index=index)[0].NetConnectionStatus

    if state == '2':
        return 'up'

    return 'down' if state == '0' else 'unknown'


