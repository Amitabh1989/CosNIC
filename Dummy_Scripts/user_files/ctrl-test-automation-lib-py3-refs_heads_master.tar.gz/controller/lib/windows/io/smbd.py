"""
:mod:`smbd` -- SMB Direct Wrapper.
====================================

.. module:: controller.lib.windows.io.smbd
.. moduleauthor:: Venugopala Bhat <vebhat@broadcom.com>

This is a wrapper python module for SMB Direct. Listed below are the functionalities
provided by this module:

1. Setup a Windows node as SMBD server.
2. Setup a Windows node as SMBD client.
3. Test transferring a BIG file using SMBD.
4. Perform IO on an SMBD mount point using MLTT.
5. Optionally verify SMBD statistics after IO.
6. Restore the states of the SMBD server and client nodes.
"""

import time
import re

from controller.lib.common.shell import exe
from controller.lib.core import exception
import controller.lib.common.io.mltt as mltt

class SMBDController(object):
    def __init__(self, mode='server', **kwargs):
        """
        The Constructor.
        
        Args:
            mode   : The mode in which SMBD controller runs.
                   - 'server' to run as SMBD server.
                   - 'client' to run as SMBD client.
            kwargs : A dictionary of additional optional arguments.
                   - 'smb_share_name':'<smb_share_name>'
                     The SMBD share name (Mandatory).

                   - 'smb_share_path'='<smb_share_path>'
                     The path to the SMBD share (Mandatory).

                   - 'server_name'='<server_name>'
                     The name or IP address of the SMBD server node (Mandatory).

                   - 'io_type'='<io_type>'
                     'mltt_io' - Test IO using MLTT.
                     'diskspd_io' - Test IO using DiskSpd.

                   - 'file_size'='<file_size>'
                     The size of the file to use for testing with DiskSpd (default='2G').
                     Valid only if 'io_type' is 'diskspd_io'.

                   - 'io_duration'='<io_duration_in_seconds>'
                     The duration for which to run IO (default='120').
        """
        self._mode = mode
        self._server_name = kwargs.get('server_name', None)

        if self._mode is 'client' and self._server_name is None:
            raise exception.ConfigException('No SMBD server name specified')

        self._smb_share_name = kwargs.get('smb_share_name', 'SMBShare-0')
        self._smb_share_path = kwargs.get('smb_share_path', 'C:\\SMBShare-0')
        self._io_type = kwargs.get('io_type', 'mltt_io')
        self._file_size = kwargs.get('file_size', '2G')
        self._io_duration = kwargs.get('io_duration', '120')
        self._drive_name_letter = kwargs.get('drive_name_letter', 'Z') + ':'
        self._use_ram_disk = kwargs.get('use_ram_disk', 'no')
        self._io_mode = kwargs.get('io_mode', 'asynchronous')
        # The set of information presented as test result.
        self._results = {'THROUGHPUT (MB/s)':'',
                         'IOPS':'',
                         'LATENCY':'',
                         'CPU':'',
                         'ERRORS':''}

    def setup_smbd_server(self):
        """
        """
        if self._mode is not 'server':
            raise exception.ConfigException('Attempt to setup SMBD server on client node')

        command_status = False
        # If asked to setup SMBD share on ram-disk, create the RAM disk.
        if self._use_ram_disk == 'yes':
            command = [ 'powershell', 'imdisk.exe -a -s ' + self._file_size + \
                ' -m ' + self._drive_name_letter + ' -p "/FS:NTFS /C /Y"' ]
            command_output = exe.block_run(command, shell=True)
            # Make sure that the ram-disk is created.
            for each_line in command_output.split('\n'):
                if 'Done' in each_line:
                    command_status = True
                    break
            # If the ram-disk is created, mark it for sharing.
            if command_status is True:
                self._smb_share_path = self._drive_name_letter
        command = [ 'powershell', 'net share ' + self._smb_share_name + '=' + \
            self._smb_share_path + ' "/GRANT:Everyone,FULL"' ]
        command_output = exe.block_run(command, shell=True)

        for each_line in command_output.split('\n'):
            if self._smb_share_name in each_line:
                command_status = True
                break

        if command_status is False:
            raise exception.TestCaseFailure('Failed to create SMBD share')

        return True

    def setup_smbd_client(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to setup SMBD client on server node')

        command_status = False
        command = [ 'powershell', 'net use ' + self._drive_name_letter + ' \\\\' + \
            self._server_name + '\\' + self._smb_share_name ]
        command_output = exe.block_run(command, shell=True)

        for each_line in command_output.split('\n'):
            if 'successfully' in each_line:
                command_status = True
                break

        if command_status is False:
            raise exception.TestCaseFailure('Failed to mount SMBD share')

        return True

    def do_smbd_file_transfer(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to perform file transfer test on server node')

        return True

    def verify_smbd_stats(self, operation='load'):
        """
        """

        return True

    def cleanup_smbd_server(self):
        """
        """
        if self._mode is not 'server':
            raise exception.ConfigException('Attempt to cleanup SMBD server on client node')

        command_status = False
        command = [ 'powershell', 'net share ' + self._smb_share_name + ' /delete /YES' ]
        command_output = exe.block_run(command, shell=True)

        for each_line in command_output.split('\n'):
            if 'successfully' in each_line:
                command_status = True
                break
        # If asked to use ram-disk, delete the RAM disk.
        if self._use_ram_disk == 'yes':
            command = [ 'powershell', 'imdisk.exe -D -m ' + self._drive_name_letter ]
            command_output = exe.block_run(command, shell=True)
            # Make sure that the ram-disk is created.
            for each_line in command_output.split('\n'):
                if 'Done' in each_line:
                    command_status = True
                    break
        # If not, cleanup the data file from the disk.
        else:
            command = [ 'powershell', 'del -force ' + self._smb_share_path + '\\targetfile.dat' ]
            exe.block_run(command)

        if command_status is False:
            raise exception.TestCaseFailure('Failed to delete SMBD share')

        return True

    def cleanup_smbd_client(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to cleanup SMBD client on server node')

        command_status = False
        command = [ 'powershell', 'net use ' + self._drive_name_letter + ' /delete /YES' ]
        command_output = exe.block_run(command, shell=True)

        for each_line in command_output.split('\n'):
            if 'successfully' in each_line:
                command_status = True
                break

        if command_status is False:
            raise exception.TestCaseFailure('Failed to unmount SMBD share')

        return True

    def do_smbd_diskspd_io(self):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to perform IO on server node')

        # Setup the DiskSpd command options.
        diskspd_options = [ '-b512K', '-h', '-L', '-o8', '-t8', '-r', '-w50', \
            '-d' + self._io_duration + ' -c' + self._file_size + ' ' + \
            self._drive_name_letter + '\\targetfile.dat']
        # Perform the IO using DiskSpd.exe.
        command = [ 'powershell', 'DiskSpd.exe ' + ' '.join(diskspd_options) ]
        command_output = exe.block_run(command, shell=True)
        # Compose the results, just in case someone asks for them.
        for each_line in command_output.split('\n'):
            if 'total:' in each_line:
                result = re.search( \
                    '\|[\s]*([0-9]*\.[0-9]*)\s\|[\s]*([0-9]*\.[0-9]*)\s\|[\s]*([0-9]*\.[0-9]*)\s\|', each_line)
                self._results['THROUGHPUT (MB/s)'] = result.group(1)
                self._results['IOPS'] = result.group(2)
                self._results['LATENCY'] = result.group(3)
            elif 'avg.|' in each_line:
                result = re.search( \
                    '\|[\s]*([0-9]*\.[0-9]*)%', each_line)
                self._results['CPU'] = result.group(1)
            # If all the expected results are collected, break out.
            if self._results['IOPS'] != '' and \
                self._results['CPU'] != '':
                break

        return True

    def do_smbd_mltt_io(self, block=True,med_ops=None):
        """
        """
        if self._mode is not 'client':
            raise exception.ConfigException('Attempt to perform IO on server node')

        # Setup the MLTT command options.
        if med_ops == None:
            mltt_options = [ '-b512K', '-t2', '-Q1', '-C1', '-o', '-%f100', '-M30']
        else:
            mltt_options = med_ops
        if self._io_mode == 'synchronous':
            self._io_tool = mltt.Pain()
        else:
            self._io_tool = mltt.Maim()
        # Run the MLTT command on SUT #2.
        self._io_tool.start('\\\.\\' + self._drive_name_letter, self._io_duration, mltt_options)
        if block is True:
            while self._io_tool.poll() is None:
                time.sleep(1)
            # If the command failed, return failure.
            if self._io_tool.poll() != 0:
                raise exception.ExeExitcodeException(command, self._io_tool.poll(), '')
            # Compose the results, just in case someone asks for them.
            result = self._io_tool.get_data()
            temp_string = re.sub('.*\s-\s','', str(result.throughput)).replace('|',';').replace('>','')
            self._results['THROUGHPUT (MB/s)'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.iops)).replace('|',';').replace('>','')
            self._results['IOPS'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.latency)).replace('|',';').replace('>','')
            self._results['LATENCY'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.cpu_util)).replace('|',';').replace('>','')
            self._results['CPU'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.errors)).replace('|',';').replace('>','')
            self._results['ERRORS'] = temp_string
            # Remove the temporary folder created by MLTT.
            command = [ 'powershell', 'del -r -force ' + self._io_tool.temp_dir ]
            exe.block_run(command)

        return True

    def get_smbd_mltt_poll(self):
        """
        """
        if self._io_tool.poll() is None:
            return self._io_tool.poll()
        else:
            return self.poll()

    def poll(self):
        """
        """
        while self._io_tool.poll() is None:
            time.sleep(1)

        if self._io_tool.poll() != 0:
            raise exception.ExeExitcodeException(command, self._io_tool.poll(), '')

        # Compose the results, just in case someone asks for them.
        if self._io_type == 'mltt_io':
            result = self._io_tool.get_data()
            temp_string = re.sub('.*\s-\s','', str(result.throughput)).replace('|',';').replace('>','')
            self._results['THROUGHPUT (MB/s)'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.iops)).replace('|',';').replace('>','')
            self._results['IOPS'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.latency)).replace('|',';').replace('>','')
            self._results['LATENCY'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.cpu_util)).replace('|',';').replace('>','')
            self._results['CPU'] = temp_string
            temp_string = re.sub('.*\s-\s','', str(result.errors)).replace('|',';').replace('>','')
            self._results['ERRORS'] = temp_string
            # Remove the temporary folder created by MLTT.
            command = [ 'powershell', 'del -r -force ' + self._io_tool.temp_dir ]
            exe.block_run(command)
        return self._io_tool.poll()

    @property
    def results(self):
        """
        """
        return self._results

class SMBDServer(SMBDController):
    def __init__(self, **kwargs):
        super(SMBDServer, self).__init__(mode='server', **kwargs)

class SMBDClient(SMBDController):
    def __init__(self, **kwargs):
        super(SMBDClient, self).__init__(mode='client', **kwargs)
