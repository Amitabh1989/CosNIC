"""
:mod:`driver` -- Windows driver install/uninstall API
===========================================================

.. module:: controller.lib.common.windows.system.driver
.. moduleauthor:: Hemanth MB <hemanth@broadcom.com>



API driver is used to perform device driver installation and uninstallation.
PnPutil.exe built-in tool is used to install and delete drivers.
Devcon is microsoft's command line tool for Device management console.
Devcon.exe is used to unload or remove device from the system. 
To get the driver, device info WMI object is used through Powershell shell.

Note: To use pnputil executable, we need to install architecture specific
Python shell (i.e., Cpython)
"""


from controller.lib.core import exception
from controller.lib.core import log_handler
from controller.lib.common.system import driver
from controller.lib.windows.system import powershell
from controller.lib.common.shell import exe

log = log_handler.get_logger(__name__)


class WinDrv(driver.BaseDriver):
    """Driver operations method implementation
    
    This class uses user-space tools to do driver operation on the NIC

    Args:
        None

    Returns:
        Interface: Interface object that has methods to interact with
            the driver operations
    
    """
    def __init__(self):
        super(WinDrv, self).__init__()
    
    def install(self, filename):
        """Function to install driver.
        
        PnPutil.exe is windows built-in tool used to install
        device driver, specifically .inf format files.
        
        Exception will be raised if driver trying to install
        is already installed in the system. Exit code is 259.
        
        Usefull link: 
        https://technet.microsoft.com/en-us/library/ff800798.aspx
        
        Args:
            filename (str): Path of device driver (Absolute path)
        
        Returns:
            res: output of driver installation.
        
        Example: 
            
        C:\\Users\Administrator>pnputil.exe -i -a C:\\Users\Administrator
                                                \Desktop\compo\b57nd60a.inf
        Microsoft PnP Utility
        
        Processing inf :            b57nd60a.inf
        Successfully installed the driver on a device on the system.
        Driver package added successfully.
        Published name :            oem1.inf
        
        Total attempted:              1
        Number successfully imported: 1
            
            
        C:\\Users\Administrator>pnputil.exe -i -a C:\\Users\Administrator
                                                \Desktop\compo\b57nd60a.inf
        Microsoft PnP Utility
        
        Processing inf :            b57nd60a.inf
        Failed to install the driver on any of the devices on the system : 
        No more data is available.
        
        Total attempted:              1
        Number successfully imported: 0
         
        """
        if not filename.endswith("inf"):
            raise exception.ValueException(
                'Cannot recognize the filename. Expect '
                '<driver_name>.inf')
        log.info('Install %s ... ' % filename)
        cmd = "pnputil -i -a \"%s\"" % filename
        res = exe.block_run(cmd, shell=True)
        return res
           
    
    def uninstall(self, driver_name):
        """Function to uninstall the device driver.
        
        To uninstall the device driver we have to remove devices.
        
        To remove devices we have used devcon.exe, an alternative
        tool for Device Manager console. 
        
        NOTE: Please place the relevent devcon.exe in the SUT and 
        add path to environment variables  
        
        To remove driver we have used pnputil.exe
        
        Args:
            driver_name (str): service name of the device driver.
            
            Service name can be found in different ways. Manually,
            open the inf driver file, service name will be mentioned.
            
            For CuW and NX1 Drivers, part of Driver file name forms the
            service name.This is not mandatory, but it depends on developer's
            choice, how to be the driver file name.
            
        Returns:
            bool: True if successful else False
            
        Usefull Links:
            https://msdn.microsoft.com/en-us/library/windows/hardware/
            ff544746(v=vs.85).aspx
            
            https://support.microsoft.com/en-us/kb/311272
            
            https://msdn.microsoft.com/en-us/library/windows/hardware/
            ff544707(v=vs.85).aspx
        """
        log.info('Removing all the hidden devices...')
        exe.block_run('devcleanup.exe *')
        pnp_dev_ids = self.get_pnp_dev_id(driver_name)
        if pnp_dev_ids:
            inf_names = []
            for pnp_dev_id in pnp_dev_ids:
                inf_names.append(self.get_inf_name(pnp_dev_id))
                self.remove_device(pnp_dev_id)
            inf_names = set(inf_names)
            for inf_name in inf_names:
                self.remove_driver(inf_name)
            self.rescan_hardware()
            return True
        else:
            log.info("Driver uninstallation skipped......")
            pass

    def cleanup_devices(self, driver_name, device_mac):
        device_mac_list = device_mac if isinstance(device_mac, list) else [device_mac]
        net_devices = powershell.exec_powershell('get-wmiobject Win32_NetworkAdapter')
        for device_mac in device_mac_list:
            for device in net_devices:
                if device.ServiceName == driver_name and (str(device.MACAddress).lower() == device_mac or
                                                        str(device.MACAddress).lower() == device_mac.replace("-", ":")):
                    self.remove_device(device.PNPDeviceID)
                    break
        self.rescan_hardware()

    def dev_health_check(self, driver_name, device_mac):
        net_devices = powershell.exec_powershell('get-wmiobject Win32_NetworkAdapter')
        for device in net_devices:
            if device.ServiceName == driver_name and (device.MACAddress == device_mac or device.MACAddress == device_mac.replace("-", ":")):
                return self.get_health_state(device.PNPDeviceID)


    def get_health_state(self, pnp_dev_id):
        cmd = r'devcon status @%s' % pnp_dev_id
        try:
            res = exe.block_run(cmd)
        except WindowsError as e:
            if 'system cannot find the file specified' in str(e):
                raise Exception("System cannot find DEVCON. Copy DEVCON and DEVCLEANUP into C:\Windows")
        log.info('Response is %s' % res)
        if "Driver is running" in res:
            return True
        else:
            log.warning("Device is not in running state")
            return False
    
    def is_installed(self, driver_name):
        """Function to verify device is installed or not?
        
        Args:
            driver_name (str): service name of the device driver.
            
        Returns:
            bool: True if successful else False
        """
        if self.get_pnp_dev_id(driver_name):
            return True
        return False
    
    def get_version(self, pnp_dev_id):
        """Function to get the driver version installed on the device.
        
        Args:
            pnp_dev_id (str): Plug and Play device ID of the device trying
                                to get the driver version.
            
        PnPDeviceID can be fetched through function get_pnp_dev_id(macaddress)
        pass the macaddress as an argument
        
        example for PnPDeviceID:
        PCI\VEN_14E4&DEV_1678&SUBSYS_167814E4&REV_A2\5&249BBF88&0&210020
        
        Returns:
            driver_version (str): Driver version
        
        Usefull link: 
        https://msdn.microsoft.com/en-us/library/windows/hardware/
        ff541224(v=vs.85).aspx
        
        https://msdn.microsoft.com/en-us/library/ms913235(v=winembedded.5).aspx       
        """
        signed_drvs = powershell.exec_powershell('Get-WmiObject Win32_PnPSignedDriver')
        for drv in signed_drvs:
            if drv.DeviceID == pnp_dev_id:
                return drv.DriverVersion
        return None
            
    def get_inf_name(self, pnp_dev_id):
        """Function to get published driver package name
        
        Args:
            pnp_dev_id (str): Plug and Play device ID of the device trying
                                to get the driver name.
        
        Returns:
            inf_name (str): inf file name installed in driver store or None
        
        Usefull Link:
        https://msdn.microsoft.com/en-us/library/aa394354(v=vs.85).aspx
        
        Examples of inf name in the driver store:
        
        oem1.inf, oem2.info etc....
        
        Name of the .inf file that installed the device. Example: "machine.inf"
        """
        signed_drvs = powershell.exec_powershell('Get-WmiObject Win32_PnPSignedDriver')
        for drv in signed_drvs:
            if drv.DeviceID == pnp_dev_id:
                return drv.InfName
        return None
        
    def remove_device(self, pnp_dev_id):
        """Function to remove device from the system.
        
        This function is similar to device unload.
        
        Args:
            pnp_dev_id (str): Plug and Play device ID of the device trying
                                to device from the system.
                            we can also pass the hardware id in place of 
                            device id. this will remove whole adapter 
                            from the system.
                            
        Returns:
            bool: True if successful else False
        
        NOTE: Please place the relevant devcon.exe in the SUT and 
        add path to environment variables
        
        Usefull Links:
        https://msdn.microsoft.com/en-us/library/windows/hardware/
        ff544746(v=vs.85).aspx
        
        """
        cmd = r'devcon remove @%s' % pnp_dev_id
        try:
            res = exe.block_run(cmd)
        except WindowsError as e:
            if 'system cannot find the file specified' in str(e):
                raise Exception("System cannot find DEVCON. Copy DEVCON and DEVCLEANUP into C:\Windows")
        if "1 device(s) removed." in res: 
            return True
        else:
            log.info("Failed to remove device")
            return False
        
    def get_pnp_dev_id(self, driver_name):
        """Function to get the pnp device ids.
        
        Args:
            driver_name (str): service name of the device driver.
            
        Returns:
            list: pnp device ids A.K.A instance ids A.K.A Device Ids or None
        """
        pnp_dev_ids = []
        net_devices = powershell.exec_powershell('get-wmiobject Win32_NetworkAdapter')
        for device in net_devices:
            if device.ServiceName == driver_name:
                pnp_dev_ids.append(device.PNPDeviceID)
        return pnp_dev_ids
    
    def remove_driver(self, inf_name):
        """Function to remove or delete device driver from driver store.
        
        Args:
            inf_name (str): Published driver package name.
            
        Returns:
            bool: True if successful else False
        """
        cmd = 'pnputil.exe -f -d %s' % inf_name
        try:
            exe.block_run(cmd)
        except Exception as e:
            if str(e).find('The specified file is not an installed OEM INF') != -1:
                pass
        return True
    
    def rescan_hardware(self):
        """Function to rescan hardware.
        
        Args:
            None
            
        Returns:
            bool: True if successful else False
        """
        cmd = 'devcon.exe rescan'
        try:
            exe.block_run(cmd)
        except WindowsError as e:
            if 'system cannot find the file specified' in str(e):
                raise Exception("System cannot find DEVCON. Copy DEVCON and DEVCLEANUP into C:\Windows")
        return True
    
    def get_driver_name(self, macaddress):
        """Function to get service name of the driver installed.
        
        Args:
            macaddress (str): Macaddress of the network port.
            
            Note: parse macaddress with ":" as separator or delimiter.
            
        Returns:
            driver_name (str): service name of the driver.
        """
        net_devices = powershell.exec_powershell('get-wmiobject Win32_NetworkAdapter')
        for device in net_devices:
            if device.MacAddress == macaddress:
                return device.ServiceName
        return None
    
    def get_package_info(self, pkg_name):
        pass
    
    def rollback(self, driver_name):
        pass
    
    def upgrade(self, filename, force=False):
        pass


def install(filename):
    windows_driver = WinDrv()
    windows_driver.install(filename)
