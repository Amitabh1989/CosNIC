"""
:mod:`ipmi` -- IPMI controller
===========================================

.. module:: controller.lib.windows.system.ipmi
.. moduleauthor:: Hemanth MB <hemanth.mb@broadcom.com>

"""
__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2022 Broadcom Inc"

import re

from distutils.spawn import find_executable
from controller.lib.core import exception
from controller.lib.common.shell import exe

class Ipmi(object):
    """
    IPMI controller

    Args:
        ip_adrr (str): IP address to BMC

    """
    def __init__(self, ip_addr, username='root', password='br0adc0m$'):
        self._ip_addr = ip_addr
        self._prg_path = find_executable('ipmitool')
        self._username = username
        self._password = password

        if not self._prg_path: # No ipmitool installed
            raise exception.ConfigException('No ipmitool found')

    @property
    def ip_addr(self):
        return self._ip_addr

    def on(self, username=None, password=None):
        self.exec_command('on', username or self._username, password or self._password)

    def off(self, username=None, password=None):
        self.exec_command('off', username or self._username, password or self._password)

    def cycle(self, username=None, password=None):
        self.exec_command('cycle', username or self._username, password or self._password)

    def soft(self, username=None, password=None):
        self.exec_command('soft', username or self._username, password or self._password)

    def status(self, username=None, password=None):
        output = self.exec_command('status', username or self._username, \
            password or self._password)
        return re.search('Chassis Power is (.*)', output).group(1)

    def exec_command(self, command, username=None, password=None):
        return exe.block_run('ipmitool -I lanplus -H %s -U %s -P %s power %s' % \
            (self.ip_addr, username or self._username, password or self._password, command))

    # device=none,pxe,disk,safe,diag,cdrom,bios
    def bootdev(self, device, bootmode=None, username=None, password=None):
        return exe.block_run('ipmitool -I lanplus -H %s -U %s -P %s chassis bootdev %s %s' % \
            (self.ip_addr, username or self._username, password or self._password, device, \
            'options=efiboot' if bootmode == 'uefi' else ""))

def on(ip_addr, username, password):
    return cmd('on', ip_addr, username, password)

def off(ip_addr, username, password):
    return cmd('off', ip_addr, username, password)

def cycle(ip_addr, username, password):
    return cmd('cycle', ip_addr, username, password)

def soft(ip_addr, username, password):
    return cmd('soft', ip_addr, username, password)

def status(ip_addr, username, password):
    return cmd('status', ip_addr, username, password)

def cmd(cmd, ip_addr, username, password):
    ipmi = Ipmi(ip_addr=ip_addr, username=username, password=password)
    return getattr(ipmi, cmd)()
