"""
:mod:`qos` -- QOS library
=========================================

.. module:: controller.lib.windows.system.qos
.. moduleauthor:: Hemanth MB <hemanth.mb@broadcom.com>

"""


import logging
from controller.lib.common.system.qos import BaseQos
from controller.lib.windows.system import powershell as ps
from controller.lib.windows.eth import powershell
from controller.lib.core import exception
from controller.lib.common.shell import exe


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = logging.getLogger(__name__)


class WindowsQos(BaseQos):
    def __init__(self, iface):
        super(WindowsQos, self).__init__(iface=iface)
        self._if_desc = powershell.get_netadapter(self.iface).ifDesc
        

    @property
    def if_desc(self):
        return self._if_desc.replace('/', '-')

    def enable(self, bnxtnvm_file_path):
        """
        dcbx_mode = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=155:0#1'
            % (bnxtnvm_file_path, self.if_desc))
        if "option-155 (dcbx_mode):successfully set" in dcbx_mode:
            log.info(dcbx_mode)
        else:
            log.info(dcbx_mode)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % dcbx_mode)
        mgmt_fw = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=255#1'
            % (bnxtnvm_file_path, self.if_desc))
        if "(mgmt_fw_select_type):successfully set" in mgmt_fw:
            log.info(mgmt_fw)
        else:
            log.info(dcbx_mode)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % mgmt_fw)
        lldp = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=269#1'
            % (bnxtnvm_file_path, self.if_desc))
        if "(lldp_nearest_bridge):successfully set" in lldp:
            log.info(lldp)
        else:
            log.info(lldp)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % lldp)
        lldp_tpmr = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=270#1'
            % (bnxtnvm_file_path, self.if_desc))
        if "(lldp_nearest_non_tpmr_bridge):" \
           "successfully set" in lldp_tpmr:
            log.info(lldp_tpmr)
        else:
            log.info(lldp_tpmr)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % lldp_tpmr)
        """
        raise NotImplemented

    def disable(self, bnxtnvm_file_path):
        """
        dcbx_mode = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=155:0#0'
            % (bnxtnvm_file_path, self.if_desc))
        if "option-155 (dcbx_mode):successfully set" in dcbx_mode:
            log.info(dcbx_mode)
        else:
            log.info(dcbx_mode)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % dcbx_mode)
        mgmt_fw = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=255#0'
            % (bnxtnvm_file_path, self.if_desc))
        if "(mgmt_fw_select_type):successfully set" in mgmt_fw:
            log.info(mgmt_fw)
        else:
            log.info(dcbx_mode)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % mgmt_fw)
        lldp = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=269#0'
            % (bnxtnvm_file_path, self.if_desc))
        if "(lldp_nearest_bridge):successfully set" in lldp:
            log.info(lldp)
        else:
            log.info(lldp)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % lldp)
        lldp_tpmr = ps.exec_powershell(
            '& %s -dev=\"%s\" setoption=270#0'
            % (bnxtnvm_file_path, self.if_desc))
        if "(lldp_nearest_non_tpmr_bridge):" \
           "successfully set" in lldp_tpmr:
            log.info(lldp_tpmr)
        else:
            log.info(lldp_tpmr)
            raise exception.NvmConfigException(
                'Bnxtnvm.exe returned error: %s' % lldp_tpmr)
        """
        raise NotImplemented

    def set_ets_bandwidth(self, **kwargs):
        """Set QOS ets bandwidth"""
        raise NotImplemented

    def set_qos_policy(self, **kwargs):
        """Set QOS ets policy"""
        raise NotImplemented

    def remove_ets_policy(self, pname=None):
        """Set QOS ets policy"""
        try:
            if pname is not None:
                remove_policy = ps.exec_powershell('remove-netqospolicy',
                                                   name=pname,
                                                   confirm=False)
                log.info("Policy removed successfully")
            else:
                get_policy = ps.exec_powershell('get-netqospolicy')
                if get_policy is not None:
                    for policy in get_policy:
                        if "default" not in str(policy.Name).lower():
                            remove_policy = ps.exec_powershell('remove-netqospolicy',
                                                               name=policy.Name,
                                                               confirm=False)
                            log.info("Policy removed successfully")
        except AttributeError:
            log.info("remove_ets_policy: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: remove_ets_policy: " + str(e))
            raise Exception("Error")

    def verify_op_tc(self, tc, bw, pt):
        """verify qos operational settings"""
        try:
            qos = False

            operational_tc = ps.exec_powershell('get-netadapterqos',
                                                name=self.iface)
            op_tc = operational_tc[0].OperationalTrafficClasses.split("\n")
            for op in [op_tc[2], op_tc[3]]:
                if tc[0] in op and bw[0] in op and pt[0] in op:
                    qos = True
                elif tc[1] in op and bw[1] in op and pt[0] in op:
                    qos = True
                else:
                    qos = False
            return qos
        except AttributeError:
            log.info("verify_op_tc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: verify_op_tc: " + str(e))
            raise Exception("Error")

    def verify_remote_tc(self, tc, bw, pt):
        """verify qos operational settings"""
        try:
            qos = False

            remote_tc = ps.exec_powershell('get-netadapterqos',
                                           name=self.iface)
            op_tc = remote_tc[0].RemoteTrafficClasses.split("\n")
            for op in [op_tc[2], op_tc[3]]:
                if tc[0] in op and bw[0] in op and pt[0] in op:
                    qos = True
                elif tc[1] in op and bw[1] in op and pt[0] in op:
                    qos = True
                else:
                    qos = False
            return qos
        except AttributeError:
            log.info("verify_remote_tc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: verify_remote_tc: " + str(e))
            raise Exception("Error")

    def verify_remote_fc(self, pfc):
        """verify qos operational settings"""
        try:
            remote_fc = ps.exec_powershell('get-netadapterqos',
                                           name=self.iface)
            if pfc in remote_fc[0].RemoteFlowControl:
                return True
            else:
                return False
        except AttributeError:
            log.info("verify_remote_fc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: verify_remote_fc: " + str(e))
            raise Exception("Error")

    def verify_op_fc(self, pfc):
        """verify qos operational settings"""
        try:
            op_fc = ps.exec_powershell('get-netadapterqos',
                                       name=self.iface)
            if pfc in op_fc[0].OperationalFlowControl:
                return True
            else:
                return False
        except AttributeError:
            log.info("verify_op_fc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: verify_op_fc: " + str(e))
            raise Exception("Error")

    def get_ets_bandwidth(self, **kwargs):
        """Get ETS bandwidth"""
        raise NotImplemented

    def is_ets_policy(self, pname):
        """Get ETS settings"""
        try:
            get_policy = ps.exec_powershell('get-netqospolicy')
            if get_policy is not None:
                for key in range(len(get_policy) - 1):
                    if pname in get_policy[key].Name:
                        return True
            return False
        except AttributeError:
            log.info("is_ets_policy: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: is_ets_policy: " + str(e))
            raise Exception("Error")

    def is_ets_tc(self, tc_name):
        """Get ETS settings"""
        try:
            get_tc = ps.exec_powershell('get-netqostrafficclass')
            if get_tc is not None:
                for key in range(len(get_tc) - 1):
                    if tc_name in get_tc[key].Name:
                        return True
            return False
        except AttributeError:
            log.info("is_ets_tc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: is_ets_tc: " + str(e))
            raise Exception("Error")

    def set_ets_policy(self, pname, priority, port=2001, smb=False):
        """Set ETS polienablesettings"""
        try:
            if smb:
                if self.is_ets_policy(pname):
                    set_policy = ps.exec_powershell('set-netqospolicy',
                                                    name=pname,
                                                    smb=smb,
                                                    priorityvalue=priority)
                    log.info(set_policy[0])
                else:
                    set_policy = ps.exec_powershell('new-netqospolicy',
                                                    name=pname,
                                                    smb=smb,
                                                    priorityvalue=priority)
                    log.info(set_policy[0])
            else:
                if self.is_ets_policy(pname):
                    set_policy = ps.exec_powershell('set-netqospolicy',
                                                    name=pname,
                                                    port=port,
                                                    priorityvalue=priority)
                    log.info(set_policy[0])
                else:
                    set_policy = ps.exec_powershell('new-netqospolicy',
                                                    name=pname,
                                                    port=port,
                                                    priorityvalue=priority)
                    log.info(set_policy[0])
            return set_policy[0]
        except AttributeError:
            log.info("set_ets_policy: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: set_ets_policy: " + str(e))
            raise Exception("Error")

    def set_ets_tc(self, tc_name, algo, priority, bw):
        """Set ETS settings"""
        try:
            if self.is_ets_tc(tc_name):
                set_tc = ps.exec_powershell('set-netqostrafficclass',
                                            name=tc_name,
                                            priority=priority,
                                            algorithm=algo,
                                            bandwidthpercentage=bw)
                log.info(set_tc[0])
            else:
                set_tc = ps.exec_powershell('new-netqostrafficclass',
                                            name=tc_name,
                                            priority=priority,
                                            algorithm=algo,
                                            bandwidthpercentage=bw)
                log.info(set_tc[0])
            return set_tc[0]
        except AttributeError:
            log.info("set_ets_tc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: set_ets_tc: " + str(e))
            raise Exception("Error")

    def remove_ets_tc(self, tc_name=None):
        try:
            if tc_name is not None:
                remove_tc = ps.exec_powershell('remove-netqostrafficclass',
                                               name=tc_name,
                                               confirm=False)
                log.info("Traffic class : " + remove_tc[0])
                return remove_tc[0]
            else:
                get_tc = ps.exec_powershell('get-netqostrafficclass')
                if get_tc is not None:
                    for tc in get_tc:
                        if "default" not in str(tc.Name):
                            try:
                                remove_tc = ps.exec_powershell(
                                    'remove-netqostrafficclass',
                                    name=tc.Name,
                                    confirm=False)
                                log.info("Policy removed successfully: "
                                         "%s" % str(remove_tc[0]))
                            except Exception as e:
                                pass
        except AttributeError:
            log.info("remove_ets_tc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: remove_ets_tc: " + str(e))
            raise Exception("Error")

    def enable_ets_pfc(self, priority):
        """Enable ETS PFC settings"""
        try:
            enable_pfc = ps.exec_powershell(
                'enable-netqosflowcontrol',
                priority=priority)
        except AttributeError:
            log.info("enable_ets_pfc: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info(
                "Exeception: enable_ets_pfc: " + str(e))
            raise Exception

    def is_ets_pfc(self, priority):
        get_pfc = ps.exec_powershell(
            'get-netqosflowcontrol',
            priority=priority)
        return bool(get_pfc[0].Enabled)

    def disable_ets_pfc(self, priority):
        """Disable ETS PFc settings"""
        try:
            if self.is_ets_pfc(priority):
                disable_pfc = ps.exec_powershell(
                    'disable-netqosflowcontrol',
                    priority=priority)
                log.info("PFC disabled")
            else:
                log.info("PFC not enabled on this "
                         "priority: %s" % str(priority))
        except AttributeError as ae:
            log.info("disable_ets_pfc: Attribute error: " + str(ae))
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: disable_ets_pfc: " + str(e))
            raise Exception("Error")

    def get_qos_policy(self, **kwargs):
        """Get QOS policy"""
        raise NotImplemented

    def verify_dcbx(self):
        """TO verify Whether DCBX feature installed or not"""
        try:
            dcbx = ps.exec_powershell(
                'get-windowsfeature',
                name='data-center-bridging')
            return dcbx[0].Installed
        except AttributeError:
            log.info("verify_dcbx: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: verify_dcbx: " + str(e))
            raise Exception("Error")

    def install_dcbx(self):
        """To install DCBX windows feature"""
        try:
            if not self.verify_dcbx():
                log.info(
                    "Installing Data-center-bridging feature...")
                dcbx = ps.exec_powershell('add-windowsfeature',
                                          name='data-center-bridging',
                                          includeallsubfeature=True)
            log.info("Data-center-bridging feature installed.")
            log.info(dcbx[0])
        except AttributeError:
            log.info("install_dcbx: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: install_dcbx: " + str(e))
            raise Exception("Error")

    def verify_packet_tags(self, **kwargs):
        """To capture packets and verify the COS tags"""
        raise NotImplemented

    def verify_traffic(self, dst_ip, mltt_client):
        pass

    def get_traffic_class(self):
        """Gets Ets traffic class"""
        raise NotImplemented

    def set_willing(self, will):
        """Sets Willing bit"""
        try:
            ps.exec_powershell('set-netqosdcbxsetting',
                               willing=will,
                               confirm=True)
            log.info("Willing bit set to " + will)
        except AttributeError:
            log.info("set_willing: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: set_willing: " + str(e))
            raise Exception("Error")

    def is_rdma_enabled(self, iface_name):
        try:
            rdma = ps.exec_powershell('get-smbclientnetworkinterface')
            for rd in rdma:
                if rd.FriendlyName == iface_name:
                    return bool(rd.RdmaCapable)
            return False
        except AttributeError:
            log.info("is_rdma_enabled: Attribute error")
            raise AttributeError("Error")
        except Exception as e:
            log.info("Exeception: is_rdma_enabled: " + str(e))
            raise Exception("Error")

    def get_counter_pfc(self):
        cmd1 = ps.exec_powershell('get-ciminstance',
                                 namespace=r"root\wmi",
                                 classname="BRCM_ExtendedStats")
        query = r'select * from ' \
                r'BRCM_ExtendedStats ' \
                r'where instancename like \"%s\"' % cmd1[0].InstanceName
        cmd = ps.exec_powershell('invoke-cimmethod',
                                 namespace=r"root\wmi",
                                 query=query,
                                 methodname="queryportstats")
        return cmd[0].rx_pfc_frames

    def create_smb_share(self, ram_disk_path, name="smb1"):
        if not self.is_smb_share(name):
            share = ps.exec_powershell('New-SmbShare',
                                       path=ram_disk_path,
                                       name=name)
            grant_share =  ps.exec_powershell('Grant-SmbShareAccess',
                                              accountname="everyone",
                                              name=name,
                                              accessright="Full",
                                              confirm=False)
        else:
            log.info("Share already created in this name")
            return None
        return [share[0], grant_share[0]]

    def is_smb_share(self, name):
        get_share = ps.exec_powershell('Get-SmbShare')
        for share in get_share:
            if share.Name == name:
                return True
        return False

    def delete_smb_share(self, name="smb1"):
        if self.is_smb_share(name):
            share = ps.exec_powershell('Remove-SmbShare',
                                       name=name,
                                       confirm=False)
        else:
            log.info("Share doesn\'t exists in this name")

