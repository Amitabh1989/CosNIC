"""
:mod:`stats` -- System statistics library
=========================================

.. module:: controller.lib.windows.system.stats
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""


import re
import logging
from controller.lib.common.system.stats import BaseStats
from controller.lib.windows.eth import powershell


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"

log = logging.getLogger(__name__)

class WindowsStats(BaseStats):
    def __init__(self, iface):
        super(WindowsStats, self).__init__(iface=iface)
        self._if_desc = powershell.get_netadapter(self.iface).ifDesc

    @property
    def if_desc(self):
        return self._if_desc.replace('/','-')

    def get_per_proc_nic_activity_counter(self, instance):
        """Return the raw counter of the "Per Processor Network Interface Card
        Activity".

        """
        int_info = powershell.ps.exec_powershell(
            '(get-counter -counter '
            '\'\Per Processor Network Interface Card Activity(*, %s)'
            '\%s\').CounterSamples' % (self.if_desc, instance))
        log.info('Came till here')
        ret_dict = {}
        for cpu_int_info in int_info:
            cpu_num = cpu_int_info.InstanceName.split(',')[0]
            if cpu_num == 'total':
                ret_dict[cpu_num] = int(cpu_int_info.RawValue)
                continue
            ret_dict[int(cpu_num)] = int(cpu_int_info.RawValue)

        return [ret_dict[idx] for idx in range(len(ret_dict)-1)]

    def get_network_interface_counter(self, instance):
        # Convert # to _, as get-counter network interface does.
        if_desc = re.sub(
            '#(\d+)$', '_\\1', self.if_desc) if re.match(
            '.*(#\d+)$', self.if_desc
        ) else self.if_desc

        return powershell.ps.exec_powershell(
            '(get-counter -counter '
            '\'Network Interface(%s)\%s\').CounterSamples'
            % (if_desc, instance)
        )[0].RawValue

    def get_nic_interrupt(self):
        return self.get_per_proc_nic_activity_counter('Interrupts/sec')

    def get_rx_offload_counter(self):
        """Return a raw counter of RSC"""
        return [
            self.get_network_interface_counter('tcp rsc coalesced packets/sec')]

    def get_tx_offload_counter(self, **kwargs):
        raise NotImplementedError

    def get_tcp_retransmitted(self, ip_ver=4):
        return powershell.ps.exec_powershell(
            '(get-counter -counter '
            '\'\TCPv%s\Segments retransmitted/sec\').CounterSamples' % ip_ver
        )[0].RawValue
