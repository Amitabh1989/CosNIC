"""
:mod:`sysinfo` -- The test script template
===========================================

.. module:: controller.lib.linux.<DIR>.sysinfo
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


import re

from controller.lib.common.shell import exe
from controller.lib.core import exception
from controller.lib.common.system import sysinfo
# CTRL-48082: Wmic deprecated, use lib/linux/eth/interface/powershell.py methods
from . import wmic

class SysInfo(sysinfo.BaseSysInfo):
    @classmethod
    def get_memory(cls):
        return exe.block_run(
            'wmic OS get TotalVisibleMemorySize /value').split('=')[1].strip()

    @classmethod
    def get_driver_info(cls, driver_list):
        ret_dict = {}

        if isinstance(driver_list, str):
            driver_list = [driver_list]

        for driver in driver_list:
            if re.match('.*\.sys$', driver):
                driver = re.match('(.*)\.sys$', driver).group(1)

            entity_list = wmic.pnp_entity(service=driver)

            if not entity_list:
                raise exception.ValueException(
                    'driver %s is not found' % driver)

            entity = entity_list[0]

            drv_version = wmic.pnp_signed_driver(deviceid=entity.DeviceID)[0]
            ret_dict[driver] = drv_version.DriverVersion

        return ret_dict





