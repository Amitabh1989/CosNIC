"""
:mod:`wmic` -- WMIC wrapper
===========================

.. module:: controller.lib.windows.system.wmic
.. moduleauthor:: Eugene Cho <echo@broadcom.com>
CTRL-48082: Wmic depracated, port code to use lib/windows/eth/interface/powershell.py
"""

import re

from xml.etree import ElementTree

from controller.lib.core import exception
from controller.lib.common.shell import exe


__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2015 Broadcom Corporation"


# Create some well used functions
def get_wmic(path, fields=None, **kwargs):
    """Execute WMIC with the given path and keyword arguments

    Keyword arguments are for "SELECT" and "WHERE". key=select, where=value.
    For example, if you use::

        exec_wmic('Win32_NetworkAdapter', ['Name'], DeviceID=16)

    It will be translated into::

        SELECT Name FROM Win32_NetworkAdapter WHERE DeviceID=16

    Args:
        fields (list): A list of fields
        **kwargs (dict): key=parameter, value=value to filter out the results

    """

    fields = fields or []

    where_clause_list = []

    for name, value in list(kwargs.items()):
        if re.match('(.*)__like', name):  # like operation
            name = re.match('(.*)__like', name).group(1)
            oper = ' like '
        else:
            oper = '='
        value = str(value).replace('\\', '\\\\')

        where_clause_list.append(name + oper + '\'' + value + '\'')
    where_clause = ' and '.join(where_clause_list)

    command = ['wmic', 'path', path]

    if kwargs:
        command += ['where', where_clause]

    command += [
        'get', ','.join(fields) if fields else '*', '/format:rawxml']

    output = exe.block_run(
        command, universal_newlines=True, stderr=None).strip()

    root = ElementTree.fromstring(output)
    if root.find('RESULTS/ERROR'):
        error_output = root.find('RESULTS/ERROR/DESCRIPTION').text.strip()
        if 'no instance(s) available' in error_output.lower():
            raise exception.WmicNoInstance(
                'No such instance exists. Output: %s' % error_output)
        raise exception.WmicException('wmic returned error: %s' % error_output)

    instance_list = []

    for instance in root.findall('RESULTS/CIM/INSTANCE'):
        instance_dict = {}
        for prop in instance.findall('PROPERTY'):
            value = prop.find('VALUE')
            instance_dict[
                prop.get('NAME')] = None if value is None else value.text
        for prop in instance.findall('PROPERTY.ARRAY'):
            instance_dict[prop.get('NAME')] = [
                value.text for value in prop.findall('VALUE.ARRAY/VALUE')]

        instance_list.append(type('wmic', (object,), instance_dict))

    return instance_list


def network_adapter(**kwargs):
    """Win32_NetworkAdapter proxy"""
    return get_wmic(path='Win32_NetworkAdapter', **kwargs)


def network_adapter_config(**kwargs):
    """Win32_NetworkAdapterConfiguration proxy"""
    return get_wmic(path='Win32_NetworkAdapterConfiguration', **kwargs)


def pnp_entity(**kwargs):
    return get_wmic(path='Win32_PnPEntity', **kwargs)


def pnp_signed_driver(**kwargs):
    return get_wmic(path='Win32_PnPSignedDriver', **kwargs)


def perf_raw_network_interface(**kwargs):
    return get_wmic(
        path='Win32_PerfRawData_Tcpip_NetworkInterface',
        **kwargs
    )


def perf_raw_per_processor_network_interface_activity(**kwargs):
    return get_wmic(
        path='Win32_PerfRawData_Counters_'
             'PerProcessorNetworkInterfaceCardActivity',
        **kwargs
    )
