import atexit
import distutils.spawn
import os
import platform
import sys
import time
from subprocess import PIPE, call

import controller
from setuptools import setup, find_packages
from setuptools.command.install import install


# from distutils.command.clean import clean


def _post_install_linux():
    if platform.system() == 'Linux':
        import psutil
        import serviceinstaller
        serviceinstaller.install_service(
            {'Service': {'ExecStart': f'{sys.executable} {distutils.spawn.find_executable("stat_server.py")}',
                         'TimeoutSec': 10, 'LimitNOFILE': 150000},
             'Unit': {'Description': 'STAT Server', 'After': 'syslog.target network.target'}},
            'stat-server.service')

        for pid in set(psutil.pids()):
            try:
                proc = psutil.Process(pid)
                if any('stat_server.py' in token for token in proc.cmdline()):
                    proc.kill()
                    time.sleep(2)
                    if pid in psutil.pids():
                        raise Exception(f'Failed to kill stat_server process')
            except:
                pass

        os.system('systemctl restart stat-server.service')


def _post_install_windows():
    if platform.system() == 'Windows':
        import psutil
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        DETACHED_PROCESS = 0x00000008
        user_profile = os.environ["USERPROFILE"]
        stat_server_path = f"{user_profile}\Start Menu\Programs\Startup\statserver.bat"

        command = f'START /B {sys.executable} {os.path.dirname(sys.executable)}\Scripts\stat_server.py'
        os.system(f'echo {command} > "{stat_server_path}"')
        for pid in set(psutil.pids()):
            try:
                proc = psutil.Process(pid)
                if any('stat_server.py' in token for token in proc.cmdline()):
                    proc.kill()
                    # os.system(f'taskkill /pid {pid} /f')
                    time.sleep(2)
                    if pid in psutil.pids():
                        raise Exception(f'Failed to kill stat_server process')
            except:
                pass

        call([stat_server_path], stdin=PIPE, stdout=PIPE, stderr=PIPE,
             creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP, close_fds=True)


class cntl_install(install):
    user_options = install.user_options + \
                   [('no-virt', None, 'Ignore the absense of libvirt.')]

    def __init__(self, *args, **kwargs):
        super(cntl_install, self).__init__(*args, **kwargs)
        atexit.register(_post_install_linux)
        #atexit.register(_post_install_windows)

    def initialize_options(self):
        install.initialize_options(self)
        self.no_virt = None

    def finalize_options(self):
        install.finalize_options(self)

    def run(self):
        if platform.system() == 'Linux' and self.no_virt is None:
            try:
                import libvirt
            except ImportError:
                print(
                    'No libvirt-python found! Aborting. Install libvirt-python and retry.')
                print(
                    'Alternatively, use --install-option="--no-virt" to skip this check.')
                sys.exit(1)
            try:
                from pathlib import Path
                ctrl_config_file = '/etc/controller_pkg/ctrl_config.yml'
                ctrl_config = {}
                import yaml
                ctrl_config['ctrl_ver_in_vm_template'] = "Unknown"
                config_path = Path(ctrl_config_file)
                config_path.parent.mkdir(exist_ok=True, parents=True)
                with open(ctrl_config_file, 'w') as fd:
                    yaml.dump(ctrl_config, fd, default_flow_style=False)
            except ImportError:
                print('Failed to import yaml, yaml installation failed. check and resolve yaml dependency')
                sys.exit(1)
        else:
            print('--no-virt flag specified; skipping libvirt check.')

        install.run(self)


# CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
# Install suitable packages based on the Python version we are dealing with.
PYTHON_VERSION = sys.version.split('.')[:3]
PYTHON_3_X = int(PYTHON_VERSION[0]) == 3

# CTRL-47625: Linux Automation DPDK : After updating the b23 controller DPDK Gre test suite aborts
# with "pyshark error".
# Use the right version of pyshark based on Python version in use.
my_pyshark = 'pyshark>=0.3.8'

# Use typing.Literal on python < 3.8 for any/all OSes
# (cap each install at typing_extensions versions where support for obsolete python versions was removed)
if sys.version_info < (3, 6):
    typing_extensions_ver = 'typing_extensions>=3.7.2, <4.0'  # 4.0 removes python 3.5 support
elif sys.version_info < (3, 7):
    typing_extensions_ver = 'typing_extensions<4.2'  # 4.2 removes python 3.6 support
elif sys.version_info < (3, 8):
    typing_extensions_ver = 'typing_extensions<4.8'  # 4.8 removes python 3.7 support
else:
    typing_extensions_ver = ''  # module not needed

install_requires = [
    'rpyc>=5.0.1,<6.0.0',
    'netaddr>=0.7.5',
    'regex>=2.4',
    'wget>=2.2',
    'distro',
    'psutil',
    'requests',
    'py-cpuinfo',  # require to collect CPU info (equivalent for lscpu command)
    'netmiko==4.0.0',
    'redfish>=3.2.2',
] if '.NET' not in platform.python_compiler() else []

if platform.system() == 'Windows':
    install_requires.append('scapy==2.4.3')
    install_requires.append('wexpect')
else:
    install_requires.append('paramiko>=2.4.2')
    install_requires.append('pyserial>=3.4')
    install_requires.append('scapy>=2.4.5')
    install_requires.append(my_pyshark)
    install_requires.append('pexpect')
    install_requires.append('docker')
    install_requires.append('pyyaml')
    install_requires.append('serviceinstaller')

if typing_extensions_ver:
    install_requires.append(typing_extensions_ver)

scripts = ['controller/bin/stat_server.py', 'controller/bin/maxq_tool']
scripts += ['virt/bin/virt-cli.py', 'virt/bin/virt-switch.py', 'virt/bin/virt-ifcfg.py']
scripts += ['controller/bin/ibdev2netdev']
scripts += ['controller/bin/config_acs.sh']

setup(
    name='controller-lib',
    version=controller.get_version(),
    packages=find_packages(),
    scripts=scripts,
    install_requires=install_requires,
    cmdclass={'install': cntl_install}
)
