__version__ = '0.3.9b25'
__min_compatible_version__ = '0.3.9b25'
__max_compatible_version__ = __version__


def get_version(*args, **kwargs):
    # Create a funciton to return a translated version number as PEP 386
    # For now, return the current version
    return __version__
