import libvirt
import logging
import os
from xml.etree import ElementTree
from virt.lib.linux.core.libvirt_ei import LibvirtOpen
from virt.lib.linux.core.libvirt_ei import LibBase
from virt.lib.core import exception

log = logging.getLogger(__name__)


class Domain(LibBase):
    """Wrapper around the libvirt domain object

    Args:
        name (str): Name of the domain
        memory (int): Memory size in MB. Default=512
        vcpus (int): A number of virtual CPUs. Default=1


    """
    def __init__(self, name, disk_file, memory=512, vcpus=1, domain_type='kvm', **kwargs):
        super(Domain, self).__init__(name)
        self._disk_file = disk_file
        self.memory = memory
        self.vcpus = vcpus
        self.device_list = []
        self._domain_type = domain_type
        self.aarch = kwargs.get('platform_arch', 'x86_64')
        self.cpu_model = kwargs.get('cpu_model', 'host-model')
        self.uefi_support = kwargs.get('uefi_support', False)
        self.secure_boot = kwargs.get('secure_boot', False)

    @property
    def name(self):
        return self._name

    @property
    def disk_file(self):
        if self._disk_file:
            return self._disk_file

        with LibvirtOpen(self._conn, self._uri) as conn:
            _domain = conn.lookupByName(self.name)
            domain_root = ElementTree.fromstring(_domain.XMLDesc())
            return domain_root.find('./devices/disk/source').get('file')

    @name.setter
    def name(self, new_name):
        self._name = new_name

    def _get_object(self):
        with LibvirtOpen(self._conn, self._uri) as conn:
            return conn.lookupByName(self.name)

    @property
    def domain_type(self):
        return self._domain_type

    def add_device(self, device_root):
        """Add a device to domain "devices"

        The device_root must have the root which is named as "device_root" and
        its text should have the name of the subelement tag.

        Args:
            device_root (ElementTree): root object of ElementTree

        """
        self.device_list.append(device_root.find(device_root.text))

    def _get_root(self):
        root = ElementTree.Element('domain', type='kvm')
        ElementTree.SubElement(root, 'name').text = self.name
        ElementTree.SubElement(root, 'memory', unit='MiB').text = str(self.memory)
        ElementTree.SubElement(root, 'currentMemory', unit='MiB').text = str(self.memory)
        ElementTree.SubElement(root, 'vcpu', placement='static').text = str(self.vcpus)
        if self.aarch == 'aarch64':
            self.uefi_support = True  # UEFI boot is compulsory on AARCH64 platforms
            os_element = ElementTree.SubElement(root, 'os', firmware='efi')
        else:
            os_element = ElementTree.SubElement(root, 'os')

        if self.aarch != 'aarch64' and self.uefi_support:
            ElementTree.SubElement(os_element, 'type', arch=self.aarch, machine='q35').text = 'hvm'
            ovmf_path = self.get_ovmf_path(secure_boot=self.secure_boot)
            ElementTree.SubElement(os_element, 'loader', secure='yes', type='pflash').text = ovmf_path
        else:
            ElementTree.SubElement(os_element, 'type', arch=self.aarch).text = 'hvm'

        if self.uefi_support:
            ElementTree.SubElement(os_element, 'type', machine='virt')
        ElementTree.SubElement(os_element, 'boot', dev='hd')
        feature_element = ElementTree.SubElement(root, 'features')
        ElementTree.SubElement(feature_element, 'acpi')
        ElementTree.SubElement(feature_element, 'apic')
        if self.aarch != 'aarch64' and self.uefi_support:
            ElementTree.SubElement(feature_element, 'smm')

        if self.cpu_model == 'host-model' or self.cpu_model == 'host-passthrough':
            cpu_element = ElementTree.SubElement(root, 'cpu', mode=self.cpu_model)
            ElementTree.SubElement(cpu_element, 'model', fallback='allow')
        else:
            cpu_element = ElementTree.SubElement(root, 'cpu', mode='custom')
            ElementTree.SubElement(cpu_element, 'model', fallback='allow').text = self.cpu_model
        devices = ElementTree.SubElement(root, 'devices')
        disk = ElementTree.SubElement(devices, 'disk', type='file', device='disk')
        ElementTree.SubElement(disk, 'driver', name='qemu', type='qcow2')
        ElementTree.SubElement(disk, 'source', file=self.disk_file)
        ElementTree.SubElement(disk, 'target', dev='vda', bus='virtio')
        # Some basic serial console devices
        serial_element = ElementTree.SubElement(devices, 'serial')
        ElementTree.SubElement(serial_element, 'target', port='0')
        console_element = ElementTree.SubElement(devices, 'console')
        ElementTree.SubElement(console_element, 'target', type='serial', port='0')
        if self.aarch != 'aarch64':
            graphics_element = ElementTree.SubElement(devices, 'graphics', type='vnc', port='-1',
                                                      autoport='yes', listen='0.0.0.0')
            ElementTree.SubElement(graphics_element, 'listen', type='address', address='0.0.0.0')
            video_element = ElementTree.SubElement(root, 'video')
            ElementTree.SubElement(video_element, 'model', type='vga')
        # Add the qemu guest agent, only if the libvirt version is higher than
        # 1.0.6 which does not require source path
        channel = ElementTree.SubElement(devices, 'channel', type='unix')

        if libvirt.getVersion() < 1000006:
            ElementTree.SubElement(channel, 'source', mode='bind',
                                   path='/var/lib/libvirt/qemu/%s.agent' % self.name)
        else:
            ElementTree.SubElement(channel, 'source', mode='bind')

        ElementTree.SubElement(channel, 'target', type='virtio', name='org.qemu.guest_agent.0')

        for device_element in self.device_list:
            devices.append(device_element)

        return root

    def create(self, conn=None, uri=None):
        with LibvirtOpen(conn=conn, uri=uri) as conn:
            # CTRL-45362: Automation: Fix the syntax errors identified during Py2.7 to Py3.X
            # porting.
            # If the xml is a byte stream (as in case of Python 3.X), convert it to str.
            domain_xml = self.get_xml()

            if isinstance(domain_xml, bytes):
                domain_xml = domain_xml.decode('utf-8')

            domain = conn.defineXML(domain_xml)
            domain.create()

        log.info('Domain "%s" is successfully created' % self.name)

    def destroy(self):
        if os.access(self.disk_file, 0):
            log.info('Deleting the disk file %s.' % self.disk_file)
            os.remove(self.disk_file)

        super(Domain, self).remove()

    @staticmethod
    def get_ovmf_path(secure_boot=False):
        file_name = 'OVMF_CODE.secboot.fd' if secure_boot else 'OVMF_CODE.fd'
        folder_location = '/usr/share/OVMF'
        file_path = f'{folder_location}/{file_name}'
        if os.path.exists(file_path):
            return file_path
        else:
            raise exception.ConfigException(f"Could not find {file_name} in {folder_location}")
