import os
import sys
import libvirt
import traceback
from virt.lib.core import exception
from virt.lib.core import log_handler
from virt.lib.common.virtual_machine.template import BaseTemplate, BasePool
from virt.lib.linux import storage
from virt.lib.linux.core.libvirt_ei import LibvirtOpen


log = log_handler.get_logger(__name__)


class Pool(BasePool):
    def __init__(self, path):
        super(Pool, self).__init__(path)

    def create(self):
        template = storage.Pool(
            name='template', path=os.path.join(self.path, 'template'))
        vm = storage.Pool(
            name='vm', path=os.path.join(self.path, 'vm'))

        if not template.object:
            template.create()

        elif template.object.isActive() == 0:
            template.object.setAutostart(1)
            template.object.create()

        if not vm.object:
            vm.create()
        elif vm.object.isActive() == 0:
            vm.object.setAutostart(1)
            vm.object.create()

        return True

    def remove(self):
        template = storage.Pool(name='template')
        vm = storage.Pool(name='vm')

        template.remove()
        vm.remove()


class KVMTemplate(BaseTemplate):
    def __init__(self):
        super(KVMTemplate, self).__init__(file_ext='qcow2')

    def validate(self, vswitch_list=None):
        vswitch_list = vswitch_list or []
        with LibvirtOpen() as conn:
            try:
                conn.storagePoolLookupByName('template')
                conn.storagePoolLookupByName('vm')
            except libvirt.libvirtError:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                if 'Storage pool not found' in str(ex_value):
                    raise exception.ConfigException(
                        f'"template" and/or "vm" storage pools do not exist. \n '
                        f'Traceback Info: {str(traceback.format_exc())}')
                else:
                    raise

            for vswitch in vswitch_list:
                try:
                    conn.networkLookupByName(vswitch)
                except libvirt.libvirtError:
                    ex_type, ex_value, ex_traceback = sys.exc_info()
                    if 'Network not found' in str(ex_value):
                        raise exception.ConfigException('"%s" does not exist. \n '
                                                        'Traceback Info : %s'
                                                        % (vswitch, str(traceback.format_exc())))
                    else:
                        raise


class BASETEMP(KVMTemplate):
    name = None  # to be filled by user
    url = 'http://http-server.dhcp.broadcom.net/vm/linux'
    os_type = 'linux'


def get_template(name, *args, **kwargs):
    for subclass in KVMTemplate._get_all_subclasses(KVMTemplate):
        subclass.name = name
        return subclass(*args, **kwargs)


def get_template_list():
    return [
        template.name for template in
        KVMTemplate._get_all_subclasses(KVMTemplate)
    ]
