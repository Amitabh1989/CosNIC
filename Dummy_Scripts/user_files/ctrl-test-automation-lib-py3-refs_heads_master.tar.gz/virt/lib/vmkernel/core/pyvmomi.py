import re
from . import exe
from pyVmomi import vim, vmodl
from pyVim import connect
from virt.lib.core import log_handler
from virt.lib.common.system.sysinfo import get_sysinfo



log = log_handler.get_logger(__name__)


def WaitForTasks(tasks):
    si = connect.Connect('localhost', 443)
    # si = connect.Connect('10.130.217.66', 443, 'administrator@vsphere.local', 'Br0adc0m$')
    pc = si.content.propertyCollector
    tasklist = [str(task) for task in tasks]
    # Create filter
    objspecs = [vmodl.query.PropertyCollector.ObjectSpec(obj=task) for task in tasks]
    propspec = vmodl.query.PropertyCollector.PropertySpec(type=vim.Task, pathSet=[], all=True)
    filterspec = vmodl.query.PropertyCollector.FilterSpec()
    filterspec.objectSet = objspecs
    filterspec.propSet = [propspec]
    filter = pc.CreateFilter(filterspec, True)

    try:
        version, state = None, None
        # Loop looking for updates till the state moves to a completed state.
        while len(tasklist):
            update = pc.WaitForUpdates(version)
            for filterSet in update.filterSet:
                for objSet in filterSet.objectSet:
                    task = objSet.obj
                    for change in objSet.changeSet:
                        if change.name == 'info':
                            state = change.val.state
                        elif change.name == 'info.state':
                            state = change.val
                        else:
                            continue

                        if not str(task) in tasklist:
                            continue

                        if state == vim.TaskInfo.State.success:
                            # Remove task from taskList
                            tasklist.remove(str(task))
                        elif state == vim.TaskInfo.State.error:
                            raise task.info.error
            # Move to next version
            version = update.version
    finally:
        if filter:
            filter.Destroy()


def get_content():
    """
    Get the vsphere object associated with a given text name
    """
    si = connect.Connect('localhost', 443)
    # si = connect.Connect('10.130.217.66', 443, 'administrator@vsphere.local', 'Br0adc0m$')
    return si.RetrieveContent()


def get_obj(vimtype, name=None):
    """
    Get the vsphere object associated with a given text name
    """
    si = None
    obj = None
    while True:
        if si is None:
            si = connect.Connect()
        try:
            content = si.RetrieveContent()
            container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
            break
        except vim.fault.NotAuthenticated:
            si = None
    if vimtype == [vim.HostSystem]:
        return container.view[0]

    if name and name == 'GetAll':
        return [obj for obj in container.view]
    for c in container.view:
        if name:
            if c.name == name:
                obj = c
                break
        else:
            obj = c
            break

    return obj


def get_properties(viewtype, props, spectype):
    """
    Obtains a list of specific properties for a
     particular Managed Object Reference data object.

    :param viewtype: Type of Managed Object
    Reference that should populate the View
    :param props: A list of properties
    that should be retrieved for the entity
    :param spectype: Type of Managed Object Reference
    that should be used for the Property Specification
    :return:
    """
    # Get the View based on the viewtype

    si = None
    while True:
        if si is None:
            si = connect.Connect()

        try:
            content = si.RetrieveContent()
            objview = content.viewManager.CreateContainerView(
                content.rootFolder, viewtype, True)
            print('Connected to pyvmomi host.')
            break
        except vim.fault.NotAuthenticated:
            si = None
    # Build the Filter Specification
    tspec = vim.PropertyCollector.TraversalSpec(
        name='tSpecName', path='view', skip=False, type=vim.view.ContainerView)
    pspec = vim.PropertyCollector.PropertySpec(all=False,
                                               pathSet=props, type=spectype)
    ospec = vim.PropertyCollector.ObjectSpec(obj=objview,
                                             selectSet=[tspec], skip=False)
    pfspec = \
        vim.PropertyCollector.FilterSpec(
            objectSet=[ospec], propSet=[pspec],
            reportMissingObjectsInResults=False)
    retoptions = vim.PropertyCollector.RetrieveOptions()
    # Retrieve the properties and look for a token coming back
    # with each RetrievePropertiesEx call
    # If the token is present it indicates there
    # are more items to be returned.
    totalprops = []
    retprops = content.propertyCollector.RetrievePropertiesEx(
        specSet=[pfspec], options=retoptions)
    totalprops += retprops.objects

    while retprops.token:
        retprops = content.propertyCollector.ContinueRetrievePropertiesEx(
            token=retprops.token)
        totalprops += retprops.objects

    objview.Destroy()
    # Turn the output in totalProps into a usable dictionary of values
    gpoutput = []

    for eachprop in totalprops:
        propdic = {}

        for prop in eachprop.propSet:
            propdic[prop.name] = prop.val
            propdic['moref'] = eachprop.obj

        gpoutput.append(propdic)

    return gpoutput


def attach_virtual_adapter(network, mac_addr, ens=False, ens_port=None):
    nic = vim.vm.device.VirtualDeviceSpec()
    nic.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
    # nic.device = vim.vm.device.VirtualE1000()
    nic.device = vim.vm.device.VirtualVmxnet3()
    nic.device.deviceInfo = vim.Description()
    if mac_addr:
        nic.device.deviceInfo.label = mac_addr
        nic.device.macAddress = mac_addr
        nic.device.addressType = 'Manual'
    if not ens:
        nic.device.deviceInfo.summary = network
        nic.device.backing = vim.vm.device.VirtualEthernetCard.NetworkBackingInfo()
        nic.device.backing.network = get_obj([vim.Network], network)
        nic.device.backing.deviceName = network
    else:
        nic.device.backing = vim.vm.device.VirtualEthernetCard.DistributedVirtualPortBackingInfo()
        nic.device.backing.port = vim.dvs.PortConnection()
        nic.device.backing.port.switchUuid = network.dvsUuid
        nic.device.backing.port.portKey = ens_port
        nic.device.backing.port.connectionCookie = 1
    return nic


def attach_virtual_function(vf_data):
    nic = vim.vm.device.VirtualDeviceSpec()
    nic.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
    nic.device = vim.vm.device.VirtualPCIPassthrough()
    nic.device.deviceInfo = vim.Description()
    nic.device.backing = vim.vm.device.VirtualPCIPassthrough.DeviceBackingInfo()
    nic.device.backing.id = vf_data['id']
    nic.device.backing.deviceId = vf_data['deviceId']
    nic.device.backing.systemId = vf_data['systemId']
    nic.device.backing.vendorId = vf_data['vendorId']
    nic.device.backing.deviceName = vf_data['deviceName']
    return nic


def attach_vf(network, vf_data):
    # print("*********************")
    # print(vf_data)
    # print("*********************")

    hostobj = get_obj([vim.HostSystem], None)
    nic_name = get_physical_nic_by_network(network)
    pf_pci_id = get_physical_nic(nic_name).pci
    devices = hostobj.hardware.pciDevice
    pf_data = None
    for dev in devices:
        if dev.id == pf_pci_id:
            pf_data = dev

    # print(pf_data)
    nic = vim.vm.device.VirtualDeviceSpec()
    # nic.fileOperation = 'create'
    nic.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
    nic.device = vim.vm.device.VirtualSriovEthernetCard()
    # nic.device.macAddress = mac_addr
    # nic.device.addressType = 'assigned'
    nic.device.addressType = 'Generated'
    nic.device.key = 13016
    nic.device.deviceInfo = vim.Description()
    nic.device.deviceInfo.label = "swe sriov test"
    nic.device.deviceInfo.summary = network

    # nic.device.slotInfo = vim.vm.device.VirtualDevice.BusSlotInfo()
    # # nic.device.controllerKey = 230
    # # nic.device.unitNumber = 16
    # nic.device.uptCompatibilityEnabled = False
    # nic.device.wakeOnLanEnabled = False
    # nic.device.externalId = '100'

    # nic.device.resourceAllocation = vim.vm.device.VirtualEthernetCard.ResourceAllocation()
    # nic.device.resourceAllocation.limit = -1
    # nic.device.resourceAllocation.reservation = -1

    nic.device.backing = vim.vm.device.VirtualEthernetCard.NetworkBackingInfo()
    nic.device.backing.network = get_obj([vim.Network], network)
    nic.device.backing.deviceName = network
    nic.device.backing.useAutoDetect = False
    nic.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
    # nic.device.backing.inPassthroughMode = True
    nic.device.connectable.startConnected = True
    nic.device.connectable.allowGuestControl = True
    nic.device.wakeOnLanEnabled = False
    nic.device.allowGuestOSMtuChange = True
    # nic.device.connectable.status = 'untried'
    nic.device.sriovBacking = vim.vm.device.VirtualSriovEthernetCard.SriovBackingInfo()
    nic.device.sriovBacking.physicalFunctionBacking = vim.vm.device.VirtualPCIPassthrough.DeviceBackingInfo()
    nic.device.sriovBacking.physicalFunctionBacking.id = str(pf_data.id)
    nic.device.sriovBacking.physicalFunctionBacking.deviceId = str(pf_data.deviceId)
    # nic.device.sriovBacking.physicalFunctionBacking.systemId = str(systemid_by_pciid[pf_data.id])
    nic.device.sriovBacking.physicalFunctionBacking.vendorId = pf_data.vendorId

    nic.device.sriovBacking.virtualFunctionBacking = vim.vm.device.VirtualPCIPassthrough.DeviceBackingInfo()
    nic.device.sriovBacking.virtualFunctionBacking.id = vf_data['id']
    nic.device.sriovBacking.virtualFunctionBacking.deviceId = vf_data['deviceId']
    nic.device.sriovBacking.virtualFunctionBacking.systemId = vf_data['systemId']
    nic.device.sriovBacking.virtualFunctionBacking.vendorId = vf_data['vendorId']
    nic.device.sriovBacking.virtualFunctionBacking.deviceName = vf_data['deviceName']

    # print("######################")
    # print(nic)
    # print("######################")

    return nic


def get_vmnic_ids(driver=None, nics=None):
    """
    This function is to get physical vmnic pci id list.
    If driver is None, return all up vmnic pci id list.
    pnic which link is down:
    (vim.host.PhysicalNic) {
        dynamicType = <unset>,
        dynamicProperty = (vmodl.DynamicProperty) [],
        ...
        linkSpeed = <unset>,       <--- linkSpeed is None
        ...
    }
    @param driver: select vmnics by drivers
    @param nics: a list of string, user specified testing nics
    """
    # Select all up links
    hostObj = get_obj([vim.HostSystem], None)
    vmnics = [vmnic for vmnic in hostObj.config.network.pnic if vmnic.linkSpeed]
    if nics:
        vmnics = [vmnic for vmnic in vmnics if vmnic.device in nics]
        if not vmnics:
            print('Failed to get any available vmnics.')
    # Select vmnics by specified driver
    if driver:
        device_list = [vmnic.pci for vmnic in vmnics if vmnic.driver == driver]
    else:
        device_list = [vmnic.pci for vmnic in vmnics]
    if not device_list:
        print('Failed to get any available devices')
    print("----------------------")
    print(device_list)
    print("----------------------")


def get_active_vfs(network, vm, num):
    nic_name = get_physical_nic_by_network(network)
    active_vfs = []
    output = exe.block_run('esxcli network sriovnic vf list -n %s' % nic_name)
    # Defect DCSG01697935 - Hex PCI Address value differs from Esxi 8.2.0 to 8.3.0,
    # remove 0s followed by ':' at first occurrence
    regexp_1 = re.compile('false+\s+(\w+:\w+:\w+.\w+)')
    regexp_2 = re.compile('0+:')
    vf_ids = [regexp_2.sub('', _devid, 1) for _devid in regexp_1.findall(str(output))]
    log.info(f'SRIOVNIC VF List={vf_ids}')

    pci_passthroughs = vm.environmentBrowser.QueryConfigTarget(host=None).pciPassthrough
    systemid_by_pciid = {item.pciDevice.id: item.systemId for item in pci_passthroughs}
    vms = get_obj([vim.VirtualMachine], 'GetAll')
    attached_vfs = []
    for vm in vms:
        for device in vm.config.hardware.device:
            if type(device).__name__ == 'vim.vm.device.VirtualPCIPassthrough':
                attached_vfs.append(device.backing.id)
    log.info(f'Attached VFs List={attached_vfs}')

    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    kernel_version = get_sysinfo()['Kernel']                                        # '8.0.3'
    kernel_major_version = int(re.sub('\.', '', kernel_version)[:2], base=10)       # '80' ~ 80
    kernel_minor_version = int(re.sub('\.', '', kernel_version)[-1], base=10)       # '3' ~ 3
    for dev in host.hardware.pciDevice:
        if dev.deviceName.find('Virtual Function') != -1:
            id, bus, slot = dev.id.split(':')
            bus_id = int(bus, 16)
            slot_func_info = slot.split('.')
            slot_id = int(slot_func_info[0], 16)
            function_id = slot_func_info[1]

            if (kernel_major_version == 80 and kernel_minor_version >= 3) \
                    or (kernel_major_version > 80 and kernel_minor_version >= 0):
                # This block is to address Defect DCSG01733394 - On 8.0.3, Hex to Int conversion causing pci info
                # mismatch in sriovnic vf list
                dev_check_id = '%s:%s.%s' % (str(bus), str(slot_func_info[0]), str(function_id))
            else:
                # dev_check_id = '%s:%s.%s' %(str(dev.bus).zfill(3), str(dev.slot).zfill(2), str(dev.function))
                # Below is updated to support CTRL-38647
                dev_check_id = '%s:%s.%s' % (str(bus_id).zfill(3), str(slot_id).zfill(2), str(function_id))

            if dev_check_id in vf_ids and dev.id not in attached_vfs:
                deviceid = hex(dev.deviceId % 2 ** 16).lstrip('0x')
                systemid = systemid_by_pciid[dev.id]
                vendorid = dev.vendorId
                devicename = dev.deviceName
                active_vfs.append({'id': dev.id,
                                   'deviceId': deviceid,
                                   'systemId': systemid,
                                   'vendorId': vendorid,
                                   'deviceName': devicename})

    log.info(f'Active VFs List={active_vfs}')
    return active_vfs


def get_active_pci_pass(host_pci_id_list, vm):
    active_vfs = []
    pci_passthroughs = vm.environmentBrowser.QueryConfigTarget(host=None).pciPassthrough
    systemid_by_pciid = {item.pciDevice.id: item.systemId for item in pci_passthroughs}
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    for dev in host.hardware.pciDevice:
        if dev.deviceName.find('NetXtreme') != -1:
            id, bus, slot = dev.id.split(':')
            bus_id = bus
            slot_id = int(slot.split('.')[0], 16)
            function_id = slot.split('.')[1]
            dev_check_id = '0000:%s:%s.%s' % (str(bus_id).zfill(2), str(slot_id).zfill(2), str(function_id))
            log.info("+++++++++++")
            log.info(dev_check_id)
            log.info(host_pci_id_list)
            log.info("+++++++++++")
            if str(dev_check_id) in host_pci_id_list:
                log.info("match foud with %s" % dev_check_id)
                deviceid = hex(dev.deviceId % 2 ** 16).lstrip('0x')
                systemid = systemid_by_pciid[dev.id]
                vendorid = dev.vendorId
                devicename = dev.deviceName
                active_vfs.append({'id': dev.id,
                                   'deviceId': deviceid,
                                   'systemId': systemid,
                                   'vendorId': vendorid,
                                   'deviceName': devicename})
    log.info(active_vfs)
    return active_vfs


def create_vswitch(host_network_system, vss_name, num_ports, nic_name):
    vss_spec = vim.host.VirtualSwitch.Specification()
    vss_spec.numPorts = num_ports
    vss_spec.bridge = vim.host.VirtualSwitch.BondBridge(nicDevice=[nic_name])
    host_network_system.AddVirtualSwitch(vswitchName=vss_name, spec=vss_spec)


def create_port_group(host_network_system, pg_name, vss_name):
    port_group_spec = vim.host.PortGroup.Specification()
    port_group_spec.name = pg_name
    port_group_spec.vswitchName = vss_name

    security_policy = vim.host.NetworkPolicy.SecurityPolicy()
    security_policy.allowPromiscuous = True
    security_policy.forgedTransmits = True
    security_policy.macChanges = True

    port_group_spec.policy = vim.host.NetworkPolicy(security=security_policy)
    host_network_system.AddPortGroup(portgrp=port_group_spec)


def add_virtual_nic(host_network_system, pg_name):
    vnic_spec = vim.host.VirtualNic.Specification()
    vnic_spec.ip = vim.host.IpConfig()
    vnic_spec.ip.dhcp = True
    host_network_system.AddVirtualNic(portgroup=pg_name, nic=vnic_spec)


def get_physical_nic(nic_name):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    for pnic in host.config.network.pnic:
        if pnic.device == nic_name:
            return pnic

    return None


def get_physical_nic_by_network(network):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    for portgroup in host.config.network.portgroup:
        if portgroup.spec.name == network:
            nic = [nic for nic in portgroup.computedPolicy.nicTeaming.nicOrder.activeNic][0]
            return nic
    return None


def get_physical_nic_by_mac(mac_addr):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    for pnic in host.config.network.pnic:
        if pnic.mac.lower() == mac_addr.lower():
            return pnic

    return None


def get_virtual_nic(nic_name):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    port_group_name = 'TestNetwork-%s' % nic_name

    for vnic in host.config.network.vnic:
        if vnic.portgroup == port_group_name:
            return vnic
    return None


def get_port_group(nic_name):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')

    switch_name = 'VirtualSwitch-%s' % nic_name
    for portgroup in host.config.network.portgroup:
        if portgroup.spec.vswitchName == switch_name:
            return portgroup
    return None


def get_virtual_switch(nic_name):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    switch_name = 'VirtualSwitch-%s' % nic_name

    for vswitch in host.config.network.vswitch:
        if vswitch.name == switch_name:
            return vswitch
    return None


def create_virtual_switch(nic_name, name, mode):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    host_network_system = host.configManager.networkSystem
    switch_name = 'VirtualSwitch-%s' % nic_name
    port_group_name = name
    if not get_virtual_switch(nic_name):
        create_vswitch(host_network_system, switch_name, 100, nic_name)

    create_port_group(host_network_system, port_group_name, switch_name)

    if mode == 'hostnetwork':
        add_virtual_nic(host_network_system, port_group_name)


def delete_network(name):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    host_network_system = host.configManager.networkSystem

    for portgroup in host.config.network.portgroup:
        if portgroup.spec.name == name:
            host_network_system.RemovePortGroup(pgName=portgroup.spec.name)


def delete_iface(nic_name):
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    host_network_system = host.configManager.networkSystem

    switch_name = 'VirtualSwitch-%s' % nic_name
    port_group_name = 'TestNetwork-%s' % nic_name

    for vnic in host.config.network.vnic:
        if vnic.portgroup == port_group_name:
            host_network_system.RemoveVirtualNic(device=vnic.device)

    for portgroup in host.config.network.portgroup:
        if portgroup.spec.vswitchName == switch_name:
            host_network_system.RemovePortGroup(pgName=portgroup.spec.name)

    for vswitch in host.config.network.vswitch:
        if vswitch.name == switch_name:
            host_network_system.RemoveVirtualSwitch(vswitchName=switch_name)


def main():
    host = get_obj([vim.HostSystem], 'localhost.localdomain')
    host_network_system = host.configManager.networkSystem


# Start program
if __name__ == "__main__":
    main()
