"""
:mod:`vnic` -- vNIC module
==========================

.. module:: virt.lib.linux.network.vnic
.. moduleauthor:: Eugene Cho <echo@broadcom.com>

"""

from virt.lib.common.network import BaseVNIC


class VNIC(BaseVNIC):
    def __init__(
            self, network, mac_addr=None, mgmt_iface=False, type='adapter',
            **kwargs
    ):
        """
        Args:
            network (str): Name of network where vNIC is attached to
            mac_addr (str): MAC address for the vNIC. If None, use the random
                MAC address
            nic_type (str): Type of the vNIC. Default=virtio.
            mgmt_iface (bool) If True, this network device is a management
                network device
        """
        super(VNIC, self).__init__(network, mac_addr, mgmt_iface)
        self._tag = 'interface'
        self._type = type
        try:
            self._ens_pg = kwargs['ens_pg']
        except Exception:
            self._ens_pg = None
        self._pf_pci_id = kwargs.get('pf_pci_id', None)
        self._pci_passthrough = kwargs.get('pci_passthrough', False)

    @property
    def type(self):
        return self._type

    @property
    def ens_pg(self):
        return self._ens_pg

    @property
    def pf_pci_id(self):
        return self._pf_pci_id

    @property
    def pci_passthrough(self):
        return self._pci_passthrough
