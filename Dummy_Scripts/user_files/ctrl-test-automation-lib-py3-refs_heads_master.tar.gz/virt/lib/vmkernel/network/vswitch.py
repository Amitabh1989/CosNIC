"""
:mod:`vswitch` -- ESXi vSwitch Library
=================================================

"""

from virt.lib.core import exception
from virt.lib.core import log_handler
from virt.lib.common.network import BaseVSwitch
from virt.lib.vmkernel.core import pyvmomi
from pyVmomi import vim, vmodl

log = log_handler.get_logger(__name__)


class BaseESXiVSwitch(BaseVSwitch):
    _mode = None

    def __init__(
            self, name, iface=None, sriov=None, switch_id=None, **kwargs):
        super(BaseESXiVSwitch, self).__init__(name=name)
        self._id = switch_id
        self._iface = iface
        self._sriov = sriov

    @property
    def id(self):
        return self._id

    @property
    def iface(self):
        return self._iface

    @property
    def sriov(self):
        if self.iface:
            return self._sriov
        return False

    @classmethod
    def get_vswitch_list(cls):
        host = pyvmomi.get_obj([vim.HostSystem], 'localhost.localdomain')
        vswitch_list = host.config.network.portgroup
        if not vswitch_list:
            return []

        return [vswitch.spec.name for vswitch in vswitch_list]

    @classmethod
    def _get_mode_by_int(cls, value):
        """Return a switch mode name using the given value"""
        mapping = {0: 'vmnetwork', 1: 'hostnetwork'}
        return mapping[value]

    def _get_object(self):
        host = pyvmomi.get_obj([vim.HostSystem], 'localhost.localdomain')
        network_object = []
        for vswitch in host.config.network.portgroup:
            if vswitch.spec.name == self.name:
                network_object.append(vswitch)

        if len(network_object) == 0:
            raise exception.NotFoundException(
                'vSwitch "%s" does not exist' % self.name)

        if len(network_object) > 1:
            if self.id is None:
                raise exception.ValueException(
                    'Found more than one switch that has the name %s. Need '
                    '"switch_id" argument additionally'
                )
            network_object = [
                _no for _no in network_object if _no.Id == self.id]

        if not network_object:
            raise exception.NotFoundException(
                'vSwitch "%s" %s does not exist' % (
                    self.name, '' if self.id is None else
                    '(ID: ' + str(self.id) + ')'))

        return network_object[0]

    @classmethod
    def factory(cls, name, mode=None, switch_id=None, **kwargs):
        _network = BaseESXiVSwitch(name=name, switch_id=switch_id, **kwargs)
        if not mode:  # Expect to get an exisiting switch
            network_object = _network._get_object()
            switch_type = 0
            if len(network_object.port) > 0:
                switch_type = 1
            active_ifaces = [nic for nic in network_object.computedPolicy.nicTeaming.nicOrder.activeNic]
            standby_ifaces = [nic for nic in network_object.computedPolicy.nicTeaming.nicOrder.standbyNic]
            iface = {'active': active_ifaces, 'standby': standby_ifaces}
            for subclass in BaseESXiVSwitch._get_all_subclasses(BaseESXiVSwitch):
                if subclass.get_mode() == cls._get_mode_by_int(switch_type):
                    return subclass(name=name, switch_id=None, iface=iface, **kwargs)

            raise exception.NotFoundException('Failed to detect the vswitch mode %s' %
                                              cls._get_mode_by_int(network_object.SwitchType))

        for subclass in BaseESXiVSwitch._get_all_subclasses(BaseESXiVSwitch):
            if subclass.get_mode() == mode:
                return subclass(name=name, **kwargs)

        raise exception.ValueException('Invalid mode %s' % mode)

    def create(self):
        raise NotImplementedError

    def remove(self):
        pyvmomi.delete_network(self.name)
        log.info('"%s" is successfully removed' % self.name)


class VMNetwork(BaseESXiVSwitch):
    """Internal mode vSwitch

    Args:
        name (str): Name of vSwitch
        switch_id (str, None): Unique ID of vSwitch. If given, this will be
            used to get the existing vSwitch since Windows allows to have the
            same vSwitch name
    """

    _mode = 'vmnetwork'

    def __init__(self, name, iface, sriov=False, switch_id=None, **kwargs):
        super(VMNetwork, self).__init__(
            name=name, iface=iface, sriov=sriov, switch_id=switch_id)

    def create(self):
        pyvmomi.create_virtual_switch(self.iface, self.name, 'vmnetwork')
        log.info('"%s" is successfully created' % self.name)


class SriovNetwork(BaseESXiVSwitch):
    """SRIOV Mode vSwitch
    
    Args:
        name (str): Name of Switch
        switch_id (str, None): Unique ID of vSwitch. If given, this will be
            used to get the existing vSwitch since Windows allows to have the
            same vSwitch name
    """
                                    
    _mode = 'sriovnetwork'
                                       
    def __init__(self, name, iface, sriov=True, switch_id=None, **kwargs):
        super(SriovNetwork, self).__init__(
            name=name, iface=iface, sriov=sriov, switch_id=switch_id)
                                                            
    def create(self):
        pyvmomi.create_virtual_switch(self.iface, self.name, 'sriov')
        log.info('"%s" is successfully created' % self.name)
                    

class HostNetwork(BaseESXiVSwitch):
    """External mode vSwitch
    """
    _mode = 'hostnetwork'

    def __init__(self, name, iface, sriov=False, switch_id=None, **kwargs):
        super(HostNetwork, self).__init__(
            name=name, iface=iface, sriov=sriov, switch_id=switch_id)

    def create(self):
        pyvmomi.create_virtual_switch(self.iface, self.name, 'hostnetwork')
        log.info('"%s" is successfully created' % self.name)
