import os
import logging

from virt.lib.core import exception
from virt.lib.common.storage import BasePool
from virt.lib.vmkernel.core import pyvmomi
from pyVmomi import vim, vmodl

log = logging.getLogger(__name__)


class Pool(BasePool):
    def __init__(self, name):
        super(Pool, self).__init__(name, file_ext='vmdk', path=None)

    @property
    def path(self):
        """Return a path to the pool

        Due to Windows does not manage pools as a directory level, use the
        combination of default image directory and the given name

        This means "self._path" value will be ignored.
        """
        auto_path_datastore = os.environ.get('AUTO_PATH', None)
        datastore = pyvmomi.get_obj([vim.Datastore], name=auto_path_datastore.split('/')[3])
        # should not reach this exception though.
        if not datastore:
            raise exception.ValueException('Datastore does not exist')
        _path = os.path.join(datastore.info.url, self.name)
        return _path

    def create(self):
        if not self.path:
            raise exception.ValueException('"path" is None')

        if not os.access(self.path, 0):
            log.info('Creating a directory %s ... ' % self.path)
            os.makedirs(self.path)

        log.info('"%s" is successfully created' % self.name)

    def remove(self):
        """Delete the directory"""
        if self.path:
            log.info('Removing a directory %s ... ' % self.path)
            os.removedirs(self.path)

    @property
    def exist(self):
        return os.access(self.path, 0)
