"""
:mod:`sysinfo` -- Collect system information
============================================

.. module:: controller.lib.vmkernel.system.sysinfo
.. moduleauthor:: Sharath Shanth (sharath.shanth@broadcom.com)

"""

__version__ = "1.0.0"  # PEP 8. Also check PEP 386 for the format.
__copyright__ = "Copyright (C) 2009-2024 Broadcom Corporation"

import logging
import platform
import distro
import sys

from virt.lib.core import exception
from virt.lib.common.system import sysinfo
from pyVmomi import vim
from virt.lib.vmkernel.core import pyvmomi


log = logging.getLogger(__name__)


class SysInfo(sysinfo.BaseSysInfo):

    def __init__(self):
        super(SysInfo, self).__init__()

    @classmethod
    def get_memory(cls):
        hostprops = pyvmomi.get_properties([vim.HostSystem],
                                           ['name'], vim.HostSystem)
        host = hostprops[0]
        host_moref = host['moref']
        return int(host_moref.summary.hardware.memorySize) / 1024


    @classmethod
    def get_sysinfo(cls, driver_list=None):
        """
           This method returns ESX server type, version, build ID and update.
           :return: Dict
            Example:
                    {'apiVersion': '8.0.2.0',
                     'build': '22380479',
                     'fullName': 'VMware ESXi 8.0.2 build-22380479',
                     'licenseProductVersion': '8.0',
                     'name': 'VMware ESXi',
                     'osType': 'vmnix-x86',
                     'patchLevel': None,
                     'version': '8.0.2'
                     'Hostname': 'localhost.sddc.local',
                     'OS': 'VMkernel',
                     'Kernel': '8.0.2',
                     'Arch': '64bit',
                     'Memory': '68297269248',
                     'platform': 'VMkernel'}
        """
        host = pyvmomi.get_obj([vim.HostSystem], {})
        product = host.config.product
        ret_dict = product.__dict__
        rmv_item_list = ['dynamicType', 'dynamicProperty', 'vendor', 'localeVersion', 'localeBuild',
                         'productLineId', 'apiType', 'instanceUuid', 'licenseProductName']
        for item in rmv_item_list:
            try:
                ret_dict.__delitem__(item)
            except KeyError:
                log.warning(f'Key->[{item}] does not exist. Skipping removal of item..')

        ret_dict.update({'Hostname': platform.node(), 'OS': distro.name(), 'Kernel': platform.release(),
                         'Arch': platform.architecture()[0], 'Memory': cls.get_memory(), 'platform': platform.system()})

        if driver_list:
            ret_dict.update(cls.get_driver_info(driver_list))

        return ret_dict

