import os
import re
import netaddr
import shutil

from virt.lib.core import exception
from virt.lib.common.virtual_machine import BaseManager
from virt.lib.vmkernel.core import pyvmomi
from pyVmomi import vim, vmodl
from virt.lib.core import log_handler
from virt.lib.common.system.sysinfo import get_sysinfo

log = log_handler.get_logger(__name__)


class PyvmomiManager(BaseManager):
    @classmethod
    def create(cls, name, disk_file, vnic_list=None, cpu=1, memory=512, ostype=None, **kwargs):
        if not ostype:
            raise exception.NotFoundException('OS Type of the VM is mandatory..')

        guest_ids = {
            'windows2019-flat': 'windows2019srv_64Guest',
            'windows2022-flat': 'windows2019srv_64Guest',
            'rhel76-flat': 'rhel7_64Guest',
            'rhel83-flat': 'rhel8_64Guest',
            'rhel84-flat': 'rhel8_64Guest',
            'rhel85-flat': 'rhel8_64Guest',
            'rhel86-flat': 'rhel8_64Guest',
            'rhel90-flat': 'rhel9_64Guest',
            'rhel91-flat': 'rhel9_64Guest',
            'rhel92-flat': 'rhel9_64Guest',
            'rhel93-flat': 'rhel9_64Guest'
        }
        vmx_dict = {
            'ESXi6': 'vmx-11',
            'ESXi7': 'vmx-17',
            'ESXi8': 'vmx-20',
        }
        auto_path_datastore = os.environ.get('AUTO_PATH', None)
        datastore = pyvmomi.get_obj([vim.Datastore], name=auto_path_datastore.split('/')[3])
        content = pyvmomi.get_content()

        datacenter = content.rootFolder.childEntity[0]
        vm_folder = datacenter.vmFolder
        hosts = datacenter.hostFolder.childEntity
        resource_pool = hosts[0].resourcePool

        datastore_path = '[' + datastore.summary.name + '] vm'

        vmx_file = vim.vm.FileInfo(logDirectory=None,
                                   snapshotDirectory=None,
                                   suspendDirectory=None,
                                   vmPathName=datastore_path)
        memory_alloc = vim.ResourceAllocationInfo()
        memory_alloc.reservation = memory
        vmx_version = 'vmx-11'  # maintain minimum compatible version

        kernel_version = get_sysinfo()['version']                                  # '8.0.3'
        esx_kernel_major_version = int(kernel_version.split('.')[0], base=10)      # '8' ~ 8
        kernel_major_version = int(re.sub('\.', '', kernel_version)[:2], base=10)  # '80' ~ 80
        kernel_minor_version = int(re.sub('\.', '', kernel_version)[-1], base=10)  # '3' ~ 3

        for esx_version, vmx_ver in vmx_dict.items():
            if str(esx_kernel_major_version) in esx_version:
                if esx_kernel_major_version == 8:
                    if (kernel_major_version == 80 and kernel_minor_version >= 3) \
                            or (kernel_major_version > 80 and kernel_minor_version >= 0):  # 8.3 and above
                        vmx_version = 'vmx-21'
                    else:
                        vmx_version = vmx_ver   # ie., 'vmx-20'
                else:
                    vmx_version = vmx_ver

        if ostype.startswith('win'):
            guest_id = guest_ids.get(ostype, 'windows2019srv_64Guest')
        elif ostype.startswith('rhel'):
            guest_id = guest_ids.get(ostype, 'rhel8_64Guest')
        else:
            raise exception.NotFoundException(f'Unsupported guest id {ostype}!! \n'
                                              f'Guest ID {ostype} could not find in supported list={guest_ids}')

        # guest_id = 'windows2019srv_64Guest' if ostype.startswith('win') else 'rhel8_64Guest'
        log.debug(f"{ostype} ----- {guest_id}")

        config = vim.vm.ConfigSpec(name=name,
                                   memoryMB=memory,
                                   numCPUs=cpu,
                                   files=vmx_file,
                                   guestId=guest_id,
                                   version=vmx_version,
                                   memoryAllocation=memory_alloc,
                                   memoryReservationLockedToMax=True, )
        new_disk_kb = int(os.path.getsize(disk_file) / 1024)
        vm_file = disk_file.replace('-flat.vmdk', '')
        for extn in ['.vmx', '.vmdk', '.nvram']:
            if os.path.exists(vm_file + extn):
                os.remove(vm_file + extn)
        disk_clone_file = disk_file.replace('-flat', '-cloned')
        shutil.move(disk_file, disk_clone_file)

        task = vm_folder.CreateVM_Task(config=config, pool=resource_pool)
        pyvmomi.WaitForTasks([task])

        vm = pyvmomi.get_obj([vim.VirtualMachine], name)
        # get all disks on a VM, set unit_number to the next available
        for dev in vm.config.hardware.device:
            if isinstance(dev, vim.vm.device.VirtualIDEController):
                if dev.deviceInfo.label == 'IDE 0':
                    controller = dev

        # Add cloned hard disk image here
        devices = []
        virtual_hard_disk = vim.vm.device.VirtualDeviceSpec()
        virtual_hard_disk.fileOperation = 'create'
        virtual_hard_disk.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
        virtual_hard_disk.device = vim.vm.device.VirtualDisk()
        virtual_hard_disk.device.deviceInfo = vim.Description()
        virtual_hard_disk.device.deviceInfo.label = '%s Hard Disk' % name
        virtual_hard_disk.device.deviceInfo.summary = '%s Hard Disk' % name
        virtual_hard_disk.device.capacityInKB = new_disk_kb
        virtual_hard_disk.device.backing = vim.vm.device.VirtualDisk.FlatVer2BackingInfo()
        virtual_hard_disk.device.unitNumber = 0
        virtual_hard_disk.device.backing.thinProvisioned = False
        virtual_hard_disk.device.backing.diskMode = 'persistent'
        virtual_hard_disk.device.controllerKey = controller.key
        devices.append(virtual_hard_disk)

        vmconf = vim.vm.ConfigSpec(deviceChange=devices)
        task = vm.ReconfigVM_Task(vmconf)
        pyvmomi.WaitForTasks([task])

        shutil.move(disk_clone_file, disk_file)
        # Add NIC interfaces to VM

        vfs_count = 0
        for vnic in vnic_list:
            if vnic.type == 'sriov':
                vfs_count += 1

        vfs_available = list()
        if vfs_count > 0:
            vfs_available = pyvmomi.get_active_vfs(vnic.network, vm, vfs_count)

        devices = []

        vnic_count = 0
        for vnic in vnic_list:
            pci_pass = vnic.pci_passthrough
            vf_available = None
            if vnic.type == 'sriov':
                # Defect DCSG01697935 - Hex PCI Address value differs from Esxi8.2.0 to 8.3.0
                if vfs_available:
                    vf_available = vfs_available.pop(0)
                else:
                    raise exception.VirtError(f'ERROR: Available VFs (sriov) List is empty.')

                if not vf_available:
                    raise exception.NotFoundException(
                        'VF is not available on physical nic on which %s is created..' % vnic.network)
                if pci_pass:
                    devices.append(pyvmomi.attach_virtual_function(vf_available))
                else:
                    devices.append(pyvmomi.attach_vf(vnic.network, vf_available))
            else:
                if pci_pass:
                    vf_available = pyvmomi.get_active_pci_pass([vnic.pf_pci_id], vm).pop(0)
                    devices.append(pyvmomi.attach_virtual_function(vf_available))
                else:
                    try:
                        ens = kwargs['ens']
                    except Exception:
                        ens = False
                    if ens:
                        try:
                            ens_port = vnic.ens_pg
                        except Exception:
                            ens_port = None
                    else:
                        ens_port = None
                    if vnic_count == 0:
                        ens = False
                        ens_port = None

                    devices.append(pyvmomi.attach_virtual_adapter(vnic.network, vnic.mac_addr, ens=ens,
                                                                  ens_port=ens_port))
            vnic_count += 1

        if len(devices) > 0:
            vmconf = vim.vm.ConfigSpec(deviceChange=devices)
            task = vm.ReconfigVM_Task(vmconf)
            pyvmomi.WaitForTasks([task])

    @classmethod
    def clone_disk_image(cls, template_path, vm_name):
        template_file_path = template_path['file']
        template_name = template_path['name']

        auto_path_datastore = os.environ.get('AUTO_PATH', None)
        datastore = pyvmomi.get_obj([vim.Datastore], name=auto_path_datastore.split('/')[3])
        content = pyvmomi.get_content()
        datastore_path = '[' + datastore.summary.name + ']'

        template_info_path = template_file_path.replace('-flat.vmdk', '.vmdk')

        # The RW number is the no of 512bit vectors of the complete hard disk size..
        size = int(os.path.getsize(template_file_path) / 512)

        with open(template_info_path, 'w') as f:
            f.write('# Disk DescriptorFile\n')
            f.write('version=1\n')
            f.write('encoding="UTF-8"\n')
            f.write('CID=d386039e\n')
            f.write('parentCID=ffffffff\n')
            f.write('isNativeSnapshot="no"\n')
            f.write('createType="vmfs"\n')
            f.write('\n')
            f.write('# Extent description\n')
            f.write('RW %s VMFS "%s.vmdk"\n' % (size, template_name))
            f.write('\n')
            f.write('# The Disk Data Base\n')
            f.write('ddb.adapterType = "ide"\n')
            f.write('ddb.virtualHWVersion = "11"\n')

        template_name = template_name.replace('-flat', '')
        manager = pyvmomi.get_content().virtualDiskManager
        sourcename = '%s template/%s.vmdk' % (datastore_path, template_name)
        destName = '%s vm/%s/%s.vmdk' % (datastore_path, vm_name, vm_name)
        task = manager.CopyVirtualDisk_Task(sourceName=sourcename, destName=destName, force=True)
        pyvmomi.WaitForTasks([task])

    @classmethod
    def remove(cls, name, delete_disk=True):
        delete_disk = False
        vm = pyvmomi.get_obj([vim.VirtualMachine], name)
        if vm is None:
            raise exception.NotFoundException('No such virtual machine %s' % name)
        if format(vm.runtime.powerState) == "poweredOn":
            cls.power(name=name, oper='off')

        if not delete_disk:
            devices = []
        for dev in vm.config.hardware.device:
            if isinstance(dev, vim.vm.device.VirtualDisk):  # and dev.deviceInfo.label == hdd_label:
                virtual_hard_disk = vim.vm.device.VirtualDeviceSpec()
                virtual_hard_disk.operation = vim.vm.device.VirtualDeviceSpec.Operation.remove
                virtual_hard_disk.device = dev
                devices.append(virtual_hard_disk)
        if len(devices) > 0:
            vmconf = vim.vm.ConfigSpec(deviceChange=devices)
            task = vm.ReconfigVM_Task(vmconf)
            pyvmomi.WaitForTasks([task])

        task = vm.Destroy_Task()
        pyvmomi.WaitForTasks([task])

    @classmethod
    def update_memory(cls, name, memory):
        vm = pyvmomi.get_obj([vim.VirtualMachine], name)
        if vm is None:
            raise exception.NotFoundException('No such virtual machine %s' % name)

        if format(vm.runtime.powerState) == "poweredOn":
            cls.power(name=name, oper='off')

        spec = vim.vm.ConfigSpec()
        spec.memoryMB = memory
        memory_alloc = vim.ResourceAllocationInfo()
        memory_alloc.reservation = memory
        spec.memoryAllocation = memory_alloc

        task = vm.ReconfigVM_Task(spec=spec)
        pyvmomi.WaitForTasks([task])

    @classmethod
    def configure_autorestart(cls, name, mode):
        if mode not in ['on', 'off']:
            raise exception.ConfigException('Configure_autorestart accepts only on/off as modes...')
        modes = {'on': 'powerOn', 'off': 'powerOff'}
        method = modes[mode]

        vm = pyvmomi.get_obj([vim.VirtualMachine], name)
        if vm is None:
            raise exception.NotFoundException(
                'No such virtual machine %s' % name)

        host = pyvmomi.get_obj([vim.HostSystem], 'localhost.localdomain')

        hostdefsettings = vim.host.AutoStartManager.SystemDefaults()
        hostdefsettings.enabled = True
        hostdefsettings.startDelay = 30

        spec = host.configManager.autoStartManager.config
        spec.defaults = hostdefsettings
        auto_power_info = vim.host.AutoStartManager.AutoPowerInfo()
        auto_power_info.key = vm
        auto_power_info.startAction = method
        auto_power_info.startDelay = -1
        auto_power_info.startOrder = -1
        auto_power_info.stopAction = 'None'
        auto_power_info.stopDelay = -1
        auto_power_info.waitForHeartbeat = 'no'
        spec.powerInfo = [auto_power_info]
        host.configManager.autoStartManager.ReconfigureAutostart(spec)

    @classmethod
    def power(cls, name, oper):
        vm = pyvmomi.get_obj([vim.VirtualMachine], name)
        supported_operation = ['on', 'off', 'reboot', 'status']
        if oper not in supported_operation:
            raise exception.ValueException('invalid operation %s. choices=%s' % (oper, supported_operation))
        if oper == 'status':
            return vm.runtime.powerState # power states are poweredOn , suspended and poweredOff
        if oper == 'off':
            task = vm.PowerOff()
        elif oper == 'reboot':
            task = vm.RebootGuest()
        else:
            task = vm.PowerOn()
        try:
            pyvmomi.WaitForTasks([task])
        except Exception:
            pass

        return True

    @classmethod
    def get_vm_list(cls):
        vm_list = pyvmomi.get_obj([vim.VirtualMachine], 'GetAll')
        return [vm.summary.config.name for vm in vm_list] if vm_list else []

    @classmethod
    def get_mgmt_ip_addr(cls, vm_name, ip_network):
        mgmt_ip_network = netaddr.IPNetwork(ip_network)

        vm = pyvmomi.get_obj([vim.VirtualMachine], vm_name)
        vm_ip_list = []
        vm_guest_net = vm.guest.net
        log.debug(f"Networking data of {vm_name} is {vm_guest_net}")
        for obj in vm_guest_net:
            if len(obj.ipConfig.ipAddress) > 0:
                for t_ip in obj.ipConfig.ipAddress:
                    vm_ip_list.append(t_ip.ipAddress)
        if len(vm_ip_list) > 0:
            mgmt_ip_addr_list = []

            for ip_addr in vm_ip_list:
                log.info(ip_addr)
                log.info(netaddr.IPAddress(ip_addr) in mgmt_ip_network)
                if netaddr.IPAddress(ip_addr) in mgmt_ip_network:
                    mgmt_ip_addr_list.append(ip_addr)

            if len(mgmt_ip_addr_list) == 0:
                log.info('******************Retrying with extended subnet*********************')
                for ip_addr in vm_ip_list:
                    log.info(ip_addr)
                    log.info(ip_network)
                    ip_list = ip_addr.split('/')[0].split('.')
                    ip_list1 = ip_network.split('/')[0].split('.')
                    if ip_list[0] == ip_list1[0]:
                        if ip_list[1] == ip_list1[1]:
                            mgmt_ip_addr_list.append(ip_addr)

            if mgmt_ip_addr_list:
                if len(mgmt_ip_addr_list) > 1:
                    log.warning((
                            '%s has two management IP addresses (%s) that are belong to '
                            'the same subnet. This is likely a configuration error' % (
                                vm_name, ', '.join(mgmt_ip_addr_list)))
                    )
                log.info("Using %s as management IP for %s" % (mgmt_ip_addr_list[0], vm_name))
                return mgmt_ip_addr_list[0]
            else:
                raise exception.ValueException('No management IP addresses are discovered on %s' % vm_name)
