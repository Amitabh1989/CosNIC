from setuptools import setup, find_packages
import platform
import virt
import sys
# CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
# Install suitable packages based on the Python version we are dealing with.
PYTHON_VERSION = sys.version.split('.')[:3]
PYTHON_3_X = int(PYTHON_VERSION[0]) == 3

if platform.system() == 'Linux':
    try:
        import libvirt
    except ImportError as err:
        print ('Error: No libvirt module is found. Is libvirt and '
               'libvirt-python (or equivalent) installed?')
        sys.exit(1)

install_requires = [
    'netaddr>=0.7.5',
    'wget>=2.2',
]
# CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
# importlib module is built into Python-3.X. So, don't explicitly ask for it when on Python-3.X.
if PYTHON_3_X is False:
    install_requires.append('importlib>=1.0.3')

setup(
    name='virt',
    version=virt.get_version(),
    packages=find_packages(),
    scripts=[
        'virt/bin/virt-cli.py', 'virt/bin/virt-switch.py',
        'virt/bin/virt-ifcfg.py'],
    install_requires=install_requires,
    # CTRL-44505: Python 2.7 will reach the end of its life on January 1st, 2020.
    # Do the 2 to 3 porting when installing.
    use_2to3 = True
)
