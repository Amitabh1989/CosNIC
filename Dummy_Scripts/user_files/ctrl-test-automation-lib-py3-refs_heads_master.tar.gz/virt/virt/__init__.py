VERSION = '0.4.14'


def get_version():
    return VERSION
